(Most of the readme translated by TheEnd.)
(Credits are Google translated...)
Super Thracia Patch_20110222 LIN*LIN/XxX/gw

About this patch

I take no responsibility for any physical or mental damage this patch might cause.
Since copyright is a grey area in the case, I'm forbidding any alterations.
Since I had originally no intent of finishing this but finished it forcibly, the story develops extra-fast.
Since I have no sense of humor, there are few jokes inside. Most of the dialogue is unaltered.
I've changed the dialogues trying to the keep everyone in character, but one particular young couple wasn't so lucky. Please understand.
I didn't playtest, so I adjusted the difficulty by feeling.
Since I'm a pseudo-hacker who can't read binary, there are times when I can't fix a bug even though it has been confirmed.
I order to ensure emulator and save data compatibility, I haven't expanded the rom.
I've taken care to make the mugshots not look odd compared to FE5's usual face graphics, but because of that many characters don't look like themselves.
I tried to make the story consistent, but please report if you see typos, incomplete dialogues or contradictory parts.
Since I suppose this is going to play via emulator, my aim is to make it beatable in QLQS.

Credits:
 Applicable patch and materials used, tools * Face graphics have things you can use (revise) original data by modifying it
� If it is possible, King Bloom will kill with my hands Mr. Patch author
 Fire Emblem Thracia 776 If King Can Bloom kill me with my hands patch
 Annex (structure etc.)
� Mr. ajk
 FE 4 L - 2 +
 FE 45 G
 In-site document
Mr. Min
 fe45_comp.exe
 FE 5 map editor auxiliary tool
 Fire Emblem Thracia 776 Range normalization ver1.4
� 542 * ruo0tlxqPQ
 Class change routine added patch v2a
 Fire Emblem Thracia 776 Effect normalization patch
� 316 * 316g Mr. Gitpsw
 Holy Warfare - Thracia Face Gravity Collection
 Aless
 Aideen (reform)
 Ethlin (reform)
 Oifaye (revised)
 Kurth (reform)
 Shanan
 Deirdre
 Tinny (reform)
 Tiltyu (reform)
 Patty
 Faval
 Fee (reform)
 Julia (reform)
 Lachesis (reform)
 Lana
 Seven
 Young Blume (revised)
 Sheeda
 Est (reform)
� 14-852 * jLN7WjlUs6
 GBA character transplant ver 2.0
 Ave (reform)
 Ishmeer (reform)
 Glen (reform)
 Keselda (reform)
 Gist (reform)
 Natasha (reform)
 Novala (reform)
 Rachel (reform)
 Roussea (reform)
 Roro (reform)
 Kleine (reform)
� Holy war - face slur for Thracia (Leaf et al) Mr. author
 Leaf
 Altenna (revised)
� (0 '~ `)/ - = * INF65wm8tQ
 Item icon SUNFLAME
 Item Icon Dime Thunder
 Real Battle Weapons Graub�n�ck

� Others
 Behemoth

 We would like to express our sincere gratitude to each patch, material used, tool creator.


System changes

Level and stats cap at 40 (Build at 25)
Class change to 2nd class possible at level 25+
Class change to 3rd class possible at level 35+
Level doesn't change after class change
Promoted mounted units can move inside buildings (mov cost 2)
'Wrath' skill: works like in FE4
'Astra' skill: 3x consecutive attacks, skl% activation
'Luna' skill: halves defense, def% activation
'Sol' skill: mag% activation
'Prayer' skill: luk% activation
'Big Shield' skill: bld% activation
Devil Axe's self-attack rate: (50-luk)%
Weapon triangle effect: +/- 30
Minimum damage: 1 (if attack = defense, 0)
Known bugs

Arena (can't use direct attack weapons, no opponents above lv20, etc.)
Berserked units take too long to act?
Novistador's real animation might be odd.
Interference in various magic effects.
Purge's magic effect might be odd.
Ekard = Polygon Flash.
A part of the map's battle graphics disappears (since I couldn't keep the map data intact, I had to do this).
Map, chapter title screen and dialogues' palettes change midway.
You can get the item at the end of chapter 18 even if you kill the Lenster soldiers.
Asvel keeps doing his job as strategist even if he dies or gets captured.
Harsh difficulty.
Pixel art is rough.