The overall idea is to make the start of the game easier and the end of the game harder. This is mainly done by increasing the power of the weapon triangle and giving additional weapon options to classes even at tier 1. The player should have more control over the flow of the game thanks to this change. Certain units have also received buffs and most classes have been given an offensive option.


Gameplay Edits
-Effective damage has been reduced from *3 weapon might, to *2. To compensate, all Legendary weapons have been given +5 durability and all weapons that deal effective damage (including bows) have been given +3 might.
-Nomads and Troubadour lines can be inflicted with effective damage.

-Support growths have been increased by 1 for every character pair.

-Physical Triangle has been buffed to +- 20% hit

-Magic triangle has been buffed, giving a +60% hit and +10 might on WTA and -30% hit and -3 might on WTD. Given how Anima enemies are the most common, this change helps Shaman's and Druid's the most.

-All promotion items have been replaced by Master Seals which work on any class, including Roy.
--Replacing the promotion items in the Secret Shop are other items including new weapons.

-Most enemy phase reinforcements moved to player phase. Pirates, bandits and thieves are the general exceptions as they don't attack the player immediately (or even at all sometimes).

-Battle Preparations available from Chapter 3 onwards.

Character Edits
-New items added to the inventories either because of new weapon ranks or because they're items new to the game.

-Guinevere has been added to the main campaign, joining at the start of Chapter 14.

-Roy's bases have been boosted, +1 str, +3 skl, +1 def, +1 spd, and +5 res. His Res growth rate has also been increased to 45%
-Roy can promote with a Master Seal.
-Roy can remotely access the Supply (players can't access it from him though, for some reason).

-Gonzales is recruited at Lv 7 regardless of route.
-Bors has been given a +3 boost to skill so he actually stands a chance of hitting something in Chapter 1.
-Sophia's bases have been boosted. +2 mag, +4 skill, +1 sped, +1 def. She also has +5% growths.
-Wolt +1 pow, +1 skl, +1 spd,+2 def and +3 luk
-Fir +2 spd
-Zealot and Trek, def+2, spd + 1
-Clarine +2 mag (though really it's so she can use swords better).
-Lilina HP+3, Def+2 and +1 Spd (she needs it to survive against the more powerful bows in her recruitment chapter).
-Wendy, Str+2, Def+1, Res+4, Skl+4 HP+4, she also starts with B Rank Axes and +5% to all growths.
-Oujay +5% to all growths.
-Cath comes prepromoted as a Rogue.
-Yodel's level reduced by 1 so you can level him up. Growths have also been doubled. He doesn't need it, but I think this might make crazy exp worried players like myself more willing to use him.

-Hugh starts with A rank anima magic.
-Juno and Dayan now have A rank swords from base.
-Oujay's sword rank boosted to C.

-Lalum can use Staves (Sprite Credit Vilkalizer)
-Elphin can use Light Magic (sprite Credit Omni)
-Merlinus can use Bows.

-The +3 might on bows should help characters like Wolt, but to stop Shin being OTT, he's received a -2 strength nerf to compensate (he'll still probably be the best bow user though).

Class Edits
-Knights can now use Axes and Generals can use Bows. Credit for the animations goes to the Blind Archer.
-Knights have 5 move like infantry, they do not gain move on promotion to General.
-Knights get +1 def and +2 HP to help them do their job better.

-Priests and Sisters can wield light magic at tier 1.

-All sages can wield Light Magic (so Guinevere isn't hacking the game), Druids and Shamans can use Anima magic and Bishops can use Dark Magic (which yes, I admit is a little weird). This is done because I've made the magic triangle much more important, so having more control over it is necessary.

-Troubadours and Valkyries can use Swords (this messes up the animation a bit, but generally seems to work fine).

-Thieves can promote to Rogues.

-Pegasus Knights can use Swords and Falco Knights can use Staves (animation credit ShadowOfChaos).

-Dragon Riders and Dragon Lords can use axes (animation credit The Blind Archer).

Weapon Edits
-Divine Stone is now 1-2 range.
-Exaccus is obtained on Zephiel's defeat. Any sword user can wield it. It has gained the dragon slaying effect.
-Al's Sword has been replaced by the Fire Sword. A Roy exclusive weapon that is two range.
-Gant's Lance has been renamed Fly Catcher and deals bonus damage to fliers.
-Guinevere gets Thani as a prf weapon.
-Glass Axe has been added as an item to encourage axe use.
-Wing Spear has been added as a Pegasus/Falcon Knight exclusive weapon.
-Firesweep Sword has been added. Works like in Heroes, ignores counter attacks.
-Long Bows can only be used by Archers and Snipers. Their durability has also been increased by 10.
-Spear crit chance removed. A)5% is more likely to screw over the player than help them, and B) Because the Tomahawk doesn't have one.
-Apocalypse has a Nosferateau effect, to balance the insane weight it has compared to Dark Mage's con.
-Hammer gets a 20% boost in hit since it's use is less niche now and 45% is too low even by Binding Blade standards.
-Luna Bow comes from Shadows of Valentia. Although this version works like the Luna tome, dropping HP to 1. It's hit is excellent, but it only has three uses.

Chapter Edits
-As the game progresses, enemies are given more weapons to give them more weapon triangle control.

-Manaketes now have 1-2 range.

-With the exception of Murgleiss, the Gaiden bosses wield the Holy Weapons they're guarding, because why not, they already have the weapon ranks for it.

-Rude has been moved down one tile so he's not sitting on the throne and can be attacked from melee range by more than one unit per turn (because taking him down on the throne with the nerfed effective damage is monstrous).

-Some enemy levels reduced in Chapter 7. NPCs also appear one turn later to help their survivability.

-Ally reinforcements appear one turn earlier in Chapter 8. An alternate path is also available to aid progression through the level.

-Aesthetic change only, but Aine has been renamed Manakete and his portrait is used for all Manaketes. Because he's no more special than any of the others in terms of plot. Some dragons, including Aine, can also attack at 1-2 range.

-Percival hangs around one turn longer in Chapter 13, so recruiting him then is in some way conceivable for the average player.

-Douglas has been given an Elixir to help him survive. Narcian also moves to make for a more interesting boss battle. He has buffed luck stat to compensate not being on a throne. A Manakete sits on the throne in his place. There have been some slight map changes to support this.

-Pereth has been given a massive HP boost to make him harder to warp skip (I still warp skip him anyway because screw doing that chapter legitimately).

-Guinevere gets battle quotes with the three mage generals. Zephiel has also been given some personal battle quotes, because he sorely needed them. Yahn has some too! Guess which characters trigger them.

-Yahn has capped speed.

-Idoun's speed has been buffed considerably so she can't be doubled. Her defence has also been nerfed so more units can damage her.
-Idoun has two weapons, both have equal power and a Nosferateau effect, but one targets res and the other targets def. When targeting res she has a defense boost and when targeting defense she has a res boost.
-Idoun aggros from the first turn. Roy's starting position in the battle has also changed.


Known Issues
-The opening demo causes a glitch that freezes the game. This has been circumnavigated by bringing the player directly to the main menu on loading the rom.
-The Axe Wyvern Lord sprite doesn't come with a Hand Axe animation, so they throw a javelin.
-Sprites for units that mix strength and magic get confused when attacking at one range. Checking weapon ranks also can't be done for physical wepaons on hybrids.
-Title Card for Ilia Chapter 17 is messed up for some reason.
-To implement the rogue, I had to override the female thief class, so Cath must us the male thief class. This is actually a benefit for her as male thieves have higher bases. She does lose her nice ponytail though.
-Guinevere's ending freezes the game. I would have written one for her, but for some reason the ending list ends at Zeiss and extending it gives every character after him Roy's ending.
-Guievere can support, but I never bothered to write unique convos for her. If you want to write some for me than go for it.
