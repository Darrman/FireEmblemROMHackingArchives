Apply patch to clean JP rom.

Changelog:
Myrmidon -> sword knight, promotes to Blade knight
Mercenary -> sword knight, promotes to gold knight
Cavalier -> Social Knight
Soldier -> lance knight 
Fighter/Brigand -> Axe knight 
Fighters promote to Silver Knight
Brigands/Pirates promote to Great Knight
Roy -> starts with a horse, gets a wyvern
Knight -> start as lance knight, promote to iron knight
Archers -> start as bow knight, promote to arch knight
Cleric/Priest -> start as troubadour, promote to strategist
Troubadour -> now promotes to Mage Knight
Thief -> Grassrunner
Mage -> Mage Rider, promotes to Mage Knight 
Shaman -> Dark Rider, promotes to Dark Knight
Bard -> Malig Bard
Dancer -> Sky Dancer
Manaketes get 7 move
Merlinus kicked up to 7 move

Credits:
ketchuplover for concept
ltranc for palettes

graphics to flasuban, RobertFPY, SALVAGED, Nuramon, MeatOfJustice, FPzero, Pikmin1211, Eldritch Abomination, L95, DerTheVaporeon, Aruka, Yggdra, Maiser6, eCut, Kao, Aurora, Skitty, Primefusion, Orihara_Saki, GabrielKnight, Lisandra_Brave, TBA, Feaw, Genocike, shadowofchaos, Sme, Shtick, Blue Druid, Alfred Kamon, SurfingKyogre, Jj09, Teraspark, Kenpuhu, Seal, seergiioo, St jack, Rasdel, Tordo45, Agro, HyperGammaSpaces, Siuloir and anyone else I missed



















