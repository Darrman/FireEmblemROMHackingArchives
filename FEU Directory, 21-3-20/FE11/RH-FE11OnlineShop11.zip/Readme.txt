This patch integrates exclusive items from the now-defunct Online Shop into normal gameplay.

Why does that matter? Well, I'll let the wiki explain it:
"Along with most Nintendo Wi-Fi Connection services, the online shops in both Shadow Dragon and New Mystery of the Emblem permanently closed on May 20th, 2014. For Shadow Dragon, this had the effect of rendering the Elysian Whip (and in turn the Falcoknight class) and three of the Brave weapons as essentially unused content... for new save files created after that date on original cartridges."

Now, all those items are back in the game as droppable items (or in some cases, in the starting inventory of certain characters). A list of what went where:

Chapter 7 - generic archer has droppable Longbow
Chapter 9 - generic pirate has droppable Poleax
Chapter 11 - pegasus knight has Elysian Whip
Chapter 13 - boss has Master Seal
Chapter 14 - boss has Master Seal
Chapter 15 - generic dracoknight has Elysian Whip
Chapter 18 - Sternlin (the boss) has Brave Lance
Chapter 19 - generic hero that starts near Tiki has Brave Sword; Tiki has Elysian Whip (droppable, if you want to kill her to access 24x)
Chapter 20 - Lorenz has Brave Bow (not droppable; must recruit him to get it)
Chapter 20x - Ymir starts with Brave Axe (not droppable; must recruit him to get it)
Chapter 6x - Athena starts with Wo Dao 

Be warned, these enemies will use these new items against you until you kill them and claim the weapons for your own. However, depending on your difficulty (primarily if you're playing on Normal), two or three of the above enemies will lack the weapon rank required to use the new items, although they will still drop them as normal. On higher difficulties, all bets are off - everybody is skilled enough to use everything in their new arsenal against you. 

In addition, Falcoknights have been updated to use their FE12 stats; previously, as the class was not in the original FE1, the developers intended it mostly as an easter egg and did not seem to balance it. As a result, the Falcoknight had absolutely no advantages over the Dracoknight. Now, the Falcoknight has higher Speed, Skill, and a higher maximum Speed, but lower Strength than the Dracoknight, in line with their appearance in FE12.

OnlineItemsInGame.XDELTA incorporates the Updated Gaiden Requirements Removal Patch.

OnlineItemsWithHardPrologue.XDELTA incorporates BOTH the Updated Gaiden Requirements Removal Patch and the Prologue in Hard Modes Patch.

USE ONLY ONE PATCH, NOT BOTH.

This was made using the US version of FE11, so you should use an .nds file from that region.



Installation:

1. If you have not already, download the Delta Patcher utility here: https://www.romhacking.net/utilities/704/

2. Obtain an unmodified ROM of FE11. I cannot help you do this.

3. Extract DeltaPatcherLite.exe, your unmodified .nds file of FE11, and EITHER OnlineItemsInGame.xdelta OR OnlineItemsWithHardPrologue.xdelta to the same folder. DO NOT USE BOTH .xdelta FILES; CHOOSE ONLY ONE. The difference is explained above.

4. Open DeltaPatcherLite.exe.

5. Click the "Open" button for the "Original file" box and select the unmodified .nds file of FE11.

6. Click the "Open" button for the "XDelta patch" box and select EITHER OnlineItemsInGame.xdelta OR OnlineItemsWithHardPrologue.xdelta.

7. Click the "Apply Patch" button. Users with older PCs may have to wait a few moments.

8. Your previously unmodified file, which you selected in step 5 as the "Original file", is the patched ROM you should now use. 



Your original ROM's checksums should be:

Original CRC32: 4CE55236
Original MD5: 5B7A037DFF5A904078404922642A01E8
Original SHA-1: 5174FBAB0C159CE247CCF133A8103B79FAE1435F

If you don't know what those are, this website can explain:
http://onlinemd5.com/



Patched values for OnlineItemsInGame.xdelta:

Patched MD5       EDF64863CE7C86D652B3752F4E2D8922        
Patched SHA-1     33E18A412557D5C2F967C20F9E5E7E9D4C92A4D6
Patched CRC32     7AC6FA51



Patched values for OnlineItemsWithHardPrologue.xdelta:

Patched MD5      20D44513267CB8BBD4C19F337922F341        
Patched SHA-1    D07060A0A878602B1210CAEE4C0C62BE3130BA92
Patched CRC32    FE856158   