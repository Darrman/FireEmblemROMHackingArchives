Eh... I'm bad writing .w. But here I have this... it is the readme... below I will put the credits of the patches, sprites and that (although surely I will forget someone so please let me know), and also the state of development... The game is in Spanish and English, but I no tested yet the English patch so can have graphical errors (I working in that), I hope and enjoy playing it.
I am sure that the sprites I took were free to use, but in case I have been wrong with some, please also notify me to remove it, because I would not like to use something if the owner does not want.
The story to a certain extent (chapter 23, WIP) is based on certain stories or anecdotes of the facebook group on which it is based, and the rest is a way in which we wanted to finish the story.
The patch is for a FE7 USA rom


////////////Chapter unlocking order
Civil War!Kokue -> Banrigth
Civil War!Luis Blaggi -> Loli-Con-Quest
Civil War!Berenice -> Do it for Her
Civil War!Angel -> Pirate Honor
Civil War!Yayo -> Hide The Alcohol
Civil War!Omega -> All Hail Almeja
(All Hail Almeja, Hide The Alcohol, Pirate Honor, Do it for Her, Loli-Con-Quest & Banrigth) -> (Im You But Stronger, Ban Tendency, Uragirimono & Your Waifu is shit) -> We Are Number One but is a Fire Emblem Hackrom -> AW War -> Falsos Amigos Pt.1

////////////Unlockable characters
(All Hail Almeja, Hide The Alcohol, Pirate Honor, Do it for Her, Loli-Con-Quest or Banrigth) without lose units -> Desbloquea a Angel-ko (Only usable upon Your Waifu is Shit)
(All Hail Almeja, Hide The Alcohol, Pirate Honor, Do it for Her, Loli-Con-Quest & Banrigth) without lose units -> Desbloquear a Mart�n (Only usable upon Your Waifu is Shit)
(Im You But Stronger, Ban Tendency, Uragirimono & Your Waifu is shit) without lose units -> Desbloquear a Nims (Only usable upon Your Waifu is Shit)

//////////////Development
Actual version: v.0.1.1
Chapters: 19/31
Chapters with dialogues: 18/32
Music Themes: 86
CGs: 17

~21/06/2017~
-Chapters added
Civil War
Banrigth
Loli-Con-Quest
Do It For Her
Hide The Alcohol
Pirate Honor
All Hail Almeja,
Im You But Stronger 
Ban Tendency
Uragirimono
Your Waifu Is Shit
We Are Number One But Is A Fire Emblem Hackrom
AW War
Falsos Amigos/False Friends pt.1

~17/07/2017~
-Rebalance
Civil War!Luis Blaggi
-Event modification
Banrigth (Stairs updated)
Loli-Con-Quest (Objetive modificated)
-Graphics
New item icons added
Stat Screen updated
-Holy Blood System overwriting affinities and supports bonus updated
-Text updating in spanish version and 6 chapters with texts in english version

~20/07/2017~
Added to the folder a full save, you can play any programmed chapter, in case you want to test but not play all or another motive

~24/07/2017~
-Give Up and Skip commands added, for change chapter and skip a alredy completed chapter
-More Spanish and English Translation
-SFX to Deni/Zack Animation
-Stairs at Banrigth, and escape in Loli-Con-Quest and Im You but stronger have now a Unit Command

~29/09/2017~
-Spanish and English texts updated
-Some minor bugs correcteds

//////////////Credits
Special thanks to Blazer because The last promise was the first hack I met and thanks to that I thought maybe I could try something and yo Arch because the mechanics of talking to characters in a "menu" to access to chapters with a style like Awakening/Fates DLC is the fundamental base and would lie if I said that I was not inspired by Elibean Nigths

////Tutorials
Arch - Event Assembler Tutorial
ShadowofChaos & Jubby - Battle Frames Tutorial
Lord Solrack - Some tutoriales in FEWoD

////Programs
Nintenlord - GBAGE & Event Assembler
Hextator - FEditor
Mikey_Seregon - Character Banner and Forcer Modules

////Patches
Blazer - Music Instrument Patch
jj12357 - Arbitrary number weapon types
Hextator - Melee and Magic Fix
CT075 - Character Specific Battle Themes
MisakaMikoto - Accuracy patches

////Sprites
Lord Glenn - Item icons
Trueblade1990 - Baron, Emperor & Master Knigth
shadowofchaos - Falconknigth with staves
Spud, Princess Kilvas/Great Mizuti/Ninja Pichu(Sprite Sheet) and Blue Druid - Wyvern Lord With Bows
Hextator, ShadowOfChaos - Lyn with Durandal
oracle_of_fire - Ninian with staves
oracle_of_fire and Khrene Cleaver - Ike Ranger
Primefusion - Paladin with staves and magic
Skitty of Time and Feaw - Ranger with Lances
Lt. Smirks - Shulk sprite

////Routines
MarkyJoe1990 - Check if all Allied Units Dead

////Other
Aura Wolf - Aura Wolf's free-to-use maps


/////Contact information
FB: https://www.facebook.com/Kokue.uwu
E-Mail: Matonmxx@gmail.com


