README
-------

Hey there!

This is the patch folder for FE Foreboding Dusk. To patch, use NUPS (reference "How to Patch", don't come crying to me if it doesn't work the way you want it to). 

To see what's included in this version, look inside "Version Info".

Before you report bugs, please check the Documentation folder and look at the list of known bugs.

Also check the Documentation folder for a list of credits, though until a full version is released the credits will be generalized.

Finally, I hope you enjoy!

-Crimson