Hello! 

Thank you for downloading Fire Emblem Poop! I hope you will enjoy the game!

This package comes with:
~The patch for Fire Emblem Poop
~An album containing all of the songs used (downloaded separately)
~This README
~A credit text document
~4 seperate growth-rate documents
~Official Fire Emblem Poop Artwork

Notes about the game:
-There are some events that will "glitch" up a bit if you start-skip the
cutscene. However, they will not have an effect on events that take
place after.

*The patch
-Use a vanilla FE7U ROM to patch the game.
-As you have probably heard several times, I cannot help you obtain a ROM.

*The Album
-The album contained is an iTunes ready album with 52 songs.
-If you have already opened the folder,
you might have noticed a folder labeled
'Secret'. This folder contains songs that
may spoil some contents of the game. I
recommend that you wait until these songs
are unlocked in the sound room before 
opening the folder.

*The credit document.
-This document contains the credits of the PME
-Like the 'Secret' folder, I recommend until
after finishing the game to read this.

NOTICE! -- If you see any assets that belong to you
that are not credited, please contact me ASAP.

*The growth-rate documents
-These documents contain all of the growth rates of
units in the game.
-I recommend advancing through the documents
by chapter on your first playthrough. This way
you are not spoiled as to which units are 
recruitable.