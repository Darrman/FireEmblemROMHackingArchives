FIRE EMBLEM: BARHARA REVISITED V1.0
This is an FE7 romhack, so apply it to an FE7 rom. An American FE7 rom. Don't stick it on FE8 or you'll get a buggy mess of brick.

Version History:
1.0: What you're playing right now. Everyone's mouth moves!
0.9: What Ghast played. Has more typos and portrait errors, etc...

Alright, credits time.

The text from the start of the dialogue to "ALVIS YOU DASTARD" is taken from the Project Naga script, so credits to bookofholsety. Same with death quotes.

I took the base mugs off the Serenes FE4 character page.

The Meteor animation was made by Blazer and Jubby.

The Sword Armour was made by The Blind Archer.

(The Magic and Staff animations by Primefusion are hanging around in the rom, but they are unused, since the F-Paladin doesn't feel like letting genderswaps happening.)

All the guys in the FEU Discord also get credit for dealing with my FE4 jokes and helping me with my bugs and the like.

