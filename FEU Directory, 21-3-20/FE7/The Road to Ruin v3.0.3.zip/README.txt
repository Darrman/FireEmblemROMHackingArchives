Fire Emblem: Road to Ruin
Version: v3.0.2
Author: Primefusion

This is a non-profit (i.e. free), fan-created mod. If you paid money for this, you should ask for it back!

To play simply follow these steps:

1) Open NUPS
2) Select a clean FE7 ROM as well as The Road to Ruin patch
3) Apply the patch
4) Play and enjoy!			

There are 23 chapters total.
The final chapter is chapter 20.
			
Known Glitches/Weird Stuff:
1) When resuming the game during Ch 4x or 6x the cursor disappears and becomes unusable.
	- This is the only game-breaking glitch I know of and it stems from the nature of Ch 4x/6x. 
	- If you press your L-button hot-key, the cursor will snap to Aaron, fixing the problem.

2) When trading new items such as poleaxes and greatlances, the icon becomes garbage (Also happens when interacting with Lucile or shops).
	- This is a temporary graphics glitch that seems to correct itself and I'm not worried about it at the moment. 
	- If it becomes a persistent problem, report it.
	  
3) The fortune menu can be accessed on Ch. 5 before Raizen has ever been encountered.
	- I have not looked into disabling this yet. It's likely hardcoded shenanigans. Also, I have not adjusted rankings for each chapter
	of TRTR, so the star requirements are all over the place.

4) In chapters 14, 15, and 16, the cursor may become stuck just offscreen when "View Map" is selected from the Preparation Screen. 
	Simply move the cursor onto the map or press your unit cycle key to un-stick it.
