GAMEPLAY TIPS
- Capturing/stealing is helpful, but not needed to win the game
- You only have 100 convoy slots. Don't go too crazy with getting stuff

GAMEPLAY CHANGES
- All classes have one promotion
- Armors and cavalry are mono-weapon, with Generals getting all weapons + bows
- The game uses 1RN, with a min hit of 1 and max of 99, like FE5
- The anima triangle is present
- Master knights are solo physical, while barons are solo magic
- Supports are planned to be bond supports

NOTIFYING ME
DM me on Discord or FEUniverse if you need to send me
a message about something.

My discord is MrGreen3339 (HP Drain) #4725