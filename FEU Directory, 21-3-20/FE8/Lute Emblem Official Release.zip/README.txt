Apply this patch to a regular US Sacred Stones ROM file with a UPS patcher, and it should run fine with any GBA emulator.

Enjoy!