Welcome to Justice & Pride!
This readme is meant to share important
information about the game with you.
Let's get into it, shall we?


1. New Mechanics
There are plenty of QoL mechanics in the game,
thanks to the many patches made by the community.
In addition, the skill system is present,
albeit rebalanced so not everyone is running
around with 6 skills. There are also escape
maps.

2. Music
Many different songs appear from
many different games. The whole
soundroom is unlocked, so listen
to your favorites!

3. Gaiden Chapters
Gaiden chapters do appear
in this hack. Here's the
unlock conditions.
4x - Kara is alive
9x - The green commander survives Ch. 9
15x - Win in 25 turns or less
20x - Defeat Ricardo in less than 25 turns
25x - Visit all houses without any getting destroyed

4. Postgame
There is a postgame planned for development.
It contains 8 trial maps with new units to get.
In release 1, it is not yet complete, but it
is accessible so you can keep your save when
it is released

5. Classes
Some classes have their promotions
changed.
- Mercenary gets Spartan instead of Ranger
- Female Shaman gets Witch instead of Sorcerer (renamed Druid)\
- Pegasus Knight gets Harrier instead of Malig Knight (replacement for Wyvern Knights)
New classes include Spartan, Witch, Malig Knight, and Harrier

6. Credits
If there is anything I credited
wrong or forgot to credit, please
let me know!

7. Modifying the Hack
You are free to modify the hack
for things like special modes or PMEs.
However, do not steal resources. Many of
the assets here are from F2U sources, but
stuff like my custom splices are not
for free use without permission.

8. Bugs
Report any bugs to me.
There is a bug in Ch. 17 where
one of the souther brigands vanishes
and one of the nearby cavaliers takes
his place, but I'm not sure what's
causing it or how to fix it.

9. Mountains
Yes I know the mountains look
weird. Those are annoying
to do.

10. Autosaves
The game does not autosave when
closing the emulator or resetting/changing
ROMs. This is because you could abuse
it with the RNGRandomizer to reset a death
over and over again until you dodged.
Suspend still works, however.