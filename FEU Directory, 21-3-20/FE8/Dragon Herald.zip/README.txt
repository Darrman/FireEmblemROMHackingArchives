Fire Emblem: The Dragon Herald

1. Introduction
2. Plot
3. Changes from Sacred Stones
4. Credits
5. Appendix
6. Contact Me

1. Introduction

Fire Emblem: The Dragon Herald is a fangame made using FEBuilder with Sacred Stones as the base game. It is meant to be a fully FEGBA-style game, meaning that the admittedly very cool skill system is completely omitted, and the FE8 skills are used instead. The Dragon Herald was a personal exercise in talentlessness, with two goals: to be completed with as little personal skill on the part of the developer as possible by using community resources for everything, and to be entirely complete upon release. Theoretically anyone could have made this game, which is a testament to the great strides in FEGBA hacking made by the community.

2. Plot

In the continent of Orsia, there exist three nations following a long war: Folga, a northern nation with a focus on magical research, Raudel, an empire that has recently acquired new territory along the Folga/Raudel border, and Verius, a theocracy that generally maintains neutrality in continental conflicts. Verius also serves as the central hub of the dragon faith, the only widespread religion in Orsia. The story follows You, a figure in the dragon faith tasked with delivering the word of the dragons to an annual international summit meant to prevent further war from breaking out.

3. Changes from Sacred Stones

There's a few.

Weapon Changes
- Standard Bows (Iron, Steel, Silver) are 2-3 range.
- Iron Bows require D bows to use, with Short Bows being the only E-rank bow.
- Magic Swords do not use half Str at range, but are weaker to compensate.
- Magic Swords also give out WEXP.
- Lances and Axes are largely unchanged, probably.
- Swordslayer effectiveness extended to Rangers and the main lord's classes.
- Anima/Light/Dark tomes have adjusted Wt/Mt to create roughly the same balance as Lances/Swords/Axes.
- Light/Dark A and B rank tomes shuffled around a bit with new effects.
- Staff EXP changed around. Example: Heal grants 15 EXP.
- Fortify has been removed. Sorry.

Class Changes
- Mounted casters do not have access to staves, with one obvious exception.
- Great Knight updated to 7 Mov.
- General (renamed to Vanguard) updated to 6 Mov and can use bows.
- Soldier is a real class (enemy growth Str/Skl focus).
- Archer has enemy growth Skl focus with lowered Spd.
- Berserker loses +Crit, gain low % chance of halving damage against them.
- Assassin gains Bows and no longer has lethality.
- Only Snipers can use ballistae.
- Falcoknights use Lances and Staves.
- Wyverns are Axe-based like newer games.
- Wyvern Lord has armor, removing Bow and adding Armorslaying vulnerability. Has 7 Mov.
- Wyvern Knight loses pierce but has 9 Mov.
- A lot of promotion switches, have fun figuring those out. Promotion gains also altered.
- Some new classes as well.

General Changes
- Game is Hard Mode-locked. It's probably not too hard.
- No branches.
- No world map.
- Some units are considered Lord units and cause a Game Over. These include You and Taiga.

4. Credits (possible spoilers)

There's a lot. Names used are as they appear in this hack. Please reach out to me if I have miscredited anything or if you want me to include more specific credits for anything such as the original class/character name given in the repository.

Story - Me (BigMood)

Coding Stuff - I probably missed a ton here but I'll update as requested

FEBuilder, the Savior of the Century's Beginning - 7743
A ton of associated patches that I can't even find all the ones I used - 7743
FEBuilder patch compatability - 7743
Chapter titles to text - circleseverywhere
Limit weapon rank display - jjl2357, Blademaster, Hextator, Tequila
Drumfix - circleseverywhere
Remove enemy control glitch - Brendor
Anti-huffman - Hextator
Custom Spell Animation - Hextor
Melee and Magic Menu Fix - Hextator, Tequila
Fix_lz77decompress - Tequila
Staff Exp - Tequila
Unit Action Rework - Stan
Map Danger Zone - circleseverywhere

Classes

Brigand (Magic Axe) - Blue Druid
Archer (Female) - George Reds
Cleric - Alusq
Herald - Teraspark
Dancer - Circleseverywhere, Kao
Bonewalker (Axe) - MrNight, RenOokami
Wight (Axe) - Teraspark
Sniper (Female) - Aruka, Yggdra
Falcoknight (Staff) - ShadowOfChaos
Sage (Female) - Greentea, DerTheVaporeon
Hero (Female) - St jack
Rogue (Female) - Temp, Black Mage, Wan
Swordmaster (Special) - Greentea, DerTheVaporeon
Archsage - MrNight, DerTheVaporeon (Map Sprites: Unknown)
Assassin (Male) - Glenwing, SD9K
Assassin (Female) - Keks_Krebs, Beccarte, SD9K
Blighted (Male) - Blazer
Blighted (Female) - Pikmin1211
Captain - Nuramon (Map Sprites: Dellhonne)
Cardinal - Luerock, Pikmin1211 (Map Sprites: Jiege, TLP)
Crusader (Female) - Leo_link, Iscaneus (Map Sprites: DerTheVaporeon)
Crusader (Male) - DerTheVaporeon, Pikmin1211
Dark Rider - Pikmin1211, Nuramon, DerTheVaporeon, Jj09
Disciple (Special) - MrNight, Seal, Sacred War (Map Sprites: Teraspark)
Disciple (Female) - Eldritch Abomination
Vanguard - TBA, Nuramon, GabrielKnight
Halberdier - Aruka, Yggdra (Map Sprites: Unknown)
Mercenary (Female) - TBA (Map Sprites: Agro)
Prophet - Aruka, Yggdra, Seal, Sacred War
Shadeknight - TBA, shadowofchaos (Map Sprites: L95)
Spellblade - St jack (Map Sprites: Unknown)
Merchant - Spud
Trickster - Aruka, Yggdra
Warrior (Female) - FEGirls
Wyvern Knight - Feaw, St jack (Map Sprites: ArcaneEli)
Wyvern Lord - Nuramon (Map Sprites: flasuban)
Wyvern Rider - Mikey Seregon, Alfred Kamon (Map Sprites: Unknown)

Icons

Pacify - Zane
Flare Axe - Zane
Fire Emblem - Zane

Maps

Chapter 17 Map Basis - Aura Wolf
Chapter 20 Megacastle - Alusq

Mugs - I tried to FE8 color some of these so if they look bad that's my fault.

Taiga - Melia
Ludo - SaXor
Victor - NICKT
Rona - AmBrosiac
Hooded Guy - AmBrosiac
Lorelei - AmBrosiac
Breunor - Ambrosiac
Kou - NICKT
Baird - NICKT
Borgin - Blaze
Lawrence - BuskHusker
Laguna - Capybarainspace
Hato - NICKT
Granmore - DerTheVaporeon
Conwell - DerTheVaporeon
Alto - DerTheVaporeon
Murt - NICKT
Goro - NICKT
Valentine - NICKT
Myron - GabrielKnight
Eshima - GabrielKnight
Dogra - GenericPretsel
Dracis - LaurentLacroix
Elise - LaurentLacroix
Nathan - LaurentLacroix
Kris - LaurentLacroix
Tachi - LaurentLacroix
Byrd - LaurentLacroix
Horace - LaurentLacroix
Hartmann - LaurentLacroix
Cassie - LaurentLacroix
Blapp - LaurentLacroix
Shimada - LaurentLacroix
Theodore - LaurentLacroix
Filch - Lenh
Takeuchi - Lenh
Dietrich - Lenh
Yua (temp?) - Marlon0024
Carmichael - NICKT
Shouko - Miguel-Rojo
Gregory - P33RL355
Kyogen - P33RL355
Forz - Peerless
You - Remurin
Rin - NICKT
Faraday - Sme
Mute - Sme
Iida - SmokeyGuy77
Noh - Tobiki
Shouzou - Tsushi
Aira - NICKT
Anna - Vividria
Teno - NICKT
Devin - Zarg
Samantha - Zorua

Music - Crediting ripper using original OST name

FFT Anxiety - Alusq
FFT Decisive Battle - Alusq
Knights in the Nightmare Sortie Formation - SaXor_the_Nobody
Knights in the Nightmare Battle in the Abandoned Church - SaXor_the_Nobody
Knights in the Nightmare Maria Sortie! - SaXor_the_Nobody
Knights in the Nightmare Mellia Sortie - SaXor_the_Nobody
Riviera Heaven's Gate - Pikmin1211
Seiken Denetsu 3 Nuclear Fusion - MrGreen3339
Quarantine (original music) - Teramite

Spells

Paralyze - Orihara_Saki
Pacify - Arch
Necrosis - Arch

Feedback

Mara
ArcaneEli
WarPath
Lumpi
Ribombee
FE74Ever
Rigas

5. Appendix

Growths (potential spoilers) - https://docs.google.com/spreadsheets/d/1LnSmAiQEIik7uW7AwMEAth5mNRmE35NXv6FVAnN2-YU/edit?usp=sharing

Recruit Conditions (spoilers marked at end) - https://docs.google.com/spreadsheets/d/1lOqUnfJ8-l895dIqVeNXqR7aScNpxwU5ZPUCtD7BwZo/edit?usp=sharing

6. Contact Me

If you find a bug or otherwise wish to contact me for some reason, my discord is BigMood#0666, and my FEUniverse username is BigMood. I lurk FEU, NGMansion, Ft. Mangs, and Mekkah's Keep, so if you're in any of those you can just DM me. My YouTube username is SigmaRaven1, but I don't use that often.