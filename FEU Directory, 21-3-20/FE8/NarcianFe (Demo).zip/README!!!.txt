~~~~~~Narcian and the Mirror Chamber (Demo)~~~~~~ 

Greetings dear friends!

(You can skip the introduction by scrolling down!)
My name is Max. I first heard about these Rom-hacks through a Let's Play.
(*cough* *cough* Mangs: Sacred Chairs) I really enjoyed it, so I decided to
create my own one. Apperently I've found FeBuilderGBA and downloaded it.
I had no idea what I was getting in to...
First, FeBuilder is a extreme massiv programm at first glance
Second, I had no ideas where to start...
So I closed the programm and left it for a year.
BUT, now I returned with more power and knowledge about hacking and I
started my own hack for REAL! It was quite simple for the first chapter, but,
the more I got into it, the more problems accured.
How to insert music, create special and unique events and so on.
I made like around 500 safety copies, cause I always messed something up.
But I didn't give up and now I have my very own first 4 chapters.
There are still many, many things to change and improve, but whatever!
The only thing I couldn't fix was the world map. You'll see by yourself what happened.

Still I hope, that when you are really gonna playing my hack, you have much fun and most
importantly(!) give me some feedback what I should change/improve! ;)


~~~~~~Information about the Hack~~~~~~

Creators: Alexandra & Max

Title: Narcian and the Mirror Chamber

Chapters: Ch0-Ch3 (cause it's just a demo)

Gameplay: The first chapters are pretty basic, but chapter 3 got some special objective.

Difficulty: It's automatically set an hard.

Music: I think I played with custom music the longest. Is it good? You'll hear it.

Story: You will see, where I tried to make a good plot and where I just inserted memes...

Characters: There are some unique characters...and Gheb.

Credits to the Female Fighter animation: Original Tellius Fighter by MK404
Design by Pikmin1211
Axe animation by Maiser6
Handaxe animation by Maiser6
Unarmed animation by Maiser6
Palettes by MK404 and Pikmin1211
Map Sprite by Pikmin1211
Class Card by flasuban and Pikmin1211

This animation is just beautiful!

I guess that's with the informations, so have much fun with trying it!!!