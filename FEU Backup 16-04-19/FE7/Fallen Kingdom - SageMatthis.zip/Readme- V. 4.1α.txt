[FE7] Fallen Kingdom V. 4.1α

As this is a demo version, many things have been altered temporarily for presentation purposes. 
The game is less than 50% complete.  Has no relation to the Duo Geno universe(aside from Lau and Brandon).

Created by: SageMatthis
Currently has 12 chapters, including two gaidens.

What needs to be tested:
		just about everything/anything

What needs critiquing:
		maps(progression and aesthetic appeal), story progression(not necessarily plot)/
		story consistency, character style of speech(consistency), unit stats/growths,
		balancing, events, palette aesthetics(status mini-box, window options, etc.),
		weapon stats, GUI icons/palettes, chest/village contents, enemy/NPC AI, cavalier split
		
What does not need critiquing at this point(but will or may later in the future):
		map sprites, portraits(except all of Lau and Brandon's portraits),
		character descriptions, death quotes, character
		palettes(some are untouched, others are placeholders)
		
New additions/changes:
	New cast, classes, story, maps, and events
	Different palettes/color schemes
	Cavalier split(sword/spear vs. axe/bow)
	New promotion for pirates
	New weapons/re-statted weapons
	Removal of true hit and RNG values constantly advance

Known bugs/issues:
	A certain alternate music phase theme fails to resume after battle. 
		To preserve the music, just disable battle animations.
	It is possible to miss a 100%.  Whether this is definitively due to the removal of true hit(usage of the patch) is unconfirmed.
	
	
Changelog:
	V 4.0α
		-First official release up to chapter 9
		
	V 4.1α
		-Enabled the second gaiden chapter
		-Changed gaiden requirements for the second gaiden
		-Rebalanced enemies in various chapters
		-Reworked various maps to make them smaller in size and better
		-Changed chapter 2 and 4's second opening_event to be combined with the first
		-Inserted temporary portraits and palettes for ally characters
		-Inserted Lau and Brandon's king portraits
		-Inserted various new graphics(battle screen)
		-Changed some palettes to match faction palettes
		-Added new graphics for new weapons
		-Replaced lord map sprites with more appropriate ones
		-Temporarily disabled support conversations
		-Inserted temporary death quotes for allies
		-Tweaked Brandon's growths
		-Removed the two goal ASM so that goals will display properly
		-Fixed chapter 5's tilechanges
		-Other things I forgot to mention