[FE7] Fallen Kingdom V. 4.0α

As this is a demo version, many things have been altered temporarily for presentation purposes. 
The game is less than 50% complete.  Has no relation to the Duo Geno universe(aside from Lau and Brandon).

Created by: SageMatthis
Currently has 11 chapters, including a gaiden.

What needs to be tested:
		just about everything/anything

What needs critiquing:
		maps(progression and aesthetic appeal), story progression(not necessarily plot)/
		story consistency, character style of speech(consistency), unit stats/growths,
		balancing, events, palette aesthetics(status mini-box, window options, etc.),
		weapon stats, GUI icons/palettes, chest/village contents, enemy/NPC AI, cavalier split
		
What does not need critiquing at this point(but will or may later in the future):
		map sprites, portraits(except Lau and Brandon's new world portraits), item icons,
		character descriptions and names(except enemy names), death quotes, character
		palettes(some are untouched, others are placeholders), music/music choice(currently temporary)
		
New additions/changes:
	New cast, classes, story, maps, and events
	Different palettes/color schemes
	Cavalier split(sword/spear vs. axe/bow)
	New promotion for pirates
	New weapons/re-statted weapons
	Removal of true hit and RNG values constantly advance

Known bugs/issues:
	The status/goal text display is incorrect.  The status window seems to function properly, but the status screen acts hardcoded to specific values(seems to be due to the two goals per chapter ASM).
		This also means that attempting to view certain status screens can also softlock the game.
			For reference, here are the chapter goals:
				Chapter 0x: Defeat the boss
				Chapter 01: Escape west --> Defeat all enemies
				Chapter 02: Defeat all enemies
				Chapter 03: Defend for nine turns
				Chapter 04: Seize throne
				Chapter 05: Defeat the boss
				Chapter 06: Seize castle
				Chapter 07: Defeat the boss
				Chapter 08: Defeat the boss
				Chapter 09: Seize throne
				Gaiden  01: Defeat the boss
	A certain alternate music phase theme fails to resume after battle. 
		To preserve the music, just disable battle animations.
	It is possible to miss a 100%.  Whether this is definitively due to the removal of true hit(usage of the patch) is unconfirmed.