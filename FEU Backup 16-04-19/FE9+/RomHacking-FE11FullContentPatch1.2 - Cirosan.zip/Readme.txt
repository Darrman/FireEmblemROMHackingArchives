FE11 - Full Content Patch
by Cirosan

This is a merged patch of all my (Cirosan's) previous mods for Shadow Dragon - it combines the Prologue in Hard Mode, Updated Gaiden Requirements Removal, Online Shop Items Integrated into Normal Gameplay, and Always Recruit Norne patches into one. This allows the player to recruit all units, experience all chapters, access all classes, and use the game's full inventory without content being locked behind death requirements, difficulty level, or the now-defunct Online Shop.

As an added bonus, this patch also comes with a variant that updates certain unit graphics and battle background graphics to their FE12 versions; comparison screenshots can be found below. In general, the FE12 graphics use a slightly brighter color palette and make the black outline around units less noticeable.

Finally, this mod includes a version which includes Arch's Sync Patch. This patch updates growth rates, class stats, and weapons to use their FE12 stats; however, it makes the game considerably easier than intended, as the FE12 statistics for these things were balanced for an entirely different game. Still, the option is provided here for those who would prefer it. Note that the Sync Patch includes the FE12 graphical update.

NB: All patches have a glitch on flashcarts - WHICH DOES NOT HAPPEN ON EMULATORS, ONLY FLASHCARTS - that will cause a softlock during the decoy cutscene in Prologue 4. This can be worked around by playing past that section on emulator (such as Desmume) and copying the save file back to the flashcart. The game will function perfectly on flashcarts after this section.

The combined patch without any extras is FE11FCP.xdelta.

The combined patch with the FE12 graphical updates is FE11FCPWithGraphics.xdelta.

The combined patch with Arch's Sync Patch is FE11FCPWithSyncPatch.xdelta.

USE ONLY ONE PATCH.

This was made using the US version of FE11, so you should use an .nds file from that region.



Installation:

1. If you have not already, download the Delta Patcher utility here: https://www.romhacking.net/utilities/704/

2. Obtain an unmodified ROM of FE11. I cannot help you do this.

3. Extract DeltaPatcherLite.exe, your unmodified .nds file of FE11, and EITHER FE11FCP.xdelta OR FE11FCPWithGraphics.xdelta OR FE11FCPWithSyncPatch.xdelta to the same folder. DO NOT USE MORE THAN ONE.xdelta FILE; CHOOSE ONLY ONE. The difference is explained above.

4. Open DeltaPatcherLite.exe.

5. Click the "Open" button for the "Original file" box and select the unmodified .nds file of FE11.

6. Click the "Open" button for the "XDelta patch" box and select EITHER FE11FCP.xdelta OR FE11FCPWithGraphics.xdelta OR FE11FCPWithSyncPatch.xdelta.

7. Click the "Apply Patch" button. Users with older PCs may have to wait a few moments.

8. Your previously unmodified file, which you selected in step 5 as the "Original file", is the patched ROM you should now use.



Your original ROM's checksums should be:

Original CRC32: 4CE55236
Original MD5: 5B7A037DFF5A904078404922642A01E8
Original SHA-1: 5174FBAB0C159CE247CCF133A8103B79FAE1435F

If you don't know what those are, this website can explain:
http://onlinemd5.com/



Patched values for FE11FCP.xdelta:

Patched MD5       FA44BC145D5F31841B9B621777AF7940        
Patched SHA-1     936E44BDB563077FFAF426C10236AB0DD76232DB
Patched CRC32     909FB0EA                                



Patched values for FE11FCPWithGraphics.xdelta:

Patched MD5       E9048ECEB3319661DE525BE60AFA848D        
Patched SHA-1     F92BD90A3603E35C4F9DB17974B9B929677F4545
Patched CRC32     07EE5AC4                                



Patched values for FE11FCPWithSyncPatch.xdelta:

Patched MD5       D2C4C612C6F1DFCE2F9D9B04ADBA225E        
Patched SHA-1     8B8D5CFDED647797EB3CD7DF000F072D50BB00AA
Patched CRC32     28A351FF                                



Have fun!
- Ciro