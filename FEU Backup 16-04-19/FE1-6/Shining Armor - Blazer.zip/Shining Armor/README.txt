README
-------

Fire Emblem: Shining Armor created by Fire Blazer/Keriku

smashfire17@gmail.com
http://www.feshrine.net
AIM: fireblazerx17

If you need help with patching check the other files.

This may NOT be re-distrubuted or used in anyway except for playing enjoyment without given permission from me, the creator.

Thanks to everyone who has somehow helped the FE hacking community, bla bla bla.

Hope you enjoy it!