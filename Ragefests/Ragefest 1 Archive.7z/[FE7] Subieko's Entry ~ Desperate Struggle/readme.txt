README for Subieko's Ragefest Contest Chapter

CREDITS

Nils' staff animation: made by oracle_of_fire
All other custom material made by Subieko