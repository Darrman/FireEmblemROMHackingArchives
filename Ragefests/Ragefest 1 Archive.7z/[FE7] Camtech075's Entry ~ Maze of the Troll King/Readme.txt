Hey guys, it's Cam here.

As you know, this is my submission for Marc's ragefest contest. I've been told it's pretty devastating, but only time will tell.

First off, I couldn't iron out all the bugs, so you might want to use some states. Well, you might want states to begin with. Secondly, there are a lot of things that look unintentional but are actually on purpose (some chests don't open, some chests have nothing in them at all, etc). This is because I am mean. It isn't a glitch, I assure you. Unless the game crashes, in which case I have no idea.

Anyway, enjoy!