README
-------

See "patching instructions" for patching instructions.

Overview: Yo, I'm Blazer, who you may know as Fire Blazer, Keriku, or Luffy,
but in the FE community, probably Blazer.

This hack is for Markyjoe's ragefest contest. I think the idea of a brutal hacking contest
is great and I just had to participate once. I've put a lot of time and thought into this
hack (some odd hours of pure typing on an iPhone planning this thing out)
so I hope you enjoy. While the hack will be officially complete and as a result
I will not be making many further changes to this as of version 1.0, if you have
any thoughts on the hack feel free to e-mail me at smashfire17@gmail.com or
find me at some Fire Emblem site, such as my very own (http://www.feshrine.net).

The hack itself features a series of 10 challenges where you take a certain
sad character and use brains, analysis, and strategy to defeat your opponents or whatever else
is expected of you. In my honest opinion, the best way to know is to see it for yourself, so go play it and knock yourself out!

Warning: The below warnings are in caps, don't read if you're sensitive to caps lock. ;)

WARNING2: MAY INDUCE RAGE. IF YOU ARE SENSITIVE TO BULLSHIT, MEAN JOKES, FOG OF WAR, HIGH DIFFICULTY, OR BAD LUCK, THEN THIS HACK IS NOT FOR YOU.

WARNING3: THIS HACK CONTAINS A BUNCH OF BULLSHIT. YOU MIGHT THINK IT'S A GLITCH OR SOMETHING BUT IT'S PROBABLY ME JUST MESSING WITH YOUR HEAD. SUCH AS THE GAME NOT WAITING FOR YOU TO FINISH DIALOG, DECREASING FOG OF WAR VISION RANGE, ENEMIES SPAWNING RIGHT NEXT TO YOU, ETC. CALL IT A GLITCH AND YOU FAIL.

-------------

Version 1.2 - October 2nd, 2011

I'm supposed to be done with this but I made some updates to make the game more balanced and less luck-based (you can avoid those 15 crit generals now). The more insane and unfair version is now the "hard" mode--if you want a depressing, terrifying challenge, you can try that one, but the normal version is for normal people. It's also the version I am submitting for the ragefest contest. 

Version 1.0 - September 5th, 2011

Stop trying to make me remember stuff from forever ago.

So the ragefest hack contest got delayed but I don't really have much time to fool around with this anyway,
so I decided to just call it a day and release it. If there are any bugs or glitches though, please let
me know so I can fix them.

Version 0.3.1 - August 18th, 2011

Very, very minor fixes that I felt were needed for this to be a little bit better. Late-game is also slightly easier and less binding (before the turn limit was so intense that it might be impossible to beat it without restarting if you didn't have enough time, despite using savestates...).

Version 0.3 - August 16th, 2011

Some more updates, but mostly the finishing touches to the game.

- FINALLY fixed the fire tiles for good... I think/I hope. They seemed to be working consistently.
- Altered some text here and there, mainly in the beginning and end
- Emowood accidentally shared the same class text as Darkness, he's now his own class AKA it's been fixed
- slight update to the end of challenge 1
- FINALLY remembered to fix the turn count to 60 turns (I actually made the patch and everything, then
only remembered while typing this, so I had to go back, fix it, and repatch everything... lulz)
- added custom music (3 songs--battle theme, map theme, and final boss theme, for a one-chapter hack I think that's more than enough)
- updated the battle background with new graphics (people who played Prince of Durand will notice another reference to the game... RIP oh old hack of mine)
- spiced up the game over text (if you play the game you'll almost definitely see it)

With this the game should be done with improvements/additions, any other releases at this point should only be bugfixes, which I hope I don't have to do, of course. ^_^

Version 0.2 - August 9th, 2011

Several updates here--tried to fix the fire tiles once more since those were causing trouble. I added a
weapon called Last Resort on Challenge 1 which is supposed to give a free critical hit, essentially.
When it is used is up to the player (but it's there to make challenge 4 less luck-based, I'll say that
much). I've also added a little extra cutscene after challenge 6, as well as altered challenge 2's
description (to make a bigger hint on how to beat it) and the ending. I've also updated the Final Boss
a little (minor things) and... I added fog of war, which becomes increasingly more thick as you progress
(see for yourself!), but never gets to range 3 or lower (because that'd be too cliche). That's about
all I can remember at the moment.

Version 0.1.1 - July 29th, 2011

Several medium-size fixes and additions. Emowood's growths have been upped and the difficulty has been eased
(challenge 9 has lower level enemies). Fixed a bug where the Shadowblade and final elixir would be "pilfered"
instead of received. Still trying to perfect the fire traps (I think it's still a little glitchy but
it IS beatable...). The player now receives 2 Wind Swords which now have +5 defense and 55 uses unlike
before, where they added +3 defense and had 40 uses. Challenge 9 enemies now drop items (Dracoshields and
something else not worth remembering). Challenge 6 enemies have been lightened in difficulty
(the mercenaries/archers--mercenaries should no longer double Emowood unless he got ridiculously speed
screwed...). The turn limits have been increased significantly as well (challenge 8 must be reached
by turn 45 now, and the game must be beaten by turn 60). I think I made a couple of other uh...
aesthetical changes, which I can't remember. The only problem I don't want reported is that it says
"Last Turn" at the top right for a while even though the game doesn't end until turn 60 or until
the boss/first boss/final boss (:P) is beaten. Oh, and don't say that the game doesn't have an ending,
use your brain and you should be able to figure out when the game ends. :P


Version 0.1 - July 27th, 2011

The first beta release. Game is complete but not very tested. Game has not been beaten yet even by me,
Blazer, the creator.

--------------

Credits

Blazer - Creator, idea-maker, etc.
Nayr - Eliwood recolors (the Evilwood portrait, a recolored Angry-Eliwood, was unused, but I appreciate it regardless).
Markyjoe1990 - Ragefest hack idea
Nintenlord, Xeld - Major use of their programs
Everyone who has contributed to Fire Emblem hacking - I've learned a lot from a lot of people and I've used
a lot of programs and I really appreciate everyone in the huge list of names that makes this stuff possible.

If my bad memory has left you out of this list please let me know ASAP so I can fix it! Thanks!

Betatesters - Thanks to everyone who helped make this game much better than it would have been
had they not helped, heheh! List below!

- Lungs - A VERY thorough beta log with savestates and very detailed information. Helped a LOT. Also the
first person to beat the game. Thanks!

- Black Cat
- Big FE fan
- Swordsalmon