Patch this with an FE8-U rom.
Don't change the text speed, otherwise it'll sound awful.
Questions, comments, or concerns about the creator's sanity can be referred to me (Tequila) on Serenes Forest or FEUniverse.
Enjoy! 