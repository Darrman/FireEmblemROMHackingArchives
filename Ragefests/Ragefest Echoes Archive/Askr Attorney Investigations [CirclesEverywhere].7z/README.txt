Notes:
- Patch to FE8(U)
- Hold L to toggle animations
- Select to toggle danger zone
- Select at stat screen to view growths
- Flashy mode is active (all boss kills are crits)
- You can figure out the rest yourself

Credits:
Mugs - various (see ingame credits)
Misc graphics stuff - Blaze, Monkeybard, Ukulele, LordGlenn
ASM stuff - Leonarth, Stan, the combined knowledge of FEU
This rom certified FEditor and Nightmare free
