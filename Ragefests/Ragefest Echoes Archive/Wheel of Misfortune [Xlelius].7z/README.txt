Yay! You read the README.
I love it when people do that.

Apply this patch to a Fire Emblem 7 ROM.

INFO:

Title:
	"Wheel of Misfortune"

Auther:
	Xlelius 

Author Name Pronunciation:
	"ZEL-ee-us" 	Just pretend the "X" is actually a "Z" and ignore the first "L"

Difficulty:
	RAGEFEST (or at least intended to be)

NOTE:
	The Wheel of Misfortune runs off a seperate, custom built, RNG that 
	cannot be manipulated with traditional RNG manipulation techniques. 

NOTE:
	Any errors in music loops are completely intentional.


CREDITS:
Thank to
	Nintenlord
	Blazer
	General Archibald
	Markyjoe1990
	Flioro