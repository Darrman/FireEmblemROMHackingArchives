Patch to the original, unmodified Fire Emblem 1 ROM.

This hack was made for Ragefest Echoes. Since it's FE1, emulator turbo is encouraged, nay, expected! So use it a lot!

-Ephraim225