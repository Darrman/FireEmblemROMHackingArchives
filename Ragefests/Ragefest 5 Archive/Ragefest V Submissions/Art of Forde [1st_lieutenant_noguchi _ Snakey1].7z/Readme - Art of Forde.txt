Fire Emblem: Art of Forde

Patch to a clean, FE7 English ROM

NOTE: This hack is meant to be difficult but should
be completed, under ideal conditions, without savestates

Created for Ragefest V: The Enragement Ring

Coded by Snakey1
Written by 1st_lieutenant_noguchi
You can find us on FE Universe


Animation/Art Credits:
Eldritch Abomination (Generic Necromancer)
MrNight48 (Patriarch/High Magus)
L95 (Map Sprites for Patriarch/High Magus)
MageKnight404 (Halberdier Class Card)
TheBlindArcher (Halberdier)
Unknown (Assassin Class Card)
Unknown (Halberdier Map Sprite)

Aqua Edge (Blazer/Keriku/Bonzai)
Bolganone (Unknown)
Excalibur (Unknown)
Ground Dasher (Blazer/Keriku/Bonzai)
Meteor (Blazer/Keriku/Jubby)
Shaver/Wind (Mikey Seregon)
Updated Thunder (Unknown)
Death (Unknown)
Crimson Eye (Unknown)
Swarm (Blazer/Keriku/Jubby)
Thani/Aura (Unknown)
Starlight (Blazer/Keriku/Jubby)

Additional Credits:
Blazer, for the Ultimate Tutorial, which is a godsend
MarkyJoe1990, for hosting the contest and for his eventing tutorial (also a godsend) on YouTube, as well as his Tiled tutorials
Arch, for his eventing tutorial
Nintenlord, for all the various editing programs he's made (EA, NUPS, GBAGE, Tiled Inserter)
Hextator, for FEDitor Adv
The Creators of Nightmare, Larry Kenny and Michael Cayer
Lindeijer, for making Tiled because that was useful
All of the great people who made great Nightmare Modules
All of the AWESOMELY WONDERFUL FEUniverse community who helped with our vague questions as we tried to keep this project secret
All of our playtesters

If we left you out and you deserve credit, don't
just rant! Well, you can rant a little bit.
Let us know, and we'll give you
the necessary credit you deserve.



Chapters:
Chapter 1: Deja Shroom
Chapter 2: Friends and Snows
Final Chapter: Dark



DISCLAIMER:

Fire Emblem is owned and created by Nintendo, Intelligent Systems, and their affiliates. 
We claim none of their work as our own and have made no profit off the creation of this fan-made creation.
We also claim no rights to Nintendo, Intelligent Systems, or any of their affiliates.










SPOILERS BELOW (Do not scroll if you wish to play the game blind)





















Game Guide by Snakey1

Welcome to The Art of Forde game guide! If you are reading this, then
you are either cheating, have rage-quitted, or are just curious.
Either way, the following are the steps to complete this abomination.

Actually watch the prologue! Resist the temptation to skip it!

Well... Doesn't this look familiar...
This map works with hordes of almost dangerous units. The chapter is
designed to be less reliant on luck, but instead more reliant on
clever unit placement. There are multiple ways to do the 1st turn, but regardless,
it is essential to kill as many of the Halberdiers as possible;
they can be very hard-hitting.
Choke points are also extremely important in this chapter.
Try to avoid giving up control of a chokepoint.

Unfortunately, I'm not psychic, so I can't help you with
specifics beyond the first turn. You're going to have
to figure it out for yourself.
This is in my opinion, the easiest of the three chapters.
Overall, just don't do anything too stupid.
I can give you some tips, however:
	Letting anyone die WILL trigger a game over.
		Cormag as a red unit won't.
		You need his Suber Spear, though so still don't get him killed.
	I highly recommend training Forde for later.
	The Valkyrie drops a physic staff. It's helpful for now and later.
	The Heroes and Great Knights will not stop spawning on their own.
		Step on their spawn points to make them stop.
		You can leave the fort and they will not spawn anymore.
	Don't try to kill Aias without the Suber Spear.
	Rausten does arrive, but they only distract the enemy at best.
		ENJOY THE SLAUGHTER.
	Cormag arrives from the southwest soon.
		Recruit with Eirika or Forde.
		He can kill the unprepared, so be ready.
		Use his Suber Spear to kill Aias whenever you're ready.
	Gheb arrives with troops on turn 12 because why not?
	You then learn that it's a rout. This one isn't a lie.
	Aias starts to pursue you on about turn 20.

PROTIP: Give Forde and Lute the most useful weapons left over...

Congratulations! You have survived the Hamill Archepelago!

Here we are in the 2nd chapter.
Naturally, keep the most useful items in your inventory when prompted.
ENJOY THE SLAUGHTER of the BEST prepromote of FE8. Ha ha...
There is a time requirement involved. A crazed princess arrives on turn 35
who will murder your face off, so don't dally!
You have more options in the final chapter if you finish
before said crazed princess arrives. You shouldn't have
enough time to clear all of the rooms.
If you don't care about the next chapter, go ahead and clear everything.
If you don't care about winning, go ahead and
get murdered by the crazed princess.

Here are some tips:
	Magic and weapon effectiveness is the key to the first couple turns.
	Don't think you can draw out enemies. They will run at you if you get close.
	In the chests are stat-boosters.
	A familiar face pops out of the northeast chest.
	A wandering thief aids you with lockpicking skills.
	Houses contain helpful tips.
		If you're reading this, I suppose you don't need them...
	It starts to snow eventually, but it stops soon.
	The armory has useful things: Very cheap stat boosters.
	Never put this many battle conversations in a chapter.

Here we are in the final chapter.
If you have a prep screen, good job! You have invested in your future
for the better! If not, too bad. This chapter will be a bit harder.
From the prep screen, choose two mages for heals and not Orson unless
you want to get betrayed or just for lolz. Also a flier is useful.

Some units you choose can talk to other units. Work went into these conversations,
so watch them! We tried to be funny.

You should either tank against or kill the halberdiers depending on who you chose.
Be careful not to tank too long. Also, take out the Sage with Bolting as soon as possible.
Sonia really isn't that hard to kill. I've one-rounded her with Carlyle and a brave sword before.
Naturally, go for the chests before you attack Nergal and Limstella. They hold useful weapons.
I should warn you, a memey Sniper shows up even more powerful than the memey princess if
you take too long. It's triggered by being too far back in the map after certain turns,
so if you passed the pillars in a decent amount of time, you'll be fine.
Well... The rest is self-explanatory. Do whatever you want with Nergal. As long
as Forde, Lute, or Joshua don't die, do whatever works.

Go ahead and watch the ending cutscene. Relax. You're done.
Gawk at the bizzare plot wrap-up, but oh so pretty lightning!


Congratulations. You have illegitimately finished The Art of Forde with the help of the guide.
MarkyJoe would be proud.
