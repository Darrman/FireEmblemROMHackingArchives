Patch to clean FE8.

Changes since initial version: You cannot block several of the reinforcement spawn points anymore.

Credits:

	Events: Pwntagonist

	Map: GenericCivilian3 and Pwntagonist

	Level Design: Pwntagonist and GenericCivilian3

	Writing: Royalty

	ASM: Circleseverywhere (Danger Zone and Forceful Rescue Drop hacks)

	Playtesting: Tamborrino, GenericCivilian3, RandomSwordmaster