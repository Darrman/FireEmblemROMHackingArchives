O=====================O
|The Corruption of Roy|
|By MarkyJoe1990      |
O=====================O

O=================O
|Table of Contents|
O=================O
1. Introduction
2. Patching Instructions
3. Story
4. Guide
5. Special Prize
6. Future Goals
7. Glitches
8. Contact
9. Credits

O===============O
|1. Introduction|
O===============O

This is my submission to my Fire Emblem hacking contest,
Ragefest 3: Douchey Today, Relieved Tomorrow. Despite the
goal of the contest being to make a creative hack that is
rage inducingly hard and funny, the story presented by my
submission is fairly serious.

There are bits of humor in the submission, but almost all
of it has no story context, and will likely prompt you to
say "What the heck was that all about!?"

As such, if you're playing for the story, you might want
to pretend most of the funny parts never happened. Though,
I highly doubt you're here for story in the first place.

In my opinion, you're probably here because you have a
strong urge to play something extremely hard and frustrating.
If that is the case, you're going to be very pleased.

This submission was passionately crafted from the deepest
hatred within my soul. I've playetested it several times
and designed it so that you will never have a moment
of reprise. Combining genuine difficulty with Trial
& Error, only stubborn minds will be able to conquer
this colossus of torture.

O========================O
|2. Patching Instructions|
O========================O

First, get a UPS patcher. For these instructions, I'll
assume you have NUPS, which you can get here:
http://dl.dropbox.com/u/341300/Patches/Patchers/NUPS.zip

Next, you'll need a Fire Emblem 7 ROM. I won't
tell you how to get this, but with the help of google,
you should be able to find it pretty quickly.

After you get that, open NUPS up and select "Apply an
UPS patch to a file". Select the file you wish to
patch, and the UPS that will patch the file, then under
the "If file is invalid" thing, select ignore. Lastly,
click "patch". You should be set.

O========O
|3. Story|
O========O

One year has passed since Roy lead the Etrurian alliance
and defeated the Kingdom of Bern. Ever since then, the
continent of Elibe has been in the process of reconstruction.

Sometime after the war ended, Roy married a nabata
priestess named Sophia, and with the help of her wisdom,
Roy was able to maintain peace in Pherae, a territory
in the Lycian Alliance of which he is the Marquess.

One night however, Roy's wife Sophia wakes up to find
herself locked up in a prison cell. Before she can ponder
what has happened, Sophia is released by Cath, a thief
who aided Roy in the war. The thief tells her that Pherae
has invaded the head territory of the Lycian Alliance,
Ostia. Refusing to believe her husband would be responsible
for such a traitorous act, Sophia reluctantly follows Cath
around in hopes that what she has been told is false.

O========O
|4. Guide|
O========O

Consult the guide folder.

O================O
|5. Special Prize|
O================O

If you managed to beat this hack, you should have gotten a
password. You can use that password to unlock the contents
of this zip file:
http://dl.dropbox.com/u/35795576/Special%20Prize.zip

Enjoy your prize~

O===============O
|6. Future Plans|
O===============O

Please note that this list isn't finalized. Not everything
on here is guarenteed to be put in later updates.

- Add more humor
- Remove all glitches
- Improve level design of the second half
- Improve dialogue so it feels less stilted
- Finish the special prize earned at the end of the submission
- Make a "Non-Ragefest" version that removes all trial & error
- Make a video of this hack, with commentary
- Remove all story plot holes
- Improve the ending
- Add more recruitment dialogues
- Extra Mode: Essentially the same chapter, story-wise, but with
an entirely new map, enemies are much stronger and have different
placements, and all of your characters' stats from the previous
playthrough will carry over. You will also be able to promote
your units.

O===========O
|7. Glitches|
O===========O

- Resetting the emulator or turning it off resets certain event
  IDs. This is less problematic since version 1.3
- A certain chest in part 2, if opened by a thief, gives the
  same result as if opened by a player. Not so much a glitch as
  something I overlooked.
- Most likely a flaw of the engine: Spawn points, if blocked by
  an enemy, will still spawn an enemy if the spawn point is out
  of the player's vision.

O==========O
|8. Contact|
O==========O

E-Mail - markyjoe1990@gmail.com
Youtube - http://www.youtube.com/user/markyjoe1990
Skype - Markyjoe1990
AIM - Markyjoe1990
IRC Chat - http://markyjoe1990.herobo.com/?page=chat

O==========O
|9. Credits|
O==========O

Cedar Nyx - For Shigeid's Portrait and for feedback and playtesting
Ephraim225 - For feedback and playtesting.
Obviam - For the FEditor Adv Tool and his Fire Emblem hacking documents
Nintenlord - For the Event Assembler, Tiled Map Inserter, and Graphics Editor Tools
Archibald - For making Elibean Nights, which was somewhat of an inspiration for this hack
Fire Emblem Hacking Community - For compilating together and creating Nightmare and it's modules
Nintendo & Intelligent Systems - For making the Fire Emblem series
Various other people - for the Advanced Palette Editor and Sappy program
Sophia from Fire Emblem 6 - For being damn hot and being one of the more interesting characters in the game