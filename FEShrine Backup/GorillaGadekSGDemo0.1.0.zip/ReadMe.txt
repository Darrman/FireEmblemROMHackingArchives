-----------------------------------------------------------
                      Release Notes
-----------------------------------------------------------
Project By: Mage Girl
Curent Version: 0.1.0
Released: August 30, 2009

If you wish to contact me, you can find me on
Fire Emblem Universe (http://www.feuniverse.net/forum)
or the FEShrine Forums (http://forums.feshrine.net/).
You can also contact me through e-mail at
supergal117@yahoo.com
-----------------------------------------------------------
                       Other Notes
-----------------------------------------------------------
All original graphics and characters which were created for
this patch belong to Mage Girl. If you want to use them in
any way, please ask me permission before using them.

Fire Emblem belongs to Nintendo/Intelligent Systems and
any cameo characters which appear in this belong to
Nintendo.
-----------------------------------------------------------
                     Release History
-----------------------------------------------------------
Version                                                Date
-----------------------------------------------------------
Version 0.1.0                               August 30, 2009
-----------------------------------------------------------
First release.
Text Complete to Chapter 8. (excluding world map text)
Menu Graphics complete.
Battle scene graphics complete.
Portraits inserted for characters up to Chapter 8.
-----------------------------------------------------------