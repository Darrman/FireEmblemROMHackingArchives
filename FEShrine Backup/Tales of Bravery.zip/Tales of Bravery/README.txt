README
-------

Patching instructions is in the file named so. If you need any help, contact the forums or me (smashfire17@gmail.com)

//////////////////////

Current Version: v0.1.0
Release Date: January 30th, 2011
Creator: Blazer (Fire Blazer, Keriku, Luffy)

http://forums.feshrine.net
http://www.youtube.com/FireShrine/
http://www.feshrine.net

Tales of Bravery is a crossover hack of Fire Emblem 7 between Fire Emblem and the Tales of series. It features many battle aspects from Fire Emblem, and some of Tales, as well as many Tales characters with custom animations, new, original characters that aren't in either series, and appearances of originally non-playable characters from the Fire Emblem series. It takes place in several places, including Elibe, Aselia, Brachia, and Eborakum.

Play the hack and find out what this custom wonder is all about!

~~~~~~~~~~~~~~~~~~

v0.1.0 January 30th, 2011

The game is done upto the prologue. After the prologue, the game goes to chapter 1, but it is unplayable. The only thing left to do in the prologue is add chibis for Rosale and Thanatos, which is a minor thing.