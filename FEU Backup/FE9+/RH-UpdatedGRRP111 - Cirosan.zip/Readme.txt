Shadow Dragon - Updated Gaiden Requirements Removal Patch
Original patch by Robert of Normandy a.k.a. RobertTheSable
Update by Cirosan

This is an update to the Gaiden Requirements Removal Patch, made by Robert of Normandy a.k.a. RobertTheSable. Robert gave permission for the modding community to freely use his patch, and a link to his written permission is included in the documentation. In Robert's own words, this patch is:

"Patch for Fire Emblem: Shadow Dragon that removes the unit limits to get in to Chapters 6x, 12x, 17x, and 20x. In other words, you can get into those chapters without killing off your own units."

Unfortunately, there was a bug with the original patch that made the character of Ymir, if recruited using the patch, have zero movement - effectively making him useless. This updated patch fixes this long-standing bug with Ymir's movement. As part of the fix, Ymir will now actively move during Chapter 20x (instead of being stationary, as he is in the unmodded game), and his dialogue has been slightly altered to reflect this.

To be clear, YOU DO NOT NEED THE ORIGINAL GAIDEN REQUIREMENTS REMOVAL PATCH TO USE THIS MOD. This is effectively a replacement for the original patch, and incorporates all of its features already, in addition to fixing the Ymir movement bug.

If you're using my Prologue in Hard Modes patch, YOU DO NOT NEED THIS FIX, as it has already been incorporated into that mod.

This was made using the US version of FE11, so you should use an .nds file from that region.

Please note you'll have to acquire a copy of the FE11 .nds legally; only the patch is included in this download.


Installation:

1. If you have not already, download the Delta Patcher utility here: https://www.romhacking.net/utilities/704/

2. Extract DeltaPatcherLite.exe, UpdatedGRRP.xdelta, and your unmodified .nds file of FE11 to the same folder.

3. Open DeltaPatcherLite.exe.

4. Click the "Open" button for the "Original file" box and select the unmodified .nds file of FE11.

5. Click the "Open" button for the "XDelta patch" box and select UpdatedGRRP.xdelta.

6. Click the "Apply Patch" button. Users with older PCs may have to wait a few moments.

7. Your previously unmodified file, which you selected in step 4 as the "Original file", is the patched ROM you should now use.


Credits and Acknowledgments:

- Robert of Normandy a.k.a. RobertTheSable for his Gaiden Requirements Removal Patch. Permission was given to incorporate this patch into other hacks here:
https://serenesforest.net/forums/index.php?/topic/51430-fe-shadow-dragon-gaiden-requirements-removal-patch/&do=findComment&comment=3665588
- Blazer for their suite of Shadow Dragon hacking tools, which can be found here:
http://www.feshrine.net/forums/index.php?showtopic=422&p=85130
- Mariode for their update to said suite of tools, which can be found here:
https://serenesforest.net/forums/index.php?/topic/66930-fe-shadow-dragon-unit-disposition-editor-modules-itemclass-editor-update/
- SadNES cITy Translations for their Delta Patcher tool, which can be found here:
https://www.romhacking.net/utilities/704/
- Nuthingdude for providing a save file at Chapter 20 for use in bugtesting the Ymir fix
- Will and Sam for their inexplicably continued friendship


Have fun!
- Ciro