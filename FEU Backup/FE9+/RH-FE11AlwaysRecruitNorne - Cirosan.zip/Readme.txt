Allows the player to always recruit Norne at the end of Prologue 4, regardless of how many units are alive. Alterations have been made to Chapters 1-3 to accomodate having her as an extra unit.

FE11AlwaysRecruitNorne.xdelta incorporates the Prologue in Hard Modes Patch, for obvious reasons.

FE11RecruitNorneWithGaidens.xdelta incorporates BOTH the Updated Gaiden Requirements Removal Patch AND the Prologue in Hard Modes Patch.

USE ONLY ONE PATCH, NOT BOTH.

This was made using the US version of FE11, so you should use an .nds file from that region.



Installation:

1. If you have not already, download the Delta Patcher utility here: https://www.romhacking.net/utilities/704/

2. Obtain an unmodified ROM of FE11. I cannot help you do this.

3. Extract DeltaPatcherLite.exe, your unmodified .nds file of FE11, and EITHER FE11AlwaysRecruitNorne.xdelta OR FE11RecruitNorneWithGaidens.xdelta to the same folder. DO NOT USE BOTH .xdelta FILES; CHOOSE ONLY ONE. The difference is explained above.

4. Open DeltaPatcherLite.exe.

5. Click the "Open" button for the "Original file" box and select the unmodified .nds file of FE11.

6. Click the "Open" button for the "XDelta patch" box and select EITHER FE11AlwaysRecruitNorne.xdelta OR FE11RecruitNorneWithGaidens.xdelta.

7. Click the "Apply Patch" button. Users with older PCs may have to wait a few moments.

8. Your previously unmodified file, which you selected in step 5 as the "Original file", is the patched ROM you should now use. 



Your original ROM's checksums should be:

Original CRC32: 4CE55236
Original MD5: 5B7A037DFF5A904078404922642A01E8
Original SHA-1: 5174FBAB0C159CE247CCF133A8103B79FAE1435F

If you don't know what those are, this website can explain:
http://onlinemd5.com/



Patched values for FE11AlwaysRecruitNorne.xdelta:

Patched MD5      E4C421A1C2B067A913A7BC205F734620        
Patched SHA-1    12A472DF1FC3FC225609B7D85FF3895C83F42DC4
Patched CRC32    8838BBBB



Patched values for FE11RecruitNorneWithGaidens.xdelta:

Patched MD5      A3069026FDABC8E2ED21E6772D85DE11        
Patched SHA-1    F5E97102441EF2DE27185D4344AAE183F85C9671
Patched CRC32    731D3197