FE11 Prologue in Hard Mode patch
by Cirosan

This patch allows you to play through the prologue of Shadow Dragon on higher difficulties. Enemies will scale up to your difficulty of choice for the prologue's duration. This also allows you to choose the sacrifice and (potentially) obtain Norne on higher difficulties.

Changes have been made to Prologue 1 and 2 to help accommodate higher difficulties, such as placing a vulnerary in Marth's inventory, having certain enemies drop vulneraries, and changing the class and equipment of certain enemy units.

Script edits have also been made to make the intro cinematic always load the normal difficulty version - the one that ends with, "Thus Marth applied himself to the ways of the pen and sword, until one day..." instead of summarizing the prologue - even when you pick hard modes. Text editing has also been used to make the help text say that you get the prologue on all difficulties, rather than hard modes still saying that no prologue is included.

The Gaiden Requirements Removal Patch, made by Robert of Normandy a.k.a. RobertTheSable, has been incorporated into this patch. If you want to use the Gaiden Requirements Removal with this patch, use FE11HardPrologueWithGaiden.xelda. If you want the regular game with no changes other than being able to play through the prologue on higher difficulties, use FE11HardModePrologue.xdelta. USE ONLY ONE VERSION OF THE PATCH, NOT BOTH.

This patch also fixes the long-standing Ymir movement bug associated with the Gaiden Requirements Removal Patch. As part of the fix, Ymir will now actively move during Chapter 20x, and his dialogue has been slightly edited to reflect this.

This was made using the US version of FE11, so you should use an .nds file from that region.

Please note you'll have to acquire a copy of the FE11 .nds legally; only the patch is included in this download.


Installation:

1. If you have not already, download the Delta Patcher utility here: https://www.romhacking.net/utilities/704/

2. Extract DeltaPatcherLite.exe, your unmodified .nds file of FE11, and EITHER FE11HardPrologueWithGaiden.xdelta OR FE11HardModePrologue.xdelta to the same folder. DO NOT USE BOTH .xdelta FILES; CHOOSE ONLY ONE. The difference is explained above.

3. Open DeltaPatcherLite.exe.

4. Click the "Open" button for the "Original file" box and select the unmodified .nds file of FE11.

5. Click the "Open" button for the "XDelta patch" box and select EITHER FE11HardPrologueWithGaiden.xdelta OR FE11HardModePrologue.xdelta.

6. Click the "Apply Patch" button. Users with older PCs may have to wait a few moments.

7. Your previously unmodified file, which you selected in step 4 as the "Original file", is the patched ROM you should now use.


Credits and Acknowledgments:

- Robert of Normandy a.k.a. RobertTheSable for his Gaiden Requirements Removal Patch. Permission was given to incorporate this patch into other hacks here:
https://serenesforest.net/forums/index.php?/topic/51430-fe-shadow-dragon-gaiden-requirements-removal-patch/&do=findComment&comment=3665588
- Blazer for their suite of Shadow Dragon hacking tools, which can be found here:
http://www.feshrine.net/forums/index.php?showtopic=422&p=85130
- Mariode for their update to said suite of tools, which can be found here:
https://serenesforest.net/forums/index.php?/topic/66930-fe-shadow-dragon-unit-disposition-editor-modules-itemclass-editor-update/
- SadNES cITy Translations for their Delta Patcher tool, which can be found here:
https://www.romhacking.net/utilities/704/
- Nuthingdude for providing a save file at Chapter 20 for use in bugtesting the Ymir fix
- Will and Sam for their inexplicably continued friendship


Have fun!
- Ciro