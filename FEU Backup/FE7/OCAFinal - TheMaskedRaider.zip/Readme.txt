Editor's note: The original hack download lacks a readme. The Serenes Forest OP is copied down to serve as one.

Some of you may recognize this hack for what it is.
This is the fourth and from the looks of it on the way to being the final version of tacthack.
For those that don't know, Tacthack is a hack for FE7 with a playable tactician with an original setting and characters.
Issues and rebalances galore later here's an update and the first release of the FINAL version of the hack.
This version goes all the way through to the epilogue and rolls endings. Not all the endings are in mind you, as we are still writing supports to see what goes where but a majority of the Single endings are in. Dialogue for the final map has been added so if you beat it and have a save feel free to go back and view it.
as far as changelogs go.
Light magic has been revamped
Aras recieved a slap on the wrist nerf but shes still strong.
Gerwulfs statline and growths have been changed hopefully for the better this time.
Brendan received a buff as did sven.
Some late game bosses have received changes.
It's been a fun ride and I'll keep polishing it but they'll be slower more paced out updates.
Thanks for all the help on this.

[Patch download link here.] 

A small plot introduction:
[spoiler tags]

Fire Emblem: Order of the Crimson Arm is a hack which follows the trials
and tribulations of Algimas, an up and coming mercenary leader,
and a foreign tactician testing their knowledge of warfare on the battlefield.
The two set out together to the continent of Fadrel for fame and fortune.
Over the course of time, both will go through various events which will decide
not only their future, but the fate of many others as well.

[end spoilers] 
 
[Screenshots removed as this is plain text.]
  

Changes from the base game:
[spoilers]
Wyverns use axes. gain lances on promotion.
Cavaliers are split into Light and Heavy cavalry.
Light cavalry are the traditional cav, using lances and swords and promote into paladins.
Heavy cavalry use swords and axes and promote into great knights.
Knights get bows! Retain axe gain on promotion.
Playable soldiers and Halberdiers.
Weapon bonus hack added.
Weapon balance changed, bows are really scary now.
Thieves promote into rogues.
Class base stat changes.
Custom animations both original and from the community.
Different music!
[end spoilers]
 
And since this is tact hack I encourage you to try making and using your own portrait and palette for the tactician character!

Here are some already done portraits with the feditor index and palette offset as well as

instructions on how to switch them out below.

[Alt male tactician portrait]

Mtact variation2
Feditor Portrait index 03
Unpromoted palette offset: FDA714

10 A0 00 00 00 55 53 FF 7F FF 6B 1F 4B 00 2E 19 9D 1B BF 1E 31 05 00 29 25 E7 1C A5 14 59 01 00 14 01 AE 00 69 00 A5 14
 
[Alt female tactician portrait]

Femtact variation2
Feditor Portrait index 04
Unpromoted palette offset: 10000F0

10 A0 00 00 00 55 53 FF 7F FF 6B 1F 4B 00 2E 19 9D 1B BD 73 18 5F 00 BD 73 18 5F 6B 39 78 77 00 B1 62 AA 41 E6 24 A5 14
 
 
Instructions:
[spoilers]

All you'll need to insert these is a copy of feditor and HxD (or your hex editor of choice).
To insert the portraits open the rom with feditor go to the portrait editor and then go to the index of the corresponding tactician. Once there just load the portrait, apply, save the rom and your set.
For the battle palettes open the rom in your hex editor, copy the palette hex listed here and paste overwrite the current version(ctrl+b in HxD.) and save. Then you'll be ready to play the game with your choice of tactician.

[end spoilers]

Credits:WIP

An important note, for some reason the rom will lock in the Chapter 13 endscene on every emulator that I know of besides VBAM. We tried figuring it out but no luck.

So if you do want to play or are in the middle of playing, use or switch over to VBA if you can/haven't already.

Leave feedback on story, characters, maps units anything!

Find any bugs? Post em!

Make your own tacticians for people to use or just show them off.

Vote in the poll for your favorite character, as a combatant or otherwise.

Just remember to have fun!

EN: https://serenesforest.net/forums/index.php?/topic/66048-fire-emblem-order-of-the-crimson-armfinalversion10-out/
To see screenshots and portraits, go here.