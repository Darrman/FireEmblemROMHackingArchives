This patch effectivley removes the requirements to enter Chapters 6x, 12x, 17x, and 20x. In other words, you can get those gaiden chapters without doing anything special. No more killing off your units!

Apply this patch with XDelta3 to a U.S rom of Fire Emblem Shadow Dragon.