Instructions:
-Download Microsoft .net 4 if you haven't already (https://www.microsoft.com/en-us/download/details.aspx?id=17851)
-Download the xna framework (https://www.microsoft.com/en-us/download/details.aspx?id=20914)
-Run oalinst.exe if you haven't already (provided in the download)
-Open SoA.exe
-Enjoy the game!

For a list of bug fixes in this version and what's still not fixed, go here: https://docs.google.com/spreadsheets/d/1copYYMBjO5hrobuSi00Tpo5jdpQM7AXa3kLUAntbStU/edit?usp=sharing

Known Issues:
-Music doesn't play during the pre-chapter rally in 1-F.
-All battle palettes are not in.
-Some map palettes aren't done and use a default FE7 map palette instead.
-Some map sprites have incorrect colors once they're greyed out after acting.
-Many skill icons are using placeholders for now.
-Javelin and Hand Axe animations are not in the game and will be added in a future update.
-Rankings for chapters are currently not implemented and will be added in a future update.
-Some skills don't have their flavortext description.
-Hardmode isn't balanced, tested, or properly set up, don't play it.