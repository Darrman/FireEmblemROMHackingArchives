README Ver 0.1

DO NOT SUSPEND/RESUME WHEN PLAYING THIS HACK. THERE IS A SAVE POINT YOU CAN USE.

Suspending and resuming while at the bar will cause the 5th customer to despawn for some reason, the player should always get 5 customers total.

Currently there are 33 unique customer events in the game.
5 events occur during each playthrough.

I do not own any of the music in this hack.

-JacobTJP