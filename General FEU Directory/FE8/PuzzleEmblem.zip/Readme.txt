Apply to FE8U
This is a puzzle hack- you are meant to think through to the solution, and should not need to "get lucky".
Note that there will be non-zero combat.
Spoiler.txt lists all the puzzles that you will need to have solved by the end(note that just naming some of them may be a bit of a spoiler, hence the name). It also includes hints for a couple of puzzles.
Game mechanics follow the FE8 engine (with some skills thrown in), but some knowledge of FE7 is required.