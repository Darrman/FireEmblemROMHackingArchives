Sun God's Wrath Complete Release.

This is the complete release of Sun God's Wrath, which covers the full 27 chapters of this hack. There are no gaiden chapters and no further planned chapters.


How to patch:

Apply the UPS patch to a clean FE8 Rom using NUPS/any UPS patching program.

Instructions on how to patch a rom can be found here: http://serenesforest.net/forums/index.php?showtopic=349

Please remember to read the credits. Feedback is always welcome.


Known Glitches/Errors:

1. If a halberdier doubles for zero damage, the game seems to freak out for a bit and then returns to normal.

2. If a battle animation by some odd chance freezes, just exit, resume the chapter, and skip the animations by holding the GBA L button

3. Multiple mugs have odd pixels when blinking

4. In chapters 24 and up, in the preperation menu, depending on the amount of characters you have recruited and their class combinations, there can be an issue where their standing map sprite isn't working properly. This is a purely cosmetic issue. The best way to fix this is to make sure you have at most 4 combinations of two characters sharing the same standing map sprite.

5. The support room also suffers from the above

6. There may occasionally be an issue in the item menu where a character's name gets displayed in a place holder where
no character exists. This is purely cosmetic.

7. If animations are off, there is a cosmetic only issue when a unit gets a boost to their con or movement

8. If you engage in a support convo with a mounted unit and try to canto away, the conversation will repeat. You can only
attack or wait.


Gameplay changes:

1. Skills have been added in. Skills are both class and character based and are gained on level up and class change.

2. Units now have a con and move growth.

3. Growth rates are affected by the units current class. Promoted classes have worse growths than unpromoted ones, generally by a factor of 60% total.

4. Staff weapon level is set based on class and does not grow.

5. Growth altering hold items exist (crusader scrolls). See their item description to see the bonus they give.

6. A unit may promote once they reach level 10. Upon promoting, their level does not change. 

7. The level cap is now 30.

8. Units now get various bonuses depending on their weapon level. These bonuses are dropped when a unit has a weapon triangle disadvantage.

9. Hold L to skip battle animations. Try using this if you run into a bug with the animations

10. You can view a units growth rates on the stat screen by pressing L (or R, but pretty sure it's L)

11. Weapon level bonuses are as follows:

Swords:

C: +1 Str

B: +2 Str

A: +3 Str

S: +4 Str, 5 Crit

Lance:

C: +1 Str

B: +1 str, 5 crit

A: +2 Str, 5 crit

S: +3 Str, 10 crit

Axe:

C: +5 Hit

B: +10 Hit

A: +1 Str, 10 hit

S: +1 Str, 10 Crit, 10 hit

Bow:

C: +5 Crit

B: +1 Str, +5 Crit

A: +2 Str, +5 crit

S: +3 Str, +10 crit

Anima:

C: +1 Str

B: +1 Str, 5 hit

A: +2 Str, 5 hit

S: +2 Str, 15 hit

Light:

C: +5 Hit

B: +5 Hit, 5 Crit

A: +10 Hit, 5 crit

S: +10 Hit, +15 Crit

Dark:

C: +1 Str

B: +2 Str

A: +3 Str

S: +5 Str

12. The weapon Triangle is greatly altered. 
Bows are always advantageous against magic and have better bonuses when attacking a magic user. The bonuses given depending on which weapon is weak in the triangle is also changed.

13. The exp formula is much stricter.

14. HP bars and icons indicating enemies have effective or high crit weapons now show up

15. It is possible to check enemy range.

16. You always crit when you kill a boss

17. When a unit promotes, they learn their class line skills a few levels later.

18. Support bonuses have changed. They are as follows per level:

Fire: +1.5 attack, +2.5 hit, +2.5 crit avoid
Thunder: +5 Hit, +2.5 avoid, , +2.5 crit, +2.5 crit avoid
Wind: +5 hit, +5 avoid, +2.5 crit avoid
Ice: +1.5 defense, +2.5 avoid, +2.5 crit avoid
Dark: +1 attack, +5 crit, +2.5 crit avoid
Light: +.5 attack, +.5 defense, +2.5 hit, +2.5 avoid, +2.5 crit avoid
Earth: +1 attack, +1 defense, +2.5 crit avoid

19. Pursuit critical has been implemented. When a unit is using a double attack, their critical rate is increased
by their pursuit critcal coefficient for the second attack. This value can be found under a unit's weapon level. So a unit with a PCC of 3 and 10 critical will have 30 critical in their pursuit attack.

20. Capture: Capturing enemies is now possible. To do so requires having more aid than the foe's con. You can only capture at 1 range. You cannot capture mounted or enemies with the watchful skill. Sleeping enemies or those with no equipment are not automatically captured. Once you've captured an enemy, you can trade their items to your units. After you've traded a captured foe's inventory, you can release them.[A][N]


21. Fatigue has been implemented. When a unit's fatigue goes over their durability (see under their weapon level) they cannot be deployed next chapter

22. You can always use mercy against enemies to assist in capturing.

23. Adept, Aether, and Astra do not consume extra weapon uses.

24. When a unit is silenced or slept, they cannot recover from the status without a restore staff or the chapter ending. Bosses cannot be slept or silenced.