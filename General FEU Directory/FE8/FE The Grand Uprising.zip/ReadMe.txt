WARNING:this list consist of assests that I've used from the community or am planning to use. It's a big list so I might've missed out on
potential crediting for some assests in my hack. If that is the case message me on FEU privately and I'll fix it ASAP.
If I misuse a assest Dm me so I can remove it. Thanks for reading!

repalette animations-eldrict animation
Sword troboudour-Is,TBA (emblem anims)
Teraspark,Sme,Lisandre_Brave,Flasuban-Eirika repalette
Leo_link,Nuramon,iscaneus for baron cape
zRobertFPY, Dinar87-trueblade custom animation
Pikmin1211, Maiser6, Lisandra_Brave, TBA-troubadour repallete custom animation
Red Bean, Zelix-Echidna custom animation
DerTheVaporeon, Nuramon, Greentea-Linus animation
Iscaneus, Leo_link-myrmidon Animations
Memae, Skitty, BwdYeti, MeatOfJustice-valkyrie
Mercenary Lord, NYZGamer, Pikmin1211, Maiser6-Dragoon v2 animation
Jj09, Furious Squid-F alt pirate
MK404-Ds knight
Nuramon-zelgius animation v2
Leo_link, Nuramon, Iscaneus-baron cape+weapon
team SALVAGED-cavaliers
Luerock, Pikmin1211-holy sage
Eldritch Abomination, Shin19-generic necromancer
Team salvaged for cavalier,mercenary.
Shin19 fixed helmless shaman
Mikey Seregon-arcwind
Sme-bakuretsu
SHYUTER-fe6
Harbedir 1.0 redesign-Jj09
ltranc Greentea and robertfpy-Swordmaster karel
mikey_seregon-Skill procs
map sprite:DerThevaporeon,BaltimatheBat
strong shoutout to team SALVAGED,dervaporeon,{Ash3wl, L95},{Smug_Mug, Unknown},NYZgamer3,pikmin1211,aruku,kepuhu,n427fegirls and flasuban for map sprites
Some portraits assets credits:
Melia
Tobiki
Melia fe4/5 portraits edit
Smokeyguy77
serif
DerTheVaporeon
Random Wizard
Zoisite
Joerge_reds-cordelia portrait
meatofjustice
HyperGammaspaces
LaurentLacroix
Imperial
P33RL355
Class cards:RobertFYB,L95,Flasuban,Dervaporeon,L95,CamusZekeSirius,Female Druid(uknown),
Febuilder assistance credit:
7748 
FEU discord
Weapon Icons:
Feier
Valak
2WB
Zelix
From Sacred war
lordglenn
Music credit:
Pongball for the Smiles and Tears MIDI from VGMusic
Sme for the FE12 Calamity Ganon theme, Rickard theme, FE3
Theme of Love and Twilight Princess shop theme
http://nehcdnr.ngamer.net/music/midi2.html for the FE5 Advance B, & FE5 Army A MIDI
SaXor_the_Nobody for the Arvis battle theme, March, Durant Sortie,FE 11 music
Leaps and Bounds, Fateful Showdown, and The Devoted tracks
Alusq for Dwelling of Doom, AR2 ~ Deception, 
Shattherhand ~ Boss, and FE12's Endless Battle
Agro for the Knight's Pride MIDI
Tamborrino for the FE5 World Map B track and Anthem of Valor
Brutal Mario for the Romancing SaGa 2 final battle theme (MIDI ripped from the game)
Dethraxx for his Black Knight music
http://www.angelfire.com/ny3/firemblem/Music.htm for the When The Rush Comes
and Light Inheritors MIDIs
Tristan Hollow for the FE6 battle theme and Chrono Trigger Battle 2 tracks
Join Us, Kingdom of Bern, Another Assault and Winning Road themes
A Reliable Chair for Pokey Means Business (both parts) and Attaque!
CCMonger of VGMusic for the FE2 Final Map MIDI
DerTheVaporeon for the FE4 Arena theme
Lucio2 of ChinaFE for the Air of Brutality MIDI
Cobacapy of Musescore for the Justice RIP MIDI
Daniel Lawrence of VGMusic for the Ascent MIDI
Pikmin1211 for the Heaven's Gate, FE16 Main Theme, and Battle Against Demons track
DerTheVaporeon for the Fon Rosso theme
The MIDI Shrine Archive for the Corneria MIDI
CharaGunner of Musescore for the SSBU Menu Theme
King Meteor of VGMusic for the Encounter MIDI
MIDIShrine Archive for the Felix Battle theme
Mother 3 Ultimate Music Repository for the It's Over, Love Theme, & Memory of Life MIDIs
Erik of VGMusic for the Lower Brinstar theme
Tyler Prevost of VGMusic for the Puppet Ganon theme
GratedShtick for Dialga's Fight to the Finish!
hypergammaspaces for the FE2 boss theme (Warring Powers)
Yggdra patch for Destiny
Deltre for As Swift as Wind
The Minstrel-Mensch of Musescore for In The Battle ~ Destiny
TheBruce of VGMusic for the Zelda Overworld MIDI
Ashton Henry II of Musescore for God-Shattering Star
SHYUTERz-Ereshkigal animation
mikey surgeon-Thoron Glacies and golden sun fe magic spells
HUGE shoutout to A_Reliable_Chair for Musics of castlevania.
Gratedsticks for alder's theme
Gratedshtick-FE12 liberation
SMe for pokemon black route 10,bloody tears castlevania,Fe songs inserted to GBA such as FE9-with us and for custom songs
huge credit to Runa/unuesu custom music in Music repository.
Map tilesets:
Wave
Zoramine
Nathan
Sme
Venno

