#What this is

This is a demake of Fire Emblem Echoes: Shadows of Valentia on the GBA. It includes reworked maps and a few new characters, as well as a few changes to the writing and game mechanics, Otherwise, it is largely faithful to the original games. The base game is FE8U.

Specifically:

- All weapons are unbreakable.
- Magic costs HP to cast. Cost is based on WEXP value.
  - When out of HP to cast a spell, that spell is disarmed until HP is restored enough to cast it.
  - Unit HP is updated visually when casting spells with cost.
- Hit and Avoid calcs are adjusted to mirror Echoes calcs.
  - Magic has fixed hitrate and is not affected by Skill or terrain
  - CON no longer factors into weapon weight/AS calcs - a Steel Lance will slow the user by 1 point no matter who uses it
  - The doubling threshold is now 2 AS instead of 4 AS.
- The Weapon Triangle is in effect for equipped weapons (so a Sword has no disadvantage against a Lance, but an Iron Sword has disadvantage against any type of Lance)
  - The Soldier line gets access to additional weapon types as it progresses. (Promotion to Knight adds Axes, and promotion to Baron adds Swords)
- Promotion brings units up to the new class's bases rather than giving promo gains
- Promotion is no longer item based but is done through the Mila option in the menu when they reach promotion level, and when the unit is standing next to a Mila statue on the map. Mila statues are available in repeatable dungeon maps which you can replay as needed (Thief Shrine, Deliverance Hideout, and Seabound Shrine). You will see a notification when a unit has reached the level they can promote at, and the unit will have a Mila icon beside their name on the statscreen.
  - Class promotions become available at the same levels as in SoV. Female archers (not present in SoV) follow the same promotion levels as male. The playable Thief class promotes at level 14.
  - As in Gaiden/Echoes, Dread Fighters can promote back into Villager, so units in the Mercenary class line can be further customized.
  - Additionally, the Priestess class that promotes from female Mages can now promote into a magic-wielding Dread Fighter. Female Dread Fighters can also reclass into female Villagers.
- Villager classes can promote into any of 5 first-tier classes
  - Villager_F: Cleric, Peg Knight, Mage, Cavalier, Archer
  - Villager_M: Archer, Mage, Soldier, Cavalier, Mercenary
    - Battle palettes have been expanded to cover full promotions for each branch.
- Units learn spells at particular levels rather than spells existing as inventory items
  - Invoke can be used to summon multiple units onto the field.
  - Warp/Rescue use their GBAFE ranges. (Mag/2)
  - Expel has been buffed to 100% accuracy but only affects monster classes. It will destroy enemies in Mag/2 range which are of a Monster class type.
  - Promoted magic units will learn their whole unpromoted spell list. (This is why Mage/Cleric promotion levels are so high)
- A (mostly) working world map that you can explore.

Optional QOL fixes to GBAFE are included:

- Includes Talk and Support Fixes that don't end the unit's turn
- Includes HP bars and effective weapon notices on the map
- Includes danger zone highlighting with Select button
- Includes battle stats with animations off (with a UI inspired by the original Gaiden battle frame)

#Promotion levels

When a unit is at or above this level while in one of these classes, they can promote when standing next to a Mila statue. The Thief class (not in SoV) promotes to Rogue. The Priestess (non-Celica) can now promote to Dread Fighter.

- Level 3: Villager
- Level 7: Cavalier, Mercenary, Archer, Soldier
- Level 10: Paladin, Armor Knight, Myrmidon, Dread Fighter, Sniper
- Level 12: Mage (M), Priestess (non-Celica), Pegasus Knight, Cleric
- Level 14: Thief, Mage (F)
- Item promotion only: Alm, Celica

#Spell lists

Spell lists are largely the same as SoV.
- Gray:
  - Lv1 Fire
  - Lv9 Sagittae
  - Lv10 Thunder
  - Lv1 (Sage) Heal
  - Lv6 (Sage) Unlock
- Tobin
  - Lv1 Fire
  - Lv6 Excalibur
  - Lv1 (Sage) Heal
  - Lv5 (Sage) Physic
  - Lv8 (Sage) Torch
- Kliff
  - Lv1 Fire
  - Lv4 Thunder
  - Lv9 Excalibur
  - Lv15 Sagittae
  - Lv1 (Sage) Heal
  - Lv5 (Sage) Aura
- Faye (Cleric)
  - Lv1 Nosferatu
  - Lv1 Heal
  - Lv6 Physic
  - Lv10 Rescue
  - Lv1 (Saint) Seraphim
  - Lv14 (Saint) Anew
- Faye (Mage)
  - Lv1 Fire
  - Lv8 Seraphim
  - Lv12 Sagittae
  - Lv1 (Priestess) Heal
  - Lv6 (Priestess) Freeze
- Silque
  - Lv1 Nosferatu
  - Lv1 Heal
  - Lv7 Warp/Rescue
  - Lv14 Expel
  - Lv18 Invoke (DF)
  - Lv1 (Saint) Seraphim
- Celica
  - Lv1 Fire
  - Lv5 Seraphim
  - Lv8 Thunder
  - Lv9 Heal
  - Lv15 Excalibur
  - Lv20 Ragnarok
- Mae (Mage)
  - Lv1 Fire
  - Lv1 Thunder
  - Lv9 Aura
  - Lv14 Seraphim
  - Lv1 (Priestess) Heal
  - Lv6 (Priestess) Silence
- Mae (Cleric)
  - Lv1 Nosferatu
  - Lv1 Heal
  - Lv9 Aura
  - Lv14 Seraphim
  - Lv1 (Saint) Physic
  - Lv6 (Saint) Silence
- Boey
  - Lv1 Fire
  - Lv3 Thunder
  - Lv12 Sagittae
  - Lv18 Excalibur
  - Lv1 (Sage) Heal
  - Lv6 (Sage) Unlock
- Genny
  - Lv1 Nosferatu
  - Lv1 Heal
  - Lv4 Invoke (Soldier)
  - Lv8 Physic
  - Lv12 Expel
  - Lv1 (Saint) Seraphim
- Saber
  - Lv1 Fire
  - Lv5 Seraphim
  - Lv1 (Sage) Heal
  - Lv5 (Sage) Physic
  - Lv9 (Sage) Unlock
- Kamui
  - Lv1 Fire
  - Lv7 Excalibur
  - Lv1 (Sage) Heal
  - Lv5 (Sage) Freeze
  - Lv9 (Sage) Torch

#Known issues

This is not a complete release by any means, so there are a few bugs which had to be deprioritized for this release. Everything we surfaced that could be potentially game-breaking has been covered, but there may still be some we aren't aware of.

- Suspending a chapter and restarting it without resuming may cause certain world map paths to disappear. If this happens to you, just reset and choose "Restart Chapter" and it will fix itself. A permanent fix is still being looked into.
- There is no indication from the world map which locations are repeatable. A custom icon is planned to indicate this in the next release. For now, if you enter a repeatable map without meaning to, just choose "Retreat" from the system menu once the battle starts.
- Alm and Celica share a convoy, this will be split in later releases if playing on Normal or Hard.
- The game has only been balanced for Normal mode (hard mode results may vary). It is recommended to only play on Normal for now.
- Some support conversations have been implemented while others are still placeholders.
- Some sprites and animations have not been finalized yet and are using placeholders. (Priestess (Generic), Sagittae, Seraphim)
- Expel is visually kind of buggy but should not affect gameplay.
- Anew is not implemented yet (still works like Latona from FE8)

#Credits

- Circleseverywhere’s Modular Stat Screens and everything2ea modules
- macplustrees’ base-stat promotion gains
- Teraspark’s staff/item range rework
- Assorted small tweaks and patches by Stan, Tequila, Crazycolorz5, Vennobennu, Leonarth, 7743 and aera
- Music hacking utilities by Sme and Alusq
- Music arrangements based on Echoes OST and on Gaiden MIDI remixes by 雨原
- NGMansion for save expansion patch
- Battle Animations: 
  - Alm, Villagers, Dread Fighter, Gold Knight and Cape General by Nura
  - Soldier by Alusq
  - Armor Knights by Team SALVAGED
  - Caped Baron by Iscaneus, Nuramon and Leo_Link
  - Saint by Melia
  - Myrmidon/Hero by Wan and Zane
  - Cavaliers by Team SALVAGED and Flasuban
  - Paladins by Team SALVAGED (female edit by me)
  - Rogue Repalette by Pikmin1211, Maiser6, Ukelele, SD9k, Temp, Black Mage and Wan
  - Battle Sage (F) by St.Jack
  - Bow Knight by Spud
  - Celica by RedBean
  - Mercenary Repalette by Dancer_A
  - Witch by Luerock and Pikmin1211
  - Woodcutter by Waleed and Flasuban
  - Axeman by DerTheVaporeon, Aruka, Kenpuhu
  - Barbarian by Orihara_Saki (Bow edit by me)
  - Pegasus Knight by OreoStyx
  - Falcoknight by TBA
- Map sprites and class cards by flasuban, Tordo45, Alusq, Melia, Nura, Pikmin1211, Seal, L95, and Team SALVAGED
- Battle palettes by Hypergammaspaces and Dancer_A
- LordGlenn's Cipher icons for weapon ranks
- Cardcafe’s Echoes item icons and FEier's Weapon icons
- Snakey1's REDA helpers, MSS fixes and event cleanup
- RandomWizard for text formatting help
- Pikmin1211 for eventing and enemy placement on "The Warship" and "Zofia Harbor"
- ZoramineFae for "The Warship" map
- Sme for assistance with summoner AI
- Vennobennu's Improved FE8 Boat/Village Tileset
- DerTheVaporeon's improved cave tileset

Please let me know if I missed anyone.