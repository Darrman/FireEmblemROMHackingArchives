THE FIGHT FOR FREEDOM README

Day of Release: Aug, 16, 2020
Current Release: V1

Credits:

Maps:
The Iron Fortress(MrGreen3339)
Death Mountain)MrGreen3339)
Some Maps(FE Universe Map Directory)

Music:
The Knight's Pride(Agro FE Universe)
Lower Brinstar(MrGreen3339)
Final Map Gaiden(MrGreen3339)
Anthem of Valor(MrGreen3339)
Verdane Army(MrGreen3339)
Attack(MrGreen3339)
Defense(MrGreen3339)
Battle Preparations(MrGreen3339)
FE6, FE7 & FE8 Music(Nintendo)
Castlevania Music(FE Universe Music Directory)

Portraits:
FE6, FE7 & FE8 Portraits(Nintendo)
George(MrGreen3339)
Evius and Other Characters(Portrait Directory FE Universe)

Dialogue:
Myself


Social Media:
YamiEvius on Discord
Join my Server Here:https://discord.gg/XFg7jAu
Followe Me on Twitter:https://twitter.com/yamievius1706
Facebook:https://www.facebook.com/FlaynFF/

