Thanks for downloading my hack.
I appreciate any and all feedback.

Credits
7743 for making FE Builder, without which I wouldn't have had a clue how to do any of this.
Circles for various patches that make GBA fe a lot more enjoyable (skills, HP bars)
Everyone who submits to the resource blitz's so that I can shamelessly steal stuff.
Animations
The Blind Archer for the female merc animation
Alusq for the armoured mer animation
MageKnight404 for the Tellius fighter animation
Black Mage for the female fighter animation
Deranger for the hunter animation
Primefusion for the axe and sword cav animation
Music
SME for his port of FE3 music into Midis

LaurentLacroix for the portrait bases for Amea, Liara, Talshin, Reath
GabrielKnight for the portrait base of Belth
BorsDeep for the portrait base of Keale
Nickt for the portrait base of Lera
Blade for the portrait base of Uthil
DerTheVaporeon for the portait base of Breya
Also my portrait for Carmine borrowed heavily from Wayland from Order of the Crimson Arm. If this is a problem just let me know, and sorry in advance.


Minor bugs
Opening lore text glitches out, but is fine if you restart the chapter.
The npc placement on chapter 2x (Regroup) bugs out if you press start to skip the event.
Saiban in the opening chapter, because I'm not sure how to have chapters without the lord unit.
If the first boss of chapter 3 isn't killed quick enough then the other boss just stands on him.
