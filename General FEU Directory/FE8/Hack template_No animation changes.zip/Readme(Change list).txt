Note: Some weapons haven't been added or changed.
The main point of this ups is for feedback for changes. No actual maps have been changed, or animations added.

List of changes applied summarized:
-Multiple changes to classes and weapons.
-Additional classes and weapons.
-S rank weapons are now A rank.
-S rank provides larger bonus to compensate, and a unit can have multiple S-Ranks.
-Skill now effects Attack Speed. Fomula is Con + Skill / 4.
-Ballistas are gone.
-Changes to Weapon Triangle effectiveness and affinities.

List of planned ideas:
-All villages will give items, but the roof color will determine the rarity of the item, with red have rarer items than green.
