Applying UPS Patch:
1. Download a UPS patcher such as NUPS
2. Apply Fire Emblem_LonelyMirror_v1.0.ups to a clean Fire Emblem Sacred Stones ROM.
3. Play.

Compatible Emulators:
- Visual Boy Advance 2.0.2 (preferred)
- mGBA 0.7.1
