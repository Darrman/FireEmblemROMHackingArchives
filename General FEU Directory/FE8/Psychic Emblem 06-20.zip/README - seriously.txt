
Welcome to Psychic Emblem, user:BlackLightningXerath's (aka Generic Thunder Mage) first ROM hack. 

I. Introduction
II. Weapon Info
III. Other Dev Notes

--------------------------

I. Introduction

- Besides Staves, each of the other seven weapon types have been replaced with an element. The new weapon types are Fire, Wind, Elec (Thunder), Ice, Anima (Psychokinesis), Light, and Dark.

- Playable classes that are still present are: Priests/Clerics/Bishops, Pegasus/Falco Knights (which use Wind), Wyvern Riders/Lords (wield Fire), and Thieves/Rogues (wield Anima). Journeyman uses Fire, Recruit uses Elec, Pupil uses Anima.

- Lyon's Necromancer class can now use Light in addition to Dark & Staves. 

- The female Lord Eirika wields Elec, and the male Lord Ephraim wields Fire (based on the original lore elements of Sieglinde and Siegmund).

- Besides the ones mentioned above, there are 7 unpromoted and 7 promoted playable classes, called "Psions". Each unpromoted class wields 1 weapon type, and can choose one of two promotion options that grant them an additional weapon type. 

-------------------------------

II. Weapon Info

- The Weapon Triangle is now a "Weapon Heptagon". Each weapon type beats 2 others, and loses to 2 others:
 - [Anima] > Light, Fire
 - [Light] > Fire, Elec
 - [Fire] > Elec, Dark
 - [Elec] > Dark, Ice
 - [Dark] > Ice, Wind
 - [Ice] > Wind, Anima
 - [Wind] > Anima, Light

The reasoning behind this format is largely arbitrary. A case can be theoretically made for any one element beating any other, so instead I focused on making each "opposing" element be neutral to one another (Fire = Ice, Elec = Wind, Light = Dark) (making two weapon types strong against each other causes an awkward player-phase-only effect to occur). Light beats both of the "hot" elements (Fire & Elec) while Dark beats both of the "cold" elements (Ice & Wind). I could have made Anima the "Bow" weapon that's neutral to everything, but I thought things would be more interesting if I shoe-horned it right in the middle this way.

- THERE ARE 10 E-THROUGH-A-RANK WEAPONS WITHIN EACH WEAPON TYPE: 5 PHYSICAL AND 5 MAGICAL. Physical weapons have only 1-range but are stronger and lighter than their Magical counterparts, while the Magical weapons have 1-2-range. 

- Within each element, both E-rank Physical & Magical weapons have the same sprite, and both D-rank Physical & Magical weapons have the same sprite. However, every C-through-A-rank weapon within a single element has its own unique sprite. All Physical weapons have red pages and all Magical weapons have blue pages (yes they're tomes).

- Besides Sieglinde, Siegmund, and the Latona staff, there is a Legendary weapon for each of the 7 weapon types. All of them have white pages in their sprites, deal Magical damage, have 1-2 range, and deal effective damage vs monsters. 8 mt and 12 weight each, by the way.

- Besides the Legendary weapons, all other weapons have no additional effects and have infinite durability (this is my first hack so I didn't want to go overboard by including any Killing Edges, Reaver weapons, effective-damage weapons, Nosferatu/Luna, or siege tomes). I put a lot of effort into ensuring that the game is actually somewhat challenging (by FE8 standards) in spite of infinite weapon durability, and I balanced all of the weapons' stats & prices, as well as enemy stats & growths, as carefully as I could to compensate for this. That being said, enemies are stronger in this hack than they are in vanilla FE8.

-------------------------------

III. Other Dev Notes

- I added my own custom spell animation for D & C ranked Elec weapons.

- The Arena is disabled because, even though I believe I could get it to work, I was too lazy to actually test it in-game and just kind of decided it to leave it out.

- I SWEAR this is an FEBuilder bug because I checked every possible manner in which I could have made an error somewhere, but for whatever reason the Secret Shops are now inaccessible from the World Map. All three in-chapter Secret Shops now stock the same wares to make up for that.

- All story dialogue is unchanged. This includes mentions of the Legendary Weapons ("the Black axe Garm..."; "the Serpent bow Nidhogg..."), even though they do have new names. I know, it's extremely easy to change story dialogue but I figured, hey, you're not playing this hack for the story. Just ignore it.

- Because Brigands have been replaced in this hack, and that I still need certain enemies to walk over mountains, each of the 14 "standard" classes now have exactly 1 movement over mountains. From my playtesting experience this has not impacted gameplay too much, and in fact the defensive bonuses from mountain tiles might just be necessary for the player to exploit at some points.

- Unmounted units can SHOVE in this hack and fliers can use Reposition. For some reason, Joshua can't be shoved and I don't know why. 

- Almost every playable unit has had their base stats & growths tweaked, since the 14 "standard" classes have all-new class bases. Now, no one has a growth% below 25% in any stat. 

- Knoll in particular has been buffed considerably and let me explain why: compared to the other combat units who join at the same time or shortly before he does (Dozla, Gerik, Innes, Saleh, Duessel), Knoll's bases are kind of sad and his growths aren't exactly Est-level either. I believe the reason for this is because Knoll is the only unit besides Ewan, who also sucks, that can become a Summoner. Summoners aren't in this hack (Necromancers can still summon though) so there's no reason for Knoll to stay bad. Also he's my favorite character.

- KNOWN VISUAL BUGS: 
(1) For some reason Thieves and Rogues can move more spaces than their Movement stat should allow them to. If you try to exploit this by moving them too far, the game might freeze & crash.
(2) Promotion screen for Journeyman is glitchy but it still works. May also be the case for Recruit & Pupil. 
(3) Blank passage of text, namely when attacking an enemy with no equipped weapon (like priests), will appear as a long string of s's ("ssssssssssss"). 

- At the time of releasing this hack I have playtested Eirika's route but not Ephraim's. There MAY be one or two enemies in the campaign that are mistakenly holding weapons they can't use.





