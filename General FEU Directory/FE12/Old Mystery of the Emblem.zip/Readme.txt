FIRE EMBLEM: OLD MYSTERY OF THE EMBLEM
VERSION 2.0

Mystery of the Emblem is the Fire Emblem that set the course of the series for the next seven games.
New Mystery of the Emblem did make some beneficial changes, but also made some harmful changes that negatively impact on the game.
The primary aims of this patch are twofold.

Aim #1: Compare the FE3 and FE12 scripts and restore all details cut out of the remake.
Aim #2: Remove all lines of dialogue from Kris, the player self-insert.
This applies to the 22 chapters in the original game. All Kris-centred cutscenes in these chapters have also been removed.
Dialogue in the prologue and gaidens has not been touched, aside from some in Prologue 1.
Some scenes have been replaced in order to restore the FE3 tapestry, cut out for Kris worship.

Patching Instructions:
Download an FE12 rom from somewhere.
Apply the patch using an XDelta tool. There's some on Romhacking.net and the FE12 translation has a command line version bundled.
There are a large variety of patches available in this package.
First one of the two base patches should be applied.
"Old Mystery of the Emblem.xdelta" is applied to a clean Japanese rom.
"Old Mystery English.xdelta" is applied to v3.01 of the Heroes of Shadow translation.
The result should be the same either way.

All Kris dialogue has been removed.
Many scenes have been expanded to add missing details.
Terminology has been reverted to the FE3 translation's names.

From there, you can either play the base form of the hack, or apply an optional patch.

NO PROLOGUE:
"No Prologue.xdelta" additionally completely removes almost the entire prologue.
Only Prologue 1 remains, which can be easily completed even on Lunatic difficulty.

NO GAIDENS:
"No Gaidens.xdelta" additionally removes the gaiden chapters from the game.
Even when the requirements have been met, the next standard chapter is loaded instead.

NO PROLOGUE OR GAIDENS:
"No Prologue or Gaidens.xdelta" combines the above patches.
Aside from Prologue 1, the only chapters played are Book 2 of the original FE3.

MORE STANDARD TERMINOLOGY:
Some of the more mundane terms have always been the same as since FE7.
Yet sometimes they differ from the Japanese.
While the base patch has all names as the FE3 names for consistency,
this reverts more common terms to their English equivalents.
Eg: "Social Knight" -> "Cavalier", "Kill Sword" -> "Killing Edge".
Character names are NOT reverted. 

FE3 MECHANICS:
This is a more drastic gameplay change. FE12 completely changes much of the balance.
Most egregiously, some characters lost their personal weapons; Feena and the Rapier, for instance.
This patch pushes some FE12 changes back closer to their original effects.

Changelog:
All weapon stats reverted to FE3 levels. Technical limitations prevent the restoration of weapon weight.
Personal weapons are reinstated. To detail:
	Feena can use the Rapier with Marth
	Yumina alone can use Rescue
	Thief is for Malliesia alone
	Excalibur is now Marich's alone
	Aura is now Linda's alone
Some FE3 item effects are partially restored.
The Life Orb now fully heals, and the Star Orb has had its infinite weapon durability effect restored to it.
It also retains its +2 to all stat bonus, for want of its +30% growth bonus.
Reclassing is a feature that largely removes unit individuality, and has been removed to conform to the game's original balance.

The vastly increased roster has not been pared back.
Features such as How's Everyone are still active.
Supports have not been touched; most FE3 supports are still present in some form in 12 anyway.

Both of the above patches have a form that combines them with "Disable Prologue and Gaidens".

Known Issues:
Graphics have basically not been touched. This includes the guide and chapter titles.
If the prologue has been skipped, then Marth starts with a Large Bullion in his inventory.
This is to compensate for the loss of the prologue gold, which is simply a fixed 10,000 in the original.
With FE3 Mechanics, only the most optimised Krises can kill Jeigan and enter Lunatic.
This is because the Javelin has 5 more might in FE3 compared to FE12.
Mercenaries are capable of victory on most settings.
In addition, most characters get killed in one hit by the brigands in Chapter 1.
The Rainbow Potion is still accessible, so it might be possible to complete...

Additional Notes:
The dragon girl... The forbidden option... The touch screen...
The last version has Belf's name as Vergil for fun.
I've reverted it though, in the interests of seriousness.
Her name is Sheeda and I am not changing it. Deal with it.
I will enclose a copy of the spreadsheet that I have used to compare the FE3 and FE12 scripts.
This covers every scene in FE3. The sheet was created in Microsoft Excel.
Note that base convos have not been touched; Kris still supports the entire cast.

Credits:
Shouzou Kaga: Creating Fire Emblem as a whole.
Original FE3 developers: For developing the original game.
VincentASM and RPGuy: For translating FE3.
The Heroes of Shadow: For translating FE12, and on whose work this patch is based upon.
Nintenlord: For creating the text tools, without which this project would be impossible.
Darrman: Put this hack together.

Have fun!
- Darrman