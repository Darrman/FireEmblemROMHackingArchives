FIRE EMBLEM: OLD MYSTERY OF THE EMBLEM
VERSION 1.0

Mystery of the Emblem is the Fire Emblem that set the course of the series for the next seven games. New Mystery of the Emblem did make some beneficial changes, but also made some harmful changes that negatively impact on the game. This patch aims to retain the more beneficial additions while reverting the harmful ones.

Instructions:
Download an FE12 rom from somewhere.
Apply the patch using an XDelta tool, there's some on Romhacking.net and the FE12 translation has a command line version bundled.
"Old FE12.xdelta" is applied to a clean Japanese rom.
"Old FE12 Eng.xdelta" is applied to v3.01 of the Heroes of Shadow translation.
"No Prologue.xdelta" just applies the removal of the prologue. It should be applied to an English patch.

Apply

Changelog:
All weapon stats reverted to FE3 levels. Technical limitations prevent the restoration of weapon weight.
Personal weapons are reinstated. To detail:
	Feena can use the Rapier with Marth
	Yumina alone can use Rescue
	Thief is for Malliesia alone
	Excalibur is now Marich's alone
	Aura is now Linda's alone
Some FE3 item effects are partially restored.
The Life Orb now fully heals, and the Star Orb has had its infinite weapon durability effect restored to it. It also retains its +2 to all stat bonus, for want of its +30% growth bonus.
All class caps are now 20 across the board, even after promotion. Enemies also comply to this.
Character, class, and item names are taken from the original Mystery of the Emblem patch by VincentASM and RPGuy in place of the Intelligent Systems and Heroes of Shadow names. Heroes of Shadow names retained for items absent from the original.
Missing dialogue is restored to the game: most notably, the fact that Adrah, the first king of Akaneia, was just a common thief. The stories of Anri's Saga are no longer relegated to base conversations.
Kris has been removed from all main story scenes, and additional FE12 scenes focusing on them have been removed in their entirety. A known issue: the screen fades in and out where removed scenes once were.
Reclassing is a feature that largely removes unit individuality, and has been removed to conform to the game's original balance.
The prologue was an unnecessary tutorial, and it has been largely removed. The first chapter remains for technical limitations, and its story has been replaced with FE3's original opening cutscene, which is absent in the remake.

Known issues:
Some character names are too long and overflow.
Some item names are in CamelCase as there is no documentation with Nintenlord's FE12 Text Tool that details how they are input, and they glitch out when they are extracted.
Marth starts with a Large Bullion in his inventory to compensate for the loss of the prologue gold, which is simply a fixed 10,000 in the original.
Only the most optimised Krises can kill Jeigan and enter Lunatic due to the Javelin might increase. In addition, most characters get killed in one hit by the brigands. The Rainbow Potion is still accessible, so it might be possible to complete...

Easter eggs:
Chiki *can* reclass. It's untested though.
A certain new addition had his name tweaked.

For those curious on what script revisions took place, refer to "script changes.log".
Have fun!
- Darrman