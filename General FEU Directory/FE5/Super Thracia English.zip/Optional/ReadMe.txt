All these patches are applied the same way as the Super Thracia translation BPS patch. They are all compatible with each other, unless specified otherwise.

* SuperThraciaEnglish IPS is an alternate way of patching your game, if the tool you are using does not support BPS patches.
Only use this if you are 100% sure that you are patching the right rom, as this patch will not check if you have the correct one.

The other patches are smaller, optional changes that must be applied AFTER patching with SuperThraciaEnglish.BPS.

---------------------------------------------------

Difficulty and Gameplay patches:

* 24x Access places a Kaia staff in Ishtar's inventory in chapter 24, so that you may access to 24x.
The chapter is perfectly functional but otherwise inaccessible without cheats.

* Double WEXP gives you twice as much weapon and staff EXP for all characters.
It's for if you have a problem with ST's difficulty and want to give yourself a small edge.

* 0% Growths makes all character growths and scroll growth bonuses 0.
It's for if you have a problem.

---------------------------------------------------

Interface and QOL patches:

* HP Bars is one of the quality-of-life patches made by Zane Avernathy. This displays HP bars on the map for damaged units.
Be aware that if many HP bars are displayed at once, especially in a single row, some sprites may disappear.
This minor glitch is the reason this was not included in the base patch, but if this is no bother to you, go ahead and patch it in.

* HP Bars - Colorblind-friendly
This adaptation of Zane's HP bars changes the green-red HP bar to a green-black bar.
However, to make this work, one small graphic had to be sacrificed. The cursor for Window Color options looks a bit weird now, but the settings still function as intended.
Only apply either this patch, or the regular HP Bars.

* Top-Wait.
In Lil' Manster and Super Thracia English, commands have been re-ordered to match with the command order of more recent FE games. For instance, the Wait command is located at the bottom, rather than near the top.
If this is not to your liking, this "Top-Wait" version keeps the original game's command order.

* WEXP Display
This shows the amount of weapon EXP above a character's current weapon rank. For example, a character with 120 Sword WEXP will show "C 20" next to the Sword icon.

* Visual Relief
This changes the visuals of chapter 8 and 11x to reduce visual strain.
Chapter 8's map is no longer 95% pure white, and instead has a snowy palette.
Chapter 11x's maze is no longer 95% pure black, and instead uses the castle interior tileset.
Dead-ends use a darker tiling, and there are five floor markers gently nudging you in the boss's direction.

---------------------------------------------------

Preps change patches:

* Unit Ordering Patch by Robert of Normandy: https://forums.serenesforest.net/index.php?/topic/52223-thracia-776-unit-ordering-patch/
This patch allows you to pick the order of your units on the Deploy screen. Just like in Mystery of the Emblem, if you pick your units, then exit the menu, the units you selected will be at the top of the list when you come back. 

* Unit Rearrange Patch by Min
This does the same as Robert of Normandy's patch, but also displays units on the map during preparations for you to swap with the Y button, similar to most modern FE games.
Before units start showing on the map, you need to enter the Deploy or Items menu first. Mounted units won't dismount in indoors maps until preparations are complete.
This patch is VERY incompatible with the Unit Ordering patch, so pick one.

While these two latter patches alter the gameplay and make some maps quite easier, they also allow you to ignore one of Thracia 776's more annoying features.
And I mean, it's not like it's going to trivialize Super Thracia, either.
