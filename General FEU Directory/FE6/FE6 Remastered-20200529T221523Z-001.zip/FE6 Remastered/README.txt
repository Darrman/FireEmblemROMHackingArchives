This is the Fire Emblem 6 Remastered UPS Patch!

This patch gives some characters higher growth rates.
This patch buffs all weapons and magic.
This patch includes two new playable characters.
Thea/Tate removed for New Character 1.
Second New Character not removed but exists in Vanilla Version of FE6.

To patch Open NUPS, then select patch a ROM, 
then select your ROM and Patch and press Patch!

Any further question at:

aevan992@gmail.com 
The Dark Emperor(Serenes Forest)