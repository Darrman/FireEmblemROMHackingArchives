How to play: Use NUPS or another UPS patcher to patch the file onto a clean localized FE7 ROM. Hit "ignore" if necessary. If it still doesn't work, contact me (info listed at the bottom).

BACKGROUND~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Carcino's Civil War is a FE7 ROM hack that takes inspiration from Fire Emblem 8: The Sacred Stones. It takes place in Carcino, the growing mercantilist country, 3 years prior to the events of FE8. You will follow Gerik's mercenary crew as he quickly becomes involved in a plot of deception, politics, and manipulation.

This hack has achievements. Collect at least 5 to unlock a final bonus chapter. I recommend screenshotting them when they are stated at the beginning of the chapter so you don't forget.

MUSIC USED~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Chapter 1-2 Player Phase Theme: All You Have To Do Is Practice (Riviera: The Promised Land)

Chapter 3-4 Player Phase Theme: Determination (Fire Emblem: The Sacred Stones)

Chapter 5-6 Player Phase Theme: A Taste of Justice by MarkyJoe1990 (edited by Pwntagonist to be GBA-insertable)

Chapter 7-Bonus Player Phase Theme: Wagnerian Finale by MarkyJoe1990 (edited by Pwntagonist to be GBA-insertable)

Enemy Phase Theme: Hector's Ambition (Riviera: The Promised Land)

Attack Theme: Battle With Demons (Riviera: The Promised Land)

Defend Theme: Seth-Rah's Awakening (Riviera: The Promised Land)

Boss Battle Theme: Fearless Adversary by MarkyJoe1990

Preparation Screen Theme: Combat Preparation (Fire Emblem: The Sacred Stones)

Used In Cutscene: Indignation (Fire Emblem: The Sacred Stones)

CREDITS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Creator, Eventer, and Writer

-Pwntagonist

Maps

-GenericCivilian3

Portraits

-Coby

-NICKTOfficial

Title Screen

-Xenith

Custom ASM patches

-circleseverywhere ("Danger Zone" and DSFE movement nullifier)

-CrazyColorz (Check for equipped item)

-Venno (passive stat boost and Autocursor fix)

-Nintenlord (prep screen character forcer/banner)

-Agro/Brendor (16 tracks 12 sounds)

-Mariobro3828 (Native Instrument Map)

Special thanks to SuperSonic1212 for coming up with the idea for Chapter 3.

Special thanks to Ephraim225 and his Ragefest submission "Emblem Warriors" for inspiring Chapter 5.

Special thanks to Arch's Elibian Nights for inspiring me to implement an achievement system.

Special thanks to MarkyJoe1990 for giving me some really solid feedback early on.

Special thanks to the FEUniverse community and specifically Tequila, CrazyColorz, circleseverywhere, and Camdar for... a ton of different things. Teaching me ASM, making ASM for me, solving my weird eventing problems, and of course solving my not-so-weird eventing problems. Couldn't have done it without them and their wealth of knowledge and resources.

Special thanks to 7743 for creating FEBuilderGBA, that thing is a godsend and saved my ass on numerous occasions.

Super DUPER special thanks to GenericCivilian3. He might as well be the co-author of this hack. I can't express how much work he's done in terms of playtesting, mapping, and bouncing ideas. His enthusiasm and willingness to help have really kept me going.

CONTACT INFO~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

I respond quickest to Discord and Reddit PMs.
Email: thepwntagonist@gmail.com
Serenes Forest: Pwntagonist
FEUniverse: Pwntagonist
Reddit: Pwntagonist
Discord: Pwntagonist (I am on the FEUniverse Discord server)