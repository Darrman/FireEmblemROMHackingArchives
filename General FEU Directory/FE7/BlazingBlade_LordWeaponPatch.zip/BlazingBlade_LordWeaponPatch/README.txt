Basic hacking done by Jotari.
Eliwood Lord Lance Animation Credit to Spud.
More info can be found at https://serenesforest.net/forums/index.php?/topic/83702-blazing-blade-lords-weapon-patch/