MAKE A FUN CHAPTER 3: GET THE PANTS
by Darrman

Normally I'd put credits here but you gotta finish the game for those! Apply the patch to an *FE1 ROM with the English translation applied.*