These patches convert older versions of the game to a newer version of the game, such as version 1 of The Last Promise to version 1.1. The file names should tell you what they do.

You should ONLY use this if you've already started playing an old version and you need to update your ROM.

Simply apply the patch OVER your CURRENT ROM--it will then apply the fixes for you when you reload your game. Do NOT patch this on a clean FE7 ROM--if you want to do that, use the normal patch.

The normal patch is always the latest version. These patches are only for people who are using older versions and want to update to newer versions without losing their save data. If you're multiple versions behind, just apply multiple patches until you get to the latest version, or re-patch on a clean ROM and transfer your save.

Lastly, if NUPS gives you an error message while patching over an old ROM, your game may be corrupted, but you can try to bypass it by hitting "Notify" to the left.

Thank you and have a great day.

- Blazer