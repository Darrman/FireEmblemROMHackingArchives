Alternate Modes README
------------------------

On Patching:
-------------

If you are using a patch for an Alternate Mode, you MUST select "Notify" or "Ignore" under the "If file is invalid" text. See here: http://gyazo.com/1904dfa6e7d0708b57d63e71e7f83db2.png.

It is HIGHLY SUGGESTED you back-up both your ROM and your save file before patching in case something goes wrong. Once you lose your working ROM or save data, there is little I can do to help you, especially with save data.

On Patching Compatibility:
---------------------------

These patches are intended to be PATCHED OVER a working ROM of The Last Promise Version 2.1. It -may- work on version 2.0 but you will probably have any bugs that were also in that version.

Furthermore, you cannot combine Easy and Chaos Mode together. This is because they edit the same data. I suppose you technically could attempt to, but the result would probably be a glitchy, conflicting mixture of some sort, likely resembling the patch you applied last more than the one before it since they edit some of the same data.

On Easy Mode:
--------------

This patch just makes the game easier. I won't bother you with petty details; it's no insult to anyone, the game's not a total pushover, but it's more akin to normal Fire Emblem game difficulty.

On Chaos Mode:
---------------

This is JUST A DEMO. DO NOT PLAY PAST CHAPTER 3. You may try, but the game is UNCHANGED PAST THAT POINT. That is, in fact, the point of a demo. If you are patient, an extension of the demo will be released and you can continue to play in chaos mode using an update patch. You have been warned.