README
-------

Very briefly:

- Patching instructions and version info are in the main folder. Before you try to patch, read the instructions. There are two ways to patch, but as far as I know, only NUPS will work with non-Windows users.

- Version info details all the releases including what's in them but it does NOT include a list of bugs and glitches. The game is a hack and it isn't perfect; furthermore, before you go reporting things, please check the "Documentation" folder for the list of already known issues.

- All special patches are in .ups (NUPS-only) form. You can apply them on top of any already patched version of The Last Promise. Applying them alone will likely break the game. You've been warned.

- Another warning--you may create your own problems by patching improperly or trying to use certain programs or cheats on the game. Don't blame me for stuff you try to do to the hack--play it normally and you should have minimal issues with the game. Backing up games and save files is suggested.

- A lot of people helped with this project, so be sure to take a peek at the credits.

Enjoy!