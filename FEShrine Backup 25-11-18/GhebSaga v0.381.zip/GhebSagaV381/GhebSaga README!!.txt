||GhebSaga Demo Patch v0.381||
||--------------------------||
{{Fire Emblem 7: Blazing Sword Mod}}
By Aitos Saibankan/game_adict 46/Furry YunSeong
All Rights Reserved to AS/GA46/FYS
Updated 06/11/10

This update:
- Latest chapter: Test 29 (not completed, give it a peek if you wish)
	- Completely New (Nevar Before Seen) Chapter

I. Introduction

	First of all thanks for downloading this epic haxxx. Second of all, I hope you enjoy it. Third of all, this will be a very short readme file. Enjoy the Readme.

II. GhebSaga Does What?

-Increases difficutly somewhat
-Changes the story for the lulz
-Changes a few mechanics

Changes Chart:
- Lots of stuff, I'll list them later.
- Mini Turrets : You wont see them too often, but they have 4x4 range.  It wont show when you select them.
- Rocketframes : I got rid of ballistas and instead placed these.  They are not super-effective against flying
	units as before, but they work better against dragons.  Yay explosives.
- Psy-Thief : They have a special weapon class of their own : Psychic weapons.  Offensive ones will always
	have the same range as Bows, and most of them can do something when used as an item.
	It's up to you to find out.
- Added from the other FEs:
	- Female Cavalier
	- King
	- Female Druid
	- Female Hero
	- Zombies
	- Gargoyles
	- Ghosts
- Completely New:
	- Female Mercenary
	- Slayer
	- Presence
- This is a copy of the GhebFE readme.  Don't judge me!


III. Actually Playing GhebSaga

GhebSaga is a big patch, like Gheb, so big, that it was divided into 2 sides, To play GhebSaga, you need to follow these instructions precisely:

1.Grab a clean US Fire Emblem ROM (eg V_EMBLEM.gba) file.*
2.Grab your Stealth Patch [It should be included in the GhebSaga bundle zip. If not, just follow this link: >>>http://www.romhacking.net/utils/357/<<< or just plain Google it]
3.Grab your GhebSagav381.ips andGhebSagav381B.ips
4.Start Up Stealth Patch and select [Apply IPS Patch]
5.Select your V_EMBLEM.gba Rom File.
6.Now youre promted to select the IPS file to use. Select GhebSagav381.ips.
7.Now name your newly patched ROM file something (eg, GhebSaga.gba).
8.Now you're promted to apply a second data set. Select Yes.
9.Select GhebSagav381b.ips.
10.Your new GhebSaga ROM should be completely patched and ready to be played.
* Any clean US FE7 ROM should work, but European and Japanese ROMs will not.

Or you can use a new format, that is only one patch.  To do that:

1. Grab your Tsukuyomi.exe [In bundle]
2. [Apply to New File]
3. [UPS Patch File to Apply] : Select your GhebSagav381.ups
4. [Source Input File To Apply to] : V_EMBLEM.gba
5. [Target to Write Patched File to] : Type in: GhebSaga.gba
6. [Bypass Checksum validation] : Check this box in the bottom right corner**
7: [Apply patch] : You should now have a newly patched game!
**While this was required when patching GhebFE to FE8, GhebSaga seems to patch fine without this bypass.

 _______________________________________________________________________________________________________________________
(It is important that you create a new copy of your original FE7 ROM and patch that one, to avoid any peculiar problems)
 \_____________________________________________________________________________________________________________________/

IV. Very Frequently Asked Questions

-MFV is annoying at the tutorial.  Can she shut up?
 I'll have an option for that eventually.


V. Unfixable Glitches

- So Far, none.

Bickering

Ive you have any questions, you can email or post at the GFAQs, FEU or FESS topics of the same name.***

written ~2009-2010 by Aitos/FurryYunSeong
slightly updated for clarity Feb. 2012 by FEGuy

***there's no e-mail listed here, the GFAQs topics have long since been locked, as is (was?) FESS. 
I don't really know how to contact him, and it looks like he hasn't logged into most sites since late last year.
Best bet's gonna be community support if you need support.