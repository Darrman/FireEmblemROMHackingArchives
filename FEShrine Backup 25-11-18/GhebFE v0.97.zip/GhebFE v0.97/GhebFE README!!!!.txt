||GhebFE Demo Patch v0.97||
||-----------------------||
{{Fire Emblem 8: The Sacred Stones Mod}}
By Aitos Saibankan/game_adict 46/Furry YunSeong
All Rights Reserved to AS/GA46/FYS
Updated 02/08/09

This update:
- Full Working Supports:
Gheb
Amelia
Caellach (missing Moulder B and C)

- Scattered Working Supports:
Tana x Ewan C
Selena x Colm C and B
Lucius x Ewan C and B
Glass x Kiwi C
Glass x Glen C
Glen x Marcus C and B
Glass x Marcus C
Ephidel x Karla C
Batta x Karla C
Kiwi x Lucius C

I. Introduction

	First of all thanks for downloading this epic haxxx. Second of all, I hope you enjoy it. Third of all, this will be a very short readme file. Enjoy the Readme.

II. GhebFE Does What?

-Increases difficutly greatly
-Changes the story for the lulz
-Changes a few mechanics

Changes Chart:
A-Mug:You can steal almost anything from any enemy provided you have enough Speed to do so.
B-New Classes:
 -Lancer
 -Mad Hero
 -Raider
 -Female Raider/Assasin
 -Trapwhore
 -Medium
 -Loli
 -The Stache
 -The Beast
 -The Brave
 -Master Gheb
 -Master Glass
C-Class Changes:
 -Valkyries/Great Bitches, Snipers, Rangers, Falcoknights, Wyvern Knights, Paladins gain +10 Crit
 -Assasins have sub-par stats but superior move, Steal, Crit and Lockpick use.
 -Rogues are more balanced, steal, pick, crit and move again.
D-Third Tiers:
 -Promotion to 3rd tier requires the same promotion item for 2nd tier.
 -Mechwarrior:For Generals
 -God Incarnate:For Gheb
 -Chaos Lord:For Glass
 -Holy Bitch:For Great Bitches/Valkyries
 -Queen:For Sages and Female Bishops
 -Gambler:For Swordmasters
 -Falcomaiden:For Falcoknights
 -Dragoon:For Wyvern Lords and Wyvern Knights
 -Masta Knight:For Rangers, Great Knights and Paladins
 -Beastmaster:For Berserkers
 -Warlock:For Sages
 -Necromancer:For Druids and Summoners
 -Sharpshooter:For Snipers
 -Champion:For Heroes and Mad Heroes

III. Actually Playing GhebFE

GhebFE is a big patch, like Gheb, so big, that it was divided into 2 sides, To play GhebFE, you need to follow these instructions precisely:

1.Grab a US Fire Emblem: The Sacred Stones ROM (eg, 1997_-_Fire_Emblem_-_The_Sacred_Stones_(U).gba) file*.
2.Grab your Stealth Patch [It should be included in the GhebFE bundle zip. If not, just follow this link: >>>http://www.romhacking.net/utils/357/<<< or just plain Google it]
3.Grab your !GhebFE.ips and !GhebFEb.ips
4.Start Up Stealth Patch and select [Apply IPS Patch]
5.Select your 1997_-_Fire_Emblem_-_The_Sacred_Stones_(U).gba Rom File.
6.Now youre promted to select the IPS file to use. Select !GhebFE.ips.
7.Now name your newly patched ROM file something.
8.Now you're promted to apply a second data set. Select Yes.
9.Select !GhebFEb.ips.
10.Your new GhebFE ROM should be completely patched and ready to be played.

*Clean US ROM files ONLY! European and Japanse releases WILL NOT WORK!


Or you can use a new format, that is only one patch.  To do that:

1. Grab your Tsukuyomi.exe [In bundle]
2. [Apply to New File]
3. [UPS Patch File to Apply] : Select your GhebFEv97.ups
4. [Source Input File To Apply to] : 1997_-_Fire_Emblem_-_The_Sacred_Stones_(U).gba
5. [Target to Write Patched File to] : Type in: GhebFE.gba
6. [Bypass Checksum validation] : Check this box in the bottom right corner
7: [Apply patch] : You should now have a nu patch!

 ______________________________________________________________________________________________________________
(It is important that you create a new copy of your original FE8 ROM and patch that one, to avoid any peculiar problems)
 \____________________________________________________________________________________________________________/

IV. Very Frequently Asked Questions

-A bard appears in CH5, but I can't recruit him, what's up?
 You'll recruit him in CH9.

-Who recruits McCartney, in what chapter?
 McCartney is recruited in Ch9a/b by your lord, be it Gheb or Glass, or Tana.

-Who recruits Lucius?
 In Ch10b, either Kiwi or Duessel can recruit Lucius

-Who recruits Pent?
 You need Lucius to recruit Pent.

-Who recruits Carlyle?
 Marisa recruits Carlyle, but you also need to pay over 9000 gold.

V. Unfixable Glitches

-If you press B when selecting the target of a staff, the game will lock. Soft or hard reset will solve this.
-Any weapon with Sword of Seals or Fa's Dragonbreath animations will mute the in-battle music.
-There may appear an egg Ai-ke in Ch14a.  Ignore it, as I never found a true means to get rid of it.
-Certain characters have 1-way supports, or their supports yield no conversation.  I don't know how to add extra support convos yet, but as soon as I find out I'll add them.  As for the support inconsistencies, I'm still working on that, should be taken care of by v.98.

Bickering

Ive you have any questions, you can email or post at the GFAQs, FEU or FESS topics of the same name.**

written ~2008-2009 by Aitos/FurryYunSeong
slightly updated for clarity Feb. 2012 by FEGuy

**there's no e-mail listed here, the GFAQs topics have long since been locked, as is (was?) FESS. 
I don't really know how to contact him, and it looks like he hasn't logged into most sites since late last year.
Best bet's gonna be community support if you need support.