This archive contains 0% growth edits for:

Fire Emblem: Thracia 776 (J) (ROM)
Fire Emblem: Fuuin no Tsurugi (J)
Fire Emblem: Blazing Sword (U)
Fire Emblem: The Sacred Stones (U)
Fire Emblem: Shadow Dragon (U)

Use NUPS or another UPS patcher to patch the SNES and GBA ROMs.
Use xdelta to patch the NDS ROM.

Notes:
Fire Emblem: Thracia 776 is the ROM version, not the NP version. I don't know whether it should have a header or not.
Fire Emblem: Fuuin no Tsurugi should be compatible with the widely available translation patch.

Happy playing! I hope you will enjoy this as much as I do.

dondon151