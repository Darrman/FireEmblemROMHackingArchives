This patch adds unit ordering functionality to Fire Emblem: Thracia 776.

Ordering works just like in Mystery of the Emblem: pick the units you wish to deploy, then exit the "pick" menu. When you re-enter the menu, the units you picked will have been moved to the front.

This patch should work with any version of Thracia 776. There are two versions included: one for headered ROMs, one for unheadered ROMs. If you don't know which one yours is, it's probably unheadered, but make a backup of your ROM just in case.