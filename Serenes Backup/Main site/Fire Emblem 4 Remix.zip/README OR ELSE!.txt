I'm not going to bother you with all kinds of boring bullshit and get straight to what you want. Also keep in mind
your ROM needs to have a header for this patch. There are also some hints at the end as well. PLEASE inform me of
any glitches, bugs, or errors no matter how minor as well as just general feedback.


Basic

Strength now reduces the weapon weight penalty like in Path of Radiance.
BRANCHED PROMOTION IS ADDED!!!
Holy blood growth bonuses have been lowered (30% total as opposed to 50% total)
Arena gold has been nerfed *slightly* (500G or so)

Skills

Pursuit is baseline now.
Critical is still a skill due to it's damage calculation method (x2 damage prior to defense application)
Ambush/Vantage now will always strike first, like in Path of Radiance.
Sword skills can now activate together.
Sword skills can now be used by any weapon.
All skills have had their icons "cleaned up" for lack of a better term.

Characters

Characters have increased growth rates (300% Average first gen, 450% average gen 2)
Characters have had some skill changes mostly to fit with the family tree or to balance them.
Substitute characters are much better now, although still not as good as children.
Certain characters have had their level increased to not be awful (Such as Tiltyu or Corpul).
Sukasha/Rodalban starts as an axe fighter.
Hannibal doesn't suck anymore.

Enemies

Generic enemies have higher growth rates in general, and often times better weapons.
Certain enemies that were generic originally have now been changed to holy (Such as Shagarl).
Many important bosses (Ishtar for example) are much stronger.
Enemies have had their blood/skills fixed (So Ishtar has minor Fala and Blume + Hilda's skills for example).
The arena is a bit more difficult now.

Classes

Major class balancing, now each class should be at least viable.
Forests/Heros can now use axes.
Social Knights can now only use swords, think of them as a Sword Knight.
Free Knights have myrmidon-like stats now, making them different from Social Knights.
The Master Knight is now OP as hell (More then before), however it is enemy only.

Weapons

Like classes, weapons have been balanced quite a bit so things like fire and axes don't suck anymore.
Each nature magic type has an effectiveness bonus towards something now. This also applies to the magic swords.
Holy weapons now have been nerfed quite a bit, but are still considerably powerful.
Each holy weapon now grants a special skill, skills will be listed at the bottom of this document.
The holy lances now have +1 range.

Tyrfing		-Prayer
Mistoltin	-Critical
Balmung		-x2 Attack
Gaibolg		-Luna
Gungnir		-Sol
Swanchika	-Awareness
Ichival		-Recover
Fala Flame	-Uncounterable
Thor's Hammer	-Critical
Holsety		-x2 Attack
Narga		-Negate loptous
Loptous		-Halves enemies' attack power.

There is more, but I don't want to ruin it for you all.