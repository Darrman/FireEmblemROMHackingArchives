Fire Emblem - Crossover Hack 2.0.1

- Index -
1. Content
2. Legal Stuff
3. Commands Translation
4. Credits
5. FAQ
6. Contact

- 1. CONTENT -
This folder contains:
 a. Readme.txt - The file that are you reading right now.
 b. Fire Emblem - Crossover Hack 2.0.ups - The patch.
 c. NUPS - The program to patch the game.

- 2. LEGAL STUFF -
I do not own Fire Emblem games, any character, music and/or scenario are property of Nintendo and Intelligent System.
Also, I do not own something of the hack, the authors and creators are listed in the credits.

- 3. COMMANDS TRANSLATION -
Since this is an latin american hack in spanish, I'll help you with some commands:

A. Map Commands.

    Spanish       English
 a. Atatar    -   Attack
 b. Objeto    -   Item
 c. Baston    -   Staff
 d. Tocar     -   Play
 e. Inter.    -   Trade
 f. Rescatar  -   Rescue
 g. Tomar     -   Take
 h. Soltar    -   Drop
 i. Apoyo     -   Support
 j. Hablar    -   Talk
 k. Tomar     -   Seize
 l. Usar      -   Use
 m. Equipar   -   Equip
 n. Interc.   -   Trade 
 �. Tirar     -   Drop
 o. Cofre     -   Chest
 p. Puerta    -   Door
 q. Robar     -   Steal
 r. Visitar   -   Visit
 s. Esperar   -   Wait
 t. Unidad    -   Unit
 u. Estado    -   Status
 v. Opciones  -   Options
 w. Susp.     -   Suspend
 x. Fin       -   End
 y. Armeria   -   Armory
 z. Tienda    -   Vendor
 aa Comp.     -   Buy
 ab Vend.     -   Sell
 ac Si        -   Yes
 ad No        -   No

B. Preparations Screen Commands.

    Spanish       English
 a. Unidades  -   Pick Units
 b. Objetos   -   Trade
 c. Ramdom    -   Fortune
 d. Puntuacion-   Rank
 e. Tactico   -   Tactician
 f. Invitado  -   Augury
 g. Ver Mapa  -   Check Map
 h. Guardar   -   Save
 i. Inter.    -   Trd
 j. Lista     -   List
 k. Usar      -   Use
 l. Vend.     -   Sell
 m. Da tod.   -   Give All
 n. Dar       -   Give
 �. Tomar     -   Take
 o. Ver Mapa  -   View Map
 p. Formacion -   Formation
 q. Opciones  -   Options

If in the game are commands that you don't understand, just ask me or use a translator.


- 4. CREDITS -
 - oracle_of_S�regon/oracle_of_fire/Dr_Stein/Flame_Alchemist/Edgar Lysander Moreno Membre�o
.Creator and author of all not listed below.

a. FEWoDians (http://fireemblemwod.net/):
 - Luzan:
.Creator of these mugs:
 *Thar
 *Riku
 *Celice
 *Yuria
 *Celica
 *Julian
 *Leaf
 *Nanna
 *Levin
 *Soren
 *Langobart
 *Godot
 *Pearl Fey

.Creator of these animations:
 *Leaf
 *Celice
 *Thar

.Creator of these Map Sprites:
 *Hechicera
 *Lord (Leaf)
 *Mercenario (Ike)

.Creator of these weapons: "H de Hierro", "H de Acero", "H de Plata" and "Ixion"

.Creator of the character "Thar"

.Creator of the Custom CG of the Cap. 15.

 - Kanningu-Chan/Rebeca Carolina Chico Mar�n
.Creator of these faces:
 *Black Star
 *Dr. Stein
 *Winry Rockbell

.Creator of these chibis:
 *Riku
 *Celice
 *Yuria
 *Celica
 *Julian
 *Leaf
 *Nanna
 *Levin
 *Soren
 *Ike
 *Kanningu

.Creator of the character "Kanningu"

 - Enex/Jos� Vargas
.Recolor of these Faces:
 *Eirika
 *Seth

.Creator of the character "Alvin"

 - Volug Vanguard
.Creator of the character "Riku"

.Co-Creator of some dialogues.

b.From Serenes Forest (http://serenesforest.net/), Shrine of Seals (http://shrineofseals.net/) y/o ChinaFE
 - Arch
.For his "Event Hacking for Dummies" (http://serenesforest.net/forums/index.php?showtopic=25360)

.For his tutorial Tutorial "Inserting Map Sprites" (http://serenesforest.net/forums/index.php?showtopic=24957)

 - Luffy/Blazer
.For his "The Ultimate Tutorial [V2]" (http://serenesforest.net/forums/index.php?showtopic=22051)
Also, he helped me a lot with hacking stuff.

 - Xeld/Zeld/Hextator/Obviam/*Insert nick of the day*
.Co-Creator of the program "FEditor Adv." (http://shrineofseals.net/forum/showthread.php?tid=273)

.Creator of the "Melee/Magic Hack" patch.
He helped me with Custom CG Insertion and other things.

 - Zahlman
.Co-Creator of the program "FEditor Adv." (http://shrineofseals.net/forum/showthread.php?tid=273)

.Creator of the program "Song Editor" (http://shrineofseals.net/forum/showthread.php?tid=67)

 - Nintenlord
.Creator of these programs:
 "Event Assembler"
 "GBA Graphic Editor"
 "Nintenlord's Compressor"
 "NUPS"

.Creator of some Modules for "Nightmare" and "Nightmare 2.0"

.Creator of these patches:
 *Steal Hack
 *Move after battles
 
Also he helped me with some EA codes.

 - The Blind Archer
.Creator of "Ike"'s mug.

.Creator of the animation "Troubadour using Swords"

 - markyjoe1990
.Creator of the tutorial "Fire Emblem GBA Map creation and Insertion" (http://shrineofseals.net/forum/showthread.php?tid=255)

 - Mariobro3828
.Creator of the tutorial "Expanding and Relocating Data Arrays" (http://shrineofseals.net/forum/showthread.php?tid=788)

 - Shadow Kaste
.Creator of "Micaiah"'s mug.

 - CHEEPER_LEE
.Creator of "Micaiah"'s animation.

 - Khrene Cleaver
.Creator of "Ike"'s animation.

 - VGMusic
.From where I took most of the midis used in the hack, I'll name the authors of each midi in the final version.

c. Compa�ias
 - CAPCOM
.For the Gyakuten Saiban 1, 2 and 3 and Megaman ZERO 1 Music.

 - SQUARE ENIX
.For the Final Fantasy V, Final Fantasy Tactics and Kingdom Hearts RE: Chain of Memories Music.

 - Nintendo
.For the Fire Emblem Series, Kirby's Amazing Mirror and The Legend of Zelda - Minish Cap Music.

IF I FORGOT NAME SOMEBODY, PLEASE SAY IT.

- 5. FAQ -
1. I don't understand nothing, Why this hack isn't in english?
A// Because this hack is in spanish, I think it's the first one.
You can use a translator while I'm making a translation.
But the translation will be released only after finish the project.

2. The game gets slow when I use X weapon, Why?
A// I expanded the Item Editor and the Spell Association Editor modules, maybe I forgot associate
a weapon. If something like this happens, please, report wich weapon cause this.

3. X character doesn't have a chibi/mini mug/icon, Why?
A// Some characters don't have one, I haven't made yet.

4. Hey, a weapon is usable in the preparation screen, is that normal?
A// No, and it only will screw your stats, if you found one, please say wich is to fix it.

5. I can't continue playing after Ch. 15, What I have to do to continue playing?
A// This is only a DEMO, and there are only 19 Chapters (Counting the Prologue and the Gaidens)


- 6. CONTACT -
You can contact me to report me bugs, glitches, etc. to:

.E-mail/MSN: edgarlyz@hotmail.com
.Facebook: http://www.facebook.com/pages/Fire-Emblem-Crossover-Hack-20/137020753049272
.Forum: 
 Fire Emblem - Wars of Dragosn (Spanish) - http://fireemblemwod.net/foro/viewtopic.php?f=29&t=8295
 Serenes Forest - http://serenesforest.net/forums/index.php?showtopic=26051 
 Shrine of Seals - http://shrineofseals.net/forum/showthread.php?tid=928