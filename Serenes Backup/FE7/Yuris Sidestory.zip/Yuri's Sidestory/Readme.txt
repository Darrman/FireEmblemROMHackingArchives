A MK404 Special: Yuri Tanaka's Sidestory - v1.0
For Fire Emblem 7: The Blazing Sword
By Raymond Soto, A.K.A. Mage Knight 404

=+-+=+-+=+
DISCLAIMER
=+-+=+-+=+

I do not own the rights to Fire Emblem, nor am I affiliated in any way with Nintendo, Intelligent Systems, or any other company.

========
Contents
========
- Release Log
- Overview
- Known errors/glitches
- Credits

-----------
Release Log
-----------

May 19, 2011: First Patch - Ver. 1.0

--------
Overview
--------

A curious me had recently discovered the obscure as all get out edutainment game EMIT, made by Koei(whom you may know from the Dynasty Warriors franchise). Its protagonist, 17-year-old Yuri Tanaka, left so much of an impression on me, I placed her among "the Favorites", a slew of fictional characters I find great, but had no idea what to do with her(as would be expected from my previous FE ROM hack, Fire Emblem 404).

So work started and stalled on my second ROM hack, Fire Emblem: A Sacred Dawn. I decided that I needed to take a break from it, so this idea to put Yuri the realm of FE came to be, and that is this ROM hack.

Yuri's Sidestory is a short 2-chapter ROM hack of Fire Emblem: The Blazing Sword. It brings in two fully playable maps under the original pretense of Fire Emblem 404's "plotline". Zaniness abound when you play!

Difficulty is sizable, not too hard, not too easy.

---------------------
Known errors/glitches
---------------------

-- North's NPC palette is untested, may look incorrect

-----------------
Credits/Thanks to
-----------------

- Lord Glenn, my best friend, for being the planner for everything I did, as well as being a beta-tester
- General Archibald/Rodimus Supreme Overtroll, for creating Elibian Nights, partial inspiration for this project, and for laying     the basics of event editing
- markyjoe1990, for teaching me event editing
- seph1212 for inserting one MIDI file into the game and bonestorm for making said MIDI file
- VincentASM for making the DS-styled battle template employed in this patch
- The members of our little Skype group, Team OVERTROLL, for providing varying degrees of support
- The Fire Emblem community and my YouTube subscriber base
- Koei, for making EMIT
- Nintendo and Intelligent Systems, for making Fire Emblem
- The original creators of the various sources represented in this ROM hack
- And you, for reading and playing this patch!

==END==