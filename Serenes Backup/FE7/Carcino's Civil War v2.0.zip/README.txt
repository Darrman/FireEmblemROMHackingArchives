How to play: Use NUPS or another UPS patcher to patch the file onto a clean localized FE7 ROM. Hit "ignore" if necessary.

BACKGROUND~

Carcino's Civil War is a ROM hack that takes inspiration from Fire Emblem 8: The Sacred Stones. It takes place in Carcino, the growing mercantilist country, 3 years prior to the events of FE8. You will follow Gerik's mercenary crew as he quickly becomes sucked into a plot of deception, politics, and manipulation.

MUSIC USED~

Chapter 1 Player Phase Theme: Clash on the Big Bridge (Final Fantasy 5)

Chapter 2 Player Phase Theme: Walking the Streets of a Former Hell (Touhou 11)

Chapter 2 Cutscene Theme: Clock Tower (Castlevania: Aria of Sorrow)

Normal Battle Theme: Hunting for your Dream (Hunter x Hunter)

Boss Battle Theme: Dark Emperor Hardin (Fire Emblem: Mystery of the Emblem)

Chapter 3 Player Phase Theme: The Grim Angel (Riviera: The Promised Land)

Preparation Screen Theme: Pursuit ~ Cornered (Phoneix Wright: Ace Attorney)

CREDITS~

Creator, Eventer, and Writer

-Pwntagonist

Maps

-GenericCivilian3

Portraits

-CobyTheKid

-NICKT (collection)

Custom ASM patches

-Blazer (all instrument hack)

-circleseverywhere ("Danger Zone" and DSFE movement nullifier)

-Venno (passive stat boost)

-Nintenlord (prep screen character forcer/banner)

Special thanks to SuperSonic1212 for coming up with the idea for Chapter 3.