  Z�  V(       1                $R�w�i��b|$B�A�W�g�O��-��|$<$F3$FCL_GREIL|$F4$FCL_IKE|$F1$FCL_MIST|$F1$PFather!$w4 Brother!$w4 It's that lady
Ike rescued$MC...$MD$w2 She's awake!$K
$F4$PReally?$K
$F3$PCome on. $w2Let's greet our guest.$K  $R�w�i��b|$B�A�W�g����-02|$<$F3$FCL_GREIL|$F0$FCL_ERINCIA|$F3$PSo, $w2how are you feeling?$K
$F0$POh, $w2I$MC...$MD$w4
I'm $w2fine$MC...$MD$w4
And you are?$K
$F3$PThe name's Greil.$w4 I'm the commander
of this mercenary company.$K
$F0$PMy lord Greil$MC...$MD$w4 You are the one who
came to my aid, $w2are you not?$w4
I don't know how to thank you$MC...$MD$K
$F3$PHold on.$w4 The one who found you$w1
and brought you here$w2 is my son, Ike.$w4
If you want to thank someone, $w1thank him.$K
$F4$FCL_IKE|$F4$PNo, $w2please, that's not$MC--$MD$K
$F0$PLord$MC...$MDIke, was it?$w4
You have my gratitude.$K
$F4$POh$MC...$MD$K
$F3$PPardon my bluntness, $w2but I have some
questions for you.$w5 Tell me, $w2who are you?$w4
What were you doing in that place?$K
$F0$P$MC...$MD$K
$F3$PThe place where Ike found you$w2 was
evidently the site of a fierce battle
between Crimean and Daein forces.$K$PDo you have some relation to the Crimean
royal family?$K
$F0$P$Fc$MC...$MD$K
$F4$PI make no promises,$w2 but we may be able
to help you.$w4 Will you share your story
with us?$K
$F0$P$FdYou took me in and cared for me.$w2
I will$MC...$MD$w3place my trust in you.$K
$Ub$H$P$Ub$HMy name is $w2Elincia $w1Ridell $w1Crimea.$w4
I am the daughter of
King Ramon of Crimea.$K
$F4$PWhat?$K
$F3$PYou say you are$w4 the princess of Crimea?$K
$F0$PYes.$K
$F3$PThat's an $w2odd claim to make.$w4
I've never heard of King Crimea
having any children.$K
$F0$PThat is$MC...$MD$w3to be expected.$w4
My heritage, my very existence,$w2
has never been made public.$K
$F4$PWhy's that?$K
$F0$PTo avoid national turmoil.$K$PYou see, $w2I was born after my uncle,$w2
Lord Renning, was named as successor to
the throne.$w4 So$MC...$MD$K
$F3$PThey kept you a secret$w2 to avert a possible
blood feud.$w4 Yes, $w2I'm willing to accept
that for the time being.$K$PVery well, $w2let's suppose that you
truly are Princess Crimea.$K$PYou must know what's become of the king
and your uncle.$w2 I would like to hear
that news.$K
$F0$P$MC...$MD$w4My father $w2and my mother$w2
are dead$MC...$MD$Fc$w5 They fell $w2at the hand of
Ashnard, King of Daein$MC...$MD$K$w5$Fd$PMy lord uncle$w1 and the royal knights$w2
are still battling the Daein army, $w2I believe.$w4$K
$F3$PI see.$K
$F0$P$MC...$MDI$MC...$MD$w2fled the castle$MC...$MD$w4to follow
my lord uncle's orders $w2and seek
refuge in the kingdom of Gallia$MC...$MD$K
$F3$PIn Gallia?$K
$F0$P$MC...$MD$w1Yes. We believed that King Caineghis$w2
would grant me sanctuary.$w2 So that's
where I was going$MC...$MD$K$PBut $w2we were discovered by Daein
troops, and I lost my escort of knights$MC...$MD$K$Fc$PMy life$MC--$MD$w2the life I have now$MC--$MD$w3
was purchased$MC...$MD$w3with the blood of
those brave knights$MC...$MD$K
$F4$PDoes King Daein $w2know of your
existence?$K
$F0$P$FdYes.$w4 I was told the royals of each nation$w2
were informed of my identity in the event
of dire circumstances$MC...$MD$K
$F3$PIf that's the case, $w2they must be
searching frantically for you.$K
$F4$P$MC...$MD$K
$F0$PMaster Greil, $w2my lord Ike,$w4 you said
that you were mercenaries, did you not?$K$PPlease$MC...$MD$w4 Would you help me to gain Gallia?$K$PI beg of you!$w4 I have$MC...$MDno one$Fc
$Ub$H$MC...$MD$w4no one else to turn to.$K
$=0500 $R�w�i��b|$B�A�W�g-�H��-��|$<$F3$FCL_IKE|$F1$FCL_TIAMAT|$F1$PPrincess Crimea?$w4 Truly?$K
$F3$PFather $w2spoke to her as if he
believed she were telling the truth.$K
$F1$PI see$MC...$MD$K
$F3$PWhat is it, $w2Titania?$K
$F1$PMm,$w2 it's nothing.$w4 I was just
remembering $w2something from the past.$K
$F3$PFrom the past?$w4 Back when you
were still a Crimean royal knight?$K
$F1$PWhat?$w4 How$w2 do you know about that?$K
$F3$PA long time ago, $w2I overheard Shinon and
some others talking about it.$K
$F1$PThey$w4 keep such loose tongues.$K
$F3$PWas it a secret?$K
$F1$PNo, it wasn't, but$MC...$MD$w4 Much like I have
more experience than you,$w2 I also
have many more things to worry about.$K
$F3$PLike Princess Crimea?$K
$F1$PWell$MC...$MD$w4yes.$w4 I myself$w2 was unaware
of the princess's existence, but$MC...$MD$K$PNow that I think about it, $w2she does bear a
striking resemblance to both the king
and queen.$K
$F3$PSo $w2she probably is the true princess.$w4
I wonder what Father will do.$K
Will he take on her request?$K
$F0$FCL_LOFA|$F0$PWe've got trouble!$w4
$Ub$HOutside!$w2 There are soldiers!
A lot of them!$K
$F3$PWhat?$K  $R�w�i��b|$B�A�W�g-��펺-��|$<$F1$FCL_GREIL|$F3$FCL_TIAMAT|$F1$PIs everyone here?$K
$F3$PYes.$K$N$UB$H    $F4$FCL_CHINON|$F4$PCommander, $w2what are the
Daein dogs saying?$K
$F1$P"Turn over Princess Crimea $w2and leave
the area immediately.$w4 Comply now, or
we will attack."$w5 Pretty straightforward.$K
$F4$FD$N$UB$H    $F1$PWe've received demands from the
Daein army.$K$P"Turn over Princess Crimea $w2and leave
the area immediately.$w4 Comply now, or
we will attack."$w5 Pretty straightforward.$K
$N$UB$H   $F4$FCL_GATRIE|$F4$PWhat are we going to do?$K
$F1$PThat's $w2what we're here to decide.$w4
One thing $w2has been made clear by
the arrival $w2of our friends outside.$K
$F4$FD$N$UB$H  $F1$PWhat we do now $w2is decide on a course
of action.$w4 One thing $w2has been made
clear by the arrival $w2of our friends outside.$K
$N$UB$H $F4$FCL_SENERIO|$F4$PSo, I would say this confirms$w4 her
identity as Princess Crimea, wouldn't you?$w2$K
$F1$PYes, but what do we do now?$w4 I'd like to
hear the opinion$w2 of everyone here.$K
Titania,$w3 I'd like to hear from you first.$K
$F3$PThe blame for this war$w2 rests on Daein.$w4
If we ally ourselves with them,$w2 the
company's reputation will surely suffer.$K$PConversely,$w2 if we deliver Princess Crimea
safely, $w2our stock will rise$w2 in the eyes of
our primary employers.$w4 Our road is clear.$K
$F1$PSoren, how about you?$K
$F4$PThere's nothing to think about.$w4
We must $w2deliver the princess to
Daein immediately.$K
$F1$PEven if Crimea is in the right?$K
$F4$PWe$w2 are mercenaries.$w4 Our actions$w2
are dictated only by self-interest.$K$PIf we want to ensure our future,$w2 we need
Daein in our debt.$w4 They will win this war,
after all, $w2and nothing else serves us better.$K
$F3$FD$F4$FD$N$UB$H    $F3$FCL_CHINON|$F4$FCL_GATRIE|$F1$PShinon? $w2Gatrie?$K
$F3$PSoren's a pompous, superior whelp,$w2
but he's got the right idea.$K$PBesides, $w2the destination's Gallia,
so it's a moot question.$K$PI don't care how much we get paid;$w2
there's no way under the sun I'm
going to stinking beast country.$K
$F4$P$FSPrincess Elincia$MC...$MD$w4 She does possess
a certain regal beauty$MC... $MDThere's a lot to be
said for that, you know.$K$PHowever, $w2I do prefer country girls$MC...$MD$w2
A bit cuter, and not quite so standoffish$MC...$MD$w4$FA
Oh! Forget I said that.$K$PWhatever you decide is good for
me, Commander.$w4 Yep, uh-huh, yep$MC...$MD$K
$F3$FD$F4$FD$N$UB$H    $F3$FCL_CHINON|$F1$PShinon, $w2what do you say?$K
$F3$PSoren's a pompous, superior whelp,$w2
but he's got the right idea.$K$PBesides, $w2the destination's Gallia,
so it's a moot question.$K$PI don't care how much we get paid;$w2
there's no way under the sun I'm
going to stinking beast country.$K
$F3$FD$N$UB$H  $F4$FCL_GATRIE|$F1$PGatrie, $w2what do you say?$K
$F4$P$FSPrincess Elincia$MC...$MD$w4 She does possess
a certain regal beauty$MC... $MDThere's a lot to be
said for that, you know.$K$PHowever, $w2I do prefer country girls$MC...$MD$w2
A bit cuter, and not quite so standoffish$MC...$MD$w4$FA
Oh! Forget I said that.$K$PWhatever you decide is good for
me, Commander.$w4 Yep, uh-huh, yep$MC...$MD$K
$F4$FD$N$UB$H   $F3$FCL_OSCAR|$F4$FCL_BOLE|$F1$POscar, $w2Boyd,$w4 what about the
two of you?$K
$F3$PI agree with Captain Titania.$K
If we turn the princess $w2over to the
Daein army,$w2 we're essentially giving
them$w2 permission to kill her.$K
$F4$PI'm in favor $w2of helping her.$w4$FS
That's what heroes $w2are supposed to do.$K
$F3$FD$F4$FD$N$UB$H    $F3$FCL_OSCAR|$F1$PAnd you, Oscar?$K
$F3$PI agree with Captain Titania.$K
If we turn the princess $w2over to the
Daein army,$w2 we're essentially giving
them$w2 permission to kill her.$K$PIf Boyd were here, $w2I think he'd agree
with the captain as well.$K
$F3$FD$N$UB$H  $F4$FCL_BOLE|$F1$PAnd you, Boyd?$K
$F4$PI'm in favor $w2of helping her.$w4$FS
That's what heroes $w2are supposed to do.$K$PAnd if my brother were alive, $w2there's
no way he'd agree $w2to turn the
princess over to Daein!$K
$F4$FD$N$UB$H    $F4$FCL_KILROY|$F1$PWell, Rhys?$w3 What's your opinion?$K
$F4$PI believe$MC...$MD$w2that none of this hinges on
whether she's a princess or not.$K$PRefusing to aid someone in need$w2
is not something we should ever do.$w3
That's what I think.$K
$F3$FCL_LOFA|$F3$PThat's right!$w3 Let's help her!$K
$F0$FCL_MIST|$F0$PPlease! We have to help her!$K
$F3$FD$F4$FD$F0$FD$N$UB$H    $F1$PMist? Rolf?$K
$F0$FCL_MIST|$F0$PPlease, everyone!$w4
Say you'll help her!$K
$F3$FCL_LOFA|$F3$PThat's right!$w3 We can't just let
her get killed!$K
$F3$FD$F0$FD$N$UB$H $F3$FCL_IKE|$F1$PAnd what about you, $w2Ike?$K
$F3$PI$w5 agree with Titania.$w4 I say we help her$w2
and take her to Gallia.$K
$F1$PI see.$w3 I think I know where you all stand.$K
$Fc$MC......$MD$K$P$FdWell then, $w2here's my decision.$K$P$F4$FCL_SENERIO|$w5$F1$PWe $w2escort the princess to Gallia.$K
$F4$P$Fc$MC...$MD$K$F4$FD
$N$UB$H $F4$FCL_CHINON|$F4$P$MC...$MDTsk.$K$F4$FD
$N$UB$H   $F3$P$MC...$MDAre you sure $w2that's for the best, $w2Father?$K
$F1$PYes.$w4 Besides, $w2I think the choice has
been taken out of our hands.$K
$F3$PWhat?$K$F3$FD
$F1$POpen your ears and listen.$w4
Listen! $w2All of you.$K
$N$UB$H   $F4$FCL_BOLE|$F4$PHuh?$w4
$MC...$MDWhat is it?$K$F4$FD
$F3$FCL_GATRIE|$F3$PUh$MC...$MD$w4
I don't hear a thing$MC...$MD$K$F3$FD
$N$UB$H $F3$FCL_IKE|$F3$PHuh?$K I don't hear anything
special, but$MC...$MD$K$F3$FD
$N$UB$H $F4$FCL_CHINON|$F4$PIdiot!$w4 That's the problem.$w4
Don't you think that's a bit odd?$w4
Complete silence, $w2in all four directions.$K$F4$FD
$N$UB$H  $F1$PThink about it.$w4 Don't you
think it's a little TOO quiet?$K
$N$UB$H  $F3$FCL_GATRIE|$F3$POh, $w2so that's what you're
talking about!$K$F3$FD
$N$UB$H $F4$FCL_OSCAR|$F4$PNot only are the animals quiet, $w2but the
bugs are silent, too.$w4 And that $w2is
unnatural beyond belief.$w4 Which means$MC...$MD$K
$N$UB$H    $F4$FCL_SENERIO|$F4$PNot only are the animals quiet, $w2but the
insects are still as well.$w4 Which means$MC...$MD$K
$N$UB$H    $F3$FCL_IKE|$F3$PWe're surrounded. The soldiers aren't
waiting for an answer. They already
decided to attack.$K
$F4$FD$F3$FD$F3$FCL_TIAMAT|$F3$PIt would appear $w2they had no
intention of keeping their side of
the proposed bargain.$K
$F4$FCL_SENERIO|$F4$PThey were planning on lulling us into a
false sense of security $w2and destroying
every one of us.$K
$F1$PProbably so.$w4 But the deal is,$w2 we're
not so naive or inexperienced as to fall
for their trap.$K$P$Ub$HEveryone, $w2take your positions!$w4
We're going to settle this right now!$K    $R�㉺��b|$c0GREIL|$s0I'll go and hold the rear entrance.$K$PIke!$w4 You're in command here!$w5
Don't let the enemy take the front.$K
$c1IKE|$s1$MC...$MDGot it!$w4 Be careful, $w2Commander!$K
$s0$FSHah.$w3 I'll give it a shot.$K   $R�㉺��b|$c0DAYNE1|$s0Reporting in, sir!$w4
The mercenaries have taken up arms$w2
and formed up in the bailey!$K
$c1DAKKOWA|$s1Oh$MC...$MD$w3so they've sniffed out our
plan, have they?$K$PWhich means$w4 they're not an
opponent that will be easily fooled.
We'll need something special.$K
$s0Shall we$w2 continue with
the planned attack?$K
$s1No$MC... $MD$w3Princess Crimea is somewhere
within that fort.$K$PIf we use flaming arrows $w2to try to
smoke them out,$w3 we might bring
the princess to harm.$K$PWe've been told to do our best
to deliver her alive and uninjured.$K$PIt would be preferable$w2 if they were to
come out of their own accord. $w5If
they do, $w2slay all but the princess!$K
$s0Yes, sir!$K    $R�㉺��b|$c0DAKKOWA|What's going on?$w4 Weren't they
supposed to be completely
surrounded?$K  $R�㉺��b|$c0IKE|$s0Are you the commander of this
battalion?$K$POrder your men to retreat,$w4
and I'll let you escape with your life.$K
$c1DAKKOWA|$s1Don't push your luck,$w4
mercenary dog!!$K   $R�㉺��b|$c0DAKKOWA|I$MC...$MDdon't believe it$MC...$MD$w4
What went$w2 wrong$MC...$MD$K  $R�㉺��b|$c1SENERIO|$s1Ike!$w4
The enemy's taken the fort!$K
$c0IKE|$s0Oh no!$w5 Mist and the others$MC...$MD$K
$d1$c1TIAMAT|$s1$MC...$MDIke$MC...$MD$w4 It's too bad, but$MC...$MD$w3
We've $w2been defeated.$K
$s0How$MC...?$MD$w4$Fc
Father$MC...$MD$w2forgive me$MC...$MD$K   $R�㉺��b|$c0DAYNE2|General Dakova!$K$PNo, $w2not$MC...$MD$w3the general$MC...$MD$w4
Not at the hands of these scum$MC...$MD$w5
I will not allow it!$K$PAaaaah!$w3 Face me,$w4 and breathe
your last, you wretched scum!$K $R�㉺��b|$c1DAYNE2|General Dakova's gone$MC...$MD$w3
We're being beaten$MC...$MD$w4
We$MC...$MD$w2 We don't stand a chance.$K$PRetreat!$w3 Quickly now, retreat!$K    $R�㉺��b|$c1DAKKOWA|Grr$MC...$MD$w2 How've they lasted this long?$w3
Just who$w2 are these mercenaries?$K$PKnowing your enemy's strength$w2
is vital to any strategy$MC...$MD$K$PSoldiers!$w3 Retreat!$w4
We fall back for now!$K $R�w�i��b|$B�A�W�g�O��-��|$<$F3$FCL_IKE|$F1$FCL_SENERIO|$F1$PWe've cleared the surrounding area$w2
of Daein troops.$K
$F3$PThere's no question about it.$w2 We're enemies
of the Daein kingdom now, aren't we?$K
$F1$FD$F3$FD$F0$FCL_GREIL|$F0$PWe've no time for rest!$w4 Everyone,$w2
pack your things now!$w4 We leave at once,
before the enemy brings reinforcements!$K
$F3$FCL_OSCAR|$F3$PUnderstood!$w4
Boyd! $w2Come with me.$K
$F4$FCL_BOLE|$F4$PRight behind you, $w2Brother!$K
$F3$FD$F4$FD$F6$FCL_MIST|$F6$PAh! $w2We've got to hurry, too!$w4
Come on, $w2Rolf!$w4 We've got to pack as
much food and supplies $w2as we can!$K
$F4$FCL_LOFA|$F4$PUh, $w2whatever you say!$w4
Let's go, Mist!$K
$F6$FD$F4$FD$N$UB$H    $R�w�i��b|$B�A�W�g�O��-��|$<$F3$FCL_IKE|$F1$FCL_SENERIO|$F1$PWe've cleared the surrounding area$w2
of Daein troops.$K
$F3$PThere's no question about it.$w2 We're enemies
of the Daein kingdom now, aren't we?$K
$F1$FD$F3$FD$F0$FCL_GREIL|$F0$PWe've no time for rest!$w4 Everyone,$w2
pack your things now!$w4 We leave at once,
before the enemy brings reinforcements!$K
$F6$FCL_MIST|$F6$PAh! $w2We've got to hurry, too!$w4
Come on, $w2Rolf!$w4 We've got to pack as
much food and supplies $w2as we can!$K
$F4$FCL_LOFA|$F4$PUh, $w2whatever you say!$w4
Let's go, Mist!$K
$F6$FD$F4$FD$N$UB$H $F4$FCL_TIAMAT|$F0$PTitania!$w4 Take Shinon and Gatrie
and make sure we have a secure road
from here to the great forest.$K$PWe'll make our way to Gallia through
the sea of trees.$K
$F4$POn my way, sir!$K$F4$FD$N$UB$H   $F4$FCL_TIAMAT|$F0$PTitania!$w4 Take Shinon and make
sure we have a secure road from
here to the great forest.$K$PWe'll make our way to Gallia through
the sea of trees.$K
$F4$POn my way, sir!$K$FD$N$UB$H $F4$FCL_TIAMAT|$F0$PTitania!$w4 Take Gatrie and make
sure we have a secure road from
here to the great forest.$K$PWe'll make our way to Gallia through
the sea of trees.$K
$F4$POn my way, sir!$K$FD$N$UB$H $F4$FCL_TIAMAT|$F0$PTitania!$w4 I want you to go ahead
and make sure we have a secure road
from here to the great forest.$K$PWe'll make our way to Gallia through
the sea of trees.$K
$F4$POn my way, sir!$K$FD$N$UB$H  $F4$FCL_KILROY|$F0$PRhys, you stay with me.$K$PI want you to help me pull essential
documents from the library.$w4
Everything else we burn.$K
$F4$PY-yes, sir!$K$F4$FD
$F3$FCL_IKE|$F0$PIke!$w4 You're in charge of the princess.$K
$F3$PAll right.$K$F0$FD
$F1$FCL_ERINCIA|$F3$PPrincess Elincia!$K$PI'm $w2going to ready a horse for you.$w5
What should we have you do$MC...$MD$w3
I know$MC--$MD$w2go to the mess hall.$K
$F1$PI'm sorry?$K
$F3$PTime will go by faster $w2if you're helping
Mist$w3 than it will if you're just sitting
around waiting for me.$K
$F1$P$FSOh,$w4 I understand.$w3
I can do that!$K
$=0500  $F3$FCL_IKE|$F0$PIke!$w4 You're in charge of the princess.$K
$F3$PAll right.$K$F0$FD
$F1$FCL_ERINCIA|$F3$PPrincess Elincia!$K$PI'm $w2going to go$w2 and ready a horse for you.$w5
What should we have you do$MC...$MD$w3
I know$MC--$MD$w2go to the mess hall.$K
$F1$PI'm sorry?$K
$F3$PTime will go by faster $w2if you're helping
Mist$w3 than it will if you're just sitting
around waiting for me.$K
$F1$P$FSOh,$w4 I understand.$w3
I can do that!$K
$=0500   $R�w�i��b|$B�q��-��|$<$F1$FS$F1$FCL_ERINCIA|$F3$FCL_MIST|$F3$PSorry,$w4 this is kind of awkward.$w4
Making a princess $w2help with packing$MC...$MD$K
$F1$PPlease don't worry, $w2Mist.$w4
I just hope that I don't end up slowing
you down$w2 by getting in your way.$K
$F3$P$FSDon't be silly!$w4 You're so much better
at this than I am.$w2 It's a big help!$K$PAre$w3 all princesses $w2as good
at this sort of thing as you are?$K
$F1$PHa ha!$w3 I wasn't raised at court,$w2 so my life
was a bit different$w2 than other princesses.$K$PI cooked, $w1cleaned, $w1sewed$MC...$MD$w4 Why,
I did all manner of things.$K
$F3$PReally? $w2That's surprising.$w4
I would never have guessed that
by looking at you.$K
$F1$PLet's see, I also$w2 rode horses, $w1practiced
swordfighting$MC...$MD$K$FA
Ah, $w2Mist.$w4
What's that around your neck?$K
$F3$PWhat?$w4 $FAOh, $w2ah$MC...$MD$K
$F1$PI'm sorry, I didn't mean to$MC...$MD$K
$F3$P$MC...$MDI guess I can show it to you,$w3
Princess Elincia.$K $R�w�i��b|$B�q��-��|$<$F1$FCL_ERINCIA|$F3$FCL_MIST|$F1$POh$MC...$MD$w3 It's a lovely... That's an incredible
medallion, isn't it?$w5 I wonder what that
light is.$K
$F3$PIt used to belong to my mother. It's all I
have to remember her by.$w4 Hmm$MC...$MD$w4 I don't
know $w2where the light comes from.$K$PIt didn't used to $w2be like that.$w4
A while back, $w2it just started glowing.$K
$F1$PThe world is full of mysteries, isn't it?$w4$FS
One thing is clear, though$MC...$MD$w4 It certainly
is $w2beautiful.$K
$F3$PI wonder what that light means$MC...$MD$K
$=1500 $=0500$R�w�i��b|$B���-������02|$<$F3$FCL_DAYNE2|$F1$FCL_PRAGUE|$F1$PWhat?$w3 What did you just say?$w5
I think I must be hearing things.$w4
I thought you said, $w2"They got away."$K
$F3$PIt appears $w2treating them as ordinary
mercenaries$w2 was a mistake.$K$PIf they're strong enough to defeat
General Dakova,$w4 we rank and file were
overmatched from the beginning.$K
$F1$PSo?$w3 You tucked your worthless tail$w2
and came running back here, is that it?$K$PHave you forgotten the Daein army's motto?$w5
"Success or failure,$w3 life or death."$w4 Hey,
$w1you!$w3 Get this trash out of here!$K
$F4$FCL_DAYNE1|$F4$PYes, ma'am!$w4
Move it, $w2you.$K
$F3$PNoooo!$w5 P-$w1please!$w4 I don't
want to die!$K
$F4$FD$F3$FD$F1$PDog's breath!$w4 I'm surrounded$w2
by worthless imbeciles.$K
Ena!$K
$F4$Fc$F4$FCL_ENA|$F1$PTell me which way we should move$w3 to
catch these mercenaries and the girl.$K
$F4$P$Fd$MC...$MDThe Crimean capital, $w1Melior,$w2 is already
under King Ashnard's control$MC...$MD$w4 The remnants
of the Crimean army $w2are neglible$MC...$MD$K$PWhich means$w3 the only place left for the
princess to turn $w2is south, to the kingdom
of Gallia.$K
$F1$PHah! $w2So the girl, like her dead father
before her, seeks the friendship of
those hairy devils, eh?$K$PWhat an absolutely stupefying
world we live in.$K
$F4$PIf she gains sanctuary in Gallia, capturing
the princess will become that much
more difficult.$K$P$MC...$MD$w2The mercenaries she has escorting
her$w3 are a powerful group, not one
to be taken lightly.$K$PI will gather intelligence on them as
quickly as$MC...$MD$K
$F1$PIt's not necessary.$w4$FS
I will head up the pursuit of our
wandering princess.$K
$F4$PGeneral Petrine, $w2you will go$MC...$MD$w3yourself?$K
$F1$PIf we know where the princess and her band
are headed,$w2 there's no need for subtlety.$w3
I'll just hunt them down and kill them.$K$PMercenaries?$w4 Hah!$w3 What're they to me?$w4
Remember, I am General Petrine!$K$PNo matter who I face, $w2I have never
failed, nor will I ever!$w4 Ha ha ha$MC...$MD$K
$=1500 $=0500$R�w�i��b|$B���-������02|$<$F3$FCL_DAKKOWA|$F1$FCL_PRAGUE|$F1$PWhat?$w3 What did you just say?$w5
I think I must be hearing things.$w4
I thought you said, $w2"They got away."$K
$F3$PGe-$w2General Petrine.$w4
I am deeply ashamed. By my honor$MC...$MD$K
$F1$PHonor?$w3 I care nothing for your
pathetic honor.$K$PHave you forgotten the Daein army's motto?$w5
Success or failure,$w3 life or death.$w4 Hey,
$w1you!$w3 Get this trash out of here!$K
$F4$FCL_DAYNE1|$F4$PYes, ma'am!$w4
Move it, $w2you.$K
$F3$PW-$w2wait!$w4 General Petrine,$w2 have
mercy$MC...$MD$K
$F4$FD$F3$FD$F1$PDog's breath!$w4 I'm surrounded$w2
by worthless imbeciles.$K
Ena!$K
$F4$Fc$F4$FCL_ENA|$F1$PTell me which way we should move$w3 to
catch these mercenaries and the girl.$K
$F4$P$Fd$MC...$MDThe Crimean capital, $w1Melior,$w2 is already
under King Ashnard's control$MC...$MD$w4 The remnants
of the Crimean army $w2are neglible$MC...$MD$K$PWhich means$w3 the only place left for the
princess to turn $w2is south, to the kingdom
of Gallia.$K
$F1$PHah! $w2So the girl, like her dead father
before her, seeks the friendship of
those hairy devils, eh?$K$PWhat an absolutely stupefying
world we live in.$K
$F4$PIf she gains sanctuary in Gallia, capturing
the princess will become that much
more difficult.$K$P$MC...$MD$w2The mercenaries she has escorting
her$w3 are a powerful group, not one
to be taken lightly.$K$PI will gather intelligence on them as
quickly as$MC...$MD$K
$F1$PIt's not necessary.$w4$FS
I will head up the pursuit of our
wandering princess.$K
$F4$PGeneral Petrine, $w2you're going$MC...$MD$w3yourself?$K
$F1$PIf we know where the princess and her band
are headed,$w2 there's no need for subtlety.$w3
I'll just hunt them down and kill them.$K$PMercenaries?$w4 Hah!$w3 What are they to me?$w4
Remember, I am General Petrine!$K$PNo matter who I face, $w2I have never
failed, nor will I ever!$w4 Ha ha ha$MC...$MD$K
$=1500   /4      /�   	  0X     40      6�   1  9<   B  :   S  :�   f  ;�   y  <�   �  >�   �  @�   �  D|   �  F�   �  N�   �  2�   �  3L   �  1�    0�        %   �  1  x  =  �  I  X  X  0  i  �  z  �  �  4  �  �  �  t  �  �  �  H  �  �  �   �     !�    #  "  #�  3  %  B  %D  S  &,  b  &�  s  '  �  '�  �  '�  �  (<  �  (�  �  )`  �  +�  �  ,l  �MS_06_BT MS_06_BT_IKE MS_06_DIE MS_06_ED_01_01_A MS_06_ED_01_01_B MS_06_ED_01_02_A MS_06_ED_01_02_A_a MS_06_ED_01_02_A_b MS_06_ED_01_02_B MS_06_ED_01_03_A MS_06_ED_01_03_B MS_06_ED_02 MS_06_ED_03 MS_06_ED_04 MS_06_ED_04_BOSS MS_06_ED_ENEMY MS_06_ED_ENEMY_BOSS MS_06_EV_ENEMY_01 MS_06_GAMEOVER MS_06_OP_01 MS_06_OP_02 MS_06_OP_05 MS_06_OP_05_01 MS_06_OP_05_02_A MS_06_OP_05_02_B MS_06_OP_05_03_A MS_06_OP_05_03_B MS_06_OP_05_04 MS_06_OP_05_05_A MS_06_OP_05_05_B MS_06_OP_05_05_C MS_06_OP_05_06_A MS_06_OP_05_06_B MS_06_OP_05_06_C MS_06_OP_05_06_D MS_06_OP_05_06_E MS_06_OP_05_07 MS_06_OP_05_08_A MS_06_OP_05_09 MS_06_OP_05_10_A MS_06_OP_05_10_B MS_06_OP_05_11_A MS_06_OP_05_11_B MS_06_OP_05_12_A MS_06_OP_05_13_A MS_06_OP_05_13_B MS_06_OP_05_14 MS_06_OP_05_15 MS_06_OP_05_15_0 