  g4  d        $                $R�w�i��b|$B���-����-�L���o�X|$<$F3$FCL_RIEUSION|$F1$FS$F1$FCL_NEALUCHI|$F1$POh my! $w2If it isn't young Prince Serenes!$w4
Welcome, welcome, welcome.$K
$F3$P$FSNealuchi, $w2you're looking well.$K
$F1$PAnd feeling well, too, thank you very much.$w2
This old crow's as spry as ever. Hee hee!$K$w5$FA$P...$w4Tell me though. How fares your
father, King Lorazieh?$K
$F3$P$FAThe same as ever.$w2 Since that terrible day,
he remains abed...$w4 He seldom rises anymore.$K
$F1$PMmm... I'm not surprised.$K$PIn the span of a few days, he lost his
family, his friends, $w2and almost all
of his countrymen.$K
$F3$P$FhYes...$K
$F1$P$FSAnd yet, $w2we're blessed that you
are still with us!$K$PPrince Reyson, $w2if there's anything this
doddering old bird can do for you,$w2
please do not hesitate to ask.$K
$F3$P$Fd$FSThank you.$w4 I appreciate your
kind sentiment.$K
$F1$FD$F3$FA$F0$FS$F0$FCL_NAESALA|$F0$PSorry to have kept you waiting, $w2Reyson.$K$w4$FA$PNealuchi!$w4 You can talk ancient history later.$w4
Leave us at once.$K
$F0$FD$F1$FS$F1$FCL_NEALUCHI|$F1$PYes, yes, of course.$w4 I'm sure you've
much to talk about, much to say.$w2
I'll just take my leave of you...$K$PPlease, $w2Prince Reyson.$w2 Make yourself
at home.$K$F1$FD
$Ub$H$F1$FS$F1$P$F1$FCL_NAESALA|$F1$PHmph!$w4 Old Nealuchi's always been
fond of House Serenes.$K$PWhen he heard the White Prince himself
was gracing us with a visit, he could barely
contain his joy.$K$PSo, Prince. What's this all about?$K$PWe haven't seen your face around here in
a long time, $w2and I'm naturally quite
curious as to your intentions.$K
$F3$PYour attitude during the Goldoa meeting
piqued my interest.$K$PWhat is it you're after, $w2Naesala?$w4
Why do you provoke Tibarn?$K
$F1$PYou came all this way for that?$w4
Are you serious?$K
$F3$PDo not mock me, crow king!$w4
Tibarn $w2is my father's guardian.$K$PIf not for him,$w4 we might have suffered
the end of House Serenes itself.
I will not brook any insults $w2to him.$K
$F1$POh, I see.$w4 So rather than ally yourself with
me, your trusted companion of old,$w2 you
would side with this new protector?$K$PThat's an unfortunate shift in attitude.$K
I trust you remember that when you and
your sister were young, $w2it was I, $w2and
not Tibarn, who watched over you?$K
$F3$PAny change in my bearing can be laid
at your roost, Naesala.$K$PAfter all...$w3you, my old friend, are the one
who continues to engage in commerce
with my enemy.$w4 With humans.$K$PIf you were to change your ways,$w2
I'm sure we could rebuild the relationship
the two of us once shared.$K
$F1$POh no,$w3 that I could never do.$w4
You see, humans $w2are essential to
the fulfillment of my ambitions.$K
$F3$P...You've changed, $w2Naesala.$K$PIf this is the path you've chosen,$w2
I've nothing left to say.$K$F3$FD
$Ub$H$F1$P...$w4$FAI doubt you could ever understand$w5
what it means $w2to guard Kilvas, Prince.
To protect an entire country.$K$P$F4$FCL_CROW|$F4$PKing Naesala!$w4 Duke Tanas of the Begnion
Imperial Senate $w2has arrived.$K
$F1$PBring him in.$K$F4$FD
$Ub$H$F3$FCL_OLIVER|$F3$PYour Majesty!$w4 J-$w2just now,$w2 I brushed
against the most splendid specimen!$w2
W-was that a Serenes noble?$K
They're supposed to be extinct!$K
$F1$PAnd what if it were?$K
$F3$P$FSOh, $w2I was right! Wonderful!$w4
My eyes did not deceive me.$K$PThose dazzling white wings.$w2
And that shimmering hair, sparkling
like falling gold dust...$K
$FcThat $w2is the crystallization of
beauty in its purest form--$K
$F1$PDuke Oliver,$w4 can we please discuss
the business at hand?$K$PPer your request,$w2 we have
appropriated several pieces of art
from the ships of Duke Gaddos.$K
$F3$P$FdYes, yes, $w2and you will be compensated
as promised.$w4 But right now there is...$w4
something else that I simply must have.$K
$F1$P$FSReally? $w2Another request? What can we
purloin for you today? More art, perhaps?$K
$F3$POh ho!$w3 Something much more stunning.$w3
And if you agree to my proposition,
I will double your normal fee!$K
$F1$PThat $w2is a most generous offer.$w4
Tell me, $w2what is it you desire?$K
$F3$PDesire? $w2But surely you've already guessed...$K
$=1000    $R�w�i��b|$B���-����-�x�O�j�I��|$<$F3$FCL_IKE|$F1$FCL_TIAMAT|$F3$PMeeting with the apostle was fine,$w2
but all she did was pay us and give us
another job. $w2She answered no questions.$K
$F1$PI wonder what she's planning.$w4
That cargo...$w3 I can't help but believe that
there were living creatures inside, but...$K$PWhat do you suppose $w2the apostle
intends to do with them?$K
$F3$PI don't know.$w4 Titania, are all nobles
and royals like this?$K$PThey have plans and paperwork for every
little thing, $w2and their speech is as
confusing as it is tedious.$K
$F0$FCL_MIST|$F0$PBut, Ike, $w2the other nobles
we know are different!$K$PThere's Princess Elincia, $w2and King Gallia,$w2
$FSand the dragon prince, too!$K$P$FAAll of them $w2have been so nice
and friendly and easy to talk to.$K
$F1$PPerhaps the rudeness of the upper echelon
is $w2unique to the beorc class system.$K$PPrincess Elincia $w2was raised in special
circumstances. $w2Maybe that's why she's
so different.$K
$F3$PBah! I could never get accustomed to
the culture of beorc nobles.$K
$=1000   $R�w�i��b|$B����|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F3$PTell me, Soren,$w4 are you $w2all right?$K
$F1$PHm?$K
$F3$PRecently--$w2ever since we reached Begnion,
in fact--$w3you've seemed depressed.$K
$F1$PIs...$w2is that so?$w4 How odd. Well, I can think
of nothing $w2specific that's bothering me.$K
$F3$PWell, if you say so.$K
$F1$Fh$F3$PSo, $w2it's time for the desert!$w4
Which is the best direction to enter from?$K
$F1$P...$K
$F3$PSoren?$K
$F1$P$Fd...Eh?$w4 Yes, $w2what is it?$K
$F3$PAll right, $w2I know there's
something going on!$K
$F1$PI'm... $w2I'm sorry... $w5I was...thinking.$w4
What is it you wanted?$K
$F3$PWell, I was going to ask you for directions,
but it's no longer necessary.
It looks like we're being met.$K
$F1$PAh!$K   $R�㉺��b|$c0TOPUCK2|$s0Who are you?$w4
Answer me!$K
$c1IKE|$s1We're mercenaries.$w4 We were
hired to take care of a group of
bandits operating in this area.$K
$s0More of the senators' dogs!$K$PYou cast us as thieves so you can$w2
murder us and hide your guilt!$w4
But $w2we will not be defeated!$K$PMark my words!$w4 The day will come
when all slaves are free, and then
you will pay for your crimes!$K
$s1What on earth are you talking about?$K
$s0No more useless words!$w4
Come, my brothers! $w2Take them!$K   $R�㉺��b|$c0IKE|$s0What? $w2We're facing laguz?
I don't like the look of this!$K
$c1SENERIO|$s1Laguz or no, it doesn't change the
fact that they are brigands.$w4
Do not lower your guard!$K
$s0I know what I'm doing.$w4 Everyone!$w2
Watch your footing in this sand.$w2
Take care $w2and fight well!$K $R�㉺��b|$c1LETHE|$s1?$K$d1$w6
$c1LETHE|$s1Sniff... $w2Hm?$K$d1$w6
$c3LETHE|$s3I...sense...something...$w4
$MC...$MD$w3Grrrr...$w2Must be my imagination...$K $R�㉺��b|$s1$FS$c1SOANVALCKE|$s1A female cat!$w3 Splendid! I've not seen$w2
your face in these parts before.$K
$c3LETHE|$s3Aaaah!$K
$d3$Ub$H$c0LETHE|$s0Wh-$w2where...$w4
Where $w2did you come from?$K
$s1Oh,$w3 I see that I've startled you.$w4
My $w2apologies.$K
$s0Who are you?$K
$s1If you wish to learn someone's name,$w3
isn't it polite $w2to introduce yourself
first?$K
$s0Grrr...$w3 I am...Lethe.$w4 From Gallia.$K
$s1And I...$w4am Stefan!$w4 I live here in
this desolate wasteland, $w2playing at
being a hermit.$K
$s0Is that so? $w2Well, don't let me
interrupt your...$w4life.$K
$s1Oh no!$w4 Please don't worry about it.$K
$s0Oh, I won't.$K$d0$w6
$c0LETHE|$s0...And?$K
$s1What?$K
$s0Why $w2are you standing there$w3
staring $w2at me?$K
$Ub$H$s1I'm interested $w2in Gallia's beast tribes.$w4
Fascinating, really. I have an idea!
Can we go somewhere and talk?$K
$s0...I don't think so.$K
$s1Why not?$K
$s0My $w2companions and I are in the
middle of a battle! $w5I've no time to
chitchat with you!$K
$s1Very well...$w2 Then I will help you!$w4
And once this battle is finished,$w3
you'll have time to converse, yes?$K
$s0I suppose...$w3perhaps...$K
$s1Right! $w2Off we go then!$K
$s0$Fh...$w2What sort of lunatic have
I found now?$K    $R�㉺��b|$c1MORDY|$s1Sniff...$K$d1$w6
$c1MORDY|$s1Urrrr?$K$d1$w6
$c3MORDY|$s3Something's...$w3here...$w4
Beneath...the sand...$w3 Mmmrrr??$K  $R�㉺��b|$s1$FS$c1SOANVALCKE|$s1Nope! $w2I'm over here.$K
$Ub$H$c0MORDY|$s0$FSSo there you are.$w5
You are...$w2good at hiding.$K
$s1To be praised by one of the beast
tribes $w2is an honor!$K$PI am Stefan!$w4 I live here in
this desolate wasteland, $w2playing at
being a hermit.$K
Who are you? $w2I haven't seen you
in these parts before.$K
$s0I am Mordecai,$w2 a warrior of Gallia.$w4
This is the first time $w2I have walked
beyond the borders of my country.$K
$s1I thought $w2that might be the case...$w4
And $w2I was right. Hoooo!
I'm ever so clever!$K$P$Ub$H$s1Mordecai, listen here.$w3 I'm interested $w2in
the beast tribes of Gallia.$w4 Would you
mind $w2talking with me? I'll buy dinner!$K
$s0$FAUm... My$w2 friends and I$w3 are
fighting,$w2 so I...$w3cannot.$w4 Sorry.$K
$s1Very well, $w2then! I will help you.$w4
Once this battle is finished,$w3 you'll
have time to converse, yes?$K
$s0$FSAll right. $w2If you will fight with us,
then I will call Stefan a friend.$K
Later, $w2we will talk about Gallia.$K
$s1I'm looking forward to it.$w4
Right then,$w3 off we go!$K
$s0Yes! Off we go!
...Right...then...$K    $R�㉺��b|$c0ME|$s0Huh?$K
$c1SOANVALCKE|$s1Oh, look at you! Lost $w2in a place like
this...$w4 What an odd duck you must be.$w2$K$PHmm...$w3 It would be a shame $w2to see
you go home empty-handed, though.$w4$FS
I will give you this as a memento!$K$PNow, in exchange...$w4 I ask you to
treat our meeting as a dream$w3 and let
it fade from your memory.$K
And now, I bid thee...$w4farewell!$K  $R�㉺��b|$c0SENERIO|$s0Woah!$K
$c1SOANVALCKE|$s1Are you lost, young one?$w4
What are you doing in this place?$K
$s0What are YOU doing here?$w2 Are you
with the sub-humans?$w4 ...$w4Wait, did
you just pop out of the sand?$K
$s1Mmm...$K
$s0What?$K
$s1...Hmm.$w3 It seems I made an error.$K
$s0What are you talking about?$w3
You're not--$K
$s1I was wrong. It's nothing.$w4
I've $w2no use for you.$K
$s0Oh. All right, then.$K$d0
$s1Hold!$K
$c0SENERIO|$s0What now?$K
$s1It would be a shame $w2to see
you go home empty-handed.$w4$FS
I will give you this as a memento!$K$PNow, in exchange...$w4 I ask you to
treat our meeting as a dream$w3 and let
it fade from your memory.$K
And now, I bid thee...$w4 Farewell!$K    $R�㉺��b|$c0MWARIM|$s0My companions and I $w2are not
thieves.$w4 I'm sure$w2 you could
not care less, though!$K   $R�㉺��b|$c0IKE|$s0If what you say is true...$w2
If you really aren't bandits,$w4
then stop fighting!$K$PIf this is some kind of mistake,$w2
we can talk it over.$K
$c1MWARIM|$s1Ha! I won't fall for that trick.$K$PThat's how your kind$w3 always
deceives and $w2traps us.$w5
$MC...$MD$w3Here I come!$K
$s0Hey!$K $R�㉺��b|$c0LETHE|$s0Listen to me, brother.$w3 Come to
your senses and stop this!$K
$c1MWARIM|$s1Heed my words!$w4 Do not
throw away your laguz pride$w3
and run with humans like--$K
$s0What did you say?$w4 You are one
to speak of pride! You who associate
with a band of common thieves!$K
$s1This is a waste of time.$w4
Come,$w3 I will show you the
truth of my words.$K
$s0Uh!$K $R�㉺��b|$c0MWARIM|$s0Move away,$w3 brother tiger.$w4 I have
no wish to fight one of my own.$K
$c1MORDY|$s1I do not wish to harm you, either.$w4$FS
Let's stop fighting$w3 and talk.$K
$s0...Talk?$w3 It seems you've already
been tamed.$w4 ...$w2How unfortunate...
Now you die!$K
$s1$FAAh!$w4 Stop!$K $R�㉺��b|$c0SOTHE|$s0...$w3G-gulp! $w5C-$w2calm down...$w3
Oh, my heart's...$w4beating so fast...$w2
Gotta aim for a vital spot! C-careful...$K
$c1MWARIM|$s1$MC...$MDWhat?$w4 You there! Stop!$w3
I don't fight children!$K  $R�㉺��b|$c1MWARIM|$s1What?$w4 You're so young...$K
$c0LOFA|$s0I-$w1I'm not scared of you!$w4
It doesn't matter if you're a laguz;$w3
an enemy is an enemy!$K
$c1MWARIM|$s1Please!$w3 Stop!$w5 Why are young
cubs like you$w3 on the battlefield?$w2
Why?$K   $R�㉺��b|$c0MWARIM|$s0What?$w4 No, not$w3 another child...$K
$c1MISTs|$s1$MC...$MD$K
$s0Stop! $w5Your sword hand,$w2 it's trembling!$w4
$MC...$MD$w2Please! Don't do this!$K
$s1$MC...$MDNo...$w4$FcI will not be the only one
who runs away!$K   $R�㉺��b|$c0MWARIM|$s0$Fh$MC...$MD$w4Urk... N-no...$K $=0700$R�w�i��b|$B����-���|$<$F0$FCL_MWARIM|$F0$PHaah...$w3haa...$w2haa...$w5 We $w2lose...$K
$F4$FCL_IKE|$F4$PYou!$w2 You're the leader of this band,
aren't you?$K
$F0$PYes...$w2I am.$K$PI'll resist you no further.$w4 Take me with you
or execute me here...$w3 I care not.$K$Fc$PBut$w3 my companions...$w4 Would you$w2 let
them go? $MC...$w3$MD$w3Please?$K
$F7$FCDUMMY|$F7$PNo! I won't allow it!$K
$F0$Fo$F4$PHuh?$K
$F1$FCL_TOPUCK|$F1$PI won't let you take Muarim!$K
$F0$P$FdGrrr... Stay back, $w2little one!$w5
You were not supposed to expose--$K
$F1$PIf you want Muarim, you'll have to
kill me first!$K
$F4$PYou're--$K
$F0$PYes, $w2he is a beorc child.$w5 I claimed him
when he was little more than an infant.$w4
He has nothing to do $w2with us...$w3sub-humans...$K$P$F1$FD$F2$FCL_TOPUCK|$F2$PStop lying!$w4 I'm here because I want to be!$K
Who's the leader $w2of the laguz emancipation
army?$w4 I am!$K$PYou're a big jerk, Muarim! $w5Trying to cover
for everyone and get yourself killed?$w3$Fh
I won't allow it!$K
$F0$PLittle one...$K
$F4$PHey! I don't care who$w2 the real leader is.$K
$F2$FD$F1$FCL_TOPUCK|$F4$PA laguz$w3 who calls himself a sub-human
is protecting a kidnapped beorc who claims
to lead a laguz emancipation army?$K$PDo I have that right?$w4 Because if I do,
I have absolutely no idea what any of
you are talking about.$K$PWould someone please tell me what is
going on here?$K
$F1$P$MC...$MD$K
$=1000 $R�w�i��b|$B����-���-����|$<$F1$FCL_TOPUCK|$F0$FCL_MWARIM|$F3$FCL_IKE|$F3$PAll right... Please go over that again.$w2
It's been customary throughout Begnion's
history to keep laguz as slaves?$K
$F1$PThat's right.$K
$F4$FCL_TIAMAT|$F4$PBut $w2that's in the past now!$w4
Twenty years ago, $w2all slavery was
outlawed, $w2and all laguz were freed!$K
$F4$FD$F4$FCL_NASIR|$F4$PAnd as far as the general public is
concerned,$w2 that is exactly what
happened.$K
$F3$PSo there's a portion of society that$w2
willingly breaks the law?$K
$F1$PThe commoners obey,$w3 but there are still
many laguz slaves in the homes of nobles.$K$PMuarim and I $w2brought this to the attention
of the senators,$w4 but they would not listen.$K$PThat's why we gathered other fighters.$w2
We break into the homes $w2where slaves are
kept$w4 and help them escape.$K$POf course,$w4 the nobles can't let this be
known publicly,$w3 so they brand us thieves$w2
and turn us into$w4 wanted outlaws.$K
$F3$PAll right. $w2I think I understand your motives,
but you're not going to solve the basic
problem this way.$K
$F1$PWe know that.$w4 But $w2we can't give up and
leave them in chains.$w4 We can't and won't!$K
$F3$PDo you mind if I try to help?$K
$F1$PHuh?$K
$F3$PThis sort of beorc behavior$w3 is something
that's been $w2bothering me.$K$PI think$w3 there may be something
that I can do...$K $R�㉺��b|$c0RIEUSION|$s0Naesala! Stop this foolishness!$w2
Where are you taking me?$w4
Tell me!$K
$s1$FS$c1NAESALA|$s1It's only a little farther!$w4
I'll tell you once we've arrived,$w2
just as I promised.$K$d1
$s0I left no word with Tibarn. If I had
known we were coming this far,$w2
I would have $w2left a message...$K  $R�㉺��b|$c0NAESALA|$s0Here we are.$w4 This $w2is what I
wanted to show you.$K$PLook below you,$w3 Reyson.$w4
What do you see?$K
$c1RIEUSION|$s1$FoWhat...$w3what is this?$w5
How is this possible?$w4
What happened here?!$K $R�㉺��b|$c0NAESALA|$s0...$K  $R�㉺��b|$c1RIEUSION|$s1This...$w5is Serenes?$w4 Is this what
you're trying to tell me?!$K$PThis colorless vista,$w3 these cracked and
withered branches,$w3 these lifeless
trees...$w4 This is my forest?$K  $R�㉺��b|$c1RIEUSION|$s1#F01$O2O sacred trees!$w4 Seed, root, and trunk!#F02$O1
#F01$O2Awake from your slumber $w2and heed my cry!#F02$O1
#F01$O2Answer the call of the green, mighty ones!#F02$O1$K
$Ub$H$c0NAESALA|$s0...The ancient tongue.$w4 It's been many
years since I heard it last.$w4 You can
still $w2speak it.$K
$s1The voice of the forest is still.$w4
Why...$w4 How did this...$K
$s0It's been like this $w2since your clan's
been gone.$K$PThe area near the entrance is
especially bad.$w4 They used fire...$w2
Most of the trees are dead.$K
$s1...Unforgivable.$w4 How...$w2how can they
do things like this.$K$w5$Fh$PCursed humans...$w4 What did this forest
do?$w4 What did my clan $w2do...$K
$s0Humans hold all laguz in contempt.$w3
And in the same way, $w2they hold all
of nature in contempt as well.$K$PThey think everything $w2exists for
their pleasure and betterment...
They are beneath contempt.$K $R�㉺��b|$c0RIEUSION|$s0Naesala...$w4 It appears $w2that I have
misjudged you.$K$PI called you a groveling toady to
humans $w2and labeled you traitor.$w4
I was overly harsh. $w5I apologize.$K
$c1NAESALA|$s1Not to worry.$w5 I engage in occasional
commerce with humans...$w2
That much is true.$K$PA more pressing issue$w3 is the growing
darkness.$w4 You can return to Phoenicis
tomorrow, can you not?$K$PI'm certain that$w3 some noble has a
villa $w2in this area.$K$PAt this time of year, $w2it is almost
certain to be empty. $w2I suggest
we borrow it for the evening.$K
$s0You would sleep $w2in a human building?$K
$s1Think about it... $w5Bird folk like you and
I have no$w2 night vision whatsoever.$K$PIf we were discovered by humans,$w2
they would surely overwhelm
and capture us, $w2right?$K
$s0Mmm... I see your point.$K   $R�w�i��b|$B�^�i�X�@-����|$<$F1$FS$F1$FCL_NAESALA|$F1$PVery good. $w2I'll go stumble around until I
find something to eat. Please...$w3
make yourself comfortable.$K$F1$FD$P$F3$FCL_RIEUSION|$F3$PNaesala!$K$P$F0$FS$F0$FCL_NAESALA|$F0$PYes?$K
$F3$PThank you.$w4 For everything you've done.
I...$w3I appreciate it.$K
$F0$PDon't be ridiculous.$w4 We're old friends,$w2
are we not?$K
$F3$P$FSRight you are!$w4 Old friend.$K
$=0800   $R�w�i��b|$B�^�i�X�@-��O-��|$<$F5$FCL_NAESALA|$F5$PIs everything in place?$K$P$F4$FCL_CROW|$F4$PYes.$w4 That Duke Tanas cannot sit still.$w2
He is literally...$w3quivering with anticipation.$w5
It's not pretty.$K
$F5$P$FSI bet it isn't.$K$PJust $w2make sure that mountain of suet stays
hidden.$w4 If Reyson catches so much as a
glimpse of his bulk, $w2he will take wing.$K
$F4$PUnderstood.$K$P$F4$FD$w6
$F5$PNow, $w2time to put on the finishing touches.$w5
This, too, $w2I do to raise up Kilvas.$w4
Reyson, $w2please don't judge me too harshly.$K$w4$Fc$PThat being said, $w2I'm sure you will.
Ah, well. Such is life.$w3
Enjoy your new one...$w4 Old friend...$K
$=1500   $R�w�i��b|$B���-����-�x�O�j�I��|$<$F1$FCL_SERVANT|$F3$FCL_IKE|$F1$PAhem.$w4 You $w2are from the northwest
nation of Crimea, are you not?$K$PYou have my condolences$w3 for the
terrible misfortune$w4 that has befallen
your country and people.$K$PYet$w3 you remain blessed!$K$PFate has brought you here$w3 to the Grand
Temple Mainal! $w2To the splendor of Begnion,$w3
grandest of all the nations of Tellius.$K$PBy the way,$w3 I hear you are traveling$w2
north to the Grann Desert. There are
ancient ruins there, you know?$K$PThey are the remnants of a race known as
the Zunanma, who come from a civilization
that predates our own.$K$PI'm sure you will enjoy$w3 the sensation of
being immersed $w2in such primordial
surroundings!$K
$F3$PUm...yeah.$w4 It'll be a real picnic.$K
$F1$POh, yes, picnics are indeed nice.
Oh, but a word of caution.$K$PStudying the ruins from afar is one thing,$w3
but you would be well advised to keep
your distance...$w2 For safety's sake!$K$PIt's said that there's a bandit stronghold$w3
near the northwest ruins.$K$PAnd we hear occasional reports of
strange figures wandering the dunes
in the northeast.$w4 Be careful!$K   $R�w�i��b|$B���-��|$<$F3$FCL_IKE|$F1$FS$F1$FCL_SIGRUN|$F1$PHow are your preparations progressing?$K
$F3$PThey're underway. We leave within the hour.$K
$F1$PYour next mission $w2takes you to the
Grann Desert.$w4 You must choose
your companions $w2with care.$K
$F3$PA desert is just a large patch of
sandy soil, is it not?$K
$F1$PHa ha!$w4 With one major difference!
Unlike sandy soil, $w2you'll not find
solid earth $w2near the surface.$K$PYou could dig and dig $w2and find only more
sand.$w4 Those on foot and horseback$w2
may find it difficult to move around.$K
$F3$PI see.$w4 I'm sure that Soren knows $w2much
about these things, but...$w4$K
$F1$PHmm? Has something befallen$w2
master Soren?$K
$F3$PI don't know if he's feeling ill $w2or
just moping about.$w4 It all started
when we arrived in Begnion.$K
$F1$P$FAOh...$K
$F3$PBe that as it may,$w3 it won't hurt for me
to have this information.$w4 Can you tell
me more?$K
$F1$P$FSOf course. $w5There's little water in the
desert, $w2and the soil is very dry.$w3
Few trees or grasses grow there.$K$PWhich means$w3 there are no groves or
anything$w2 else which would provide cover.$K$PAnd, $w2as I mentioned before,$w3 those on foot
$w2or horseback will find the sand slows their
pace considerably.$K$PThe exceptions are $w2magic users, staff
wielders,$w3 and thieves.$w4 Such people
will not be affected to so large a degree.$K
$F3$PThieves are agile, so I understand why they
would be unaffected. But those skilled in
the magical arts? That doesn't make sense.$K
$F1$PI once heard an explanation from
a $w2magic user that I know...$K$PHe claimed that the spirits he employed$w2
flew before him$w3 and cleared the sand
from his path.$K$PHowever, considering the source,$w3
I'm not sure how much of that is truth.$K
$F3$PWho was the source?$K
$F1$PPrime Minister $w2Sephiran.$K
$F3$PWould he $w2play a joke like that?$K
$F1$PHa ha!$w4 Well, the prime minister is a very
amusing man.$w4 But, please, allow me to
continue my explanation.$K$PWhat else...?$w3 Others who are unaffected
by sand$w3 are pegasus knights, wyvern riders,$w2
and other flying units.$K$POh, and laguz, too.$w3 Terrain features don't
seem to affect them much in either form,
although they will be slowed some.$K
$F3$PYou said $w2laguz, didn't you?
Almost everyone here says sub-human.$K
$F1$P$FAWell, of course.$w4 Beorc and laguz$w5
are both living things.$K$PEvery precious life $w2was created to
be equal by the blessed goddess.$K$PThe fact that there are still those $w2who
persecute laguz in the land of the
goddess...$w4$Fc It is deplorable.$K
$F3$P...$w2Are you of a noble house?$K
$F1$P$FdYes, I am.$w4 One must be of noble
birth to serve the goddess.$K
$F3$PBut I thought...$w4that all nobles were
half-crazed fools who can't speak the
truth.$w4$FS You seem quite honest.$K
$F1$P$FSHa ha,$w4 I'll take that as a compliment...
Oh,$w3 and one last thing.$K
$F3$P$FAWhat is it?$K
$F1$PThe desert $w2contains the remnants $w2of
more than one lost civilization.$K$PRumor has it$w3 that treasures from those
times still lie undiscovered beneath the
shifting sands.$K$PThose with good luck$w3 may come across
such treasures $w2during battle.$K    $R�w�i��b|$B���-��|$<$F5$FS$F5$FCL_MAKAROV|$F5$PHoooweee!$w3 The Grand Temple!$w4
Luxury and...$w3gorgeousness as far as
the eye can see.$K$PIf a scoundrel like myself$w3 can find
employment in a place like this,$w4 I guess
my luck $w2hasn't abandoned me after all.$K
$F3$FCL_IKE|$F3$P...$K
$F5$P$FABut...$w4for all the glitter and gold,$w3
there's an equal amount of dangerous work.$w4
Hmm... $w2That I could do without.$K$PMaybe I can use my prone-to-illness ploy...$w3
Cough!$w4 Yes, I think I can arrange to work$w2
about one out of every...$w3five jobs or so!$K$FS$PAnd now that I've a fixed income,$w4
it's time to visit the local inns $w2and see
what games of chance are about!$K
$F3$PEvening.$K
$F5$FD$F1$FCL_MAKAROV|$F1$PWHAAAA!$w4 You... $w5Did you $w2happen to$w3
hear any of $w2that?$K
$F3$PYou were talking out loud. $w6Loudly.$K
$F1$PUm...$w2I, uh...$w4 I wasn't $w2being serious...$w4$FS
I am$w3 an extremely diligent man!$w3 Yes, I am!$K
$F3$PThose peddlers you were with...$w2
You were in debt to them, right?$K
$F1$P$FAHuh?$w4 How do you know that?$K
$F3$PWhen we took out that group,$w2
your debt vanished...$K
$F1$P$FSYes!$w4 You're right!$w4 That was$w2
a tremendous help. Thanks much!$K
$F3$PCome now,$w4 you can't believe that
the world$w2 is as forgiving as that.
Or that we are so foolish.$K
$F1$P$FAWhat?$K
$F3$PDebts are debts,$w3 and you have many.
Those peddlers weren't the only people who
were owed coin by you... Right?$K$PWe can't have $w2debt collectors hounding the
company $w2day in and day out.$K
My staff officer $w2repaid the rest of
the money you owe.$K
$F1$P$FSTha-$w2that's...$w3very kind of you.$K
$F3$PIt was from the company coffers.$w4
You, my friend,$w3 are now in OUR debt.$w2
You fight to repay the Greil Mercenaries.$K
$F1$P$FAAh! $w1But! $w1Aaah!$w2$K
$F3$PPayment$w3 will be deducted from your wages.$w3
For...quite some time.$w4 It seems
you're working for free, friend.$K
$F1$POh! $w1I--! $w1Oooh!$w2$K
$F3$PUntil your debts are completely repaid,$w3
don't even think about leaving the company.$w5
Or getting sick.$K$PRight then!$w3 I trust you'll do your best.$K$F3$FD
$F1$P...$w3What a mess...$w4$Fc
Awww...$w4 Nuts!$K    $R�w�i��b|$B���-����-�x�O�j�I��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'm here to report
the results from the last battle.$K$N$UB$H  $F3$P$Fc...$K$P$UB$H    $F1$P$FSWe suffered no casualties,$w2 and
no one was seriously injured.$w4
Everyone was at their best.$K$P$UB$H $F1$PThat concludes my report.$w4
Excuse me.$K    )      )�   	  *�     .@   "  /@   .  ,4   :  -`   F  04   R  0l   \  5�   i  ;L   u  <�   �  =p   �  =�   �  >`   �  A�   �  E(   �  F�   �  T   �  �   �  �   �   \    $�    &D    It  *  M�  8  ZX  F      T    `  D  n  (  |  (  �  b�  �  ch  �  c�  �  c�  �MS_16_BT MS_16_BT_IKE MS_16_BT_LE MS_16_BT_LO MS_16_BT_MI MS_16_BT_MO MS_16_BT_SO MS_16_DIE MS_16_ED_02X MS_16_ED_03 MS_16_ED_04X MS_16_ED_05 MS_16_ED_06 MS_16_ED_07 MS_16_ED_08 MS_16_ED_08_2 MS_16_ED_09 MS_16_ED_10 MS_16_EV_02A MS_16_EV_02A_2 MS_16_EV_02B MS_16_EV_02B_2 MS_16_EV_02C MS_16_EV_02d MS_16_INFO_01 MS_16_INFO_02 MS_16_INFO_04 MS_16_OP_01 MS_16_OP_02_1 MS_16_OP_02_2 MS_16_OP_03 MS_16_OP_04 MS_16_REPO_BEGIN MS_16_REPO_DIE MS_16_REPO_END MS_16_REPO_NODIE 