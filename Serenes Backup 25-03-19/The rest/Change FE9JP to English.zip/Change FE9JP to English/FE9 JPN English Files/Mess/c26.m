  le  i        '                $RGMAP��b|$O3$GIke and company break the siege of Delbray
Castle $w2and join ranks with the Crimean
retainers therein.$K$PThe army grows to its largest size yet, $w2and
with the addition of the retainers, truly$w3
becomes the armed force of its name.$K$PIn addition, their recent heroic acts finally
move the conservative Gallians to dispatch
much-needed reinforcements.$K$P$Ub$HThe long-awaited warriors of Gallia$w3
march through the treacherous
Marhaut mountain range,$K
$Ub$Ha series of jagged peaks that spread across
southern Crimea.$K$PThey then slip through the gaps in the
Daein forces and move toward
Crimea's army.$K$P"Gallia rises." $w4This information emboldens
Ike, and he marches the army at top
speed $w3to join their new allies.$K    $=0750$R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_LEARNE|$F8$FCL_DUMMY|$F8$PLeanne! $w4I'm coming in.$K$P$F8$FD
$F1$P$FS#F01$O2King Tibarn!#F02$O1$K
$F3$FS$F3$FCL_TIBARN|$F3$PHow are you feeling?$K
$F1$P#F01$O2Today I am feeling#F02$O1
#F01$O2most splendid.#F02$O1$K
$F3$PAh, it is good to hear that you are well.
Not surprising--$w2it is a beautiful day!$K
$F1$P#F01$O2And I am growing used to#F02$O1$w2
#F01$O2the smell of the sea.#F02$O1$K
$F3$PYes, we hawks enjoy the smell of the sea
as well. $w2Then you are starting to feel
more at home here? Good, good.$K$P$FAAnd $w2how is Lord Lorazieh?$K
$F1$P$FA$Fc#F01$O2$MC...$MDUnchanged.$MC......$MD#F02$O1$K
$F3$P$FSHm... I had thought his condition might
have improved. Well, let's hope for a
brighter tomorrow.$K
$F1$P$Fd$FS#F01$O2$MC...$MDYes!#F02$O1$K
$F4$FCL_LOTZ|$F4$PYou can understand what the heron
princess is saying, $w2can't you,
Your Majesty?$K
$F3$P$FAHm? $w4Yes. $w3Well, some of it, $w2at least.$w3
$FSOh, $w2you weren't around when Reyson
first got here, were you, Lotz?$K$PWhen he arrived, $w2he was just like this.$w3
You'd never know it by how fluently he
speaks our modern tongue, would you?$K
$F4$P$FSNow that you mention it, $w2he does use
some funny words $w2when he gets angry.$K$PBut, $w2the letter that just arrived $w2is written
in standard script, isn't it?$K
$F3$POver these twenty years, $w2he's gained
total mastery of... $w3$FAYou...$w2you
read the letter, $w2didn't you?!$K
$F4$P$FAN-$w2no, I just caught a glimpse of it
in your hand. $w2That's all. $w4I'm sorry!
Er...Your Majesty...$K
$F3$PYou little scamp...$K
$F1$P$FA#F01$O2A letter?$w4#F02$O1$K
$F3$PHm? $w4$FSYes, $w2that's right.$w4
It's a letter from Reyson.$K$PIt appears the Crimean army $w2has passed
safely through Daein $w3and is on its way
$w2to the homeland.$K
$F1$P$FS#F01$O2What good news!#F02$O1$w4
#F01$O2So he's $w2doing well, isn't he?#F02$O1$K
$F3$P$FAYes, Reyson is fine, but...$w2 I wonder what
happened. $w4He doesn't give details, but$w2
he asks Phoenicis to send reinforcements.$K
$F4$PIf Prince Reyson is asking for help,$w2
things must be fairly serious.$K
$F3$PI'd like nothing better than to take wing
immediately, $w2but I can't leave Lord
Lorazieh $w2and Leanne here alone...$K
$F1$P$FA#F01$O2I'll go $w2with you!#F02$O1$K
$F3$PNo, $w2that won't work.$K
$F1$P#F01$O2But$MC...!$MD#F02$O1$K
$F3$PDon't try that look on me. $w2There's
no way $w2I'm taking you with me.$K
$F4$PYeah, that's $w2crazy talk!$K
$F1$P#F01$O2$MC...$MD$w2Big meanie!!#F02$O1$K
$F3$PI suppose it's time to put my plan
into action.$K
$F4$PWhat is it?$K
$F1$P#F01$O2Plan?#F02$O1$K
$=0600  $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_LOTZ|$F3$FCL_TIBARN|$F3$PAll right, $w2I'm off to Gallia $w2to get
things settled.$K$PLotz, $w2I want you to watch over Leanne$w2
and help her pack.$K
$F1$P$FSYes, sir!$K
$=1000 $R�w�i��b|$B�q��|$<$F3$FCL_LOTZ|$F1$FS$F1$FCL_LEARNE|$F1$P#F01$O2Please put that cloth $w3in here.#F02$O1$K
$F3$PUm, $w2I... $w4I don't have any
idea $w2what you're trying to say.
Maybe I should talk louder...$K
$F1$P$FA#F01$O2Tee hee! You're not very smart! I want you#F02$O1
#F01$O2to take this...$w2and put it in here.#F02$O1$K
$F3$P$FSUm, $w2DO YOU WANT ME... TO PUT THIS...
IN THAT BAG??$K
$F1$P$FS#F01$O2Yes, $w2yes.#F02$O1$K
$F3$PGot it! $w4In it goes! I'm getting the hang
of this. I'M PUTTING IT IN THE BAG!$K
$Ub$H$F1$P$FA#F01$O2Ah! Aaaaahhhh!!!#F02$O1$K
$F3$PWhat? $w4Is something wrong?$K
$F1$P#F01$O2!! Who's there!?#F02$O1$K
$F3$PWhat are you...? Over there? Behind me?$w4
WHAT? SOMEONE IS BEHIND ME??$K$P$Ub$H$FAGwaaaa!!!$w4$F3$FD
$F1$P#F01$O2Lotz!#F02$O1 $w5#F01$O2No! $w4Let him go!#F02$O1$K
$Ub$H$F4$FCL_DARKKNIGHT|$F4$PIf you want your father to be killed, then
by all means keep screaming.$K
$F1$P#F01$O2$MC...$MDBrother$MC...$MD#F02$O1$K$=1200   $R�w�i��b|$B���{-�N���~�A|$<$F4$FCL_DARKKNIGHT|$F0$FS$F0$FCL_ASHNARD|$F0$PAh! The prodigal son returns!$K
$F4$PI have $w2gained that which you requested.$K
$F0$PShow me.$K
$F4$PThis way.$K   $R�w�i��b|$B���{-�N���~�A|$<$F4$FCL_DARKKNIGHT|$F0$FCL_ASHNARD|$F0$PThese heron royals all look alike, don't
they? Perhaps it proves their bloodline,$w2
but it's unsettling how similar they are.$K
$F4$PI believe $w2you had one in your possession
previously.$K
$F0$PYes, I tried to get her to free the dark god
from the medallion, but all she did was
get sick and die. Pah!$K$PThey're ridiculously frail creatures. I should
have just killed her in the first place and
saved some time.$K
$F4$PMight I suggest this one be treated with
more care? $w3Capturing her was not
an easy task.$K
$F0$PFor you, it did take quite a long time...
Didn't it?$K
$F4$PDiverting the sharp eyes of the hawk king$w2
proved to be quite difficult. It required$w4
much planning and care.$K
$F0$P$FSHa! $w2Don't tell me it was difficult! I know
you! I know you use that arcane powder to
travel about at will.$K
$F4$PThe powder $w2drains my strength. $w4For that
reason, $w2I would rather not use it unless
absolutely necessary.$K
$F0$PYou are an enigma, dark one. $w4Everything you
possess is fey $w2and of unknown origin.$K
$F4$PThe armor $w2I presented to you...$w4
Do you find it dissatisfactory?$K
$F0$PNo, $w2it has my approval.$K$PMy wyvern Rajaion, and this armor which
renders any enemy attack impotent...
Both are well suited to me.$K$PThey both shine because they are mine!
And now the medallion, and that galdr as
well, both belong in my hands!$K
$F4$PWill the revival of the dark god take
place soon?$K
$F0$PLet me see... The conditions aren't bad.$w4
But, $w2how long will they continue...
Har! It is no matter.$K$PAs long as all my chess pieces are on the
board, things will work out. Soon every knee
will bow to Ashnard!$K
$=1000 $R�w�i��b|$B�q��|$<$F3$FCL_TIBARN|$F3$P...$w4What $w2is going on?$w4
What's happened here?$K
$F1$Fh$F1$FCL_LOTZ|$F1$PM-my...$w4king...$K
$F3$PLotz! $w4Hold on!$K
$F1$P$FcI'm...$w4so...$w4sorry...$w4
...the...$w4princess...$w4...$K
$F3$PWho did this? $w4Who was the craven dastard
that did this to you?$K
$F1$P$Fh...Knight...$w4in...black armor...
$FcGwaa...$w4urrk!$K$F1$FD
$F3$PLotz! No!$K$PCurse you, Daein! This was evilly done!
Well, if you think to play such a game,$w4
you'll not find me an easy mark!$K
$=1100   $=1000$R�w�i��b|$B�R��-��|$<$F1$FS$F1$FCL_LAY|$F3$FCL_IKE2|$F3$PRanulf! $w4Whereabouts is the Gallian
army encamped?$K
$F1$PJust over those mountains.$K
$F3$PSo we're finally going to join forces...$K
$F1$PReports say that King Ashnard is gathering
his forces in the capital. $w4The time to
work together is certainly upon us.$K
$F4$FCL_SENERIO|$F4$PIke! $w4There's an enemy ambush waiting
for us on that mountain.$K
$F3$PMmm... If we go around that mountain and
avoid it, how much time will we lose?$K
$F4$PA couple of days, at least.$K
$F3$PIn that case, $w2we've no choice but to
go through them, right?$K
$F1$P$FA$F4$PAgreed.$K
$F1$PUm, wait a second... Isn't this where there's
usually some sort of discussion? $w2Hello?$K$=0750  $R�㉺��b|$c0DAYNE3|$s0The enemy approaches, sir.$K
$c1GURORMERU|$s1Listen up, men! $w2Let them get as close
as possible before pushing the rocks
over the cliff.$K
We must not let Crimea $w2join forces
with those sub-humans!$K $R�㉺��b|$c1TIAMAT|$s1Commander, the foes are encamped
on top of the rise. $w4I wonder what
sort of trap they have this time.$K
$c0IKE2|$s0Those boulders didn't get up there all
by themselves... $w4Are they seriously
going to roll them down on us?$K
$d1$c1SENERIO|$s1At first glance, it seems a simplistic
trap, $w4but these narrow paths
make avoiding the rocks impossible.$K
I think $w2they may be surprisingly
effective.$K
$s0So...$w4$K
$s3$FS$c3LAY|$s3"We run up the mountain as quickly
as possible and smash the enemy
commander!" $w2Right?$K
$s0Right... $w3How did you--$K
$s3$FhI know...genius.$K$d3
$s1Actually, that is the best plan.$K$PTry to avoid the boulders and reach
the top as quickly as possible.$w4
Once there, defeat the general.$K
$s0Right. $w2Move out!$K $R�㉺��b|$c0GURORMERU|$s0Grr! $w2So you've made it this far,
have you? $w4Then prepare to
be sent down screaming!$K   $R�㉺��b|$c0GURORMERU|$s0You knew we were here, $w2but still
you charged our positions? I'll teach
you to regret $w2your impudence!$K
$c1IKE2|$s1Sorry, but at this point, I don't think
you're in a position $w2to teach me
anything.$K  $R�㉺��b|$c0GURORMERU|$s0Sub-humans? $w4Have they already
joined with the Gallian army? $w4No,
it's not possible.$K$PMy chance is now!$w2 I won't let it pass!$K  $R�㉺��b|$c0GURORMERU|$s0Bothersome birds!$K
You think you can fly wherever you
please? $w5I'll pluck your wings,$w2
and laugh as you fall to your doom!$K    $R�㉺��b|$c0GURORMERU|$s0YOU! Shame of the Daein army! $w4For
your blackhearted treachery, $w4I will
execute you here and now!$K  $R�㉺��b|$c0GURORMERU|$s0You're one of Shiharam's men! $w4You
betrayed your country twice, you
cowardly dog! Now die like one!$K  $R�㉺��b|$c0GURORMERU|$s0Hmph! $w4So you're $w2Shiharam's
daughter?$K
You may ride a wyvern like your
father,$w2 but you know nothing of
a true knight's faithfulness!$K  $R�㉺��b|$c0GURORMERU|$s0A Begnion pegasus knight, eh?$w4
I'll prove that Daein's aerial prowess
is more than equal to yours!$K   $R�㉺��b|$c0GURORMERU|$s0Here comes another bird...$w4
Oh...$w2it's so beautiful...$w4
It cannot be of our world...$K$PThat's it! $w2It must be a sub-human!
Die, half-breed! Die!$K  $R�㉺��b|$s0$FS$c0GURORMERU|$s0Heh heh...$w3ha ha ha...$w4
Gather as many fools as you like...$w2
your weakness cannot survive...$K$PNo one on this earth $w2can
withstand the might...of our king...
Ggghhhaaaa...$K $R�㉺��b|$c1IKE2|$s1Is this the lot of them?$K
$c3LAY|$s3It looked like there were more
of them from down there.$K    $R�㉺��b|$c0DAYNE2|$s0Now we've got you! $w4Eat rock!$w4
Heh...eat rock... I'm pretty clever...$K $R�㉺��b|$c3ERINCIA|$s3Eeeek!$K
$c1IKE2|$s1Above us! Look out!$K$d3   $R�w�i��b|$B�R��-��|$<$F0$FS$F0$FCL_TIBARN|$F3$FCL_IKE2|$F0$PNeed a hand?$K
$F4$FS$F4$FCL_RIEUSION|$F4$PTibarn! $w4You came!$K
$F0$PWell met, $w2Reyson. $w3And well met to the
rest of you as well, $w4warriors of Crimea.$K
$F3$PHow did you come to be here?$K
$F0$PI thought I'd help you wipe out Daein.$K
$F3$PThat's good news for us, $w4but has
something happened? Why did you
suddenly decide to help?$K
$F4$PI asked for his aid.$K$P$FAWe must defeat King Daein. To that end,
the more powerful we are, the better. Yes?$K
$F3$PSo that's the story, is it?$K
$F0$P$FAIt's true that Reyson requested my aid.
However, that's not the only reason
that I'm here.$K
$F4$PHm? What is it?$K
$F0$P$FSIn a moment. First, $w2let us meet with the
king of lions. $w4He waits for us at the
foot of the mountain.$K
$F3$PUnderstood. $w4Come on, everyone!$w2
Let's get off this peak and take a rest
at the bottom.$K
$=1000 $R�w�i��b|$B�V���l�p-��|$<$F0$FS$F0$FCL_CAINEGHIS|$F3$FS$F3$FCL_ERINCIA|$F3$PKing Caineghis! $w4It's an honor to see
you again.$K
$F0$PFirst, let me offer you my congratulations.$w4
You've made quite the triumphant return,$w2
Princess Elincia.$K
$F3$PThank you.$K$PAnd allow me to express my gratitude $w2for
having the kingdom of Gallia fighting at our
side. $w4Your presence fills me with strength.$K
$F0$PDuring this short interim, $w2you've
managed to turn the tide of the war.$w4
To be honest, $w2I'm quite surprised.$K
$F3$PI didn't...$w4I didn't come this far on my own.$K$PMy lord Ike and his brave companions were
with me. It was only with the support of
many$w2 that I was able to return home.$K
$F0$P$FAYes, $w2my reports cover most of that.$w4
Everything that happened in Begnion,$w2
and in Daein as well.$K
$F3$P$FAAs to that... $w2About Nasi--$K$P$F4$FCL_TIBARN|$F4$PKing Gallia! $w4Princess Crimea!$K$PI apologize for interrupting the festivities,$w2
but there's something I must discuss with
you. $w4Would you gather over there?$K
$=0900    $R�w�i��b|$B�V����c�p|$<$F0$FCL_CAINEGHIS|$F3$FCL_ERINCIA|$F0$PThis group contains the people who were
at the heart of that last battle, correct?$K
$F3$PYes, it is.$K
$F0$FD$F1$FCL_TIBARN|$F1$PWhat about those two children? Surely they
weren't involved.$K
$F3$FD$F3$FCL_MIST|$F4$FCL_SENERIO|$F4$P...Children?$K
$F3$PUm...$K
$F3$FD$F3$FCL_IKE2|$F3$PThis is Soren. $w4He's my tactician.$K
$F4$FD$F4$FCL_MIST|$F3$PAnd this is my sister, Mist.$K$P$Ub$HBefore we begin this war council, there's$w2
something $w2I need to share with all of you...
It's a story that involves my parents as well.$K$PI've kept most of it from my sister, but I
felt this would be a good chance for her
to hear it, so I asked her to join us.$K
$F1$PUnderstood. $w2Go on.$K
$Ub$H$F3$PIt all begins $w2when we meet Princess Elincia$w4
and escorted her into the forests of
Gallia...$K
$=1000  $R�w�i��b|$B�V����c�p|$<$F0$FCL_CAINEGHIS|$F1$FCL_TIBARN|$F3$FCL_IKE2|$F4$FCL_MIST|$F3$P$FcAnd that $w2is everything I know.$K
$F4$PF-Father...$w2he... $w4Is that how...$w3
Mom?$K
That's...$w4not true, is it?$K
$F3$P$Fd$F1$FD$F0$FD$F1$FCL_TIAMAT|$F1$PMist... $w4Do you want to leave?$K
$F4$PUm... $w4No...$w3I'm all right. I'm all right...
I'm just $w2a little confused.$w4$K
$F1$PMist...$K
$F3$P...$K
$F1$FD$F0$FCL_CAINEGHIS|$F0$PThat's the whole of it, eh?$K
$F1$FCL_TIBARN|$F1$PSo this wasn't ever just a dispute between
Crimea and Daein... There was something
else at play the entire time.$K
$F0$FD$F1$FD$F0$FCL_ERINCIA|$F0$PWhat could King Ashnard's $w2ultimate goal
possibly be? He has risked everything,
even surrendering his own country...$K
$F1$FCL_CAINEGHIS|$F1$PTwenty years ago, even before he became
king, he tried to release the dark god from
within the medallion.$K$PHowever, $w2he was thwarted by the actions
of Greil and Elena.$K
$F3$PWhat manner of being is this dark god?
What would happen $w2if it were
freed from its prison?$K
$F1$PI fear the world would once again be beset
by natural calamity--much like it was
800 years ago.$K$PAt that time, $w3all the world, save Tellius,
was drowned beneath the seas.$K
$F0$PThat is $w3a true story? $w4I thought it
nothing more than a fable...$K
$F1$PWe have living proof:
Goldoa's King Deghinsea.$K$PHe and two other heroes fought alongside
the goddess herself to defeat the dark one.$K
$F0$PKing Goldoa was $w3one of the legendary
heroes? But he's...$w2still alive...$K
$F1$FD$F1$FCL_TIBARN|$F1$PThe Black Dragon King is a living fossil,$w2
and as stubborn as anything alive.$K$PHe's been trying to control the rest of
us for years, and he always says the
same thing.$K$P"Do not fan the flames of strife."$K$P"As long as Lehran's medallion exists,$w2
you must never begin a war that engulfs the
entire continent."$K
$F4$FD$F4$FCL_SENERIO|$F4$P..."Never begin a war"? $w4It's possible...$w3
Perhaps there is more than one way$w2
for the dark god to gain its freedom.$K
$F1$P$FSOh ho!$w4 Aren't you the clever one?$w4
That's just what the Black Dragon King
says. $FAYet, $w2the truth of that is unknown.$K$PThere's a war going on right now,$w2
but the dark god's nowhere in sight, is it?$K
$F4$P...Could it be...? $w3I think I may finally know
Ashnard's intentions.$K
$F3$PReally?$K
$F4$PKing Goldoa said that a conflict which
engulfs the entire continent would free the
dark god from the medallion.$K$PLet us assume that the war would have
such an effect on the medallion no matter
where it was...or who possessed it.$K$PAnd let's also assume $w2that the king
of Daein thinks this as well.$K$PI can hear him now... $Fc"Where is the
tinder for the blaze I need?"$K$P$FdThe answer to this question $w2proved to
be an easy one. $w4Yet he had to find a way
to test his theory...$K$PSo, $w2he attacked neighboring Crimea.$w4
It had to be Crimea. $w2Begnion was too
big, too powerful. Daein would have lost.$K$PCrimea, however, is a country known more
for its scholarship than its military strength.$K$PDaein probably felt that a surprise invasion
would let them win while taking minimal
casualties themselves. $w4And they were right.$K
$FcCrimea was easy prey.$K
$F0$P...$K
$F4$P$FdKing Ramon was also friendly toward laguz...$w4
I imagine $w2that this, too, influenced
Daein's decision.$K$PIf things went well, $w2the conflict would be
enough to engulf Crimea's ally, Gallia,$w2
and the fires would spread.$K$PFirst Crimea, $w2then Gallia...$w4
And eventually Begnion as well.$K$PDaein's power would increase, $w2and strife
and discord would spread across the land,$w4
eventually reaching the lost medallion.$K
$F3$PSo you believe King Daein's goal $w4is
to awaken the dark god after all?$w2$K
$F4$PAt the very least, it is one of his ambitions.$w2
There can be no mistaking that.$K
$F1$FD$F1$FCL_CAINEGHIS|$F1$PWhich means $w2that our plan to attack
him at the capital fits right into his
strategy, doesn't it?$K$PIt's the trigger he needs to break the dark
god's bonds.$K
$F1$FD$F1$FCL_TIBARN|$F1$PEven if that's true, $w2we can't stop now.$w3
This war's gone too far for that.$K
$F3$PWe have to smash Daein to end its menace
once and for all. We bury every one of
them and finish it.$K
$F1$FD$F1$FCL_CAINEGHIS|$F1$PMmm... Agreed. $w4That's the only plan that
makes any sense.$K
$F0$FD$F1$FD$F1$FCL_RIEUSION|$F1$P$FcIf only we had the medallion with us...$K
$F4$FD$F4$FCL_TIAMAT|$F4$PWhat is it, Reyson? Is there a way to avoid
all of this?$K
$F1$P$FdWe, that is, the descendants of Lehran,
we have a gift...$K$PThrough the power of the slumber galdr,$w2
we have the ability $w4to suppress the chaotic
energies of the dark god in the medallion.$K$PSo even if a massive battle occurred, if it
were in my possession, I might be able to...$K
$Ub$H$F4$FD$F4$FCL_MISTs|$F4$PI'm so sorry! $w4It's because of my
carelessness that $w4the medallion
was lost in the first place!$K
$F3$PMist! $w4I told you that it wasn't your fault,
didn't I?$K
$F4$P$FhBut--$K
$F1$FD$F0$FS$F0$FCL_ERINCIA|$F0$PYou were never careless, Mist.$w2 I know.
You kept the medallion next to you at
all times.$K$PYou told me it was a keepsake of your
mother's, $w2and you always, always
took good care of it. Didn't you?$K$P$F4$P$Fc$F0$PThat's why it's not your fault. So please
don't punish yourself anymore. $w4All right?$K
$F4$P$FhPrincess Elincia...$K
$F0$FD$F1$FS$F1$FCL_LAY|$F1$PShe's right. $w4And besides, $w2the dark god
could be released no matter where the
medallion is. So it's nothing to worry about.$K
$F4$PThank you, Ranulf.$K
$Ub$H$F0$FCL_TIBARN|$F0$PAll right... $w2It's about time for you to
hear what I have to say.$K
Reyson!$K
$F1$FD$F4$FD$F4$FCL_RIEUSION|$F4$PYes?$K
$F0$PI'm sorry.$K$F0$FD
$F4$PHuh? $w4F-for what?$K
$Ub$H$F0$FCL_TIBARN|$F0$PLeanne's been kidnapped. $w4It may have
been $w2by Daein's hand.$K
$F4$PThat...can't be...$K
$F3$PWhy would Leanne be taken? $w4The release
galdr can only be sung by the girl Altina.$w2
Right?$K
$F4$PBut Ashnard doesn't $w2know that.$Fc$K
$F3$POh no...$K
$F1$FCL_LAY|$F1$PWhat a mess... $w2Nothing can ever be clear
and simple, can it?$K
$F0$P$Fc...$K
$F3$P...$K
$=2000    $R�w�i��b|$B�V��-��|$<$F1$FCL_IKE2|$F3$FCL_BOY|$F3$PMister! 'Scuse me, mister! $w3Are you guys
gonna go into these mountains? There are
lots of soldiers wearing black up there.$K$PThose guys...$w3they $w4killed my poppa and
burned our village. $w3That's why we went to
the mountains in the first place.$K$PYou're gonna go up there $w3and take care
of 'em, aren't you? Gonna make 'em pay?
Please, mister, say that you are!$K$PMy momma $w2and my sister $w2and me don't
have anywhere else to go, and I wanna go
back to the cabin my poppa built.$K
$F1$P$FSI understand. $w4We're going to take care of
those guys. $w4You just stay here a bit longer.$w4
All right?$K
$F3$P$FSYay! Go give 'em heck, mister! Oh, wait!
Wait! $w4I heard those guys talking about
something, too!$K$PThey said $w2if anyone comes up the mountain
single file, $w2they'd get 'em all at once.$w4
It was something like that $w2anyway.$K
$F1$PReally? $w5That's a lot of help. $w4Thanks.$K
$F3$P$FSGood luck, mister!! Kill 'em all!
Do it for my poppa!$K  $R�w�i��b|$B�V���l�p-��|$<$F0$FCL_IKE2|$F0$PExcuse me, $w2do you have a moment?$K
$F3$FS$F3$FCL_ULYSSES|$F3$PForsooth! What ho! My eyes behold Sir Ike!$w4
Pray tell, $w3what would you ask of me,
good sir?$K
$F0$PUm...well... $w3I just wanted to chat. I try
to speak with all the members of
the army when I have a minute.$K
$F3$PI see! $w4A fine idea that is, good sir.
Some generals hope their soldiers all to be
aloof, and ready always for the fight.$K$PIf all goes well, sweet happiness abounds.$w3
But if the tides do turn, then anger grows.$K$POne wonders if he can lead men at all...$w3
I, too, am often plagued by such
grim thoughts.$K
$F0$P$FhUh...yeah. Listen, I--$K
$F3$PYet you walk out among your men-at-arms;$w2
spin tales, tell jokes, and lend a willing ear.
Huzzah, dear sir! $w4Huzzah until the end!$K$PIn truth, I did much fear your name at first.
I swore to find the mettle of the man,
and studied you with cautious, steady eye.$K$PI thought to find yourself a brutish rogue.
A villain crafty in his fiendish plans!
With status and great wealth his only goals.$K$PHad such been your own ethic and deceit,
I would have taken measures sure and swift
to see your person vanished in the night.$K$PYet lo! What do I find before mine eyes?
A man so noble, true, and without peer,
as would beset the moon herself with lust!$K
$F0$P...$Fc$K
$F3$PGeneral?$K
$F0$PZzz...$Fo$K$Fd
Wha--? Huh? ...Er... Sorry about that. $w3Must
have dozed off. $w4What were you saying?$w4
Something about the moon or...something?$K
$F3$P$FACommander, you are tired and unaware
of how your body doth cry out for rest.$K$FS$PIf it would please you, I was of a mind
to partake in a sweet and soothing draught.
A beverage warm, and pleasant to the lips.$K
$F0$P...$w2Um, if you're offering me a cup of tea
in your tent, $w4I'll accept. ...That IS what
you're offering...$w5 Right?$K$POh, and I apologize in advance if I fall
asleep again. I'm really tired.$K
$F3$PYour words do make my ears alive with joy!$w4
I shall regale you with a tale or two,
and poems to ease the savage toll of war.$K $SD$R�w�i��b|$B�V��-��|$<$F1$FCL_IKE2|$F3$FS$F3$FCL_LARGO|$F3$PHey there, $w2little man! $w4I've got serious
business with the general of this army.
Take a message, will ya?$K
$F1$PAnd you would be...?$K
$F3$PThe name's Largo,$w4 and I'm a world-class
berserker!$K
$F1$PWorld-class berserker...$w4 That's a rather
dubious title.$K
$F3$PWhat's this?$w2 You doubting my strength?$w4
I can pin a tiger with my bare hands!$w3
That's not just hot air either!$K
$F1$PDubious.$K
$F3$PYou think I'm fooling with you? Have your
general hire me and then see for yourself!$K$PYou can decide how much I'm worth after
you see me in action.$K$PBut let me tell you, $w3if the gold's not good
enough, pffft! $w2I'm gone!$K
$F1$PHuh? $w4All of this sounds vaguely familiar...
But at least you're confident.$K
$F3$PLike I said. $w4World-class berserker.
Here, watch me bend this lance.$w4
$Fc$FARrrrrrrrrr!!!$K
$F1$P...$K$N$UB$H Hire.   Don't hire. $SE$F1$PAll right. $w4You're in.$K
$F3$P$Fd$FSYes! $w4So, uh, $w3how about taking me
to meet the general?$K
$F1$PI'm the general.$K
$F3$PWah? Bwaa ha ha ha ha ha haaaaa!$w4
That's good! $w4You're a funny little guy!
Bwaa ha ha ha haaaa!!$K$PSo, $w4seriously. Where's the general's tent?
Must be that big one there.$K
$F1$P...$K
$F7$FCDUMMY|$F7$P$F7$FDLargo?$K
$F1$FD$F0$FCL_IKE2|$F1$FCL_CALILL|$F3$PHey!$w4 I thought I'd find you here, $w2Calill!$w4
You're looking hot! Almost as hot as me!
Bwaaa ha ha ha haaaaaa!$K
$F1$PDid you come looking for little old me?$K
Oh, how sad for you. $w4My contract with
this army isn't up for quite some time.$K
$F3$PYeah, I thought you'd say that. $w3That's why
I'm joining up, too!$K
$F1$PWhat? $w4Are you really going to hire Largo,$w2
General Ike?$K
$F0$PThat's the plan.$K
$F3$PHuh? $w3This little guy really is the general?$w5
Bwa ha ha ha! $w4Don't I look like the biggest
fool around? And I mean big! Rrrrrrr!$K$PSorry if I offended you, little guy!$K
$F1$POh... $w3He's such a clown.$w4$FS
But $w2you made a good hire. $w5After all,
he's a world-class--$K
$F0$PBerserker. $w4Yeah, I heard.$K
$F1$PHe pinned a tiger with his bare hands!$w4
Two of them, actually. At the same time.$K
$F3$PBwa ha ha ha haaaaa!$w4
Yeah, that was awesome!$K
$F0$P$Fh...$w3Definitely dubious...$K  $SE$F1$PSorry, but I'm not going to be able to hire
you. $w4We've got more than enough axe-
wielders already.$K
$F3$P$Fd$FSThat so? $w5That's all right, I can handle it.$w4
I'm a man. I can take rejection.$w4
Well, $w3good luck out there, little man.$K$PNo regrets, right? Save those $w3for when
you're dead.$K$F3$FD
$F1$PYeah...right.$K   $R�w�i��b|$B�V��-��|$<$F1$FCL_IKE2|$F3$FS$F3$FCL_LARGO|$F3$PHey there, $w2little man! $w4I've got
serious business with the general of this
army. $w3Take a message, will ya?$K
$F1$PAnd you would be...?$K
$F3$PThe name's Largo,$w4 and I'm a world-class
berserker!$K
$F1$PWorld-class berserker...$w4 That's a rather
dubious title.$K
$F3$PWhat's this? $w2You doubting my strength?$w4
I can pin a tiger with my bare hands!$w3
That's not just hot air either!$K
$F1$PDubious.$K
$F3$PYou think I'm fooling with you? Have your
general hire me and then see for yourself!$K$PYou can decide how much I'm worth after
you see me in action.$K$PBut let me tell you, $w3if the gold's not good
enough, pffft! $w2I'm gone!$K
$F1$PWell, at least you're confident...$K
$F3$PLike I said. World-class berserker.
Here, watch me bend this lance.$w4
$Fc$FARrrrrrrrrr!!!$K
$F1$PSorry, but I'm not going to be able to hire
you. $w4We've got more than enough axe-
wielders already.$K
$F3$P$Fd$FSThat so? $w5That's all right, I can handle it.$w4
I'm a man. I can take rejection.$w4
Well, $w3good luck out there, little man.$K$PNo regrets, right? Save those $w3for when
you're dead.$K$F3$FD
$F1$PYeah...right.$K  $R�w�i��b|$B�V��-��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke, $w3I'd like to report the results
of our last battle.$K$N$UB$H $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all. $w4By your leave,$w2
I will excuse myself.$K    "      "�   	  #|     $    "  $�   .  %D   :  %�   F  &t   R  &�   ^  '�   k  (�   u  )    �  )d   �  )�   �  -4   �  1X   �  4�   �       �  L�   �  P�   �  X�   �  \�  	  a�    \�  -  \x  ?  c  Q  �  a  ,  m    y  �  �  �  �  D  �  L  �  ,  �    �  g�  �  h$  �  h�  �  h<  �MS_26_BT MS_26_BT_IKE MS_26_BT_R1 MS_26_BT_R2 MS_26_BT_R3 MS_26_BT_R4 MS_26_BT_R5 MS_26_BT_R6 MS_26_BT_RYU MS_26_DIE MS_26_ED_01 MS_26_ED_01_2 MS_26_ED_02 MS_26_ED_02_2 MS_26_ED_02_3 MS_26_ED_04 MS_26_ED_05 MS_26_GMAP_01 MS_26_INFO_01 MS_26_INFO_02 MS_26_INFO_05_A MS_26_INFO_05_A_A MS_26_INFO_05_A_B MS_26_INFO_05_A_N MS_26_INFO_05_A_Y MS_26_INFO_05_B MS_26_OP_01 MS_26_OP_02 MS_26_OP_03 MS_26_OP_04 MS_26_OP_05 MS_26_OP_06 MS_26_OP_07 MS_26_OP_08 MS_26_OP_09 MS_26_REPO_BEGIN MS_26_REPO_DIE MS_26_REPO_END MS_26_REPO_NODIE 