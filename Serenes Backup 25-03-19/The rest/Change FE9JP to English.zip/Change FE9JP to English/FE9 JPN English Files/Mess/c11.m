  �C  �0       D                $R�w�i��b|$B��̒�|$<$F1$FCL_IKE|$F4$FS$F4$FCL_LAY|$F4$PHey, $w2Ike! $w4I heard you're leaving.$w2
Going to Begnion, eh?$K
$F1$PHello, Ranulf. $w4I was hoping I'd see you.
I'd wanted to thank you for everything
you've done.$K$PI'm glad to have the chance
before I leave.$K
$F4$PWell, aren't you the dutiful one!$K$PHey, that reminds me$MC...$MD$w2you were
born here in Gallia, right?$K$PI knew there was something odd
about you. $w4You're awfully friendly
for a beorc, you know!$K$P$FAOh, you might not know, but a
beorc is what$MC--$MD$K
$F1$PI know what it means.$w4
It's what you call us humans, right?$K
$F4$P$FSOh, $w2knew that, did you? $w4Well then,$w2
let me tell you something else.$K$PWhen we use the word "human,"
we mean it much the way you beorc
do when you call us "sub-human."$K
$F1$PReally? It's an insult to be called human?$K
I'm glad you told me.$w2 I would
never have guessed.$K
$F4$P$FAI should warn you, if you run across any
laguz $w2who call you that, be careful.$w4
They are no friend of yours.$K
$F1$PGot it. $w4Thanks.$w4
I won't forget.$K
$Ub$H$F4$P$FSBut I've digressed long enough.$w2
Let me explain why I'm here.$K
$F1$PHuh?$K
$F4$PPrincess Elincia, $w4may I have a
moment of your time?$K
$F0$FCL_ERINCIA|$F0$PY-$w1yes. Of course.$K
$F4$PThe king asked that I give you this.$w4
Please, $w4accept it as a gift.$K
$F0$PWhat? $w4May I ask$MC--$MD$K
$F4$PWithin that leather pouch$w2 is
twenty thousand gold pieces.$w4
Beorc currency, of course.$K
$F0$POh$MC... $MD$w3I truly appreciate $w2this generous
offer, but $w4a gift of this magnitude$w2
is not something I can accept.$K$PKing Caineghis $w2has done so much more
than necessary already$MC...$MD$K
$F4$PThe king is ashamed $w2that he cannot,
at this time, $w2provide any personal support.$K$PPlease. $w2Will you accept his apology and
acknowledge his desire to aid you?$K
$F0$PBut$MC...$MD$K
$F4$PNo? Well then, $w3let's try this$MC...$MD$K
$F0$PYes?$K
$F4$PYou accept the king's gift.$w2 Then, as
payment for conducting you safely
to Gallia, $w4you hand it over to Ike$MC...$MD$K
$F0$PUm$MC...$MD$K
$F1$PCome on, Ranulf. $w4You can't expect her to
accept this.$w2 And it's an outrageous fee,
no matter how you look at it.$K
$F4$P$FATwenty thousand gold for the life of
a princess? $w3Perfectly reasonable.$w5
In fact, it almost borders on insulting!$K$PConsider how you have suffered, $w3the lives
you have lost$MC...$MD$w5 Ten, $w2no, a hundred times
this amount would not be $w3unreasonable.$w2$K
$F1$P$MC...$MD$K
$F0$PI$MC... $MD$w3I have reconsidered.$w2
I will accept the king's kindness.$K$PIn turn, I will present it to my lord Ike$MC...$MD$w5$FS
You will accept it, will you not?$K
$F1$P$F1$FD$F2$FCL_IKE|$F2$PI$MC...$MDI will. $w5Thank you.$K
$F0$PNo, my lord Ike. It is I
who must thank you.$K
$Ub$H$F2$P$F2$FD$F1$FCL_IKE|$F4$P$FSWell, $w3now that that's settled, let's move on.$w5
Unfortunately, $w2we do not have
any ships here in Gallia.$K$PIf you are to find a ship that will take you
to Begnion, $w4you must return to
occupied Crimea.$K
$F1$PIf there's no other way,$w2 then we'll
just have to risk it.$K
$F4$P$FANo matter how cautiously you proceed,$w2
you're certain to run into Daein forces.$w4
Keep that in mind.$K
$F1$PI understand. It's too bad we're so
short on soldiers$MC...$MD$K$PStill, there's not much we can do about
that now. $w3However, I will review our
supplies carefully$w2 before we depart.$K $R�w�i��b|$B��̒�|$<$F1$FCL_IKE|$F4$FS$F4$FCL_LAY|$F4$PIn regard to your personnel problems,$w2
the king has decided to lend you what
aid he can.$K
Lethe! $w4Mordecai!$K$F4$FD
$F4$FCL_LETHE|$F3$FCL_MORDY|$F3$P$FSI $w2will join you.$K
$F1$PMordecai! $w4And Lethe?$w4
Both of you?$w2
Are you sure?$K
$F4$PNone of the others could stand the
idea of traveling with humans.$K$PI myself tremble with loathing at the
thought of going to Begnion, but$MC...$MD$K$PWhen the king gives an order,$w2
obedience is the only option.$K
$F1$PThat may be,$w2 but having witnessed
the combat prowess of the Gallians for
myself, $w4I know how fortunate we are.$K
$F3$PWe will not fail you.$K
$F4$PHsss! $w4I've no intention of becoming friends!$w4
Do not forget that$MC...$MD
And stay out of my way!$K$P$F3$FD$F4$FD
$F4$FS$F4$FCL_LAY|$F4$PHa ha! $w2You must forgive Lethe. Her
tongue cuts as deep as her claws do.$K$PI will return once I've reported to the king.$w4
While I'm gone, $w2please finish your
preparations for departure.$K
$F1$PVery well.$K   $R�w�i��b|$B��̒�|$<$F1$FCL_IKE|$F4$FS$F4$FCL_LAY|$F4$PIn regard to your personnel problems,$w2
the king has decided to lend you what
aid he can.$K
Lethe!$K
$F3$FCL_LETHE|$F3$P$MC...$MD$K
$F1$PLethe! $w4Are you coming with us?$K
$F3$PNone of the others could stand the
idea of traveling with humans.$K$PI myself tremble with loathing at the
thought of going to Begnion, but$MC...$MD$K$PWhen the king gives an order,$w2
obedience is the only option.$K
$F1$PThat may be,$w2 but having witnessed
the combat prowess of the Gallian tribe for
myself, $w4I know how fortunate we are.$K
$F3$PHsss! $w4I've no intention of becoming friends!$w4
Do not forget that$MC...$MD
And stay out of my way!$K$P$F3$FD
$F4$PHa ha! $w2You must forgive Lethe. Her
tongue cuts as deep as her claws do.$K$PI will return once I've reported to the king.$w4
While I'm gone, $w2please finish your
preparations for departure.$K
$F1$PVery well.$K    $R�w�i��b|$B��̒�|$<$F1$FCL_IKE|$F4$FS$F4$FCL_LAY|$F4$PIn regard to your personnel problems,$w2
the king has decided to lend you what
aid he can.$K
Mordecai!$K
$F3$FCL_MORDY|$F3$P$FSI $w2will join you.$K
$F1$PMordecai! $w4Are you sure?$K
$F3$P$FAThe king asked for volunteers, but$w3
no one else $w3will travel to Begnion.$K
I am sorry$MC...$MD$K
$F1$P$FSYou're more than enough, Mordecai.$w4
I've seen how powerful you are,$w2
and we're fortunate to have you.$K
$F3$P$FSIs that so? $w4If your words are true,
then I am$MC...$MD$w3most happy.$K$P$F3$FD
$F4$PGood. $w4Everyone's happy.$K
I'll return once I've reported to the king.$w4
While I'm gone, $w2please finish your
preparations for departure.$K
$F1$PVery well.$K
$=1000    $RGMAP��b|$O3$GAfter his father's death places the mantle
of leadership on his young shoulders,$w3
Ike agrees to continue as Elincia's escort.$K   $RGMAP��b|$O3$GThe company heads now for the Begnion
Empire, $w3the oldest and largest nation
on the continent of Tellius.$K$PAs Crimea is a former fiefdom of Begnion,
the princess turns to them for succor,
much as a scared child returns to a parent.$K$PMany in Tellius believe that without
Begnion's might and influence, $w2Crimea's
reconstruction $w3will be nigh impossible.$K$PHowever, $w3Begnion and Gallia have no
diplomatic ties $w3and are further separated
by an impassable mountain range.$K$PSo the company $w3is forced to return
to Crimea, $w3where they hope to locate
a ship to carry them to Begnion.$K   $RGMAP��b|$O3$GAccompanied by Ranulf, the warrior
who has volunteered to guide them,$w2
the company leaves Castle Gallia behind.$K$PWith heavy hearts and wounded spirits,$w3
they begin the long march back to Crimea.$K$Ub$H $R�w�i��b|$B���-��-��|$<$F1$FCL_LAY|$F3$FCL_IKE|$F1$PHey, Ike! Hold up a moment.$K$PYou know, I was thinking$MC...$MD$w4
Since this castle is on the way,$w2
we should probably stop by.$K
$F3$PUm$MC...$MD$w4really? Why?
Is there something special about this place?$K
$F1$PWhy yes! There is! This is Canteus Castle!
Daein seized it early on in the war.$w2
Now, it serves as a camp for prisoners.$K$PI've even heard there are a number of
Crimean retainers $w3being held captive
in the dungeon$w2 beneath the castle.$K
$F4$FCL_ERINCIA|$F4$PWhat?! $w3Are$w2 you certain?$K
$F1$P$FSPrincess, $w4I'm hurt! Of course
my information is reliable.$K
$F4$FD$F4$FS$F4$FCL_TIAMAT|$F4$PIf we can rescue some Crimean soldiers$w2
they might decide to join us. $w3That would
be quite a boon, would it not?$K
$F3$PYes, it would.$w4
I think it's worth the risk.$K   $R�w�i�Ȃ���b|$F1$FCL_LAY|$F3$FCL_IKE|$F1$PThe question now is $w3how do you open
these cells and free the prisoners?$K
$F3$PThe cells $w2are certain to be locked,$w4
so in order to open them$MC--$MD$K
$F4$FCL_SENERIO|$F4$PLogic would dictate that the keys
will be in the possession of the jailer.$w4
We've no choice but to steal them.$K$PIf we're lucky, $w2the guards
will have keys as well$MC...$MD$K$PIn either case, $w2we must move with
caution. $w4We don't want to trade
blows$w2 with the entire castle garrison.$K
$F3$PWhich means $w2we stay close to the walls$w2
and avoid being seen or heard, right?$K
All right, then. Our first priority is to$w2
get our hands on the cell keys$MC...$MD$K$P$F1$PHey! $w2You there!$K    $R�w�i�Ȃ���b|$F1$FCL_IKE|$F0$FCL_SENERIO|$F4$FCL_VOKE|$F4$PI have business with Sir Greil.$w4
Where is he?$K
$F0$PYou're sorely lacking in $w2social etiquette,
aren't you? $w4State your business.$K
$F4$PI'll speak with Sir Greil and Sir Greil alone.$w4
Now take me to him.$K
$F0$FD$F0$FCL_TIAMAT|$F0$PWhat you ask is impossible.$w4
Commander Greil $w4is dead.$K
$F4$PWell. $w4That is a problem.$K
$F0$PJust who are you, anyway?$K
$F4$PCall me Volke. $w4Sir Greil hired me.
I'm in$MC...$MD$w2intelligence.$K
$F1$PMy father hired you?$K
$F4$PYou are Sir Greil's son, correct?$w4
You'll do.$K$PSir Greil hired me $w2to investigate
something. $w4You pay my price, and
I'll give you my report. $w3Deal?$K
$F1$PHow much?$K
$F4$PFifty thousand.$K
$F1$PThat's a bit steep.$K
$F4$P$FSAnd worth every penny.$K
$F1$PI don't have that much$MC...$MD$w4
Give me some time.$K
$F4$PSo, $w3you're willing to pay?$w2$K
$F1$PMy father hired you. $w4He must
have had a good reason.$K
$F0$PAre you sure, $w2Commander?$w3
We have no way of knowing if he's
telling the truth.$K
$F1$PWe'll know when we see the contents
of that report. $w4Until then,$w2
let's have him travel with us.$K
$F4$PSo that's your plan, eh?$w4$FA
Listen, you get the report when I get paid,$w4
and I'm not waiting around until then.$K$PI'll keep my information for the time being.$w4
Call me when you've got the gold.$K$PStop into any tavern along your way.$w4
Tell the barkeep you've need of a fireman.
You'll see me within an hour.$K
$F4$FD$F0$FD$F0$FCL_SENERIO|$F0$PHold a moment!$K$P$F4$FCL_VOKE|
$F0$PIntelligence$MC...$MD$w2 You said you were
in intelligence, right?$w4
Is information the only thing you sell?$K
$F4$PCome out with it. What are you asking?$K
$F0$PLocks. $w4Can you open locks?$K
$F4$PSure. Fifty gold per lock.$K
$F1$PYou're going to have him
open the cell doors?$K
$F0$FD$F0$FCL_TIAMAT|$F0$PIs that wise? $w4We've only just met him.
There's no telling if we can trust him.$K$FD
$F1$P$MC...$MD$K
$SD$N$UB$H      $SD$R�w�i�Ȃ���b|$F1$FCL_IKE|$F4$FCL_VOKE|$N$UB$H  Hire    Don't hire  Seek advice $SE$F1$PVolke, $w2will you help us break
into these cells?$K
$F4$PAs long as I get paid,$w2
I've got no complaint.$K
$F0$FCL_TIAMAT|$F1$PTitania? $w2Objections?$K
$F0$P$FSI told you before, didn't I? $w4You're the
commander. $w4If you decide on a
course of action, $w2I will but follow.$K    $SE$F1$PVolke, $w2I beg your pardon, but $w4let's
pretend this little talk never happened.$K$P$F4$PHm. $w2If that's how you want things, so
be it. $w4I wouldn't have objected to traveling
with you, not if it meant steady work, but...$K$P$FD
$F3$FCL_SENERIO|$F1$PAny objections, $w2Soren?$K
$F3$PI abide your decisions, Ike, as always.$K    $SE$F4$P$FD$F3$FCL_TIAMAT|$F4$FCL_SENERIO|$F1$PWhat do the two of you think?$K
$F3$PUnder the circumstances, $w2I think trusting
a man about whom we know nothing is
dangerous. $w4I am opposed to this.$K$P$F4$PIf we want to get those cells open,$w2
I think risk is going to be inevitable.$K$PIf we don't have to steal keys,$w2 we can
reduce that risk and improve our chances
of rescuing the prisoners. $w4It's worth a shot.$K
$FD$F3$FD$F4$FCL_VOKE|$F1$P...$K$N$UB$H    $R�㉺��b|$s0$FS$c0LAY|$s0Righto! $w2I'm off.$w4
Good luck and all that.$K
$c1IKE|What? Wait!$w2
You're not going to
help us here?$K
$s0Much as I would like to,$w2
I have a job to do. $w4I will
rejoin you when I'm finished.$K
$s1Hmm... I see.$w2
Well, good luck to you then.$K
$s0Yes, $w2and to you as well!$K  $R�㉺��b|$c0IKE|$s0Titania, $w4please look after
Princess Elincia.$K
$c1TIAMAT|$s1$FSUnderstood.$K    $R�㉺��b|$c0IKE|$s0Soren, $w4please look after
Princess Elincia.$K
$c1SENERIO|$s1As you wish.$K   $R�㉺��b|$c0IKE|$s0Titania, Soren... $w4Please look
after Princess Elincia.$K
$c3TIAMAT|$s3$FSUnderstood.$K
$c1SENERIO|$s1Watch your back.$K  $R�㉺��b|$s0$Fc$c0CEPHERAN|$s0...$K   $R�㉺��b|$c1CHAP|$s1Uh...$w2tell me something, will you?$w4
What's going to happen to us?$K$PThose Daein soldiers took my friends
away,$w2 and they didn't never come
back.$K$PWhat did they do to them?!$w3
Oh, something bad happened!$w2
I just know it!$K
$c0KEVIN2|$s0Quiet, fool! Keep your cowardly
mutterings to yourself.$K
It matters not $w2what vile torture they
devise. $w4A true knight of Crimea$w2
is bold, $w3steadfast, $w2and strong.$K
I care not if they pull out my nails
with tongs$w2 or insert pins into the soft
flesh of my underbelly$w2 or yank--$K
$s1STOP IT!$w6 I can't bear torture!$w4
I'm not a professional soldier!$w2
I'm just part of the militia!$K$PI can't believe I left my family behind
for this... $w3Will I ever see them again?$w4
Oh, $w2I want to go home.$K
$s0Curses...$w4
If only I had a weapon
of some sort.$K    $R�㉺��b|$c0NEPENEE|$s0Help...$w3will...come.$w4
I will not...$w2give up...$K $R�㉺��b|$c0DAYNE2|$s0L-Look out! $w2We're $w2under attack!$K $R�㉺��b|$c0DAYNE2|$s0Gwaah! $w4Enemy $w2soldiers!$K  $R�㉺��b|$c1DAYNE1|$s1Commander Danomill! $w4The castle
defenses have been breached!$w5
What are your orders, sir?$K
$s0$FS$c0DANOMIRU|$s0What fortunate timing. $w4We were
starting to run low on prisoners.$K$PDo try to capture them alive. $w4I won't
have you robbing me of my fun!$K
$s1As you command, sir!$K  $R�㉺��b|$c0IKE|$s0We've been spotted. $w4There's nothing
left to do $w2but fight!$K  $R�㉺��b|$c0IKE|$s0You there! We've come to rescue you.$K
$s1$Fc$c1CEPHERAN|$s1$Fd...Ah!$K
$s0You're not a soldier, are you?$w4
Your clothing gives you away.$K
$s1I am...$w4a pilgrim.$w4
My name $w2is Sephiran.$K
$s0You're a monk?$w2 Why would
they imprison you?$K
$s1I was arrested in a nearby village,$w2
where I was tending to wounded
Crimean knights.$K$PI received no trial $w2but have
nevertheless been kept prisoner
in this place ever since.$K
$s0I see... $w4That explains it.$K$PWe've come here $w2to liberate the
prisoners of war. $w4You should
take this opportunity to escape.$K
$s1$FSYou will set me free? $w4That is$w2
most gracious of you. $w4If you've no
objection, $w2I would ask your name.$K
$s0I am Ike of the Greil Mercenaries.$w4
Please, the cell door is open.
You should leave while you can.$K
$s1Thank you. $w4Perhaps we will meet
again, $w2Ike.$w4$K    $R�㉺��b|$c0OSCAR|$s0You're from Crimea, right?$w4
Come on--$w2we're here to rescue you.$K$PWe've opened your cell.$w2
Now's the time to escape.$K
$c1KEVIN2|$s1Ah! $w2It's you!$K$d1
$s0Pardon?$K
$c1KEVIN|$s1I could never forget that $w2squint!$w4
Knights of Crimea,$w2 twelfth regiment...$w4
your name is Oscar!$K
$s0And you're... Wait a moment...$w4
You're Kieran, right?$K
$s1That is correct! I am Kieran...$w3
The same Kieran who has sworn
himself to be your eternal rival!$K
$s0$FSUh... $w4Right... $w4Kieran...$w2
So...how've you been?$w4
You look good.$K
$s1As always, $w2your manner is
listless and inappropriate. It befits
one who would call me foe!$K$PYou were discharged three years ago...$w2
What are you doing here now?$K$PAha! $w3Could it be...$w5 You dastard!$w2
You've turned your coat and gone over
to Daein, haven't you?$K$PRarrrrr! $w4What despicable, contemptible
behavior! Unforgivable!$K$PHave you no shame? $w3You were my one
true rival! $w2Where has your pride gone?$K
$s0$FAThe mercenary company I'm attached
to$w2 serves under the command
of the princess of Crimea!$K$PWe came here to free any
Crimean prisoners.$K
$s1The princess of Crimea?!?$w4
You're not part of the royal guard!$w2
How do you know about the princess?$K
$s0Well, $w1like I said, $w2the princess$w2
is our employer and--$w2$K
$s1$FSAha! $w4So that's your scheme, is it?$K$PYou hope to distinguish yourself by
meritorious service and gain the glory
that is rightfully mine! $w4Admit it!$K
$s0Look, my duty is...$K
$s1$FABlast you! $w4Curse your name!
Curse the name of Oscar and all
who call him kin!$K
I will never let you surpass me!$w5
Princess! $w4I'm coming!$w2 Kieran will be
forever at your side!$K$d1
$s0Whoa... $w3He's even more excitable
than I remember. $w4Hard to believe
he's actually a decent knight...$K   $R�㉺��b|$c0IKE|$s0You're a Crimean soldier, right?$w5
I've opened your cell.$w2
Let's get out of here.$K
$c1NEPENEE|$s1Who...are you?$K
$s0I'm Ike. $w3I'm with a mercenary company
hired by Princess Crimea.$K
I can fill you in on the details later.$w4
For the time being,$w3
you'll just have to trust me.$K
$s1...$w4Very well.$K  $R�㉺��b|$c0IKE|$s0You're a Crimean soldier, right?$w4
Come on! I'm here to rescue you!$K
$c1CHAP|$s1S-seriously? $w4I'm not dreaming
again,$w2 am I?$K
$s0I'm a mercenary $w2in the employ
of Princess Elincia.$K
I'll give you all the details later.$w4
For now,$w2 we have to move!$K
$s1$FSWhat? $w2The princess?$w4
Oh, happy day!$K$w4$FA$PWait, let me stretch a bit... $w4Ooo...$w3
Sorry, I'm stiff from this hard floor...$w4
Ow! $w4Ow ow ow! $w4Cramp! Cramp!$K
$s0Oh, for the love of--$w4
Come on! This way!$K$d0
$s1$FSAll, $w1all right!$K$w5$FA$PHold on a second...$w4
I don't remember the king
having any children...$K
$c0IKE|$s0There's no time to explain!$w4
Hurry up!$K$d0
$s1$FSOh! Uh, $w2c-c-$w3coming!$K    $R�㉺��b|$c0KEVIN|$s0$FoGwaa...$w2aarrr...$w3
L-long live...$w2Crimea...$K    $R�㉺��b|$c0CHAP|$s0P-Poppa... $w3I did all...
I could... $w3Don't...$w2$Fc$FS
forget $w2me...$K  $R�㉺��b|$c0NEPENEE|$s0Everything's...$w3so dark...$w5
I...$Fcdon't want to...$K  $R�㉺��b|$s0$FS$c0DANOMIRU|$s0Look who's come to play!$w4
I am so VERY happy to see you.$K$PNow then, $w2are you ready to become
my prisoners and live a life of eternal
bliss within my lovely dungeon?$K    $R�㉺��b|$s0$FS$c0DANOMIRU|$s0Oh, yes... Excellent. $w4What a defiant
stare you have. You're exactly the
type of prisoner I long for.$K$PI will watch as hope fades from your
eyes $w2and revel as despair clouds
your vision. $w4It will be$w5 transcendent.$K
$c1IKE|$s1...$w2Don't count on it.$K  $R�㉺��b|$s0$s0$FS$c0DANOMIRU|$s0A sub-human? $w4Aha ha ha ha!$w3
This is fantastic! $w5I've never had a
sub-human prisoner before!$K$PCome here, $w2and behave yourself.$w4
I'll build a special cell $w2just for you...
Perhaps I'll stuff and mount you, too!$K
$s1$Fh$c1LETHE|$s1Gr$w1rr$w1rr$w1rraaaaa!$K    $R�㉺��b|$s0$FS$c0DANOMIRU|$s0Oh, dear heavens... $w2Look at the size
of this one! $w5Easy now--don't move.$w4
I'll not let such a trophy $w2escape.$K
$c1MORDY|$s1Your soul is twisted.$w4
It$w2 saddens me.$K   $R�㉺��b|$s0$FS$c0DANOMIRU|$s0You'll not escape...$w5 I will see all
of you...$w2dead... $w4You will be$w1
exe...$w2cu...$w3ted...$K  $R�w�i��b|$B����-��|$<$F4$FCL_IKE|$F3$FCL_ERINCIA|$F4$PI've brought one of the Crimean
soldiers who was being held prisoner.$K$F4$FD
$F3$PAhem... $w4I'm sure $w2you are unaware
of this, $w2but I am...$K
$Ub$H$F1$FS$F1$FCL_KEVIN|$F1$PPrincess Elincia!$K
$F3$POh...$w4yes. $w2Quite right.$K
$F1$PI am Kieran! $w3I served under General
Geoffrey,$w2 as leader $w2of Crimea's
fifth platoon.$K$PMy platoon had the honor of escorting you
from the palace during Daein's attack!$K
$F3$PReally? $w3You $w2were there$w1 when...$K
$F1$PI was! $w3Lord Renning ordered my platoon
to accompany General Geoffrey and serve
as your escort.$K$POur mission $w2was to see you safely out
of Crimea to Gallia's king.$K$P$FABut we failed you...$w2 And when
you were lost to us... $w4I believed
my worthless life was at its end...$K$PYet $w2here you are! $w2To think that I
would be so blessed as to see you again...$w2
Such emotion...$w2 I... $w4The tears...$Fcsniff...$K
$F3$PKieran, $w4were there $w3any others?$K
$F1$P$FdSuch terrific emotion...
So-- $w4I beg your pardon?$K
$F3$PDid anyone other than yourself survive?$K
$F1$P$FSOf course!$w2 Though I was the only one
unfortunate enough to suffer the misery
of captivity.$K$PGeneral Geoffrey $w2and several of his soldiers$w3
fought off $w2the Daein attack.$K$PThey were able to slip away.$w2 Even now,
they wait in Crimea, $w2hoping for one last
chance to strike a blow against Daein.$K
$F3$PGeoffrey...$w2 He is alive?$w5
$FS$FcAh... $w4How those words$w2 drive off
the shadows across my heart...$K$P$FdThank you, $w1Kieran.$w4
Thank you...$w3for surviving.$K
$F1$PYou are too kind, Your Highness.$w4
The opportunity to serve you again is
the greatest reward I could ask for.$K$PFor as long as I draw breath,$w2 I will
stand ready at your side!$w2 This, I swear.$K
$=0300   $R�w�i��b|$B����-��|$<$F1$FCL_CHAP|$F0$FCL_NEPENEE|$F3$FCL_ERINCIA|$F4$FCL_IKE|$F4$PAll right, $w2we all know where Kieran stands...$K$PHow about you two? $w4Will you recognize
Princess Elincia as the rightful heir to
the Crimean throne? $w4Will you fight for her?$K
$F1$PLook here. My name's $w2Brom, $w4and this
lass is Nephenee. We're just simple country
militiamen from the same territory.$K$PNow, we don't know much about $w2nobles
and stuff. Kings and queens don't matter
much when you're workin' the fields.$K$P'Course, we know we'll be in trouble if
someone takes our fields away from us,
so that's why we joined the militia!$K$PThis king of Daein's no friend of ours.$w2
And I hear he's doing terrible things, too...$w3
Vile tortures with rusty nails and...and more!$K$PWhat's going to happen to my family?$w2
I left them all back home, $w2and I'm so
worried I can hardly see straight.$K
$F0$PIf you can defeat the king of Daein,$w2
will this country return to the way it
used to be?$w2 Is that what you're after?$K
$F3$PIt is my hope. $w4I may not be as
powerful as my father, $w2but I will
never abandon Crimea.$K
$F1$P$FSYou sound like a lady who stands by
her word. $w3Looks like my choice is easy!$K
$F0$P$FSMine too.$K
$F1$PI'll $w2fight in your name.$K$PI'll help you and yours, $w3and we'll send
those Daein milksops packing!$K
$F3$P$FSThank you.$K
$F0$FD$F1$FD$F7$FCDUMMY|$F7$PI beg your pardon...$K$F7$FD
$F1$FS$F1$FCL_CEPHERAN|$F4$PYou're...$K$P$FD$F3$FD
$F3$FCL_CHAP|$F4$FCL_NEPENEE|$F4$P$FSO blessed saint...$K
$F3$P$FSMaster Sephiran!$w4 You live!$K
$F1$PBrom, $w2Nephenee...$w4
Are either of you wounded?$w2$K
$F3$P$FAWe're fine, but what about you? You were
jailed for helping us... $w3I'm so sorry!$w4
Oh, I hope they didn't hurt you!$K
$F1$PIt is nothing to fret about.$w4
Everyone is safe,$w2
and that is what matters.$K
$F4$P$FAO blessed one...$K
$=0500 $R�w�i��b|$B����-��|$<$F1$FCL_CHAP|$F3$FCL_ERINCIA|$F4$FCL_IKE|$F4$PAll right, $w2we all know where Kieran stands...$K$PHow about you, stranger? $w4Will you recognize
Princess Elincia $w2as the rightful heir to
the Crimean throne? Will you fight for her?$K
$F1$PLook here. My name's $w2Brom. $w4I'm
just a simple country militiaman from
Crimea.$K$PNow, I don't know much about $w2nobles
and stuff. Kings and queens don't matter
much when you're workin' the fields.$K$P'Course, I know I'll be in trouble if
someone takes my fields away from me,
so that's why I joined the militia!$K$PThis king of Daein's no friend of ours.$w2
And I hear he's doing terrible things, too...$w3
Vile tortures with rusty nails and...and more!$K$PWhat's going to happen to my family?$w2
I left them all back home, $w2and I'm so
worried I can hardly see straight.$K$PSo all I need to know is if you can
set things aright and ensure my family's
safety.$K
$F3$PDo not worry, my friend. $w4I may not be
as powerful as my father, $w2but I will
never abandon Crimea.$K
$F1$P$FSYou sound like a lady who stands by
her word. $w3Looks like my choice is easy!$K
$F1$PI'll $w2fight in your name.$K$PI'll help you and yours, $w3and we'll send
those Daein egg suckers packing!$K
$F3$P$FSThank you.$K
$F1$FD$F7$FCDUMMY|$F7$PI beg your pardon...$K$F7$FD
$F1$FS$F1$FCL_CEPHERAN|$F4$PYou're...$K$P$FD$F3$FD
$F3$FCL_CHAP|$F3$PO blessed saint!$w4$FS You're alive and well!$K
$F1$PBrom, $w2have you been wounded?$K
$F3$P$FAI'm fine, but what about you? You were
jailed for helping me... $w3I'm sorry!$w4
Oh, I hope they didn't hurt you!$K
$F1$PIt is nothing to fret about. $w4More
importantly, $w2where is the young
woman with whom you were traveling?$K
$F3$PAh, $w2the dear lass $w4Nephenee,$w2
she...$w2 In the battle, she...$K
$F1$P$FAI understand...$w3
$FcHow tragic.$K
$F3$PO blessed one...$K
$=0500 $R�w�i��b|$B����-��|$<$F0$FCL_NEPENEE|$F3$FCL_ERINCIA|$F4$FCL_IKE|$F4$PAll right, $w2we all know where Kieran stands...$K$PHow about you? $w4Will you recognize
Princess Elincia $w2as the rightful heir to
the Crimean throne? Will you fight for her?$K
$F0$P...$w4Um...$K
$F4$PYes?$K
$F0$PIf you can defeat the king of Daein,$w2
will this country return to the way it
used to be?$w2 Is that what you're after?$K
$F3$PIt is my hope. $w4I may not be as
powerful as my father, $w2but I will
never abandon Crimea.$K
$F0$P$FSIn that case...I will fight with you.$w4
For Crimea.$w4
My name is Nephenee.$K
$F3$P$FSThank you, Nephenee.$K
$F0$FD$F7$FCDUMMY|$F7$PI beg your pardon.$K$F7$FD
$F1$FS$F1$FCL_CEPHERAN|$F4$PYou're...$K$P$FD$F3$FD
$F4$FS$F4$FCL_NEPENEE|$F4$PO blessed saint!$K
$F1$PNephenee, $w2have you suffered
any injury?$K
$F4$P$FAI'm fine, thanks to you.$w2 But what
about you? You were captured because
you tried to help us...$K
$F1$PIt is nothing to fret about.$w4
More importantly, $w2where is the fellow
with whom you were traveling?$K
$F4$POh, Brom...$w2 Poor, sweet Brom...$w2
In that battle, he...$K
$F1$P$FAOh...I see...$w3
$FcHow tragic...$K
$F4$PO blessed one...$K
$=0500    $R�w�i��b|$B����-��|$<$F1$FCL_CHAP|$F0$FCL_NEPENEE|$F4$FCL_IKE|$F3$FCL_ERINCIA|$F4$PHere are two Crimean soldiers$w2
who were being held as prisoners.$K
$F3$PAhem... $w4This may come
as a surprise, $w2but...$w5
My name is $w2Elincia.$K$PI am the daughter of Ramon, king of
Crimea, who was so recently killed by
Daein's heartless attack.$K$PI'm on a mission to liberate $w3and
restore our homeland... $w2And I
need all the support I can garner.$K
$F4$PWe need to know where you stand.$w4
Will you recognize Princess Elincia as
the Crimean heir? $w4Will you fight for her?$K
$F1$PLook here. My name's $w2Brom, $w4and this
lass is Nephenee. We're just simple country
militiamen from the same territory.$K$PNow, we don't know much about $w2nobles
and stuff. Kings and queens don't matter
much when you're workin' the fields.$K$P'Course, we know we'll be in trouble if
someone takes our fields away from us,
so that's why we joined the militia!$K$PThis king of Daein's no friend of ours.$w2
And I hear he's doing terrible things, too...$w3
Vile tortures with rusty nails and...and more!$K$PWhat's going to happen to my family?$w2
I left them all back home, $w2and I'm so
worried I can hardly see straight.$K
$F0$PIf you can defeat the king of Daein,$w2
will this country return to the way it
used to be?$w2 Is that what you're after?$K
$F3$PIt is my hope. $w4I may not be as
powerful as my father, $w2but I will
never abandon Crimea.$K
$F1$P$FSYou sound like a lady who stands by
her word. $w3Looks like my choice is easy!$K
$F0$P$FSYes?$K
$F1$PI'll $w2fight in your name.$K$PI'll help you and yours, $w3and we'll send
those Daein egg suckers packing!$K
$F3$P$FSThank you.$K
$F0$FD$F1$FD$F7$FCDUMMY|$F7$PI beg your pardon...$K$F7$FD
$F1$FS$F1$FCL_CEPHERAN|$F4$PYou're...$K$P$FD$F3$FD
$F3$FCL_CHAP|$F4$FCL_NEPENEE|$F4$P$FSO blessed saint...$K
$F3$P$FSMaster Sephiran!$w4 You live!$K
$F1$PBrom, $w2Nephenee...$w4
Are either of you wounded?$w2$K
$F3$P$FAWe're fine, but what about you? You were
jailed for helping us... $w3I'm so sorry!$w4
Oh, I hope they didn't hurt you!$K
$F1$PIt is nothing to fret about.$w4
Everyone is safe,$w2
and that is what matters.$K
$F4$P$FAO blessed one...$K
$=0500 $R�w�i��b|$B����-��|$<$F1$FCL_CHAP|$F4$FCL_IKE|$F3$FCL_ERINCIA|$F3$PAhem... $w4This may come
as a surprise, $w2but...$w5
My name is $w2Elincia.$K$PI am the daughter of Ramon, king of
Crimea, who was so recently killed by
Daein's heartless attack.$K$PI'm on a mission to liberate $w3and
restore our homeland... $w2And I
need all the support I can garner.$K
$F4$PWe need to know where you stand.$w4
Will you recognize Princess Elincia as
the Crimean heir? $w4Will you fight for her?$K
$F1$PLook here. My name's $w2Brom. $w4I'm
just simple country militiaman from
Crimea.$K$PNow, I don't know much about $w2nobles
and stuff. Kings and queens don't matter
much when you're workin' the fields.$K$P'Course, I know I'll be in trouble if
someone takes my fields away from me,
so that's why I joined the militia!$K$PThis king of Daein's no friend of ours.$w2
And I hear he's doing terrible things, too...$w3
Vile tortures with rusty nails and...and more!$K$PWhat's going to happen to my family?$w2
I left them all back home, $w2and I'm so
worried I can hardly see straight.$K$PSo all I need to know is if you can
set things aright and ensure my family's
safety.$K
$F3$PDo not worry, my friend. $w4I may not be
as powerful as my father, $w2but I will
never abandon Crimea.$K
$F1$P$FSYou sound like a lady who stands by
her word. $w3Looks like my choice is easy!$K
$F1$PI'll $w2fight in your name.$K$PI'll help you and yours, $w3and we'll send
those Daein egg suckers packing!$K
$F3$P$FSThank you.$K
$F1$FD$F7$FCDUMMY|$F7$PI beg your pardon...$K$F7$FD
$F1$FS$F1$FCL_CEPHERAN|$F4$PYou're...$K$P$FD$F3$FD
$F3$FCL_CHAP|$F3$PO blessed saint! $w4$FSYou live!$K
$F1$PBrom, $w2have you been wounded?$K
$F3$P$FAI'm fine, but what about you? You were
jailed for helping us... $w3I'm so sorry!$w4
Oh, I hope they didn't hurt you!$K
$F1$PIt is nothing to fret about. $w4More
importantly, $w2where is the young
woman with whom you were traveling?$K
$F3$PAh, $w2the dear lass...$w4
Nephenee, $w2in the battle, she...$K
$F1$P$FAOh, I see...$w3
$FcHow tragic.$K
$F3$PO blessed one...$K    $R�w�i��b|$B����-��|$<$F0$FCL_NEPENEE|$F4$FCL_IKE|$F3$FCL_ERINCIA|$F3$PAhem... $w4This may come
as a surprise, $w2but...$K$PMy name is $w2Elincia.
I am the daughter of King Ramon,
the recently departed leader of Crimea...$K$PI'm on a mission to liberate $w3and
restore our homeland... $w2And I
need all the support I can garner.$K
$F4$PWe need to know where you stand.$w4
Will you recognize Princess Elincia?$w2
Will you fight for her?$K
$F0$P...$w4Um...$K
$F4$PYes?$K
$F0$PIf you can defeat the king of Daein,$w2
will this country return to the way it
used to be?$w2 Is that what you're after?$K
$F3$PIt is my hope. $w4I may not be as
powerful as my father, $w2but I will
never abandon Crimea.$K
$F0$P$FSIn that case...I will fight with you.$w4
For Crimea.$w4
My name is Nephenee, by the way.$K
$F3$P$FSThank you, Nephenee.$K
$F0$FD$F7$FCDUMMY|$F7$PI beg your pardon.$K$F7$FD
$F1$FS$F1$FCL_CEPHERAN|$F4$PYou're...$K$P$FD$F3$FD
$F4$FS$F4$FCL_NEPENEE|$F4$PO blessed saint!$K
$F1$PNephenee, $w2have you suffered
any injury?$K
$F4$P$FAI'm fine, thanks to you.$w2 But what
about you? You were captured because
you tried to help us...$K
$F1$PIt is nothing to fret about.$w4
More importantly, $w2where is the fellow
with whom you were traveling?$K
$F4$POh, Brom...$w2 Poor, sweet Brom...$w5
In that battle, he...$K
$F1$P$FAOh, I see...$w3
$FcHow tragic.$K
$F4$PO blessed one...$K
$=0500   $R�w�i��b|$B����-��|$<$F1$FCL_CEPHERAN|$F3$FCL_IKE|$F3$PPardon me, $w2may I have a moment?$K
$F1$PYes?$K$FS
Oh, $w2you're the man I met earlier.$w5
I owe you so much for freeing me.$w4
Thank you $w2from the bottom of my heart.$K$N$UB$H    $R�w�i��b|$B����-��|$<$F1$FCL_CEPHERAN|$F3$FCL_IKE|$F3$PPardon me, $w2may I have a moment?$K
$F1$PAnd you are?$K
$F3$PI'm Ike. $w4I'm the commander of this
mercenary company.$K
$F1$P$FSThat must mean $w2you're the one responsible
for giving me back my freedom.$w4
I am Sephiran, $w2a monk on pilgrimage.$K$PPlease allow me $w2to express my
gratitude. $w4Thank you.$K$N$UB$H  $R�w�i��b|$B����-��|$<$F1$FCL_CEPHERAN|$F3$FCL_IKE|$F1$PPardon me...$w4
May I $w2have a moment of your time?$K
$F3$PWho are you?$K
$F1$P$FSI am $w2a monk on pilgrimage.$w4
My name $w2is Sephiran.$K$PThanks to your efforts, $w2I have been
freed from my $w2imprisonment.$K
$F3$PA monk? $w2Why did the
Daein army arrest you?$K
$F1$PI was arrested $w2in a nearby village
where I was treating $w2wounded
Crimean knights.$K$PI received no trial $w2but taken prisoner
nevertheless. $w4I was scheduled to be
executed $w2on the morrow.$K$PI owe you my life. $w4I thank you$w2
from the bottom of my heart.$K$N$UB$H   $F3$PYou don't have to thank us. $w4However,
I am curious about your situation.$K
Why $w2were you aiding Crimean soldiers?$K
$F1$P$FADo you question my story?$K
$F3$PYou're a monk on pilgrimage $w2as well as
an ally of Crimean resistance fighters?$w4
Under the circumstances, do you blame me?$K
$F1$PTell me something, Ike.$w2 If you came
across a wounded person, could
you ignore his plight?$K
$F3$PNormally... $w2No, I could not.$K$PBut $w2in times like these, $w2where
it means risking my own life...$w4
I don't know. It's tough to say.$K
$F1$P$FSHa ha... $w2You're quite honest. $w4However,$w4
if actually faced with such a choice, $w2a man
such as yourself would not hesitate.$K$PIf faced with an individual in pain, you
would act instinctively. $w4Your body
would not wait for the command.$K
$F3$PWho...$w2 Who are you? Really.$w4
You're so calm, so full of peace.$w4
I can't believe you're a simple monk.$K
$F1$PIf you'll forgive me, $w2I must be going.$K$PFare thee well, $w3young warrior.$w4
I am certain$w2 that we will meet again.$K$F1$FD
$=0500    $R�w�i��b|$B����-��|$<$F0$FCL_VOKE|$F3$FCL_IKE|$F0$P...Ike.$K
$F3$POh, hello, Volke. $w4What do you want?$K
$F0$PI was thinking $w2about traveling with you
for a bit. $w4I'll be in the general area,$w2
so if you need anything, you can call me.$K$PI'll help you out...for a fee, of course.$K
$F4$FCL_TIAMAT|$F4$PWhat did you say?$K
$F3$PWhy would you do such a thing?
In times such as these, there must be
many parties that need...intelligence.$K
$F0$P$FSWell, you've sparked my curiosity.$w4
And besides... $w2No, we'll just have
to leave it at that.$K
$F4$PThat's not acceptable.$K
$F0$PDon't be so inflexible. $w4It's not as if$w2
I'll be joining your merry band or anything.
This is strictly business.$K
$F4$PAnd yet you--$K
$F3$PTitania.$K
$F1$FCL_SENERIO|$F1$PI believe this is a good opportunity.$K
We will almost certainly have need
of this man's talents.$K$PHe is a dubious character at best,$w2
but at least we know his motives.
Everything begins and ends with gold.$K$PHe'll be easy to control.$K
$F3$PSoren, $w2he's standing right there.$K
$F1$PI don't think he minds.$K
$F4$PWhat will it be, $w2Ike?$w4
The decision's yours.$K$FD$F1$FD
$SD$N$UB$H     $SD$R�w�i��b|$B����-��|$<$F0$FCL_VOKE|$F3$FCL_IKE|$N$UB$H  Let him come.   Refuse his request. $SE$F3$PVery well. $w4You may do as you like.$K
$F0$PExcellent. $w2Call me if you need anything.$K$F0$FD
$=0500 $SE$F3$PI'm sorry, $w2but I cannot accept your
proposition.$K$PHowever, as we discussed earlier, I will
summon you when we have the fee for my
father's information. $w4Is that acceptable?$K
$F0$P$FAAgreed. $w4Be seeing you.$K$F0$FD
$=0500  $R�w�i��b|$B����-��|$<$F1$FCL_LAY|$F3$FCL_IKE|$F1$PFirst the thief$w2 and then that monk...$w2
What an odd band of characters
you've attracted!$K
$F3$PRanulf! $w4Have you finished your errands?$K
$F1$P$FSAll done! $w4$FABut about those two--$K
$F3$PYes, they're both rather mysterious.$K
$F1$PWell, $w2the monk seems like a
decent enough fellow.$K
$F3$PDetermining who is a friend and who is
a foe is something I must be able to do.$w5
But it's just so hard.$K
$F1$P$FSThat's only because you don't have enough
information to base your judgment on.$K$PAll we can do now $w2is press on.$K
$F3$PYou're right...$K
$=1500  $R�w�i��b|$B����-��|$<$F1$FCL_LAY|$F3$FCL_IKE|$F1$PThat thief? Volke?$w2 I don't know how,
but he's just vanished. $w4I can't find
hide nor hair of him.$K$PFirst him, $w2and then that monk...$w2
What an odd band of characters
you've attracted!$K
$F3$PRanulf! $w4Have you finished your errands?$K
$F1$P$FSAll done! $w4$FABut about those two--$K
$F3$PYes, they're both rather mysterious.$K
$F1$PWell, $w2the monk doesn't appear$w2
to be a bad fellow.$K
$F3$PDetermining who is a friend and who is
a foe is something I must be able to do.$w5
But it's just so hard.$K
$F1$P$FSThat's only because you don't have enough
information to base your judgment on.$K$PAll we can do now $w2is press on.$K
$F3$PYou're right...$K
$=1500   $R�w�i��b|$B��̒�|$<$F5$FCL_IKE|$F5$P$MC...$MD$K
$F4$FCL_TIGER|$F4$PYou there! Beorc!$w4
What do you think you're doing?$K
$F5$FD$F1$FCL_IKE|$F1$PI was trying to get back to my room,
but I've lost my way. $w4Can you tell
me which way $w2I need to go?$K
$F4$PIt's this way. $w4Follow me.$K$PHey! $w3Not so close!$w4
Walk behind me.$K
$F1$PWhat?$K
$F4$PEr$MC...$MD Pardon me.$w4
The king has ordered us to treat
beorc with kindness, but$MC...$MD$K$PIt will$MC...$MD$w3take some time.$w5
It is difficult to fight that instinct.$K$PPerhaps $w2some memory $w4of the
slavery our forefathers suffered $w2at
beorc hands $w2flows in our blood.$K
$F1$PI understand. $w4I'll keep my distance.$K
$F4$PVery well$MC... $MDLet's go.$K
$F1$PAll right.$K $R�w�i��b|$B���-����-�K���A|$<$F3$FCL_IKE|$F1$FS$F1$FCL_MARCIA|$F1$PAnd so we put this guy right here,$w4
and this dealy-bobber goes there$MC...$MD$w4
and we're finished!$K
$F3$PPacking, huh? Want some help?$K
$F1$PDo I want some$MC...? $MDPfff!
You're a hoot, handsome!$w4
I'm already done!$K
$F3$PYou're more skillful at this than I
would've imagined. $w4Or is it
that Mist $w2is woefully inept?$K
$F1$PAw, the Begnion pegasus knights$w3
were always moving around, so I
learned to pack quickly.$K$PThey used to train us on it all the time$MC...$MD
Go here$MC... $MDPack this$MC...$MD
Fun stuff!$K
$F3$PIs that so?$K
I can see $w2that you have a strong sense of
duty. $w4Quitting the Begnion pegasus knights
to join us must seem$MC...$MD$K
$F1$P$FAWhat are you saying? I'm a burden now?$K
$F3$PUm$MC...$MDno. $w2I'm very grateful you're here.$w4
As I told you before, $w3we're short
on personnel.$K
$F1$P$FSOh. Good then! And I'm happy to be here!$K$PUm$MC...$MD$w2say, Ike?$w3
You don't need to worry about me$w2
quitting the Begnion service.$K$PMy decision $w2wasn't based solely
on my desire $w2to repay you$MC...$MD$K
$F3$PYou had other reasons?$K
$F1$P$FAYes.$w5 I$MC...$MD$w3I'm also searching for$w2
my missing brother.$K$PHe may be a dolt and a scoundrel,$w4
but he's all the family
I have in this world.$K$PRemember when you found me?
When we were fighting the pirates?
Well, I was trying to track him down.$K$PBut every time I go looking for him, I end
up in some dangerous situation with
ugly boat monkeys trying to kill me.$K
$F3$PHeh. $w5So that's why you
decided to join us, is it?$w4
I can understand that.$K
$F1$PSo, are you sorry you asked?$K
$F3$PNot at all. $w4The important thing is$w3
finding your brother as quickly as
possible, right?$K
$F1$P$FSThat's the plan!$K   $R�w�i��b|$B��̒�|$<$F3$FCL_IKE|$F1$Fc$F1$FCL_LETHE|$F1$P$MC...$MD$K
$F3$PYou seem$MC...$MDdepressed.$K
$F1$P$FdLook at who I'm trapped with! Of course
I am depressed$MC... $MDAnd keep your
worthless observations to yourself.$K$PAll of you are so slow$MC...$MD$w4
I can't believe you're still not ready.$K
$F3$PSorry about that.$K
If we were like you$w2 and didn't need to
carry anything, $w3it would be easier, but$MC...$MD$w4
We have weapons and things to get ready.$K
$F1$PWeapons of steel$w5 are a human
weakness. $w4Without them,$w2
you cannot fight properly.$K
$F3$PBut$MC...$MD$w2Lethe,$w4 you're carrying
a dagger, aren't you?$w2
In the scabbard on your leg?$K
$F1$PThis$MC...$MD$w3is not for fighting.$K
$F3$PThen what's it for?$K
$F1$PI use it to remove small bones from meat.$w4
It can also cut fruit into bite-sized pieces.$w4
It has proven quite useful.$K
$F3$PHmm$MC...$MD$K
$F1$PWhat?$w5 If you've got something to say,$w2
spit it out!$K
$F3$PYou despise beorc, $w3but you don't
mind beorc-crafted tools?$K
$F1$PIf something's good, $w2it's good.$w4
Denying something's obvious worth out
of petty spite $w2is foolish.$K$PIt's not that I$MC... $MD$w3I do not despise
everything beorc.$K$PIf every beorc $w3could get along with us
as well as you do, $w4I'm certain$MC...$MD$K
$F3$PLethe?$K
$F1$PThis is a ridiculous conversation!$K$PI'm leaving now.$K$F1$FD
$F3$P$MC...$MD$K   $R�w�i��b|$B���-����-�K���A|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke, $w3here's a summary of our last battle.$K$N$UB$H  $F3$P$Fc$MC...$MD$K$P$UB$H  $F1$P$FSThere were no casualties,$w2 and no one
suffered permanent injury.$w4
We fought excellently.$K$P$UB$H   $F1$PThat's all I have to report.$w4
If you'll excuse me.$K   F@      G   	  H8     Il   "  J@   .  E�   8  E8   G  E�   W  J�   j  u�   w  m�   �  e    �  `|   �  Y4   �  Q�   �  {$   �  |   �  }�   �  �   �  �    ��    ��  ,  ��  ?  ��  N  �l  ^  ��  m  �\  }  ��  �  0�  �  0�  �  4D  �  4�  �  4�  �  5  �  6D  �  �  �  h  	  �    ��  #  ��  1  ��  ?      M  T  X  `  e  �  r  �       �  !�  �  )�  �  )�  �  +  �  )�  �  ,h  �  )�  �  )�    )�    .<  +  /�  6  0@  E  /t  X  ��  g  �h  x  ��  �  ��  �  6�  �  :  �  A   �  Bl  �MS_11_BT MS_11_BT_IKE MS_11_BT_LE MS_11_BT_MO MS_11_DIE MS_11_DIE_CHAP MS_11_DIE_KEVIN MS_11_DIE_NEPHENEE MS_11_ED01_A MS_11_ED03_--N MS_11_ED03_-C- MS_11_ED03_-CN MS_11_ED03_K-N MS_11_ED03_KC- MS_11_ED03_KCN MS_11_ED05_01A MS_11_ED05_01B MS_11_ED05_01C MS_11_ED05_02 MS_11_ED06_01 MS_11_ED06_01_DEL MS_11_ED06_01_SKIP MS_11_ED06_02A MS_11_ED06_02AA MS_11_ED06_02B MS_11_ED06_02BB MS_11_ED07_A MS_11_ED07_B MS_11_EV01 MS_11_EV01_KE_CH MS_11_EV01_NE MS_11_EV02_01 MS_11_EV02_02 MS_11_EV02_02_01 MS_11_EV02_03 MS_11_GMAP_1 MS_11_GMAP_2 MS_11_GMAP_4 MS_11_INFO_01 MS_11_INFO_03 MS_11_INFO_04 MS_11_OP01 MS_11_OP01_A MS_11_OP01_B MS_11_OP01_C MS_11_OP02_00 MS_11_OP02_01 MS_11_OP02_02 MS_11_OP02_02A MS_11_OP02_02AA MS_11_OP02_02B MS_11_OP02_02BB MS_11_OP02_02C MS_11_OP02_02CC MS_11_OP02_02_DEL MS_11_OP02_02_SKIP MS_11_OP04 MS_11_OP05_SEN MS_11_OP05_SEN_TMT MS_11_OP05_TMT MS_11_REPO_BEGIN MS_11_REPO_DIE MS_11_REPO_END MS_11_REPO_NODIE MS_11_TK01 MS_11_TK02 MS_11_TK03 MS_11_TK04 