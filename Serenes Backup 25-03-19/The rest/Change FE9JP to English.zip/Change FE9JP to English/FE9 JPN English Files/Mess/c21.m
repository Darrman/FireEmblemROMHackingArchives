  ��  �p       2                $RGMAP��b|$O3$GThe kingdom of Daein $w2lies on the
northernmost edge of Tellius.$K$PIts coastline is bathed in the icy currents of
the northern sea, $w2and frigid winds howl
inland with terrible ferocity.$K$PAs a result, $w2Daein winters are raw and
brutal--$w2ice and snow scour the land,
leaving frozen scars in their wake.$K$PThrough these blizzards, $w2General Ike and
the Crimean army press ever forward.$K$PBegnion's imperial senate may have lent
Crimea troops,$w3 but even they doubt that
the army can successfully fight off Daein.$K$PYet somehow, $w2Ike and company defy all
odds$w3 and capture victory after victory.$K$PEmbracing both Princess Elincia's dream of
a liberated Crimea$w3 and the tragic history
of his parents, Ike marches in grim silence.$K
$Ub$H  $R�w�i��b|$B�V���l�p-��|$<$F0$FCL_SENERIO|$F3$FCL_IKE2|$F0$P...This can only mean one thing:
the enemy knows exactly how
we are going to move.$K$PWith your permission, $w2I'll begin an
investigation to see if there's anyone
suspicious among the troops...$w4$K$P...$w3Ike?$K
$F3$P...$K
$F0$PIke?$w4 Are you all right?$K
$F3$PHm?$w4 Oh, $w2yes...$w4
Sorry. $w2What is it?$K
$F0$PNothing. I was just giving you the
standard update.$w4 Shall I put it off
till later?$K
$F3$PNo, $w2sorry, but can you start over from
the beginning? I'll pay attention this time.$K
$F0$PUnderstood.$K
$F4$FS$F4$FCL_TIAMAT|$F4$PGood morning, $w2you two.$K$PWhat's wrong, $w2Ike?$w4 You look
so sleepy!$K
$F3$P$FcI've...$w2had a lot on my mind. I meant to
sleep last night, but I was up thinking.$w4
Before I knew it, it was morning.$K
$F4$PReally? $w2I never thought I'd hear that.$w4
Ike didn't sleep because he was thinking.$w4
I wonder if Soren will start being polite...$K
$F3$P$FdListen, $w2Titania...$w4 Can I just--$K$P$F1$FCL_MISTs|$F1$PB-$w2Brother!$w4 Ike!$K
$F3$PWhat's wrong, $w2Mist?$K
$F1$PWhat am I going to do, $w2Ike?$w4
My medallion's gone!$K
$Ub$H$F3$PWhat?$w4 It's gone?$K
$F4$P$FANo!!$K
$F1$PWhat am I going to do?$w4 It was my only
memento of Mother--$K
$F3$PDid you drop it? $w2Or put it somewhere
and forget?$w2 Something like that?$K
$F1$PNo! I always $w2carry it with me!
I would never lose it!$K$PI had it before I went to bed last night...$w4
It vanished $w2while I was sleeping!$w4
$FhSniff...$w4waaaa...$K
$F3$PDon't cry.$w4 It's not your fault.$K
$F1$P$FcBut...$w4but...$K
$F3$PI said don't cry!$w4 $FSI'll find it!$w2
All right?!$K
$F1$P$FdAll...$w4right...
Sorry...$K
$F0$P...$K  $R�w�i��b|$B�R��-��|$<$F0$FCL_PRAGUE|$F3$FCL_SIHARAMU|$F3$PA-are you serious?$K
$F0$PYou are to begin immediately.$K
$F3$PYet, $w2that's... $w2General Petrine!$w4
If we do this thing, $w2Daein will suffer.$K
$F0$PIt's for the good of the country.$w4
Besides, it's only one territory!$w2
Stop mewling like an old woman.$K
$F3$PI hear you, and yet...$K$PIf the goal is merely to stop the Crimean
army, this is not necessary. $w2The
strength of my troops will suffice to--$K
$F0$PThe last idiot who told me that ended
up on a corpse pile! Now listen to me,$w4
and listen well.$K$PNo matter how passionate you are when
you tell me you'll defeat Crimea, I'll never
pin my hopes on a bunch of foreigners.$K$PAll you have to do is stop their forward
progress. That's all.$w4 My plan will
accomplish this.$K
$F3$PGeneral Petrine!$w4 Do you truly think
so little of us?$K$PIt's true that we were born in Begnion and
not Daein, but my men and I have been
loyal to this country for eighteen years.$K$PWe have spared no effort to learn all
the proper manners and customs
of this land.$K$PBut now, after all of that, to be dismissed
as a "bunch of foreigners..."$K
$F0$PNo one asked how long you've lived here.
Want to know why? Because no one cares!$w4
Certainly not me!$K$PWhere were you born? $w2Huh?$w4 Where were
you raised? $w2$FSHa!$w3 This country doesn't
need squatters like you!$K$PThe only people Daein can count on in
times of crisis$w3 are Daeins themselves!
Everyone else is just gutter leavings!$K
$F3$PSo we're useless...$w4
Is that what you're saying?$K
$F0$PYou tell me, migrant!$K$PWhy is it $w2that your unit, which was
trained to be an elite royal guard, is here
patrolling this hick-infested backwater?$K$PThe answer's clear to me!$w3
How about you?$K
$F3$PI... I...$K
$F0$POh, I'm sorry... Am I offending you?$w4
Well, here's your chance to show us
your worth.$w2 Halt Crimea's advance!$K$PIf you are as skilled as you claim, $w2you
should be able to limit the damage to
its bare minimum, should you not?$K
$F3$PGrrr...$K
$F0$PHmph! Angry is a good look for you.
I look forward to seeing the results of
your work.$w4 Get going, outlander.$K$F0$FD
$Ub$H$F4$FCL_DAYNE2|$F4$PG-General Shiharam...$w4 Must we truly$w2
go through with this?$w4
It's such a horrific act!$K$PIt's only recently that the citizens
hereabouts have even come to trust us.$K
$F3$PWe have no choice but to obey.$K$PIt's as the woman says.$w4 The only thing
we can do is ensure the Crimean army
is defeated as soon as possible.$K
$F4$PGeneral--$K
$F3$POpen the floodgates.$w4
DO IT NOW!$K    $R�w�i��b|$B����-��|$<$F1$FCL_ERINCIA|$F3$FCL_IKE2|$F1$PMy lord Ike, $w2were you able to find
the medallion?$K
$F3$PNo. It's gone.$w4 I fear that Daein may
have somehow stolen it.$K
$F1$PWhat?$w4 Is such a thing possible?$K
$F3$PI don't know to what degree, $w2but there
can be no questioning Daein's involvment.$K
$F1$PIs the medallion...$w4special?$K
$F3$P...Yes...$w4
Oh, yes...$K
$F1$P...$w5I beg your pardon.$K
$F3$PWhat is it?$K
$F1$PMy question may have touched
a sensitive area.$K
$F3$POh, $w2no...$w4 It's not that I don't want to
discuss it with you personally.$K$PI just can't$w4 really talk about it$w4
to anyone. It's $w2a private matter.$K
$F1$PAh, I see.$K$F1$FD$N$UB$H   $F0$FCL_VULCI|$F0$PIke.$K
$F3$PWhat is it, $w2Ulki?$K
$F0$PI hear the sound of rushing water just
ahead.$w4 A lot of it.$K
$F3$PRushing water?$K
$F4$FCL_SENERIO|$F4$PAccording to the map,$w2 there's a large
river up ahead.$K
$F3$PThat must be what you hear.$K
$F0$PThis is unnatural. Warped.$w4 It is not
the sound of a normal river...$K$F0$FD$F4$FD$N$UB$H    $F1$FCL_BEGNION2|$F1$PGeneral Ike!$w4 Sir, we've got trouble!$w4
The road ahead $w2is blocked by water!$K
$F4$FCL_ERINCIA|$F4$PWhat?$w4 How can that be?$K
$F1$PPerhaps a local river has flooded.$K
The whole region $w2is soaking wet.$K
$F3$PIs the road completely impassable?$K
$F1$PNo, sir! $w2We can move forward,$w4 but
the water's turned the ground to mud.$K$PAnd the water is still flowing at a
tremendous rate, sir!$w4 This is going to
cut back our speed dramatically.$K$F1$FD
$F1$FCL_SENERIO|$F1$PThis is the work of Daein.$w4
They thought to impede our progress $w2in
order to gain some time for themselves.$K$PAnd they've succeeded.$K
$F0$FCL_TIAMAT|$F0$PBlast! Is there nothing we can do?$K
$F1$PWell... If they were able to flood the road
only when we approached,$w4 there must
be floodgates in the area.$K
$F3$PSo if we can close them, $w2we'll shut off
the flow of water,$w4 right?$K$PThat makes sense.$w4 Let's get some
scouts looking for gates.$K
$F1$FD$F0$FD$F1$FS$F1$FCL_JANAFF|$F1$PWhat's that? $w2Hey, if you're looking for
something, leave it to me.$w4 I AM the
hawk king's eyes, after all!$K
$F3$PWhat do you mean?$K
$F1$PThese peepers of mine $w2can see for miles
and miles. They're quite handy.$w4
It would be a shame not to use them.$K
$F3$PIs that some laguz power? $w2You're a hawk
with the eyes of a...$w4hawk?$K
$F1$PIt beats your fantastic wit!$w4
My eyesight isn't a racial ability,
it's just my own natural talent.$K$PHeck, my pal Ulki has ears that can
hear grass growing on the other side
of the country.$K
$F3$PI see.$w4 Well then, the job's yours.$w4
Do you think you can find the floodgates?$K
$F1$PI just look for some openings with
a lot of water pouring out, right?$w4
Yeah, I can handle that!$K   $F1$FCL_BEGNION2|$F1$PGeneral Ike!$w4
Sir, we've got trouble, sir!$w4
The road ahead $w2is blocked by water!$K
$F4$FCL_ERINCIA|$F4$PWhat?$w4 How can that be?$K
$F1$PPerhaps a local river has flooded.$K
The whole region $w2is soaking wet.$K
$F3$PIs the road completely impassable?$K
$F1$PNo, sir! $w2We can move forward,$w4 but
the water's turned the ground to mud.$K$PAnd the water is still flowing at a
tremendous rate, sir!$w4 This is going to
cut back our speed dramatically.$K$F1$FD
$F1$FCL_SENERIO|$F1$PThis is the work of Daein.$w4
They thought to impede our progress $w2in
order to gain some time for themselves.$K$PAnd they've succeeded.$K
$F0$FCL_TIAMAT|$F0$PBlast! Is there nothing we can do?$K
$F1$PWell... If they were able to flood the road
only when we approached,$w4 there must
be floodgates in the area.$K
$F3$PSo if we can close them, $w2we'll shut off
the flow of water,$w4 right?$K$PThat makes sense.$w4 Let's get some
scouts looking for gates.$K
$F1$FD$F0$FD$F1$FS$F1$FCL_JANAFF|$F1$PWhat's that? $w2Hey, if you're looking for
something, leave it to me.$w4 I AM the
hawk king's eyes, after all!$K
$F3$PWhat do you mean?$K
$F1$PThese peepers of mine $w2can see for miles
and miles. They're quite handy.$w4
It would be a shame not to use them.$K
$F3$PIs that some laguz power? $w2You're a hawk
with the eyes of a...$w4hawk?$K
$F1$PIt beats your fantastic wit!$w4
My eyesight isn't a racial ability,
it's just my own natural talent.$K$P$F3$PI see.$w4 Well then, the job's yours.$w4
Do you think you can find the floodgates?$K
$F1$PI just look for some openings with
lots of water pouring out, right?$w4
Yeah, I can handle that!$K  $F1$FCL_BEGNION2|$F1$PGeneral Ike!$w4
Sir, we've got trouble, sir!$w4
The road ahead $w2is blocked by water!$K
$F4$FCL_ERINCIA|$F4$PWhat?$w4 How can that be?$K
$F1$PPerhaps a local river has flooded.$K
The whole region $w2is soaking wet.$K
$F3$PIs the road completely impassable?$K
$F1$PNo, sir! $w2We can move forward,$w4 but
the water's turned the ground to mud.$K$PAnd the water is still flowing at a
tremendous rate, sir!$w4 This is going to
cut back our speed dramatically.$K$F1$FD
$F1$FCL_SENERIO|$F1$PThis is the work of Daein.$w4
They thought to impede our progress $w2in
order to gain some time for themselves.$K$PAnd they've succeeded.$K
$F0$FCL_TIAMAT|$F0$PIs there nothing we can do?$K
$F1$PWell... If they were able to flood the road
only when we approached,$w4 there must
be floodgates in the area.$K
$F3$PSo if we can close them, $w2we'll shut off
the flow of water,$w4 right?$K$PThat makes sense.$w4 Let's get some
scouts looking for gates.$K  $R�㉺��b|$c0SIHARAMU|$s0The Crimean army is here!$K$PAll troops! Combat formations!
Hit them fast and hard!$w4
We can't let this battle drag out!$K   $R�㉺��b|$c0IKE2|$s0So those are the floodgates.$K
$c1SENERIO|$s1If we can get them closed,$w2
the water will recede in about
twelve hours or so.$K
$s0All right, $w2let's get going!$K   $R�㉺��b|$c0JILL|$s0...$K
$c1IKE2|$s1Are you all right?$w4
You look rather pale.$K
$s0Um,$w3 General Ike...$w4 To be honest, I...$K
$s1I know.$w4 The enemy general is your
father, isn't he?$K
$s0How did you know?$K
$s1I overheard you talking to that man
with the eye patch.$K
$s0I see.$K
$s1If you're having second thoughts,$w3
it's not too late. Do you want me to
switch you out with someone else?$K
$s0No... I'll be fine.$w4 At least,
I think I will.$K
$s1You don't have to be in the vanguard.
Just keep that in mind.$K$d1
$s0Thank you$w4$Fc...$K  $R�㉺��b|$c0JILL|$s0...$K
$c1IKE2|$s1Are you all right?$w4
You look rather pale.$K
$s0Oh,$w3 General Ike...$K
$s1What is it?$w3 Mist is worried that
you're not feeling well.$K
$s0To be honest...$w3 The man leading the
enemy forces, General Shiharam...$w3
He's my father.$K
$s1What?$w4 Hmm... That's not good.
Do you$w3 really want to face
your father in combat?$K
$s0I joined this army$w3 based on
my own convictions.$K$PI think I can meet my father
with my head held high.$K
$s1Well, if you're sure... $w2Just remember,$w3
if you change your mind, let me know.$K$PThere's no need for you to be in the
vanguard if you don't want to be.$K
$s0Thank you$w4$Fc...$K $R�㉺��b|$c0JILL|$s0...$K
$c1IKE2|$s1Are you all right?$w4
You look rather pale.$K
$s0Um,$w3 General Ike...$K
$s1What is it?$w3 Is there something
you need to talk about?$K
$s0No.$w3 It's nothing.$K
$s1If you say so.$K
$s0Uh-huh.$K
$s1If it's too hard,$w3 you don't have to be
in the vanguard, you know.$K
$s0What?$K
$s1These Daein wyvern riders...$w4
They're your old companions,
aren't they?$K
$s0Y-yes...$w3 Thank you for your concern.$K
$s1You've nothing to prove to us.$K$d1
$s0...$w4$FcFather...$K   $R�w�i��b|$B�R��-��|$<$F5$FCL_SIHARAMU|$F3$FCL_DAYNE2|Ge-$w2General!$w4 How long are the
floodgates to remain open?$K
$F5$PUntil the Crimean army has been defeated.$K
$F3$PSir! If we wait that long,$w2 all of the
neighboring farmland will be drowned!$K$PThe locals are already quite upset.
They may not abide this much further.$K
$F5$P$Fc...$K
$F3$PGeneral!$K$P$F4$FCL_HAAR|Enough, soldier!$K$PIf you've got the time to be bellyaching,$w4
take your butt out to the battlefield$w2
and kill some Crimean soldiers.$K
$F3$PCaptain Haar!$w4 Do you support this action?$w5
This is inhumane! Lives will be ruined!
Daein citizens will die!$K$PEven if we claim that it's necessary in order
to achieve victory...$w3 This is $w2too much!$K
$F4$PThis is Daein's way.$w4 Are you ready to
disobey the king $w2and be put to the
death for your troubles?$K
$F3$PI would rather die than kill innocent
Daein civilians.$K
$F4$PIf you're executed as a traitor to the
throne, your parents and siblings will also
pay.$w4 Are you still prepared?$K
$F3$P...$K
$F4$PNow do you understand what I'm trying to
tell you?$w4 Go. Fight bravely.$K
$F3$P...Y-yes, sir!$K$F3$FD$w6
$Ub$H$F5$P$FdTo gain the trust of the king, $w2we've
become cruel and heartless.$K$PFirst hunting $w2and executing the laguz...$w4
And now$w3 flooding the lands$w2
these people call home?$K
$F4$PGeneral Shiharam...$w4 If someone hears you
use the word laguz in this country,$w2
you'll be branded a traitor.$K
$F5$P$FSHmm...$w3you're right as always.$w4
To live in this land, where laguz
prejudice is so virulent,$K$Pwe've had to seal away everything
we know $w2and teach our children
to hate all sub-humans.$K$P$FAAll that $w2just to survive here.$K
$F4$P$FSIt's Ashnard's fault this country has become
what it is today.$w4 Ah, what a terrible
miscalculation we made...$K$PEven so, I... $w2I hated the idea of
furthering the corruption of the
imperial senate.$K$PI will continue to support $w2your reasons
for leaving Begnion.$K$N$UB$H  $F5$P...$w4
I wonder if Jill has distanced
herself from the Crimean forces.$K
$F4$P$FAI did...$w2give her warning.$K
$F5$PAbove all else,$w4 I would like to avoid
meeting my daughter in combat.$K
$F4$PI pray that she does not take to
the field this day.$K$PKnowing her temperament,$w4 talking
with you $w2would only increase both
of your sorrows.$K
$F5$PI have but one favor to ask of you.$K
$F4$PSay it, and it will be done.$K
$F5$PDo not fight today.$K
$F4$PWhat?$K
$F5$POnly one side can win a battle. $w2If we
are defeated in the end, $w5I want you to
care for the survivors$w3 and their families.$w4$K
$F4$P...Yes, sir...$w4Commander Shiharam.$K
$F5$PCommander...$w3 It's been many a long year$w2
since you last called me that.$K
$F4$PMay the fortunes of war be with you.$K$PThrough all that's...$w2happened...
$FcIt's been an honor to serve with you.$K
$F5$PMmm...$K    $F5$PI have but one favor to ask of you.$K
$F4$PSay it and it will be done.$K
$F5$PDo not fight today.$K
$F4$P$FAWhat?$K
$F5$POnly one side can win a battle. $w2If we
are defeated in the end, $w5I want you to
care for the survivors$w3 and their families.$w4$K
$F4$P...Yes, sir...$w4Commander Shiharam.$K
$F5$PCommander...$w3 It's been many a long year$w2
since you last called me that.$K
$F4$PMay the fortunes of war be with you.$K$PThrough all that's...$w2happened...
$FcIt's been an honor to serve with you.$K
$F5$PMm...$K    $R�㉺��b|$c1JILL|$s1Father!$K
$c0SIHARAMU|$s0Jill...$w2is that you?$K
$s1Why...$w4 Why are you doing this
terrible thing?$K$PYou must close the floodgates now!$w5
The fields will be lost, $w2but there may
be time to save the homes.$K
$s0I cannot...$K
$s1Father?$K
$s0If you wish to stop the water,
you must defeat your father.$w4
That is...the...only way...$K
$s1What is it? $w2There has to be a reason!$w4
I know that an act like this cannot be
what you desire.$K
$s0...$w4Jill, you must leave.$w4 Please!$w5
If you can't do that,$w4 then slay me!$K$PThere's no more time!$K
$s1...$w4
Very well!$w4 In that case,$w2
I will fight with you.$K
$s0What did you say?$K
$s1Not as a soldier of Daein,$w2
but as one of your soldiers.$w5
I will fight.$K
$s0Jill,$w3 calm yourself.$w4 You mustn't
get caught up in the emotions of the
moment $w2and lose your way.$K
$s1Joining the Crimean army opened
my eyes.$K
For the first time, $w2I was able to
think about what I fight for.$K$PUntil that moment, $w2I only did
as I was ordered...$w4
It was all for fame and glory.$K$PNow I finally understand.$w4 I fight
for those I wish to protect.$w5
Father, I want to fight for you.$K
$s0Even if you come to regret it?$K
$s1Yes.$w4 I'm prepared for that.$K$PI...Jill Fizzart,$w3 hereby return myself
to the command of General Shiharam.
What are your orders, sir?$K $R�㉺��b|$c0SIHARAMU|$s0Jill...$w2is that you?$K
$c1JILL|$s1Why...$w4 Why are you doing this
terrible thing?$K$PYou must close the floodgates now!$w5
The fields will be lost, $w2but there may
be time to save the homes.$K
$s0I cannot...$K
$s1Father?$K
$s0If you wish to stop the water,
you must defeat your father.$w4
That is...the...only way...$K
$s1What is it? $w2There has to be a reason!$w4
I know that an act like this cannot be
what you desire.$K
$s0...$w4Jill, you must leave.$w4 Please!$w5
If you can't do that,$w4 then slay me!$K$PThere's no more time!$K
$s1...$w4
Very well!$w4 In that case,$w2
I will fight with you.$K
$s0What did you say?$K
$s1Not as a soldier of Daein,$w2 but as one
of your soldiers.$w5 I will fight.$K
$s0Jill,$w3 calm yourself.$w4 You mustn't
get caught up in the emotions of the
moment $w2and lose your way.$K
$s1Joining the Crimean army opened
my eyes.$K
For the first time, $w2I was able to
think about what I fight for.$K$PUntil that moment, $w2I only did
as I was ordered...$w4
It was all for fame and glory.$K$PNow I finally understand.$w4 I fight
for those I wish to protect.$w5
Father, I want to fight for you.$K
$s0Even if you come to regret it?$K
$s1Yes.$w4 I'm prepared for that.$K$PI...Jill Fizzart,$w3 hereby return myself
to the command of General Shiharam.
What are your orders, sir?$K  $R�㉺��b|$c1JILL|$s1Father!$K
$c0SIHARAMU|$s0Jill...$w2is that you?$K
$s1Why...$w4 Why are you doing this
terrible thing?$K$PYou must close the floodgates now!$w5
The fields will be lost, $w2but there may
be time to save the homes.$K
$s0I cannot...$K
$s1Father?$K
$s0If you want to stop the water,
you must defeat your father.$w4
That is...the...only way...$K
$s1What is it? $w2There has to be a reason!$w4
I know that an act like this cannot be
what you desire.$K
$s0...$w4Jill, you must leave.$w4 Please!$w5
If you can't do that,$w4 then slay me!$K$PThere's no more time!$K
$s1$Fc...$w4
Joining the Crimean army opened
my eyes.$K
For the first time, $w2I was able to
think about what I fight for.$K$PUntil then, $w2I only did
as I was ordered$w4
It was all for fame and glory...$K$Fo$PNow I finally understand.$w4 I fight
for those I wish to protect.$w5
I'm...truly sorry.$K
$s0$FSI see. $w2You've found someone you
can trust in the Crimean army...$w4
Then I've nothing to worry about.$K
$s1Yes.$w4 Even though we're now
opponents, I...$w2am proud to be your
daughter. $w2Now and forever more.$K
$s0$FAThen go,$w4 Jill Fizzart!$w5
Be true to yourself and live!$K  $R�㉺��b|$c0SIHARAMU|$s0Jill...$w2is that you?$K
$c1JILL|$s1Father!$w4 Why...$w4 Why are you doing this
terrible thing?$K$PYou must close the floodgates now!$w5
The fields will be lost, $w2but there may
be time to save the homes.$K
$s0I cannot...$K
$s1Father?$K
$s0If you want to stop the water,
you must defeat your father.$w4
That is...the...only way...$K
$s1What is it? $w2There has to be a reason!$w4
I know that an act like this cannot be
what you desire.$K
$s0...$w4Jill, you must leave.$w4 Please!$w5
If you can't do that.$w4 then slay me!$K$PThere's no more time!$K
$s1$Fc...$w4
Joining the Crimean army opened
my eyes.$K
For the first time, $w2I was able to
think about what I fight for.$K$PUntil then, $w2I only did
as I was ordered.$w4
It was all for fame and glory...$K$Fo$PNow I finally understand.$w4 I fight
for those I wish to protect.$w5
I'm...truly sorry.$K
$s0$FSI see. $w2You've found someone you
can trust in the Crimean army...$w4
Then I've nothing to worry about.$K
$s1Yes.$w4 Even though we're now
opponents, I...$w2am proud to be your
daughter. $w2Now and forever more.$K
$s0$FAThen go,$w4 Jill Fizzart!$w5
Be true to yourself and live!$K   $R�w�i��b|$B����-��|$<$F4$FCLME|$F1$FCL_GRANDMA|Hold on, youngster! $w2Who do you think$w3
you are?$w3 You can't just come barging
into people's homes!$K$PLet me tell you something!$w4
You can ransack my home all you want,$w3
but you'll find nothing of value here.$K$PAll our young men $w2have been
dragged off to war, and$w3 all that's left
are women and children.$K$PIf it's gold you're after,$w3 take that
scroll on the floor there. You may
be able to sell it.$K$PIt's just something I picked up,$w2
so I don't know if it has any value.
But take it anyway, you dirty thief!$K $R�w�i��b|$B��-��|$<$F1$FCL_GRANDPA|$F4$FCLME|$F1$PYou! $w2You filthy Crimean!$K$PGet out!$w4 Get out now!$w4
There's nothing in this shack$w2
that would make you happy!$K$P$F4$P...$K
$F1$POh, so you won't leave$w2 till you
get something, is that it?$w4
Here, $w2take this old staff!$K$PNow hit the road!$w4 You've no need
to steal anything else from us!
Or will you take my life, as well?!$K$PIn that last skirmish... $w2My boy, $w2my
only son... You stole his life, curse
you!$w4 I hope you're satisfied!$w2$K    $R�㉺��b|$c0DAYNE2|$s0Lady Jill, is that you?$w4 What are
you doing $w2with the Crimeans?$K$d0
$c0JILL|$s0I'm sorry...$w4 I've chosen the path
that's right for me.$K$d0
$c0DAYNE2|$s0Pah!$w4 You would betray your
own father?$K$d0
$c0JILL|$s0...$K $R�㉺��b|$c0DAYNE2|$s0You...traitor!$K$d0
$c0JILL|$s0...$K    $R�㉺��b|$c0DAYNE2|$s0My lady Jill... No...$w4
Why does this have to be...$K  $R�㉺��b|$c0SIHARAMU|$s0$FoJill! $w5Why?!$w4 Why?$w3
And by my own hand...$K
$c1JILL|$s1$FoOh...$w4 Fa-$w2$FhFather...$Fc$w3
I l-lo...$K
$s0Jill??$K
JILL!!!$K    $R�㉺��b|$c0SIHARAMU|$s0Neither of us desires a
drawn-out battle.$w4 Come!
Hold nothing back!$K   $R�㉺��b|$c0IKE2|$s0You're the enemy general, right?$K
$c1SIHARAMU|$s1I am.$K
$s0I $w2lead the Crimean army.
My name is Ike. $w5I know this is
sudden, $w2but can we end this battle?$K
$s1What?$K
$s0I'd like you to shut the floodgates.$w5
There's no need to involve the locals$w2
in our combat, is there?$K
$s1...$w2 I'm sorry, but I can't do that.$w3
Until one of us $w2has fallen,
the water will continue to flow.$K
$s0If that's how it has to be,$w5
then I have no choice.$w2
Prepare yourself.$K$d0
$s1$FSHa! $w2So that's the enemy general, eh?$w3
If he's the man he appears to be,$w5
I can die $w2knowing that Jill is safe.$K   $R�㉺��b|$c0SIHARAMU|$s0You of the beast tribe...$K
I was always envious of how$w2
you were blessed with such
a glorious lord and master...$K $R�㉺��b|$c0SIHARAMU|$s0High-flying Phoenicians!$w3
Who is it $w2that truly controls the sky?$w5
Let us settle the issue here and now.$K  $R�㉺��b|$c0SIHARAMU|$s0A Serenes...royal?$w4 Can it be
that one survived?$K$PWell, $w2now that you've appeared before
me, I cannot let you escape...$w5
...Ah, goddess. Forgive me......$K   $R�㉺��b|$c0JILL|$s0Father...$K
$c1SIHARAMU|$s1We meet as enemies.$w2 There are no
pleasantries to exchange.$w4
Ready your weapon,$w3 soldier of Crimea!$K
$s0Father...$w2 I...$K
$s1You won't charge? $w5Then I will
bring the fight to you!$K   $R�㉺��b|$c1SIHARAMU|$s1A sacred pegasus knight, eh?$w4
At one time, $w2we both protected
the same country.$K
$c0TANIS|$s0So $w2you're the one who led the
defection to Daein, Lord Fizzart!$K$PThe man I heard tales about$w4
and the reality of what I see before
me are quite different.$K
$s1Tales?$K
$s0It is said that after the last apostle
died,$w2 the corrupted senate drove
one man to leave Begnion.$K$PHe was said to be in search of a
better life, and$w3 he became a hero
to many young wyvern riders.$K
$s1$FSHah, $w2that's rich...$w4 Tales always
make too much of their subjects.$K
$s0I had been looking forward to meeting
you in the flesh--$w4perhaps even
to speaking with you.$w2 But now...$K$PYou would sacrifice the lives of your
people just to slow our progress?$w3
What kind of dangerous fool are you?$K
$s1$FA...$K
$s0I will not allow you to besmirch the
name of Begnion's wyvern riders any
further.$w4 Prepare yourself!$K $R�㉺��b|$c0SIHARAMU|$s0...Haar...$w4 The rest...$w3is up...$w2to
you...$w2...$K
...Ji...$Fc$w3ll...$K    $R�㉺��b|$c1SENERIO|$s1Ike!$w4 It's no use!$w3
The water's$w2 too high!$K
$c0IKE2a|$s0I...$w3wasn't fast enough...$w5 No!$K
$d1$c1TIAMAT|$s1Ike...$w4 We must retreat!$w3
I'm sorry, but...$w4we lose.$K
$s0How can this be?$w4$Fc
Father...$w2forgive me.$K  $R�w�i��b|$B�R��-��|$<$F3$FCL_IKE2|$F0$FCL_BEGNION1|$F0$PGeneral Ike, sir!$w4 The floodgates
have been closed!$K$F0$FD$w4
$F3$PSoren,$w3 what's the damage to
the surrounding area?$K
$F1$FCL_SENERIO|$F1$PIt's terrible.$w4 All of the fields and homes$w2
have been completely destroyed.$K
$F3$PI see...$K
$F0$FCL_TIAMAT|$F0$P...$w2I don't think this is what the enemy
general wanted, either.$w5 So why
did this have to happen?$K
$F4$FCL_ERINCIA|$F4$PIt's heartless... $w2What will happen to
those$w4 who've lost their homes?$w5
Can we do anything to help them?$K
$F1$PYou want to aid the people of our enemy?$w4
That is time and energy we cannot afford.$K
$F3$PSoren.$w4 Take a portion of our supplies$w2
and distribute it among the locals.$K
$F1$PWhat?$w4 Are you serious?$K
$F3$POur opponent is the Daein army.$w5
We've no quarrel with these people.$K
$F1$PIke, I know you feel for these people,
but this is war! We don't have--$K
$F3$PI don't know what it will accomplish, Soren.$w5
But, $w2moving on without lifting a finger$w4
is something I cannot do.$K$F3$FD
$F0$PI understand.$w4 I'd rather regret something
I had done $w2than regret taking no action
at all.$K$F0$FD
$F4$PI would like to help, too.$w4
Perhaps I can aid the injured.$K$F4$FD$w6
$F1$P...$FcIdiocy...$K
$=1000 $R�w�i��b|$B�R��-��|$<$F2$Fh$F2$FCL_JILL|$F2$POh, Father...$w3$Fc$K
$F4$FCL_IKE2|$F4$PJill...$w4 No matter the reasons,$w3
I'm the one who took your father from you.$w4
I can't$w3 use this war as an excuse.$K
$F2$P$MC...$MD$K
$F4$PIf you want revenge on me for your father,
I understand.$w4 You have...$w3that right.$K
$F2$P$MC...$MD$K
$F4$POnce you've had some time to think
things through,$w4 let me know
what you will do.$K$PI'd like to have you stay with us,
but...$w4 It's really up to you.
That's all I had to say.$K
$F2$P$MC...$MDSniff.$K
...Sn...$w4sniff......$K
$=0800  $R�w�i��b|$B��-��|$<$F1$FCL_HAAR|$F4$FCL_DAYNE2|$F1$POne, $w1two, $w1three...$w4 Five in all.$w5
We're lucky to have that many.$K
$F4$PCaptain Haar...$w4 What are we
supposed to do now?$K$PGeneral Shiharam is dead, and$w3 our homes
are gone.$w4 What are we to do with our
families?$K
$F1$PWhat do you want to do?$w4 We've lost
any right $w2we had to stay here.$w5
So that leaves Begnion$w3 or Crimea...$K
$F4$PGeneral Shiharam was slain by Crimea...$w4
Joining with them now is not...$w4
It's not possible.$K
$F1$PThen all you can do is return to Begnion.$K$PI doubt you'll get a hero's welcome, but...$w4
I've an old friend in the pegasus knights.$w5
Shall I contact her?$K
$F4$PSniff...$w4 Ah, gods. Eighteen long years...$w3
What does any of it mean now?$K
$F1$PDon't say that!$w4 No matter what,$w4
I'm proud to have served under
General Shiharam.$K
$F4$PYou're right...$w4 It was an honor...$K
$=1000  $R�w�i��b|$B���{-�f�C��|$<$F1$FCL_PRAGUE|$F3$FCL_ENA|$F1$PWell, that's that.$w4 We gained some
time by flooding the river, $w2but it won't
hold them for long.$K$PI knew that foreign cur was useless...$w4
It looks like the decisive battle will
be fought near the capital.$K
$F3$PPreparations are complete, General Petrine.$w4
In order to ease command for you,$w2
Sir Bryan will serve as your deputy.$K$PRegarding strategy, $w2it would be easiest
if you spoke with him directly--$K
$F1$PSorry to tell you this, $w2Ena,$w4 but I'm not
the one who'll be directing our forces
in the capital.$K
$F3$PWill it be the Black Knight then?$w4 Hmm...
the plans must be adjusted slightly.$w4 I'll
select someone else to act as deputy...$K
$F1$P$FSNo. Not him either.$w4 His Majesty wishes
you to direct the defenses, $w2Ena.$K
$F3$PMe?$w4 I am to take command...of the army?$K
$F1$PThat's right.$w4 You're moving up in
the world, $w2General Ena.$K
$F3$PI...$w4it's too much for me...$w5
I must confirm this with the king...$K
$F1$PHa! $w2What a rare sight this is.$w4
I've never seen you so flustered!$K$PListen, $w2if you wish to meet with His
Majesty, you must fulfill your duties.$K$PHe's ordered that there be no
communications until that time.$K
$F3$P...$K
$F4$FCL_DARKKNIGHT|$F4$PI'm a bit $w2late.$K
$F1$PWell, if it isn't the big Black Knight!$w4
It's been such a long time.$K$PYou're always so very busy, aren't you?$w4
Here one day, there the next...$w4
Your secret maneuvers are--$K
$F4$PThey are proof $w2of the trust His Majesty
has placed in me.$K$PEna, $w2go to the east gate.$w4
You have a visitor.$K
$F3$PVery well...$K$F3$FD
$F1$P$FAIs it the Worm?$w4 Did he bring it with him?$K
$F4$PIt appears so.$w4 He insists that he give it
directly over to Ena, though.$K
$F1$PHmph! $w2As long as it is ours,
it makes no difference.$K
$F4$PWhen Ena returns,$w4 you will be the one
to take it directly to the king.$K$PShow care that it is not unwrapped
on the way there. That could be...
unfortunate.$K
$F1$PI don't need to be told that!$K$PMore importantly,$w2 what will you do now?$K
$F4$PMe?$w4 I will...$K
$=1000  $=0700$R�w�i��b|$B���-������01|$<$F7$FCDUMMY|$F2$FCL_ENA|$F7$PEna...$w4 Have you been well?$K
$F2$PWhere is Lehran's Medallion?$K
$F7$PRight here.$w4 Take it, please.$K
$F2$PIt feels so heavy...$w2and it's not all
the wrapping, either.$K$PCould this be $w2the chaotic energy...$w4
of an evil god?$K
$F7$PSo, $w2you can now return to King
Ashnard's side, can you not?$K
$F2$PNo.$w4 Not yet.$K
$F7$PWhat do you mean?$K
$F2$PI've been entrusted with the defense of
the capital.$w4 I...$w2must face the
Crimean army.$K
$F7$PNo!$K
$F2$P$FSThank you.$w4 You've done so much
for me...$K$P$FABut now, $w2it's...$w3 It's enough.$w4 Please...$w3
Reclaim your freedom.$K$PThere's no need $w2for you to follow Daein's
orders any longer.$K
$F7$PAnd you?$w3 Do you mean to die?$K
$F2$PNo...$w3 I cannot retreat.$K$PEven if I have to slaughter the entire
Crimean army...$w4 I will return to him...$K
$F7$PYet $w2he thinks nothing of you...$K
$F2$PThat matters not.$w4 The only place I belong
is at his side.$K$PI will $w2most likely never see you again...$w4
I will pray for your eternal happiness.$K$F2$FD$P$F7$PEna!$w4 Wait!$K$w6
$F4$FCL_ENA|$F4$PForget about me.$w4 That is my final request.$w4
Farewell...$w6Nasir.$K$F4$FD$w6
$F0$FCL_NASIR|$F0$P...Ena...$K
$=2000  $SD$R�w�i��b|$B�V��-��-2|$<$F1$FCL_IKE2|$F3$FCL_CALILL|$F3$PYoo-hoo! $w2You there!$w4 Young man!$w5
I have business $w2with the general of this
army.$w4 Would you convey a message?$K
$F1$PWho are you?$K
$F3$P$FS...Who am I?$w4 What kind of low-born
greeting is that?$w4 My name is Calill,
and$w4 I am a first-class mage.$K
$F1$PAnd what would a "first-class" mage$w2
want with this army?$K
$F3$P$FAWhat's your problem?$w4 You look as if you
don't believe me! $w5Well, $FSI suppose I
can't hold that against you...$K$PIt's not often you find beauty like this$w2
coupled with intelligence like mine.$w5
But it's true nonetheless.$K
$F1$PA mage, huh?$w3 Well, I guess you can
never have too many mages lying around.$K
$F3$POh, and as a bonus,$w3 I'm quite skilled
with a knife, as well. Beauty, brains,
and brawn... Sigh!$K
The goddess has seen fit to put the
abilities of three people into one
delectable package.$K$PSounds like favoritism, doesn't it?$w4
$FA...Um...$w4hellooooo? Are you listening to me?
There's a beautiful woman talking!$K
$F1$PYeah,$w4 the point is that you want to join
the Crimean army, right? $w5How much are
you planning to charge?$K
$F3$P$FSWell, aren't you the little businessman?$w4
Let's see...$w3 How does free sound?$K
$F1$PSuspicious.$w3 What's the catch?$K
$F3$PI like my fees to be based on performance.$w2
Watch how I do in combat,$w2
and make me an offer.$K$PDepending on what it is,$w3 I'll decide whether
or not to grace you with my assistance.$K
$F1$PYou're not lacking for confidence, are you?$K
$F3$POf course not!$w4 I already told you,$w4
I'm a first-class mage.$K
$F1$P...$K$N$UB$H    Hire.   Don't hire. $SE$F1$PAll right,$w4 you're in.$K
$F3$P$FAWhat? $w5Are you allowed to make
decisions like that on your own?
Perhaps I should speak to the general!$K
$F1$PI am the general.$K
$F3$PWhaaaaaat?!$K   $SE$F1$PSorry, not interested.$w4
We've got enough mages as it is.$K
$F3$P$FAPardon? $w5Are you allowed to make
decisions like that all by yourself?$w4
Perhaps I should speak to the general!$K
$F1$PI am the general.$K
$F3$PWhaaaaaat?!$K    $R�w�i��b|$B�V��-��-1|$<$F1$FCL_IKE2|$F1$PReyson! Could you come down here
for a moment?$K
$F3$FCL_RIEUSION|$F3$PWhat do you need?$K
$F1$PI've got something $w2I want to ask
you about.$K
$F3$P$FSIf I can help,$w3 I will.$K
$F1$PYour... $w5Your ancestors...$w4
$w2...$K$P...
...$w4
Forget it.$w4 It's nothing.$K
$F3$P$FAWhat?$w4 Is something wrong?$K
$F1$PI apologize.$w3 Please let it go.$K
$F3$PIt seems like something important has
happened,$w4 but if you do not want
to discuss it, that is your right.$K$PHowever, if this weren't a battlefield,$w3
your secret might not be safe.$w4
Please take care in the future.$K
$F1$PWhat do you mean?$K
$F3$PWe of the heron clan...$w3
If we choose to, $w2we can read the
thoughts of others.$K
$F1$PSeriously?$K
$F3$PHowever, $w2this power is only available to us
in a calm and peaceful environment.$K$PHere,$w3 in this desperate maelstrom
of chaotic emotion,$w4 it avails me not.
Energy here is $w2warped and distorted.$K
$F1$PYou know, now that you mention it...$w4
Reyson,$w3 are you feeling sick?$K
$F3$P...$K
$F1$PYou're so pale that it's hard to tell,$w3
but I think your face $w2looks more
wan than usual.$K
$F3$PPay it no mind.$w4 I'm...$w3fine.$K
$F1$PYou've got nothing to prove.$w4
Why don't you stay off the
battlefield for a while?$K
$F3$PIke!$w4 I'm fine, $w2I promise.$w5 Please,
do not give me special treatment.$K
$F1$PAs far as giving you special treatment goes,$w2
I don't really have a choice.$K$PI promised King Phoenicis $w2I wouldn't
push you too hard.$K$PIf anything were to happen to you,$w4
I'd be at war with Daein and the$w3
bird clans at the same time!$K
$F3$P...$w4I see.$K$PI came to repay my debt,$w3 but I'm
really just being a burden.$w2
That was not my intention.$K
$F1$PHold on a moment!$w4 Who said anything
about you being a burden?$K
$F3$PI cannot engage in combat,$w3
so I'm nothing more than an
obstacle in the field.$K
$F1$PReyson, no! That's absurd!$w5
Don't you understand how useful
your abilities are?$K$PNo one else $w2can do the things that
you can.$w4 You're irreplaceable.$K$PSo$w3 if you're not feeling well and try to
do too much,$w4 you may not be there
when we really need you.$K
$F3$PI'm of use to you, then?$K
$F1$PThat's what I've been trying to tell you.$w4
We depend on you,$w3 and that's why I
need to make sure you stay healthy.$K
$F3$P$FSIn that case...$w3 I wouldn't mind taking
a short break.$K$PBut $w2you can call me anytime.$w4
I'll come right away.$K
$F1$P$FSI got it.$K$P$F3$FD$w6$F1$P$FA...$K $R�w�i��b|$B�V��-��-2|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 just a bit more...$w5
Would you mind hearing my report$w2
on our last battle?$K
$F3$PUh, $w2sure.$w4 Go ahead, please.$K
$F1$PVery well.$K$N$UB$H $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 With your leave,$w2
I will excuse myself.$K      X      X|   	  \�     Z�   "  [�   .  \   :  ]�   F  U�   R  V�   ^  W$   j  al   v  Wt   �  b�   �  m�   �  u�   �  g�   �  j   �  0�   �  8�   �  ;�   �  a�   �       �  z�    �@    �  +  �4  ;  �,  K  ��  [    i  	�  u  �  �  \  �  �  �  �  �  $�  �  (�  �  )T  �  *  �  ,8  �  .�    ��    ��    �,  .  ��  =  >  N  CL  Z  H�  f  M  r  Q�  ~  S�  �MS_21_BT MS_21_BT_IKE MS_21_BT_JI MS_21_BT_R1 MS_21_BT_R2 MS_21_BT_RI MS_21_BT_TA MS_21_BT_V1 MS_21_BT_V2 MS_21_BT_V3 MS_21_DIE MS_21_DIE_JILL MS_21_ED_01 MS_21_ED_02 MS_21_ED_03 MS_21_ED_X1 MS_21_ED_XX MS_21_EV_X MS_21_EV_X_A MS_21_EV_X_B MS_21_GAMEOVER MS_21_GMAP_01 MS_21_INFO_02 MS_21_INFO_02_A MS_21_INFO_02_B MS_21_INFO_02_N MS_21_INFO_02_Y MS_21_INFO_05 MS_21_OP_01 MS_21_OP_02 MS_21_OP_03_01 MS_21_OP_03_02 MS_21_OP_03_03_A MS_21_OP_03_03_B MS_21_OP_03_03_C MS_21_OP_05 MS_21_OP_06 MS_21_OP_XA MS_21_OP_XB MS_21_OP_XC MS_21_REPO_BEGIN MS_21_REPO_DIE MS_21_REPO_END MS_21_REPO_NODIE MS_21_TK_01 MS_21_TK_02 MS_21_TK_03 MS_21_TK_04 MS_21_VIL_01 MS_21_VIL_02 