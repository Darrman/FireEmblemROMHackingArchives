  ��  ��       K                $RGMAP��b|$O3$GPrincess Elincia's $w2newly-formed Crimean
army,$w3 with Ike as its commander,$w4 marches
to Tor Garen and claims its first victory.$K$PTor Garen is a vast wall guarding Daein's
border.$w3 Manned by battalions of well-trained
soldiers, it was long thought impenetrable.$K$PYet the strength of the Crimean army$w2
under General Ike's leadership$w3 far outstrips
Daein's expectations,$w3 and Tor Garen falls.$K$PLearning of Gallia's increasing interest in
the war,$w2 Ike wastes no time$w3 ordering
his troops further into the heart of Daein.$K$PThe gears of history, $w2which had come
to a halt with the fall of Crimea,$w3
slowly creak to life once more...$K$P $R�w�i��b|$B�R��-��|$<$F4$FCL_PRAGUE|$F4$PNaesala!$w4 King Naesala of Kilvas!
I would speak with you now!$K
$F1$FS$F1$FCL_NAESALA|$F1$POh, if it isn't General Petrine.$w4
What brings you $w2up to these
frosty mountain peaks?$K
$F4$PI've no time for pleasantries. Is it true?$w2
Has Crimea's army breached Tor Garen?$K
$F1$PThough I am loathe to report it,$w2
this appears to be the case.$K
$F4$PBah!$w4 Kayachey, you worthless dog!$w2
Being defeated by that girl's motley band
just$w2 proves how useless he was.$K
$F1$PSurely it's not the general's fault alone.$w4
He was told that Crimea's army was weak
and that Tor Garen was impregnable.$K$PAnd yet...$w2he was defeated.$w4 I'd say that
someone severely underestimated our
enemy.$w4 Wouldn't you?$K
$F4$PWhat was that?$w4 Do you dare to insult
Daein, crow?$w4 Men have forfeited their
lives for less.$K
$F1$PInsult Daein?$w3 Never! Come now, General
Petrine. I'm merely stating the facts.$K$PRegardless of the previous battle's outcome,$w2
Crimea's army will be stopped here.$w4
I will be taking the field myself.$K
$F4$P...Hmph. $w2Sounds like you've set the
stage for a grand performance.$K
$F1$PGeneral Petrine,$w4 Kilvas will always stand$w2
at Daein's side...$w4 As long as we receive
our payment, of course.$K
$F4$PIf gold is all it takes, $w2then may our
friendship never end.$w4 See to it that your
performance warrants such consideration!$K$PHomasa! $w2Come here!$K
$F0$FCL_HOMASA|$F0$PYes.$K
$F4$PWork with King Kilvas and put a stop to
Crimea's army.$w4 No screw ups!$w4
Or else!$K
$F0$PLeave it to me, General.$K$F0$FD
$F4$PI will not suffer another failure, King Kilvas.$w2
You must finish them, and do so quickly...$w4
Are we clear?$K$PArrr!$w2 I am sick to death of being made a
fool $w2by that Crimean floozy and$w2 her
pathetic band of sellswords!$K
$F1$PAnd the remaining $w2portion of my fee?$K
$F4$PDon't worry, $w2we have it ready.$w4
You'll get paid when the job is done.$K
$F1$PAs long as we're clear on that point,$w2
everything's settled.$w4 Well then,$w3
I'm off.$K$F1$FD $R�w�i��b|$B�R��-��|$<$F3$FCL_PRAGUE|$F3$PDog's breath!$w4 Even by half-breed standards,
those crows are complete scum!$K$PGive that one even the smallest opening,$w2
and he'll steal the eyes from your skull.$w4
What an untrustworthy wretch.$K
$=1000 $R�w�i��b|$B�R��-��|$<$F3$FCL_IKE2|$F4$FCL_JANAFF|$F4$PSo, General...$w4there look to be a lot of
enemy soldiers ahead.$w4 Mostly Daein, but
there are some $w2crows from Kilvas as well.$K
$F3$PMore than $w2our last fight?$K
$F4$PYeah, there's a lot, but the$w3 most troubling
thing is that $w2King Kilvas is with them.$K
$F3$PThe crow king himself $w2is cooperating
with Daein?$K
$F4$PYep.$w4 And compared to the other crows,
the king is in a class by himself.$K$PObviously, he's no match for our king, but...$w5
Anyway, $w2you should move carefully.$K$F4$FD$N$UB$H  $R�w�i��b|$B�R��-��|$<$F3$FCL_IKE2|$F4$FCL_VULCI|$F4$P...General Ike.$w4 I hear the sound of
many wings ahead.$K$PIt would seem $w2Kilvas soldiers have
joined the troops of Daein for this fight.$K
$F3$PIs Kilvas's contingent larger than the what
we faced in the last battle?$K
$F4$PThere are many...$w3 But what causes me
more concern $w2is the voice of King Kilvas.$K
$F3$PThe king himself $w2is cooperating with Daein?$K
$F4$PYes.$w4 And compared to the other crows,
the king is in a class by himself.
We must be cautious.$K$F4$FD$N$UB$H    $R�w�i��b|$B�R��-��|$<$F3$FCL_IKE2|$F0$FCL_BEGNION2|$F0$PEnemy forces ahead!$w4 It's the
Daien army!$K
$F3$PAn ambush on this mountain road...$w2
They're trying to stop us from crossing.$w4
How many are there?$K
$F0$PIt's not a huge battalion,$w3 and they're
mainly foot soldiers. $w2Whether they're a
match for us or not, I can't say.$K$P...Hold, General!$w4 Kilvas crows have
just been spotted as well!$K$F0$FD$N$UB$H    $F3$PAn entire unit under the command of King
Kilvas?$w4 I think that bodes ill for us.$K
$F4$FCL_SENERIO|$F4$PThe outcome of the battle $w2hinges
on how we deal with them.$K
$F3$P...$K$F4$FD$N$UB$H  $F4$FCL_TIAMAT|$F4$PKilvas soldiers, hm? $w5As fellow
bird tribe laguz, $w2what can you
tell us about them?$K$F4$FD$N$UB$H  $F0$FCL_JANAFF|$F0$PPlease don't lump us together
with those carrion birds.$K$F0$FD$N$UB$H  $F0$FCL_VULCI|$F0$PWe're not partial...$w2to the crows.$K$F0$FD$N$UB$H  $F0$Fc$F0$FCL_RIEUSION|$F0$P...$K$F0$FD$N$UB$H  $F3$PAs you know, $w2we are outmanned
by the Daein troops.$K$PIs there any way to get the
ravens to withdraw? That would
be a tremendous help.$K$N$UB$H $F0$FCL_JANAFF|$F0$P...Well,$w3 suppose I could go meet with
King Kilvas...$w5 If I had to.$K$PI don't think that my speaking to him$w2
is going to make a difference, though.$K$F0$FD$N$UB$H   $F0$FCL_VULCI|$F0$PIf you like, we will try, but...$w4
Don't expect anything to come of it.$K$F0$FD$N$UB$H  $F0$FCL_RIEUSION|$F0$PNo matter the circumstance,$w2
I will never again speak $w2to a crow.$K$F0$FD
$N$UB$H $F4$FCL_SENERIO|$F4$PNo matter what we decide,$w2
sitting here like this $w2is giving
the enemy more time to prepare.$K
$F3$PYou're right.$w4 Come on,$w2 let's get moving!$K   $R�㉺��b|$c0DAYNE2|$s0Sir! The Crimean army has arrived!$K
$c1HOMASA|$s1I hope they are prepared to pass
into oblivion.$w4 For this will be
their final resting place!$K  $R�㉺��b|$c1NAESALA|$s1Crimean stragglers joined with an army
on loan from Begnion.$K$FS$PI've even heard they have a
betrayer in their midst. And yet
they still march on...$K$PWhat an odd group. But $w2as long as
Kilvas stands at the side of Daein,$w4
they have no future.$K
Ah, $w2I suppose they're just unlucky.$K  $R�㉺��b|$c0NASIR|$s0It appears the enemy has spotted us.$K
$c1IKE2|$s1Well, a group this large
is hard to miss.$K
$s0How will you proceed?$K
$s1No tricks. Nothing fancy.$w4
We'll hit them from the
front--fast and hard.$K
$s0I'm sure you're already aware of this,
but$w4 if you don't do something about
Kilvas, $w2you're at a disadvantage.$K
$s1Yes, I've heard about the ravens...
But even so, it's not as if we can
turn tail and run away.$K$N$UB$H  $s0Now that I think on it,$w4 King Kilvas
and Prince Reyson used to be
close friends.$K$PDid you ask him to speak
to the king?$K
$s1He was most emphatic in his refusal.$K$PIt seems that Naesala was responsible$w2
for Reyson's capture at the hands of
Duke Tanas.$K
I can't really blame him.$K$N$UB$H  $s0And the hawks?$K
They, too, are of the bird tribes.$w4
Surely $w2some connection
can be found there.$K
$s1They...$w3weren't very excited about
the suggestion.$K
$s0You could command them to do it.$K
$s1There's an antagonism between the
tribes that we don't understand.$w2
I'd rather not force the issue.$K$PTrying to $w2coerce them into it
would be...unfair.$w4 I will let
them do as they please.$K
$s0$FSThat is $w2so very like you.$K$PHowever, giving orders that are
unpopular is often necessary when
one is in command, and--$K
$s1Maybe so.$w4 But I can only do
things the best I know how.
My own way.$K$N$UB$H $s1Come, $w2it's time to go!$K  $R�㉺��b|$c0HOMASA|$s0Your fighting style is...$w3unique.$K
It is rough and awkward, yet $w2terribly
strong.$w4 Who was your teacher?$K
$c1IKE|$s1My father.$K
$s0Really? $w2Then we are the same.$w4
My father taught me to wield a sword
as well.$K
Neither of us can afford to lose.$K $R�㉺��b|$c0HOMASA|$s0I've fought many of your kind before,$w3
and I know all of your techniques.$w4
Will you challenge me $w2even so?$K  $R�㉺��b|$c0HOMASA|$s0We face hawks, too?$K
Oh, what a test this will be!$K   $R�㉺��b|$c0HOMASA|$s0Cutting one who carries no blade
lacks style...and yet it cannot
be avoided on the battlefield.$K   $R�㉺��b|$c0HOMASA|$s0You are a swordsman as well.$K
And, it appears, quite skilled!$w4
May I $w2ask for a duel?$K
$c1ZIHARK|$s1I dislike contests with strangers,
but$w3 I don't think I can refuse.
Can I?$K
$s0Ki-yah!$K   $R�㉺��b|$c0HOMASA|$s0It seems you're quite a fencer.$w4
Shall I teach you something?$K
$c1SOANVALCKE|$s1Sheathe your blade.$w4 If that's
all the skill you possess, $w2you're
not ready to challenge me.$K
$s0What?$w4 Have at you!$K    $R�㉺��b|$c0HOMASA|$s0My sword is lightning!$w4 Do you
think you can follow its dance?$K  $R�㉺��b|$c0HOMASA|$s0$Fc...$w4The shame...$K $R�㉺��b|$c0NAESALA|$s0You...$K
$c1JANAFF|$s1King Kilvas!$w4
You egg-stealing snake.$K
$s0$FSOne of Tibarn's flock, eh?$w4
You are $w2his "eyes,"
if I'm not mistaken.$K
$s1It's not enough that you sold the
White Prince to humans?$w3
Now you're fighting against laguz?$K
$s0You hawks rescued Reyson didn't you?$w4
So $w2everything worked out in the end!$w4
What's the problem?$K
$s1I'd like you to repeat those words$w2
to the prince's face.$K
$s0$FAReyson is here?$K
HERE?!$K
Why?!$K
$s1He supports the Crimean army!$w4
The beorc leading this army helped$w2
him to escape Serenes Forest.$K
$s0Helped him?$w4 Are you saying a human
came to the aid of Reyson?$w3 A laguz?$K
$s1Yes! And he$w4 rescued
Princess Leanne, too!$K
$s0Leanne...$w4is alive?$K
$s1Don't play the fool! You know the life
of the forest$w2 has returned.$w4
That $w2was their power at work.$K
$s0I see. $w2That's how the forest...$w4
Of course.$K
$s1Listen up, crow!$w4 You need to fly
over there and talk to the prince.$K$PIf you don't do it, $w2I'm gonna know
that you really are the enemy and$w2
report that back to King Tibarn.$K$PThink it over!$K$d1
$s0Yes...$w2 Mmm...
What to do.$K   $R�㉺��b|$c0NAESALA|$s0You...$K
$c1VULCI|$s1King Kilvas.$w4 Why have you decided
to make the laguz your enemy?$K
$s0One of Tibarn's flock, eh?$w4
You are $w2his "ears,"
if I'm not mistaken.$K
$s1Why did you sell Prince Reyson
to a beorc?$K
$s0$FSYou hawks rescued Reyson didn't you?$w4
So $w2everything worked out in the end!$w4
What's the problem?$K
$s1Would you repeat your words
to Prince Reyson himself?$K
$s0$FAReyson is here?$K
HERE?!$K
Why?!$K
$s1The beorc leading this army helped$w2
him to escape Serenes Forest.$K
$s0Helped him?$w4 Are you saying a human
came to the aid of Reyson? A laguz?$K
$s1That is what I say. He$w4 also
rescued Princess Leanne.$K
$s0Leanne...$w4is alive?$K
$s1She was asleep for all these years.
The forest protected her.$w4$K$PTheir voices $w2brought the
forest back to life.$K
$s0Of course, $w2so that's how...$K
$s1Why don't you try speaking to
Prince Reyson?$K$PIf you do that, $w2perhaps King Tibarn's
rage will burn less brightly.$K
$s0Tibarn's rage, eh?$w2 Hmm...$w4
Mmm...$K  $R�㉺��b|$s0$FS$c0NAESALA|$s0Reyson!$K
$s1$Fc$c1RIEUSION|$s1...$K
$s0Hey, $w2Reyson! Look at you!
You look sharp, kid!$K
$s1$FdGo...away...$K
$s0Oh, $w2so you can talk.$K
$s1You... $w2How dare you show
your face to me!$K
$s0Well, $w2I have been called brazen
before. $w2Some have gone so far
as to say shameless.$K$PCome on, $w2at least let me
give you a reason.$K
$s1$FcBegone!$w4 My ears are closed to you.$K
$s0Reyson, $w2we're friends, are we not?$K
$s1$FdOh, yes! Friends! In fact, we're such
good friends $w2that you sold me
to that foul, bloated man!$K
$s0I didn't really sell you!$w4 Besides, I
planned on rescuing you right away.$K$PYou were just impatient $w2and flew
away on your own, so--$K
$s1$FhAre you blaming me?$K
$s0$FANo, no!$w3 Well, maybe...$w4 I mean...$w4
It was I who was in the wrong.$w4
On all accounts.$K
$s1$Fc...$K
$s0No one was hurt in the end.$w2
Come on,$w4 smooth those
ruffled feathers.$w4 All right?$K$d0
$s1$FdLeanne is alive.$K
$s0$FS$c0NAESALA|$s0Yes, $w2Tibarn's attendant told me.
That's wonderful news.$K$PWhen he sees her face,$w4 I'm sure
King Lorazieh will begin to feel better
at once.$K$PThings are really looking up,$w2
aren't they, Reyson?$K
$s1...I suppose that... If you hadn't
deceived me and taken
me to the forest...$K$PWe might not have discovered her...$w4
So, $w2I will forgive you.
Just this once!$K
$s0Reyson! Oh, that's--$K
$s1WITH...$w4conditions.$w4
Will you accept them?$K
$s0$FA...What$w2 are they?$K
$s1Pull your troops from this battle.$w2
Now.$w4 And never again $w2enter
into combat against your fellow laguz.$K
$s0Oh, come now, Reyson.$w4
That's asking too much--$K
$s1What will you do, then?$w4 Will you
continue $w2to fight the Crimean
army to which I'm in service?$K
$s0$Fd$FSVery well.$w4 You win, $w2Reyson. I'll
leave and take my soldiers with me.$K$P$FdHowever, $w2I cannot say what
the future will bring.$K$PI have the fate of my nation$w2
to consider after all.$K
$s1Hmm... $w2Very well.$K
$s0So, $w2we're friends again?$K$PCome to Kilvas $w2for a visit,
will you?$w4 Nealuchi will be so pleased.$K
$s1$FSI'll do that.$w4 When this war is over,$w2
Leanne and I will both come.$K
$s0Oh, $w2and as for Tibarn...$K
$s1I'll speak with him.$w4 There's no
need for you to worry.$K
$s0Thank you.$w4 Farewell.$w2
And watch yourself!$w2
This is war, you know?$K $R�㉺��b|$c0JANAFF|$s0King of crows!$w4 Do you seriously
think to betray your fellow laguz?$K
$s1$FS$c1NAESALA|$s1...Oh, please...$w4 You hawks are
always so excitable.$K$PYou know the true nature of my
fellow ravens, so...$K $R�㉺��b|$s0$FS$c0NAESALA|$s0What's this?$w4 Well, if it isn't one
of my beloved hawk cousins.$K$PAs you can see, Kilvas has sided
with Daein.$w4 Try not to think
too poorly of us.$K
$c1VULCI|$s1...$K  $R�㉺��b|$s0$FS$c0NAESALA|$s0From where I'm sitting, $w2you look
to be the leader of your group.$w4
Do you like the way we fight?$K$PIf you double Daein's payment,$w2
we will be quite happy to join
your cause against Daein.$K
$c1IKE|$s1Are you serious?$K
$s0Of course!$w4 We're not with Daein
for the pleasant conversations.$w3 For
the right price, we'll do as you like.$K
$s1I've no need of an ally $w2who would
betray me for a handful of coin.$K
$s0Is that so?$w4 Then I've no more use
for you. $w5I suppose I'll just
have to kill you.$K   $R�㉺��b|$c0LETHE|$s0Betrayer of laguz! I'll tear those
black wings off your back!$K
$s1$FS$c1NAESALA|$s1You Gallians are with Crimea,$w2
we with Daein.$w3 We're both
helping one side.$K$PI'd like you to tell me$w3 how that
makes us the betrayers.$K
$s0Crimea and Daein are not the same!$K
$s1Oh, but they are.$w4 They're both home
to laguz-hunting, laguz-hating humans.$K$PGranted, Daein's anti-laguz sentiment
is more obvious, but...$K$PSurely you realize there's no great
difference between it and Crimea...$w3
Or Begnion, for that matter.$K
$s0B-$w2but...$K
$s1You may think yourself a warrior,$w2
but the humans have tamed you.$w5
Allow me to open your eyes!$K
$s0Ah!$K    $R�㉺��b|$c0MORDY|$s0King of the raven folk...$w4
Why $w2do you fight for Daein?$K
$s1$FS$c1NAESALA|$s1Kilvas $w2has need of much gold if
we are to become more than a
paltry island kingdom.$K$PDaein is willing to fill our coffers,
and so we work with them. There
is nothing more to it.$K$PRemember, it's not who you work with
that's important--it's how much they're
willing to pay.$K
$s0So you fight for gold, is that it?$K
$s1Nothing wrong with that, is there?$w5
Everyone fights for some kind of gain.
Even you, am I right?$K
$s0That is...$w4not untrue.$w4
But--$K
$s1No matter how hard you try,$w4 your
kind will never understand the hearts
and minds of ravens.$K$PYou appear to be an obstinate
creature... Just like your king.$K
$s0Grrr... Grrrraaawwwl!$K   $R�㉺��b|$s0$FS$c0NAESALA|$s0Oh ho! Black wings! Among humans
these are considered bad omens, are
they not?$K$PThen take these omens as fact, and
let them herald you to the afterlife!$K $R�㉺��b|$c0NAESALA|$s0N-no... This cannot be...$w4
Is this...my...fate? What of Kilvas--$K   $R�㉺��b|$c0NAESALA|$s0Guaa...$w4 I was careless...$w2
and you're better than expected.$K$PTo me, my brethren!$w4 We leave
at once!$K $R�㉺��b|$s1$FS$c1NAESALA|$s1Listen to me, $w2darkwings!$w4
We of Kilvas are leaving.$w4
Turn at once $w2and head for home.$K $R�㉺��b|$c0HOMASA|$s0Kilvas has betrayed us?$K
$c1DAYNE2|$s1I think $w2"abandoned" would
be more accurate, but--$K
$s0Idiot! It's the same thing! Aaaargh!$w4
Accursed sub-humans!$w4 We should
never have trusted them.$K   $R�㉺��b|$c0CROW|$s0King Naesala, $w2the Daein army
has been routed!$K
$c1NAESALA|$s1How nice. $w2What a lot of braggarts
they turned out to be.$w4 Very well,$w2
let us withdraw as well.$K
$s0Are you sure?$w4 If we retreat now,
what will General Petrine say?$K
$s1$FSPromises made to humans $w2are
worth less than a dead snake.$w2
Forget about her.$K
$FALosing the remainder of our payment
stings, but still...$w4 $FSYou can't buy
your life back, can you?$K
$s0Good point. Well made, sir.$K
$s1$FAFly, $w2my darkwings!$w4
We return to Kilvas!$K  $R�w�i��b|$B�R��-��|$<$F3$FCL_IKE2|$F3$PWe won...$w2somehow.$K
$F0$FS$F0$FCL_NASIR|$F0$PIt's because you did an excellent
job of driving off the ravens.$K
$F3$PYeah, $w2if we had continued to fight them,
we would have suffered more casualties
than this.$K$PI must extend thanks to Reyson.$K
$F0$FD$F1$FS$F1$FCL_ERINCIA|$F1$PMy lord Ike!$w4 I'm pleased to see you well.$w4$FA
You haven't been injured, have you?$K
$F3$PPrincess Elincia.$w4 I'm fine.$w4
I'm unharmed.$K
$F1$P$FSOh, that's good...$K
$F0$FS$F0$FCL_TIAMAT|$F0$PIke!$w4 May I have a word?$K$PAnd if you don't mind, Princess Elincia,$w2
would you join us as well?$w4
Please join me in that building.$K$F0$FD
$F1$P$FAWhat could it be?$K
$F3$PLet's go see.$K   $R�w�i��b|$B�R��-��|$<$F3$FCL_IKE2|$F3$PWe won...$w2somehow.$K
$F1$FS$F1$FCL_ERINCIA|$F1$PMy lord Ike!$w4 I'm so pleased to
see you well.$w4 $FAYou haven't
been injured, have you?$K
$F3$PPrincess Elincia.$w4 I'm fine.$w4
I'm unharmed.$K
$F1$P$FSOh, that's good...$K
$F0$FS$F0$FCL_TIAMAT|$F0$PIke!$w4 May I have a word?$K$PAnd if you don't mind, Princess Elincia,$w2
would you join us as well?$w4
Please join me in that building.$K$F0$FD
$F1$P$FAWhat could it be?$K
$F3$PLet's go and see.$K
$=0900   $R�w�i��b|$B�q��-��|$<$F1$FS$F1$FCL_TIAMAT|$F3$FCL_IKE2|$F4$FCL_ERINCIA|$F4$PThis is...$K
$F3$PHoly...$K
$F1$PIncredible, no?$w4
It's gold. $w2All of it.$K
$F3$PDaein must be filthy rich!$w4 There's so
much, $w2it doesn't even seem
real.$w4 What do we do with it?$K
$F0$FCL_SENERIO|$F0$PIt's the spoils of war.$w4
So naturally, $w2it's ours.$K
$F3$PIn that case, $w2I'd like to borrow fifty
thousand.$w2 Would that be all right?$K
$F1$P$FAThat's a lot of money. $w2What are you
planning on doing?$K
$F3$PIt's a private matter...$K
$F1$P$FSI apologize, Commander. $w2You're not
a child. There's no reason for me to pry.$K
$F0$P...$K
$F4$PMy lord Ike, $w2please use this gold
for the mercenary company.$K$PUntil now,$w4 I haven't had the resources
to adequately pay them. $w5So please...$K
$F3$PNo, $w2if I may borrow the fifty thousand,
that will be more than--$K
$F1$PYou won't borrow it, you'll accept it!
And in good faith.$K$PThe remainder$w4 we'll give to Soren for
company maintenance.$w4 Would that be
all right, Princess Elincia?$K
$F4$P$FSYes, of course.$K
$=1000    $R�w�i��b|$B�R��-��|$<$F1$FCL_PRAGUE|$F1$PGrrr...$K
$F4$FCL_DAYNE2|$F4$PUm,$w4 General P-Petrine? P-please, General!
I'm just a...m-messenger!
H-however...I have to tell you--$K
$F1$PI already heard, you dunderhead!$w4
I hated those filthy crows$w2
right from the start.$K$PEven so, $w2to be betrayed in such
a fashion$w4...$w4 Grrr...
Someone will pay for this!$K$POh, you certainly had your way with
us, didn't you, $w2King Kilvas?$K$PBut if you want to make an enemy
of Daein, then so be it!$K$POnce Gallia's fallen, $w2we'll turn our
attention to your puny nation and
wipe it off the face of the world!$K
$F4$P...$K
$F1$PWhy $w2are you still there?$w4
Do you find me $w2amusing?!
Shall I make my lance dance for you?$K
$F4$PN-$w2no, ma'am!$w4 No! Never!
N-not at all!$w4 I $w2beg your pardon!$w4
So sorry...$w4 I'll be...going...now...$K$F4$FD
$F1$PDog's breath!$K$PI need...something. $w2A brilliant plan...$w5
If this continues much longer,$w4
the king will have my head.$K
$=1000 $R�w�i��b|$B�V���l�p-��|$<$F0$FCL_VOKE|$F3$FCL_IKE2|$F0$PYou wanted to see me?$K
$F3$PYou've waited a long time.$w4 Take this.$w2
It's the gold you were promised.$K
$F0$P$FSFinally scraped it together, eh?$w4
I'll gladly accept it.$K
$F3$PAren't you going to count it?$K
$F0$PThere's no need.$w4 I'll trust you.$K
$F3$PAll right, $w2then I'll take what was promised.$w4
The report you wrote for my father.$K
$F0$P$FAThere isn't one.$K
$F3$PWhat?$K
$F0$P$FcThere is no report. $w2Never was.$K
$F3$PYou lied to me?$w4 You exploited my
need to know more about my father!?$K$P$F0$P$FdThere is something I must tell you.$w4
However, $w2it could not be written down.$w5
It is too great of a secret for that.$K$PYour father told me to wait $w2until I thought
you were mature enough to hear it,
and then to tell you myself.$K
$F3$PMature?$w4 Then what was the
fifty thousand gold for?!$K
$F0$P$FSAh, the gold. That was$w4 my idea.$w4 I thought
it would be a good way to test how
resourceful and responsible you were.$K
$Ub$H$F3$PGet started. $w2I want to hear it all.$K
$F0$P$FAI've $w2spent a long time as Greil's
hired shadow.$w4 A long time.$K$PI remained hidden from sight $w2in case
the day ever arrived that I needed to fulfill
my contract...$w4 All that time, for one job.$K
$F3$PWhat was it?$K
$F0$PIf Greil were ever to go berserk,$w2 I was
to stop him.$w6 I was to take his life.$K
$Ub$H$F3$PWhat?!$K
$F0$P$FcActually, there was one other thing.$w4
If Greil were ever slain by his pursuers...$K$PI was to watch over his son $w2and tell
him Greil's secret at an appropriate time.
That $w2was my job.$K
$F3$PBerserk...$w4 What $w2are you talking about?$K$PWhy would you have to kill my father?$K
$F0$P$FdBecause of$w4 Lehran's Medallion.$K
$F3$PWhat medallion? What are you
talking about?$K
$F0$PThe medallion your sister carries.$K
$F3$PHuh?$w4 That old bronze thing?$K$PI thought it was just a keepsake of
my mother's...$K
Are you telling me that$w2
it's something more?$K
$F0$PGreil told me it was an object of great
peril,$w2 but nothing more.$w4 I did some
investigating on my own, though.$K$PAnd what I discovered...$w2surprised me.$K
$F3$PTell me.$K $R�̂݉�b|$F1$FCL_VOKE|Lehran $w2was one of the heron clan,$w4
an ancestor of our Prince Reyson, who
carried with him a bronze medallion.$K$PLong, long ago,$w4 a band of heroes
defeated an evil god and imprisoned
it therein.$K$F1$FD$P$F1$FCL_IKE|An evil god?$w4 Do you think this is funny?$w4
You ARE joking, aren't you?$K$F1$FD$P$F1$FCL_VOKE|Unfortunately, $w2I'm not.$w4 And I've
no idea how the cursed thing came to be
in Greil's possession.$K$PThat being said, $w2I do know that the men
who hunted your father were actually
seeking the medallion.$K$PWhy they wanted it and what they planned
to do with it...$w4 Just thinking
about it gives me chills.$K$F1$FD$P$F1$FCL_IKE|I'm finding all of this $w2a little hard
to believe.$w4 You said the medallion was
"an object of great peril," didn't you?$K$PThen why $w2would my father allow
Mist to carry it around?$w4 That doesn't
make any sense.$K$F1$FD$P$F1$FCL_VOKE|It's because she can carry it safely.$w4
Actually, $w2she's the only one who can.$K$PIf you want proof, think back. $w2Have you
ever once touched it?$K$F1$FD$P$F1$FCL_IKE|...$w5No. $w2I haven't.$K$PA long time ago,$w4 I remember reaching
out for it while Mist had it in her hand...$w4
My father scolded me harshly.$K$PAfter that, $w2I assumed...$w3it was my
sister's alone, and I never reached
for it again.$K$F1$FD$P$F1$FCL_VOKE|Compared to other people, the balance
within your sister is extremely strong.$K$PYour mother, it seems, was the same.$w4
That's why they could bear it safely.$K$PThe medallion is$w4 like a strong poison.$w4
It takes the worst aspects of a person and
magnifies them a thousandfold.$K$PGreil touched it only once,$w4 and it drove
him to complete madness.$K$F1$FD$P$F1$FCL_IKE|So that's what you meant $w2when you said
he went$w4 berserk?$K$F1$FD$P$F1$FCL_VOKE|That's right.$w4$K$PBeorc and laguz are made up of two
forces: balance and chaos.$w4
In this, there is no difference between us.$K$PIt is the proportion of $w2balance to chaos$w4
that determines$w4 how much the medallion
affects a person.$K$PIn that sense, it predicts how much
harm that person might do.$K$F1$FD$P  $R�̂݉�b|$F1$FCL_VOKE|Your father was one of the preeminent
swordsmen of his generation. That day,
after he touched the medallion...$K$PTwenty soldiers had come for him.$w4
Twenty highly trained killers.$w4 Your father
barely broke a sweat cutting them down.$K$PThen $w2he began attacking his neighbors,
those who had taken him in, concealed his
identity, and called him friend.$K$PHe slew them one by one,$w4 until your mother
rushed in...$w2thinking only to save her husband
from himself.$K$P    $R�̂݉�b|$F1$FCL_VOKE|It was over in an instant.$K$PYour mother grabbed the medallion from
his hand and stepped away from him...$K$PThey say she smiled as he pulled his sword
from her breast$w3 and forgave him as her
life's blood spilled into the street.$K$F1$FD$P$F1$FCL_IKE|My father...$w4killed$w4 my mother?$w4
No. That $w2can't be...$K$F1$FD$P$F1$FCL_VOKE|It was the medallion. $w2Its power is
too great for any man. Even one
of your father's caliber.$K$PMe? $w2You? $w2If either of us touched it,$w2
I'm certain that we both would have been
consumed by madness.$K$P$Ub$HWhen your father regained his senses,$w2
he tracked me down.$w3 It seems he'd heard
rumors of me some time before.$K$PHe said he had need of someone like me:$w2
closemouthed, $w2skilled, $w2and most
importantly, willing to do any sort of work.$K$POf course, $w2after hearing what he
wanted me to do, I turned him down.$K$PGreil $w2was once a famed general...$w4
He was Sir Gawain, one of Daein's Four
Riders, $w2and I recognized him at once.$K$PThere was no chance someone like me
would ever be able to stop him.$K$F1$FD$P$F1$FCL_IKE|But $w2you took the job anyway...$w4
Why did you change your mind?$K$F1$FD$P$F1$FCL_VOKE|Greil had lost his wife, and his grief was
overpowering. $w2To keep anything like that
from happening again, $w5he crippled himself.$K$PHe slashed the tendons in his sword hand$w2
so that he could not wield a sword again.$K$PI took the job only because he had become
someone my skill could handle.$K
And even then, $w2he was still far
stronger than most men...$K$P$F1$FD$P$F1$FCL_IKE|I... I don't know what to say...$K$F1$FD$P $R�w�i��b|$B�V���l�p-��|$<$F0$FCL_VOKE|$F3$FCL_IKE2|$F0$PThat is $w2Greil's secret, as I know it.$K$PI now entrust to you $w5the responsibility
of seeing that the medallion does not
fall into the wrong hands.$K$PYour sister must keep it.$K
$F3$P...As my father lay dying,$w4 he told me to
forget everything and live in peace.$w5
What did he mean?$K
$F0$PHe didn't want you to lose yourself$w2
and go hunting for revenge, I suppose.$K$PHe was killed$w3 much, much sooner than
he ever expected to be.$K
$F3$PSo my father's dying wish $w2was for me
to protect the medallion? $w5If I can do
that, everything will be all right?$K
$F0$PI believe so.$w4 At the very least, that must
take precedent over everything else.$K
$F3$PI understand.$K  $R�w�i��b|$B�V���l�p-��|$<$F0$FCL_VOKE|$F3$FCL_IKE2|$F0$PWell then, my work here is done.$K
$F3$P...$K
$F0$PWhatever you decide to do now$w4
is up to you.$K$P$F3$PIf I call, can I count on your
assistance again?$K
$F0$PIf I'm not busy with anything else,
I might agree to work for you again.$w4
Farewell.$K$F0$FD
$F3$PFather...$K
$=0800 $R�w�i��b|$B�V���l�p-��|$<$F0$FCL_VOKE|$F3$FCL_IKE2|$F0$PWell then, my work here is done.$K
$F3$P...$K
$F0$PWhatever you decide to do now$w4
is up to you.$K$P$F3$PIf I call, can I count on your
assistance again?$K
$F0$PI guess we'll have to see.$w4
I won't do anything that goes
against my better judgment.$K$F0$FD
$F3$PFather...$K
$=0800   $R�w�i��b|$B�V���l�p-��|$<$F0$FCL_VOKE|$F3$FCL_IKE2|$F0$POh, one last thing.$K
$F3$PWhat is it?$K
$F0$PDo you want $w2to hire me? In the
event that you go berserk someday?$K$PIf we make a deal now, you won't have
to worry about it anymore.$K$PAs for payment...$w4 I can take it out of
the fifty thousand you just gave me.$w4
What do you say?$K
$SD$N$UB$H       $SD$R�w�i��b|$B�V���l�p-��|$<$F3$FCL_IKE2|$F0$FCL_VOKE|$N$UB$H   Hire.   Don't hire. $SE$F3$PPlease.$K
$F0$P$FSThat's a wise decision.$w4...$w2And in
that case, I no longer need to conceal
my true identity.$K
$F3$PHuh?$K $R�w�i��b|$B�V���l�p-��|$<$F0$FCL_VOKE2|$F3$FCL_IKE2|$F0$PI'm not really a thief.$w3 I'm an assassin.$w4
From now on, $w2I'll take on any job
you've got, no matter how...dirty.$K
$=0000    $SE$F3$PNo...$w4 I don't think that's right for me.$K
$F0$PI see.$K
$F3$PWhat will you do now?$K
$F0$PI'll continue on as before.$w4
If you need anything, call me.$w4
That's all.$K
$F3$PUnderstood.$K$F0$FD
$=0800    $=0700$R�w�i��b|$B�V���l�p-��|$<$F3$FCL_IKE2|$F3$PFather...$w4 Mother...$w6
$Fc...Oh, why...$K
$=2000    $R�㉺��b|$s0$FS$c0NAESALA|$s0Reyson!$K
$s1$Fc$c1RIEUSION|$s1...$K
$s0Hey, $w2Reyson! Look at you!
You look sharp, kid!$K
$s1$FdGo...away...$K
$s0Oh, $w2so you can talk.$K
$s1You... $w2How dare you show
your face to me!$K
$s0Well, $w2I have been called brazen
before. $w2Some have gone so far
as to say shameless.$K$PCome on, $w2at least let me
give you a reason.$K
$s1$FcBegone!$w4 My ears are closed to you.$K
$s0Reyson, $w2we're friends, are we not?$K
$s1$FdOh, yes! Friends! In fact, we're such
good friends $w2that you sold me
to that wretched sack of lard!$K
$s0I didn't really sell you!$w4 Besides, I
planned on rescuing you right away.$K$PYou were just impatient $w2and flew
away on your own, so--$K
$s1$FhAre you blaming me?$K
$s0$FANo, no!$w3 Well, maybe...$w4 I mean...$w4
It was I who was in the wrong.$w4
On all accounts.$K
$s1$Fc...$K
$s0No one was hurt in the end.$w2
Come on,$w4 smooth those
ruffled feathers.$w4 All right?$K$d0
$s1$FdLeanne is alive.$K
$s0$FS$c0NAESALA|$s0Yes, $w2Tibarn's attendant told me.
That's wonderful news.$K$PWhen he sees her face,$w4
I'm sure King Lorazieh will begin to
feel better at once.$K$PThings are really looking up,$w2
aren't they, Reyson?$K
$s1...I suppose that... If you hadn't
deceived me and taken
me to the forest...$K$PWe might not have discovered her...$w4
So, $w2I will forgive you.
Just this once!$K
$s0Reyson! Oh, that's--$K
$s1WITH...$w4conditions.$w4
Will you accept them?$K
$s0$FAWhat, $w2what are they?$K
$s1Pull your troops from this battle.$w2
Now.$w4 And never again $w2enter
into combat against your fellow laguz.$K
$s0Oh, come now, Reyson.$w4
That's asking too much--$K
$s1What will you do, then?$w4 Will you
continue $w2to fight the Crimean
army to which I'm in service?$K
$s0$Fd$FSVery well.$w4 You win, $w2Reyson.
I'll leave and take my
soldiers with me.$K$P$FdYet, $w2I cannot say what
the future will bring.$K$PI have the fate of my nation$w2
to consider after all.$K
$s1Hmm... $w2Very well.$K
$s0So, $w2we're friends again?$K$PCome to Kilvas $w2for a visit,
will you?$w4 Nealuchi will be so pleased.$K
$s1$FSI'll do that.$w4 When this war is over,$w2
Leanne and I will both come.$K
$s0Oh, $w2and as for Tibarn...$K
$s1I'll speak with him.$w4 There's no
need for you to worry.$K
$s0Thank you.$w4 Farewell.$w2
And watch yourself!$w2
This is war, you know?$K$d0$w4
$s0$FS$c0NAESALA|$s0Oh, I almost forgot.$w4
I've got something for you.
Call it an "I'm sorry" present.$K
$s1$FAEh? What's this supposed to be?$K
$s0It's a human trinket.$w3 It's called a
knight ring.$K
$s1Something made by beorc?$K
$s0Don't make such a disgusted face.$w4
I tried it,$w3 and it proved to be
quite useful.$K
$s1$FSUnderstood.$w4 I'll take it for now.$K
$s0$FADon't get killed, Reyson.$w4 If anything
were to happen to you... $w5$FSNealuchi
would never let me hear the end of it.$K$d0
$s1Naesala$w4...$w2 Thank you.$K   $R�㉺��b|$s0$FS$c0NAESALA|$s0You're not of the Gallia beast tribes,
are you?$K$PLaguz slaves!$w4 Bah! Instead of baring
your claws and escaping,$w3 you moan
and cry!$w2 What a pack of fools.$K
$c1MWARIM|$s1...$K
$s0Hah!$w4 Cat got your tongue?$K$PUnless you're incapable of speech,$w3
you're either angry or frightened.$K$PEither way, you're pathetic.$w4 If you'd
stayed in your cage, $w2you wouldn't
need to die here, hmm?$K $R�w�i��b|$B����-��|$<$F1$FS$F1$FCL_JILL|$F4$FS$F4$FCL_MIST|$F4$PBye.$w3 See ya later!$K
$F1$PYep. $w5Oh, $w2Mist!$w4 Watch your step!$w4
It's slippery...$K
$F4$P$FAWhooooa!$K
$F4$FD$F1$P$FAMist!$K
$F4$FCL_MIST|$F4$P$FSOw! I landed right on my butt!$w3
Hee hee!$w3 This snow's cold!$K
$F1$P$FSBe careful!$K
$F4$PAll righty! Hey, watch, Jill!$w3 I'm gonna make
a snow angel!$w4 Wheeee!$K
$F4$FD$F1$P...$w2It must be nice to be so cheerful.$K
$F8$FCDUMMY|$F8$PJill!$K$P$F8$FD$F1$P$FA...$w3Who's there?$K
$F4$FCL_HAAR|$F4$PIt's me.$K
$F1$PCaptain Haar?$w4 B-but...$w3
This is an enemy camp!$K
$F4$PI've been trying to track you down ever
since you disappeared at Toha.$K$PI figured you were off chasing after$w2
the Crimeans.$w3 I never imagined
that you would$w3 join up with them.$K
$F1$PAt first, it was just circumstance, but...$w5
But now$w3 it's different.$w4 Now I'm with
them because I want to be.$K$PSpending time with them--$w2and coming into
contact with laguz--$w3has shown me what
a fool I've been.$K
$F4$PLaguz?$K$FS$PI never thought I would hear that word$w3
from someone who once said "sub-human"$w3
with such absolute hatred.$K
Sounds like you've had some good
experiences with this happy little band.$K
$F1$P$FSI knew that if anyone would understand,$w2
it would be you, Captain.$K
$F4$PSo you're forming your own set of values
for the first time.$w4 That's good.$w4
That's very, very good.$K$FA$PBut what are you planning to do now?$w4
If you keep moving forward,$w3 you're
going to face General Shiharam before long.$K
$F1$P$FACausing trouble for my father$w3 was
never my intent.$w4 However...$K
As a member of this army,$w3 I will face
him with my shoulders straight $w2and
my head held high.$K
$F4$PSo you're determined to see this through?$K
$F1$PI am!$K
$F4$PSo be it. $w2Then there's nothing left
to be said.$K$PFarewell.$w3 The next time we meet, it will
be as enemies. Prepare yourself...$w5 And get
some rest! You know how important it is.$K$F4$FD
$F1$P...$K
$=0700    $R�w�i��b|$B����-��|$<$F3$FCL_MISTs|$F4$FCL_IKE2|$F3$PIke? Can I talk to you?$w4
A few minutes ago, $w2a man I've never
seen before showed up and spoke to Jill.$K$PI wasn't sure what was going on,$w2
so I went and found you.$K$PW-what should we do?$w4
Whatever they're talking about,$w3
it sure looks serious!$K
$F4$PJill trained in the Daein army.$w3 Fighting
against her countrymen will be tough...$w4
No matter how prepared she thinks she is.$K
$F3$PI don't care what happens!$w4 You can't
let her fight against her own father!$K$PAll right, $w2Ike?$K
$F4$PHmmm.$w3 It might not be a bad idea$w2
to keep her at the base camp...
Just while we're in Daein.$K    $R�w�i��b|$B�R��-��|$<$F0$FS$F0$FCL_LOFA|$F1$FS$F1$FCL_BOLE|$F3$FCL_OSCAR|$F1$PWhat do you think, $w2guys?$w4
Are we going to be able to$w3 perform
a new special attack?$K
$F3$PI think we might.$w4 I was looking through
some old scrolls on fighting techniques,$w3
and I found one that looks perfect.$K
$F1$PAwesome!$w4 Nice work!$K
$F0$PWhat is it?! What is it!? Come on,
tell us how it works!$K
$F3$PWell, if we want to learn it,$w3 there are
some things we'll have to do.$K
$F1$PAw, dang! I hope it's not all technical,$w2
'cause I won't be able to keep up.$w4
Just summarize it, will you?$K
$F3$PI can do that.$w4 All right,$w3 the most
important thing is we all have to use
the same weapon.$K$PSo, if all three of us can use a bow,
that'll be one problem out of the way.$K
$F1$P$FAA bow? $w5You and I $w2have to use bows?$K
$F3$PBoyd, are you even listening to me?$w3
Yes, we all have to use the same weapon.$w4
That's part of the deal.$K
$F1$PCrud!$w4 Nothing we can do about it,
I guess.$w4 You better not slow us down,$w2
Rolf! $w2You little brat.$K
$F0$P$FAStop calling me a brat! $w5I'm a better archer
than you!$w4 If anyone slows us down,
it'll be you, Boyd!$K
$F1$PWhat did you say? I'm gonna--$K
$F3$PKnock it off, Boyd!$w4 Your skills with a bow
aren't as polished as Rolf's.
Anyone can see that.$K$PWhich means$w3 that even if Rolf has some
natural skill, $w2whoever taught him the
fundamentals $w2was an expert archer...$K
$F1$PYeah, I know,$w3 but he just keeps blabbering
this nonsense$w3 about how he taught himself.$K
$F0$PI... $w2I did teach myself!$w4 I'm a prodigy.$K
$F3$P$FSWell,$w3 judging by your stance and the way
you hold the bow, I think we all know the
real story.$K
$F0$PEeep!$K
$F1$PHuh?$w4 What is it?$w2 What real story?!$K
$F0$POscar! $w5No!$w3 Shhh!$K
$F3$P...$w2The story...$w4 That Rolf's$w5 lucky to have
a genius like me for a brother,$w3 that's what.$K
$F1$PAw, stop messing around.$w4
This is getting stupid.$K
$F0$P$Fc$FSWhew...$K
$F8$FCDUMMY|$F8$PWhat're you guys talking about?$K
$F8$FD$F0$Fd$F4$FCL_IKE|$F4$PThe three of you have been huddled
up here for a while now.$w4
What are you scheming?$K
$F1$PShh! $w5Um... Uh... Hi, Ike!$K
$F3$PScheming is such an ugly word!$w4
We're just--$K
$F0$POh, hey, Ike!$w4 We're working on
this special man--$w4$K
$F1$PYaaaaaaaaa!$K
$F7$FCL_BOLE|$F7$PGaaa...I forgot something...$w5$P$F3$FD$F8$FCL_BOLE|$F7$POooo...gotta go...$w5$P$F0$FD$w4$F1$P$FSSorry about that, $w2Ike.$w4
He's been$w3 acting a bit odd
these days.$K$w6
$F4$PReally?$w3 Seems to me $w2that you're
the odd one in the bunch.$K
$F1$PUm, $w2sure, $w2all right!$w4
Do us a favor, though,$w3 and make sure
the three of us are all in the next battle.$K
$F4$PSure, I guess that's fine.$w4
But why?$K
$F1$PWell, $w2it's a surprise.$w3 That's all.$w4
We'll show you later!$w4 I'm sure you'll like it!$K$PCome on! $w5We can't be standing around all
day.$w4 Let's go! Oscar! Rolf!$K$F1$FD
$F4$PSpecial man? Hmm...$w3 Man...$w4
...Mandolin?
...Manicotti?$K$P...Manifesto?$w4
Oh, who cares?$K    $R�w�i��b|$B�V���l�p-��|$<$F3$FCL_JANAFF|$F1$FCL_IKE2|$F3$PBrrr...$w3 I'll take on any number of enemies,
but$w4 this snow is another story!$K
I think my beautiful wings are icing over.$K
$F1$PThat sounds like trouble.$w4 Are you going
to be able to fly?$K
$F3$P...$w4Yes, $w2of course I can fly. $w5These wings
aren't for looks, you know?$w4 They're
made of flesh and blood and feathers.$K$PIt's not like I'm some animal$w3 that has to
hibernate $w2when winter rolls in.$K$PSheesh!$w3 Can't you beorc tell the
difference between comic exaggeration$w4
and serious conversation?$K
$F1$PUm... Oh, I was supposed to laugh, was I?$w4
Sorry about that.$K
$F3$P$FSOh, my...$w3such sincerity.$w4 This is
unexpected.$w3 It looks like someone
taught you manners.$w2$K
$F1$PEr...$K
$F3$PBy the way, I've been meaning to ask...$w4
What are our chances for victory?$K
$F1$PWe're still at an extreme$w2 disadvantage.$K
$F3$P$FAWhat? That's not the answer I wanted!$w4
You gotta do better than that,$w3
beorc general!$K$PI'm here! $w2If we lose,$w3 how am I ever going
to show my face $w2in Phoenicis again?$K
$F1$PWe're at a disadvantage,$w3
but I don't intend to lose.$K$PThere's a man in Daein that I
need to find...$w4and I will be the
last thing that he sees.$K
$F3$PHa ha!$w4 $FSWell said!$w5
I wish you could $w2repeat that to
today's younger generation.$K$P$FAThere are some weaklings $w2back
home that I don't even want to
call hawks.$K$PI'd love to stick 'em back in their eggs
and start over from scratch.$K
$F1$PHey, you hatch from eggs?! Eh?$K
$F3$P$FSI was speaking figuratively. $w2You know?$w2
Like...a metaphor?$w4 We haven't hatched
from eggs$w3 for many generations now.$K$PSilly beorc...$w4 All right,$w3 I'm outta here.$w4
I gotta warm up the ol' wings before battle,$w2
or who knows what might happen.$K$F3$FD
$F1$PI figured that egg thing was a joke,$w4 but
I had no idea it ever really happened...$w4
Bird tribes...$w3 Go figure.$K    $R�w�i��b|$B�V���l�p-��|$<$F1$FCL_IKE2|$F1$PExcuse me, $w2do you have a moment?$K
$F3$FCL_VULCI|$F3$P...$w2Oh. General Ike.$w4
What is it?$K
$F1$PIt's $w2nothing really...$w4
I just thought $w2I'd say hello.$K
$F3$P$FcThat's...$w2considerate.$K
$F3$Fd$F1$PUm...$w4 Your king is very generous, $w2isn't he?$w4
And it's not just Reyson I'm talking about.$w3
He left us his two $w2retainers as well.$K
$F3$P...$w3How do we pertain to the king's
generosity?$K
$F1$PI guess it's because Reyson $w2kept
apologizing... I just thought that...$w4
Am I misinterpreting something?$K
$F3$PI...don't know.$w4 But I know that the
king can survive$w4 without our help.$K
$F1$PIs that true?$w4 That's pretty amazing.$w3
I've been given the title of lord,$w3 but
I still can't run this army on my own.$K$PTitania and Soren $w2handle all the little
details,$w3 and that's what keeps us
from collapsing into chaos.$K
$F3$POur king...$w2does nothing special.$w3
Everyone just does what's needed.$w4
There is no chaos.$K
$F1$PHe's really trusted, isn't he?$K
$F3$PThat's...natural.$w4 In laguz society,$w2
the strongest become king.$K$PUnlike the beorc, $w2kingship is not tied to
blood,$w4 so we have no weak kings.$Fc
I'm sorry...$w4 Perhaps that was improper.$K
$F1$PNo,$w3 I agree with you.$w4 Choosing a
ruler$w2 by strength instead of birth
makes much more sense.$K
$F3$P$FdWhen we $w2face Begnion troops,$w3
we target the units$w3 with weak
leadership and eliminate them first.$K$PBeorc weapons can be very powerful,$w3
but $w2not everyone wields them well.$K$PSince beorc also choose generals by
bloodlines, their competency is uneven...
and that is a weakness of beorc armies.$K$PAs for you, General Ike, $w2the time
to prove yourself is approaching.$K
$F1$PIt's true.$w3 No matter how strong the
individuals are, $w2that strength is worthless
if they're weak as a unit.$K$FA$PAn army's power $w2comes from
leadership and management...$w4$FS
That's good to remember.$w4 Thanks.$K
$F3$PMmm.$K  $R�w�i��b|$B�V��-��-1|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H   $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 By your leave,$w2
I will excuse myself.$K    "@          	  =�     4l   '  5P   ;  6   O  8<   c  :�   w  ~    �     �  �   �  �   �  !T   �   t   �  "�   �  >�   �  C   �  E�    G�    L     O�  +  XL  =  `�  N  b�  _  h�  p  k�  �  m  �  nt  �  o�  �  o�  �  p,  �  p$  �  q�    p8    p�  !  rX  1  >�  =  ?�  I  @  U  @�  a      m  �  x  �x  �  �  �  ��  �  ��  �  �  �  
�  �  �  �  �  �  �  �  �  
  l    �  (  D  8  �  H  �  X  T  g    w  �  �  �  �  �  �  H  �  �  �  L  �  x  �  �  �  �H  �  ��    �d    ��  )  "�  :  'T  G  +P  T  r�  `MS_20_BT MS_20_BT_IKE MS_20_BT_NAESALA MS_20_BT_NAESALA_02 MS_20_BT_NAESALA_03 MS_20_BT_NAESALA_04 MS_20_BT_NAESALA_05 MS_20_BT_NAESALA_06 MS_20_BT_NAESALA_MW MS_20_BT_R1 MS_20_BT_R2 MS_20_BT_RI MS_20_BT_SO MS_20_BT_TU MS_20_DIE MS_20_DIE_NAESALA MS_20_ED_01_A MS_20_ED_01_B MS_20_ED_02 MS_20_ED_03 MS_20_ED_04_01_01 MS_20_ED_04_01_2 MS_20_ED_04_01_3 MS_20_ED_04_01_4 MS_20_ED_04_01_5 MS_20_ED_04_02_A MS_20_ED_04_02_B MS_20_ED_04_02_C MS_20_ED_04_02_C_DEL MS_20_ED_04_02_C_SKIP MS_20_ED_04_03NN MS_20_ED_04_03YY MS_20_ED_04_04N MS_20_ED_04_04Y MS_20_ED_04_05Y MS_20_ED_05 MS_20_EV_01 MS_20_EV_02 MS_20_EV_03 MS_20_EV_04 MS_20_GMAP MS_20_INFO_03 MS_20_INFO_03_2 MS_20_INFO_04 MS_20_INFO_05 MS_20_INFO_06 MS_20_OP_01 MS_20_OP_01_2 MS_20_OP_02_01A MS_20_OP_02_01B MS_20_OP_02_01C MS_20_OP_02_02 MS_20_OP_02_03 MS_20_OP_02_04S MS_20_OP_02_05S MS_20_OP_02_06S MS_20_OP_02_07 MS_20_OP_02_08S MS_20_OP_02_09S MS_20_OP_02_10S MS_20_OP_02_11 MS_20_OP_03 MS_20_OP_04 MS_20_OP_05_01 MS_20_OP_05_02 MS_20_OP_05_03 MS_20_OP_05_04 MS_20_REPO_BEGIN MS_20_REPO_DIE MS_20_REPO_END MS_20_REPO_NODIE MS_20_TK_01A MS_20_TK_01B MS_20_TK_02 MS_20_TK_02_GET 