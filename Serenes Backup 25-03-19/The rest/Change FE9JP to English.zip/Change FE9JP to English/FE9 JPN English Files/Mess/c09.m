  �;  �       K                $R�㉺��b|$s1$FS$c1GREIL3|$s1What's wrong, Ike?$w2 Done already?$K
Come on, Son!$w4 You'll never
beat me with that attitude!$K$d1  $R�㉺��b|$s1$FS$c1GREIL3|$s1Ha ha ha!$w4 Think you're as stubborn$w2
as your mule-headed father?$K$d1 $R�㉺��b|$s1$FS$c1GREIL3|$s1Ike.$w4 Grow up big and strong.$w5
I believe$w2 you've got the makings
of a great warrior.$K  $R�̂݉�b|$w4$F1$FCL_IKE|$MC...$MD$w5Father.$w6
This$w4 isn't a dream,$w4 is it?$w5
This$MC... $MDThis is all$w4 real.$w3$K    $R�̂݉�b|$F1$FCL_IKE|Mist. The sun's going down,$w3 and it's
getting cold.$w5 Come on.$w2 Let's go.$K$F1$FD$P$F1$FCL_MIST|$MC...$MD$K$F1$FD$P$F1$FCL_IKE|Mist?$K$F1$FD$P$F1$FCL_MIST|Oh$MC...$MD$w4
Oh, Ike$MC...$MD$w3sniff$MC...$MD$K$F1$FD$P$F1$FCL_IKE|Mist$MC...$MD$K$F1$FD$P$F1$FCL_MIST|$MC...$MDW-$w4why$MC...$MD$w4 Why?$K$F1$FD$P$F1$FCL_IKE|I $w2was at his side,$w4 but$MC...$MD$w6
I couldn't save him.$w5
I'm sorry.$K$F1$FD$P$F1$FCL_MIST|$MC...$MDSniff$MC...$MD$w3$K$F1$FD$P$F1$FCL_IKE|It's$MC... $MDIt's so unreal$MC...$MD$K$F1$FD$P$F1$FCL_MIST|Dad's $w5gone$MC... $MDHe's gone, Ike.$w4
Sniff$MC...$MD$K$PAnd$MC...$MD$w2I$MC...$MD$w4don't$MC...$MD$w4
I don't know$w2
what to do$MC...$MD$K  $R�w�i��b|$B����-�[��-2|$<$F1$FCL_IKE|$F1$PDon't worry.$w4
I'm here.$K
$F3$FCL_MISTss|$F3$PBro-$w3Brother$MC...$MD$K
$F1$PI'll lead the company$MC...$MD$K$PIn Father's stead$MC...$MD$w4 And I'll protect
you all. You,$w3 the princess$MC...$MD$w5everyone.$w6
I'll protect you.$w4 You'll see.$K
$F3$P$FcNo$MC...$MD$K$PBrother$MC...$MD$w5
Ike$MC... $MDNo$MC...$MD$K
$F1$PMist?$K
$F3$PI won't $w2allow it$MC...$MD$K$PI can't lose you.$w3 Don't you see?$w2
If you go,$w2 then I'll be all alone$MC...$MD$K$PI won't allow it.$K
$F1$P$FcI'm not going anywhere.$w4
I promise you, Mist$MC...$MD$K
$=1200   $=0500$R�w�i��b|$B���-���O�Y-��|$<$F4$Fc$F4$FCL_TIAMAT|$F4$P$w5Commander$MC...$MD$w4 Greil$MC...$MD$Fd$w5
Why is this happening?$K$PWhy is any of this happening?$w2 Why
now? First, Crimea$MC...$MD$w3 And now you$MC...$MD$K
$F0$FCL_SENERIO|$F0$P$MC...$MD$K
$F4$FD$F3$FCL_IKE|$F0$PIke$MC...$MD$K
$F1$FCL_TIAMAT|$F1$POh, $w2Ike!$w4
Where's Mist?$K
$F3$PShe's resting in her room.$w4
Rhys and Rolf$w3 are with her.$K
$F1$PThat's good$MC...$MD$w4 She needs to sleep.$w2
She's been through too much.$w2
We all have$MC...$MD$K$PYou should rest too, $w2Ike.$K
$F3$PI'll be $w2all right.$w4 Grief won't bring
my father back to life.$K
$F3$PI know I've been a burden on the both
of you.$w4 Titania, Soren,$w2 I just need to
thank you both for staying here with me.$K
$F0$PNot at all$MC...$MD$K
$F1$P$FcThere's no need.$w4
Don't trouble yourself.$K
$=0300  $=0500$R�w�i��b|$B���-���O�Y-��|$<$F4$Fc$F4$FCL_TIAMAT|$F4$P$w5Commander$MC...$MD$w4 Greil$MC...$MD$Fd$w5
Why is this happening?$K$PWhy is any of this happening?$w2 Why
now? First, Crimea$MC...$MD$w3 And now you$MC...$MD$K
$F0$FCL_SENERIO|$F0$P$MC...$MD$K
$F4$FD$F3$FCL_IKE|$F0$PIke$MC...$MD$K
$F1$FCL_TIAMAT|$F1$POh, $w2Ike!$w4
Where's Mist?$K
$F3$PShe's resting in her room.$w4
Rolf is with her.$K
$F1$PThat's good$MC...$MD$w4 She needs to sleep.$w2
She's been through too much.$w2
We all have$MC..$MD$K$PYou should rest too, $w2Ike.$K
$F3$PI'll be $w2all right.$w4 Grief won't bring
my father back to life.$K
$F3$PI know I've been a burden on the both
of you.$w4 Titania, Soren,$w2 I just need to
thank you both for staying here with me.$K
$F0$PNot at all$MC...$MD$K
$F1$P$FcThere's no need.$w4
Don't trouble yourself.$K
$=0300    $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_TIAMAT|$F3$FCL_IKE|$F0$FCL_SENERIO|$F3$PSo$MC...$MD$w4where is everyone?$K
$F1$PIke, $w2to tell the truth$MC...$MD$K
$F3$PYes?$K
$Ub$H$F3$FD$F4$FCL_OSCAR|$F4$PBoyd and I$w2 are back.$K
$F1$PHow did it go?$K
$F4$FD$F4$FCL_BOLE|$F4$PI can't believe it! They just left, and they
didn't take one look back!$w4 Heartless
scum! I'll never forgive them!$K
$F1$FD$F1$FCL_IKE|$F1$PBoyd?$w4 What's going on?$K
$F4$PIke!$w4 Are you $w2all right?$K
$F1$PI'm fine.$w4 Tell me what's happened.$w2
Start talking.$K
$F4$PWell, $w2uh, $w2it's$MC...$MD$w4
What I mean to say is$MC...$MD$w4 Uh$MC...$MD$K
$F0$PShinon $w2and Gatrie have left us.$K
$F4$PSoren!$K
$F0$PWhat? There's nothing to hide,
$w1is there?$K
$F1$PThey left? Both of them?$w4
Why did they$MC--$MD$w4 Oh, I see.$w4
They left because of me, didn't they?$K
$F3$FCL_TIAMAT|$F3$PIke$MC...$MD$K
$F4$PTitania told us $w2you were going
to be the new commander.$K$PShinon just about exploded$MC...$MD$w4
He and Gatrie left not long ago.$K
$F4$FD$F4$FCL_OSCAR|$F4$PWe went after them. We tried to talk
things out, but it was a waste of time.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F4$FD$F4$FCL_BOLE|$F4$PHow can you say that?$w4 After all
the battles we've been through
together, how can you say that?$K
$F0$FD$F4$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PThey did what they felt they had to do.$w4
They didn't want to lose their lives$w3
to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FS$F4$FCL_OSCAR|$F4$PI'd already made up my mind. That's what
I was going to do $w2all along.$K
$F3$FD$F4$FD$F3$FCL_BOLE|$F3$PWhat, so now you want me to start
calling you Boss? Is that it?$K$FS$PWell, $w2I can do that.$w4
Boss it is!$K$P$UB$H    $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_TIAMAT|$F3$FCL_IKE|$F0$FCL_SENERIO|$F3$PSo$MC...$MD$w4where is everyone?$K
$F1$PIke, $w2to tell the truth$MC...$MD$K
$F3$PYes?$K
$Ub$H$F3$FD$F4$FCL_OSCAR|$F4$PBoyd and I$w2 are back.$K
$F1$PHow did it go?$K
$F4$FD$F4$FCL_BOLE|$F4$PI can't believe it! He just left,
without even a single look back!$w4
Heartless scum! I'll never forgive him!$K
$F1$FD$F1$FCL_IKE|$F1$PBoyd?$w4 What's going on?$K
$F4$PIke!$w4 Are you $w2all right?$K
$F1$PI'm fine.$w4 Tell me what happened.$w2
Start talking.$K
$F4$PWell, $w2uh, $w2it's$MC...$MD$w4
What I mean to say is$MC...$MD$w4 Uh$MC...$MD$K
$F0$PShinon left.$K
$F4$PSoren!$K
$F0$PWhat? There's nothing to hide,
$w1is there?$K
$F1$PWhy would he$MC--$MD$w4 Oh, I see.$w4
He left because of me, didn't he?$K
$F3$FCL_TIAMAT|$F3$PIke$MC...$MD$K
$F4$PTitania told us $w2you were going
to be the new commander.$K$PShinon just about exploded$MC...$MD$w4
He left not long ago.$K
$F4$FD$F4$FCL_OSCAR|$F4$PWe went after him. We tried to talk
things out, but it was a waste of time.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F4$FD$F4$FCL_BOLE|$F4$PHow can you say that?$w4 After all
the battles we've been through
together, how can you say that?$K
$F0$FD$F4$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PShinon did what he felt he had to do.$w4
He didn't want to lose his life$w3
to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FS$F4$FCL_OSCAR|$F4$PI'd already made up my mind. That's what
I was going to do $w2all along.$K
$F3$FD$F4$FD$F3$FCL_BOLE|$F3$PWhat, so now you want me to start
calling you Boss? Is that it?$K$FS$PWell, $w2I can do that.$w4
Boss it is!$K$P$UB$H $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_TIAMAT|$F3$FCL_IKE|$F0$FCL_SENERIO|$F3$PSo$MC...$MD$w4where is everyone?$K
$F1$PIke, $w2to tell the truth$MC...$MD$K
$F3$PYes?$K
$Ub$H$F3$FD$F4$FCL_OSCAR|$F4$PBoyd and I$w2 are back.$K
$F1$PHow did it go?$K
$F4$FD$F4$FCL_BOLE|$F4$PI can't believe it! He just left,
without even a single look back!$w4
Heartless scum! I'll never forgive him!$K
$F1$FD$F1$FCL_IKE|$F1$PBoyd?$w4 What's going on?$K
$F4$PIke!$w4 Are you $w2all right?$K
$F1$PI'm fine.$w4 Tell me what happened.$w2
Start talking.$K
$F4$PWell, $w2uh, $w2it's$MC...$MD$w4
What I mean to say is$MC...$MD$w4 Uh$MC...$MD$K
$F0$PGatrie left.$K
$F4$PSoren!$K
$F0$PWhat? There's nothing to hide,
$w1is there?$K
$F1$PWhy would he$MC--$MD$w4 Oh, I see.$w4
He left because of me, didn't he?$K
$F3$FCL_TIAMAT|$F3$PIke$MC...$MD$K
$F4$PTitania told us $w2you were going
to be the new commander.$K$PAnd then Gatrie, he$MC...$MD$w4 He said that
he wouldn't follow anyone$w2 but
Commander Greil$MC...$MD$w4 He just left.$K
$F4$FD$F4$FCL_OSCAR|$F4$PWe went after him. We tried to talk
things out, but it was a waste of time.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F4$FD$F4$FCL_BOLE|$F4$PHow can you say that?$w4 After all
the battles we've been through
together, how can you say that?$K
$F0$FD$F4$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PGatrie did what he felt was best for him.$w4
He didn't want to lose his life$w3
to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FS$F4$FCL_OSCAR|$F4$PI'd already made up my mind. That's what
I was going to do $w2all along.$K
$F3$FD$F4$FD$F3$FCL_BOLE|$F3$PWhat, so now you want me to start
calling you Boss? Is that it?$K$FS$PWell, $w2I can do that.$w4
Boss it is!$K$P$UB$H  $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_IKE|$F1$P$F3$FCL_BOLE|$F3$PIke!$w4 Are you$MC...$MD$w2sure
you're all right?$K
$F4$FCL_OSCAR|$F4$PHow are you holding up?$K
$F1$PI've been better.$w4 Sorry for all
the trouble I've caused you.$K
$F4$PYou know $w2it wasn't any trouble.$K
$F3$PStop treating us like strangers.$w5
We both know what it's like$w3
to lose a father.$K
$F4$P$MC...$MD$K$F3$FD$F4$FD
$F1$PSo$MC...$MD$w4what happens next?$w5
What are you going to do?$K
$F3$FCL_TIAMAT|$F3$PWhat do you mean?$K
$F1$PMy father's dead.$w4 Whatever obligation
you had to him, you've paid it back.
There's nothing keeping you here.$K$PEach of you has to think about what's
best for you.$w3 You can't risk your
lives for an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to get your pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me, $w2that's
what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FS$F4$FCL_OSCAR|$F4$PI'd already made up my mind. That's what
I was going to do $w2all along.$K
$F3$FD$F4$FD$F3$FCL_BOLE|$F3$PWhat, so now you want me to start
calling you Boss? Is that it?$K$FS$PWell, $w2I can do that.$w4
Boss it is!$K$P$UB$H   $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_TIAMAT|$F3$FCL_IKE|$F0$FCL_SENERIO|$F3$PSo$MC...$MD$w4where is everyone?$K
$F1$PIke, $w2to tell the truth$MC...$MD$K
$F3$PYes?$K
$Ub$H$F3$P$FD$F4$FCL_OSCAR|$F4$PI'm back.$K
$F1$PHow did it go?$K
$F4$PThey're gone.$K
$F1$FD$F1$FCL_IKE|$F1$POscar?$w4 What's going on?$K
$F4$PIke!$w4 Are you $w2all right?$K
$F1$PI'm fine.$w4 Tell me what happened.$w2
Start talking.$K
$F4$P$MC...$MDRight.$w2 What's the best way
of telling you this?$K
$F0$PShinon $w2and Gatrie have left.$K
$F4$PSoren$MC...$MD$K
$F0$PWhat? There's nothing to hide,
$w1is there?$K
$F1$PThey left? Both of them?$w4
Why did they$MC--$MD$w4 Oh, I see.$w4
They left because of me, didn't they?$K
$F3$FCL_TIAMAT|$F3$PIke$MC...$MD$K
$F4$PTitania told us $w2you were going
to be the new commander.$K$PShinon just about exploded$MC...$MD$w4
He and Gatrie left not long ago.$K
I went after them.$w3 I thought maybe
I could talk some sense into them,
but it was a waste of time.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F4$PSoren.$w4 After all we've been through
together, surely you don't need to take
that tone.$K
$F0$FD$F4$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PThey did what they felt they had to do.$w4
They didn't want to lose their lives$w3
to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FCL_OSCAR|$F4$P$FSI'd already made up my mind. That's what
I was going to do $w2all along.$K$P$F4$FD$N$UB$H    $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_TIAMAT|$F3$FCL_IKE|$F0$FCL_SENERIO|$F3$PSo$MC...$MD$w4where is everyone?$K
$F1$PIke, $w2to tell the truth$MC...$MD$K
$F3$PYes?$K
$Ub$H$F3$P$FD$F4$FCL_OSCAR|$F4$PI'm back.$K
$F1$PHow did it go?$K
$F4$PHe's gone.$K
$F1$FD$F1$FCL_IKE|$F1$POscar?$w4 What's going on?$K
$F4$PIke!$w4 Are you $w2all right?$K
$F1$PI'm fine.$w4 Tell me what happened.$w2
Start talking.$K
$F4$P$MC...$MDRight.$w2 What's the best way
of telling you this?$K
$F0$PShinon left.$K
$F4$PSoren$MC...$MD$K
$F0$PWhat? There's nothing to hide,
$w1is there?$K
$F1$PWhy did he$MC--$MD$w4 Oh, I see.$w4
He left because of me, didn't he?$K
$F3$FCL_TIAMAT|$F3$PIke$MC...$MD$K
$F4$PTitania told us $w2you were going
to be the new commander.$K$PShinon just about exploded$MC...$MD$w4
He left not long ago.$K
I went after him.$w3 I thought maybe
I could talk some sense into him,
but it was a waste of time.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F4$PSoren.$w4 After all we've been through
together, surely you don't need to take
that tone.$K
$F0$FD$F4$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PShinon did what he felt he had to do.$w4
He didn't want to lose his life$w3
to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FCL_OSCAR|$F4$P$FSI'd already made up my mind. That's what
I was going to do $w2all along.$K$P$F4$FD$N$UB$H    $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_TIAMAT|$F3$FCL_IKE|$F0$FCL_SENERIO|$F3$PSo$MC...$MD$w4where is everyone?$K
$F1$PIke, $w2to tell the truth$MC...$MD$K
$F3$PYes?$K
$Ub$H$F3$P$FD$F4$FCL_OSCAR|$F4$PI'm back.$K
$F1$PHow did it go?$K
$F4$PHe's gone.$K
$F1$FD$F1$FCL_IKE|$F1$POscar?$w4 What's going on?$K
$F4$PIke!$w4 Are you $w2all right?$K
$F1$PI'm fine.$w4 Tell me what happened.$w2
Start talking.$K
$F4$P$MC...$MDRight.$w2 What's the best way
of telling you this?$K
$F0$PGatrie left.$K
$F4$PSoren$MC...$MD$K
$F0$PWhat? There's nothing to hide,
$w1is there?$K
$F1$PWhy did he$MC--$MD$w4 Oh, I see.$w4
He left because of me, didn't he?$K
$F3$FCL_TIAMAT|$F3$PIke$MC...$MD$K
$F4$PThe captain told us $w2you were going
to be the new commander.$K$PAnd then Gatrie, he$MC...$MD$w4 He said that
he wouldn't follow anyone$w2 but
Commander Greil$MC...$MD$w4 He just left.$K
I went after him to try and talk things
out, but it was a waste of time.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F4$PSoren.$w4 After all we've been through
together, surely you don't need to take
that tone.$K
$F0$FD$F4$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PGatrie did what he thought would be best
for him.$w4 He didn't want to lose his
life$w3 to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FCL_OSCAR|$F4$P$FSI'd already made up my mind. That's what
I was going to do $w2all along.$K$P$F4$FD$N$UB$H   $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_IKE|$F4$FCL_OSCAR|$F4$PIke!$w5 How$w3 are you holding up?$K
$F1$PI've been better.$w4 Sorry for all the
trouble I've caused you, Oscar.$K
$F4$PYou know $w2it wasn't any trouble.$K
I know what it's like$w3 to lose family$MC...$MD$K$F4$FD
$F1$P$MC...$MDI know.$w5
So$MC...$MD$w4what happens next?$w5
What are you going to do?$K
$F3$FCL_TIAMAT|$F3$PWhat do you mean?$K
$F1$PMy father's dead.$w4 Whatever obligation
you had to him, you've paid it back.
There's nothing keeping you here.$K$PYou have to think about what's best
for yourself.$w3 You can't risk your life
for an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to get your pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me, $w2that's
what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FCL_OSCAR|$F4$P$FSI'd already made up my mind. That's what
I was going to do $w2all along.$K$P$F4$FD$N$UB$H   $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_TIAMAT|$F3$FCL_IKE|$F0$FCL_SENERIO|$F3$PSo$MC...$MD$w4where is everyone?$K
$F1$PIke, $w2to tell the truth$MC...$MD$K
$F3$PYes?$K
$Ub$H$F3$FD$F4$FCL_BOLE|$F4$PI'm back.$K
$F1$PHow did it go?$K
$F4$PI can't believe it! They just left, and they
didn't take one look back!$w4 Heartless
scum! I'll never forgive them!$K
$F1$FD$F1$FCL_IKE|$F1$PBoyd?$w4 What's going on?$K
$F4$PIke!$w4 Are you $w2all right?$K
$F1$PI'm fine.$w4 Tell me what happened.$w2
Start talking.$K
$F4$PWell, $w2uh, $w2it's$MC...$MD$w4
What I mean to say is$MC...$MD$w4 Uh$MC...$MD$K
$F0$PShinon $w2and Gatrie have left.$K
$F4$PSoren!$K
$F0$PWhat? There's nothing to hide,
$w1is there?$K
$F1$PThey left? Both of them?$w4
Why did they$MC--$MD$w4 Oh, I see.$w4
They left because of me, didn't they?$K
$F3$FCL_TIAMAT|$F3$PIke$MC...$MD$K
$F4$PTitania told us $w2you were going
to be the new commander.$K$PShinon just about exploded$MC...$MD$w4
They left a few minutes ago.$K$PI chased 'em down to try and talk things
out, $w2but they weren't listening.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F4$PHow can you say that?$w4 After all
the battles we've been through together,
how can you say that?$K
$F0$FD$F4$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PThey did what they felt they had to do.$w4
They didn't want to lose their lives$w3
to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FCL_BOLE|$F4$PWhat, so now you want me to start
calling you Boss? Is that it?$K$FS$PWell, $w2I can do that.$w4
Boss it is!$K$P$F4$FD$N$UB$H  $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_TIAMAT|$F3$FCL_IKE|$F0$FCL_SENERIO|$F3$PSo$MC...$MD$w4where is everyone?$K
$F1$PIke, $w2to tell the truth$MC...$MD$K
$F3$PYes?$K
$Ub$H$F3$FD$F4$FCL_BOLE|$F4$PI'm back.$K
$F1$PHow did it go?$K
$F4$PI can't believe it! He just left,
and he didn't take one look back!$w4
Heartless scum! I'll never forgive him!$K
$F1$FD$F1$FCL_IKE|$F1$PBoyd?$w4 What's going on?$K
$F4$PIke!$w4 Are you $w2all right?$K
$F1$PI'm fine.$w4 Tell me what happened.$w2
Start talking.$K
$F4$PWell, $w2uh, $w2it's$MC...$MD$w4
What I mean to say is$MC...$MD$w4 Uh$MC...$MD$K
$F0$PShinon's left.$K
$F4$PSoren!$K
$F0$PWhat? There's nothing to hide,
$w1is there?$K
$F1$PWhy did he$MC...$MD$w4 Oh, I see.$w4
He left because of me, didn't he?$K
$F3$FCL_TIAMAT|$F3$PIke$MC...$MD$K
$F4$PTitania told us $w2you were going
to be the new commander.$K$PShinon just about exploded$MC...$MD$w4
He left a few minutes ago.$K$PI chased him down to try and talk things
out, $w2but he wouldn't listen.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F4$PHow can you say that?$w4 After all
the battles we've been through together,
how can you say that?$K
$F0$FD$F4$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PShinon did what he felt he had to do.$w4
He didn't want to lose his life$w3
to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FCL_BOLE|$F4$PWhat, so now you want me to start
calling you Boss? Is that it?$K$FS$PWell, $w2I can do that.$w4
Boss it is!$K$P$F4$FD$N$UB$H  $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_TIAMAT|$F3$FCL_IKE|$F0$FCL_SENERIO|$F3$PSo$MC...$MD$w4where is everyone?$K
$F1$PIke, $w2to tell the truth$MC...$MD$K
$F3$PYes?$K
$Ub$H$F3$FD$F4$FCL_BOLE|$F4$PI'm back.$K
$F1$PHow did it go?$K
$F4$PI can't believe it! He just left,
and he didn't take one look back!$w4
Heartless scum! I'll never forgive him!$K
$F1$FD$F1$FCL_IKE|$F1$PBoyd?$w4 What's going on?$K
$F4$PIke!$w4 Are you $w2all right?$K
$F1$PI'm fine.$w4 Tell me what happened.$w2
Start talking.$K
$F4$PWell, $w2uh, $w2it's$MC...$MD$w4
What I mean to say is$MC...$MD$w4 Uh$MC...$MD$K
$F0$PGatrie's left.$K
$F4$PSoren!$K
$F0$PWhat? There's nothing to hide,
$w1is there?$K
$F1$PWhy did he$MC...$MD$w4 Oh, I see.$w4
He left because of me, didn't he?$K
$F3$FCL_TIAMAT|$F3$PIke$MC...$MD$K
$F4$PTitania told us $w2you were going
to be the new commander.$K$PAnd then Gatrie, he$MC...$MD$w4 He said that
he wouldn't follow anyone$w2 but
Commander Greil$MC...$MD$w4 He just left.$K
I chased him down to try and talk things
out, $w2but he wouldn't listen.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F4$PHow can you say that?$w4 After all
the battles we've been through together,
how can you say that?$K
$F0$FD$F4$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PGatrie did what he felt he had to do.$w4
He didn't want to lose his life$w3
to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FCL_BOLE|$F4$PWhat, so now you want me to start
calling you Boss? Is that it?$K$FS$PWell, $w2I can do that.$w4
Boss it is!$K$P$F4$FD$N$UB$H $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_IKE|$F1$P$F3$FCL_BOLE|$F3$PIke!$w4 Are you$MC...$MD$w2sure
you're all right?$K
$F1$PI've been better.$w4 Sorry for all the
trouble I've caused you, Boyd.$K
$F3$PStop treating me like a stranger.$w5
I know what it's like$w3 to lose family.$K$F3$FD
$F1$P$MC...$MD$w5
So$MC...$MD$w4what happens next?$w5
What are you going to do?$K
$F3$FCL_TIAMAT|$F3$PWhat do you mean?$K
$F1$PMy father's dead.$w4 Whatever obligation
you had to him, you've paid it back.
There's nothing keeping you here.$K$PEach of you has to think about what's
best for you.$w3 You can't risk your
lives for an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to get your pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes,$w2
and assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K
$F4$FCL_BOLE|$F4$PWhat, so now you want me to start
calling you Boss? Is that it?$K$FS$PWell, $w2I can do that.$w4
Boss it is!$K$P$F4$FD$N$UB$H  $R�w�i��b|$B���-���O�Y-��|$<$F3$FCL_TIAMAT|$F1$FCL_IKE|$F1$PSo$MC...$MD$w4where is everyone?$K
$F3$PIke, $w2to tell you the truth$MC...$MD$K
$F1$PYes?$K
$F3$PAfter everything that's happened lately,$w4
I wish I didn't have to tell you this, but$MC...$MD$K
$F0$FCL_SENERIO|$F0$PShinon $w2and Gatrie have left.$K
$F3$POh, Soren$MC...$MD$K
$F0$PWhat? There's nothing to hide,
$w1is there?$K
$F1$PThey left? Both of them?$w4
Why did they$MC--$MD$w4 Oh, I see.$w4
They left because of me, didn't they?$K
$F3$PIke, your father made one thing very
clear to me over the past few weeks$MC...$MD$w3
You are to take command of the company.$K$PBut when I told Shinon, $w2he refused to
accept it.$w2 He said he$w4 would sooner leave
than serve under you.$w4 I'm sorry.$K$PI went after him and tried to talk some
sense into him, $w2but it did no good.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F3$PSoren, please$MC... $MDStop being so analytical.
They were part of our family.$w3
We went through a lot together.$K
$F0$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PThey did what they felt they had to do.$w4
They didn't want to lose their lives$w3
to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K$P$N$UB$H    $R�w�i��b|$B���-���O�Y-��|$<$F3$FCL_TIAMAT|$F1$FCL_IKE|$F1$PSo$MC...$MD$w4where is everyone?$K
$F3$PIke, $w2to you tell the truth$MC...$MD$K
$F1$PYes?$K
$F3$PAfter everything that's happened lately,$w4
I wish I didn't have to tell you this, but$MC...$MD$K
$F0$FCL_SENERIO|$F0$PShinon left.$K
$F3$POh, Soren$MC...$MD$K
$F0$PWhat? There's nothing to hide,
$w1is there?$K
$F1$PHe left? What happened?$w4
Why would he$MC--$MD$w4 Oh, I see.$w4
He left because of me, didn't he?$K
$F3$PIke, your father made one thing very
clear to me over the past few weeks$MC...$MD$w3
You are to take command of the company.$K$PBut when I told Shinon, $w2he refused to
accept it.$w2 He said he$w4 would sooner leave
than serve under you.$w4 I'm sorry.$K$PI went after him and tried to talk some
sense into him, $w2but it did no good.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F3$PSoren, please$MC... $MDStop being so analytical.
They were part of our family.$w3
We went through a lot together.$K
$F0$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PShinon did what he felt he had to do.$w4
He didn't want to lose his life$w3
to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K$P$N$UB$H   $R�w�i��b|$B���-���O�Y-��|$<$F3$FCL_TIAMAT|$F1$FCL_IKE|$F1$PSo$MC...$MD$w4where is everyone?$K
$F3$PIke, $w2to tell the truth$MC...$MD$K
$F1$PYes?$K
$F3$PAfter everything that's happened lately,$w4
I wish I didn't have to tell you this, but$MC...$MD$K
$F0$FCL_SENERIO|$F0$PGatrie left.$K
$F3$POh, Soren$MC...$MD$K
$F0$PThere's nothing to hide, $w1is there?$K
$F1$PWhy did he$MC...$MD$w4 Oh, I see.$w4
He left because of me, didn't he?$K
$F3$PIke, your father made one thing very
clear to me over the past few weeks$MC...$MD$w3
You are to take command of the company.$K$PBut Gatrie, he$MC...$MD$w4 He said that
he wouldn't follow anyone$w2 but
Commander Greil$MC...$MD$w4 He just left.$K
I chased him down to try and talk things
out, $w2but he wouldn't listen.$K
$F0$PWe all knew $w2that Ike was going to
inherit command of the company, didn't we?$w4
It just happened $w2sooner than we wanted.$K$PIt was Greil's decision.$w4 If some of us aren't
satisfied with that,$w2 there's no reason
we should stop them from leaving.$K$PAs far as losing fighting strength is
concerned,$w2 we can solve that
by adding new members.$K
$F3$PSoren, please$MC... $MDStop being so analytical.
He was part of our family.$w3
We went through a lot together.$K
$F0$FD$F3$PForgive me, $w2Ike.$w4 I wasn't able
to stop any of this$MC...$MD$K
$F1$PIt's not your fault, Titania.$K$PGatrie did what he felt he had to do.$w4
He didn't want to lose his life$w3
to an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to gain anyone's pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K$P$N$UB$H    $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_IKE|$F1$PSo,$w4 what happens next?$w5
What are you planning on doing?$K
$F3$FCL_TIAMAT|$F3$PWhat do you mean?$K
$F1$PMy father's dead.$w4 Whatever obligation
you had to him, you've paid it back.
There's nothing keeping you here.$K$PEach of you has to think about what's
best for you.$w3 You can't risk your
lives for an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to get your pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K$P$N$UB$H $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_IKE|$F1$PSo,$w4 what happens next?$w5
What are you planning on doing?$K
$F3$FCL_TIAMAT|$F3$PWhat do you mean?$K
$F1$PMy father's dead.$w4 Whatever obligation
you had to him, you've paid it back.
There's nothing keeping you here.$K$PEach of you has to think about what's
best for you.$w3 You can't risk your
lives for an inexperienced commander.$K
$F3$PIke!$w4 Don't talk about yourself like that.$K
$F1$PI'm not saying that to get your pity.$w4
It's the truth.$K
$PBut $w2even so,$w4 I have no intention
of giving up command of this company.$K
$F3$PIke?$w4 Then what will you$MC--$MD$K
$Ub$H$F1$PI'm going to follow my father's wishes.$w2
I'm going to assume command.$K$PIf everyone will accept me,$w2
that's what I'd like to do.$K
$F3$P$FSOf course!$K$P$N$UB$H $F4$FS$F4$FCL_KILROY|$F4$PI'm in, too.$K
$F1$PRhys!$K
$F4$PMist's asleep.$K$PI know I missed most of the conversation,$w5
but I have a good idea of what you've
been discussing.$K$PCommander Ike$MC... $MD$w4Yes, $w2it does have
a nice ring to it.$K$P$F3$FD$F4$FD$N$UB$H    $F1$PWhat about you, Soren?$K$P$F4$FCL_SENERIO|$MC...$MDIke.$w5 I'm not sure what help
I could be to you.$K$PWhat place is there for me in a
mercenary company, anyway?$K
$F1$P$FSYou are so weird$MC...$MD$w4 I've always$w2
depended on you, haven't I?$K$PI need your tactical knowledge.$w3 I need
your objectivity.$w5 You're not going to
leave me, are you,$w4 Soren?$K
$F4$P$FSDon't worry.$w4 I'll be here,$w2
watching over you.$K$F4$FD$w6
$F1$P$FAThank you.$w4 I know I'm not as experienced
as most of you. I'm going to make some
mistakes, $w2but I'll try not to let you down.$K
$=0300    $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_IKE|$F3$FS$F3$FCL_TIAMAT|$F3$PWell, $w2you're going to have a lot to
learn about being commander.$w4 I'm glad
you're serious, because it's a lot of work.$K
$F1$PTell me everything.$K
$F3$PFirst, $w2you'll need to understand company
expenditures.$w4 Then we'll talk about ensuring
that $w2everyone is properly outfitted.$K$PAnd we can't forget the need to gather
good intelligence.$w5 Oh,$w2 and you'll want to
know everyone's abilities $w2and relationships.$K
$F1$PUh-huh$MC...$MD$K
$F3$PEarlier, $w2I spoke with a merchant caravan
that's taken refuge here in the castle.$w3
They fled Crimea at the same time we did.$K$PI told them who we are,$w2 and they asked
if they could travel with us.$w4 I think they're
worried about protection from Daein.$K$PIn exchange,$w1 they've offered us a good
rate on items and weapons.$w4 They'll also
buy items$w2 and forge weapons for us.$K
$F1$PUh-huh$MC...$MD$K
$F3$PThey also said$w4 we could use their
wagons to store our goods. $w2That's
one more worry off our minds.$K
$F1$PUh-huh$MC...$MD$K
$F3$PSo anyway$MC--$MD$K
$F1$PTitania!$K
$F3$PYes?$K
$F1$PI know $w2I said tell me everything, but$MC...$MD$K$PThis is too much.$w2 I can't keep up.$K$PMaybe I shouldn't learn everything in
one sitting.$w2 Can you show me the ropes
along the way?$w3 Is that all right?$K
$F3$P$FAOh$MC...$MD$w2yes, $w1$FSof course.$w4
Sorry.$w4 I got a bit carried away.$K
$F1$PI'll take over for now.$w3
Why don't you get some rest?$K
$F3$P$FAI'm all right$MC...$MD$K$P$F1$P$FSYou worry too much. Get some rest.$w2
That's an order.$w4 I'll do my best to manage.$K
$F3$P$FSYes$MC...$MD$w3Commander.$K
$=1000  $=0500$R�w�i��b|$B���-���O�Y-�J|$<$F3$FCL_IKE|$w6$F1$FS$F1$FCL_TIAMAT|Good morning, Ike.$w4 How are things going?$w3
Does everything look good?$K
$F3$PTitania.$w4 Did you get enough rest?$K
$F1$PEnough as could be expected, given
everything that's been going on.$w4 But
now, we've got some business to deal with.$K$PFirst, we need some new recruits.$w4
Oh,$w2 but our audience with King Gallia
comes first.$w5 Any word from the palace?$K
$F3$PNo, nothing yet.$K According to the laguz
who brought our food, $w2we should be
receiving word sometime soon, but$MC...$MD$K
$F0$FCL_SENERIO|$F0$PIke, I've got bad news!$w4
Look out the window!$K    $=0300$R�w�i��b|$B���-���O�Y-�J|$<$F1$FCL_IKE|$F1$PThat's not what I think, is it?$K
$F3$FCL_KILROY|$F3$PIf I'm not $w2imagining things,$w2
that's a squad of Daein soldiers.$w4
Why do they have to show up now?$K
$F4$FCL_BOLE|$F4$PWhat gives?$w4 We're inside Gallia's
borders, aren't we?$K$PThey must be out of their minds$w2
to pursue us this far!$K
$F0$FCL_OSCAR|$F0$PIf they've come this far, $w2I'm sure
getting out of here alive was never
one of their priorities.$K$F3$FD$F4$FD$F0$FD
$F1$P$MC...$MD$K
$F3$FCL_SENERIO|$F3$PWe're in trouble.$w4 They have us completely
surrounded.$w4 We cannot escape.$K
$F4$FCL_TIAMAT|$F4$PSo many of them$MC...$MD$w3and so few of us$MC...$MD$w3
It doesn't look good, does it?$K
$F1$PDoesn't matter.$w4 We have to fight.$w4
Greil Mercenaries, $w2ready yourselves!$K
$F4$PYes, sir!$K$F4$FD
$F3$PI'll begin formulating a
strategy $w2immediately.$K$P$F3$FD$N$UB$H  $=0300$R�w�i��b|$B���-���O�Y-�J|$<$F1$FCL_IKE|$F1$PThat's not what I think, is it?$K
$F3$FCL_OSCAR|$F3$PIf I'm not $w2imagining things,$w2
that's a squad of Daein soldiers.$w4
Why do they have to show up now?$K
$F4$FCL_BOLE|$F4$PWhat gives?$w4 We're inside Gallia's
borders, aren't we?$K$PThey must be out of their minds$w2
to pursue us this far!$K
$F3$PI don't know.$w4 If they've come this
far,$w3 I suspect they might be a
suicide squad.$K$F4$FD$F3$FD
$F1$P$MC...$MD$K
$F3$FCL_SENERIO|$F3$PWe're in trouble.$w4 They have us completely
surrounded.$w4 We cannot escape.$K
$F4$FCL_TIAMAT|$F4$PSo many of them$MC...$MD$w3and so few of us$MC...$MD$w3
It doesn't look good, does it?$K
$F1$PDoesn't matter.$w4 We have to fight.$w4
Greil Mercenaries, $w2ready yourselves!$K
$F4$PYes, sir!$K$F4$FD
$F3$PI'll begin formulating a
strategy $w2immediately.$K$P$F3$FD$N$UB$H   $=0300$R�w�i��b|$B���-���O�Y-�J|$<$F1$FCL_IKE|$F1$PThat's not what I think, is it?$K
$F3$FCL_OSCAR|$F3$PIf I'm not $w2imagining things,$w2
that's a squad of Daein soldiers.$w4
Why do they have to show up now?$K
$F4$FCL_KILROY|$F4$PWhat could they possibly be
thinking,$w2 coming this far into
Gallian territory?$K
$F3$PIf they've come this far, $w2I'm sure
getting out of here alive is not one
of their priorities.$K$F4$FD$F3$FD
$F1$P$MC...$MD$K
$F3$FCL_SENERIO|$F3$PWe're in trouble.$w4 They have us completely
surrounded.$w4 We cannot escape.$K
$F4$FCL_TIAMAT|$F4$PSo many of them$MC...$MD$w3and so few of us$MC...$MD$w3
It doesn't look good, does it?$K
$F1$PDoesn't matter.$w4 We have to fight.$w4
Greil Mercenaries, $w2ready yourselves!$K
$F4$PYes, sir!$K$F4$FD
$F3$PI'll begin formulating a
strategy $w2immediately.$K$P$F3$FD$N$UB$H $=0300$R�w�i��b|$B���-���O�Y-�J|$<$F1$FCL_IKE|$F1$PThat's not what I think, is it?$K
$F3$FCL_OSCAR|$F3$PIf I'm not $w2imagining things,$w2 that's
a squad of Daein soldiers.$w4 Why do
they have to show up now?$K
$F4$FCL_TIAMAT|$F4$PWhat gives?$w4 We're inside Gallia's
borders, aren't we?$K$PThey must be out of their minds$w2
to pursue us this far!$K
$F3$PIf they've come this far, $w2I'm sure
getting out of here alive is not one
of their priorities.$K$F3$FD
$F1$P$MC...$MD$K
$F3$FCL_SENERIO|$F3$PWe're in trouble.$w4 They have us completely
surrounded.$w4 We cannot escape.$K
$F4$PSo many of them$MC...$MD$w3and so few of us$MC...$MD$w3
It doesn't look good, does it?$K
$F1$PDoesn't matter.$w4 We have to fight.$w4
Greil Mercenaries, $w2ready yourselves!$K
$F4$PYes, sir!$K$F4$FD
$F3$PI'll begin formulating a
strategy $w2immediately.$K$P$F3$FD$N$UB$H $=0300$R�w�i��b|$B���-���O�Y-�J|$<$F1$FCL_IKE|$F1$PThat's not what I think, is it?$K
$F3$FCL_KILROY|$F3$PIf I'm not $w2imagining things,$w2
that's a squad of Daein soldiers.$w4
Why do they have to show up now?$K
$F4$FCL_BOLE|$F4$PWhat gives?$w4 We're inside Gallia's
borders, aren't we?$K$PThey must be out of their minds$w2
to pursue us this far!$K
$F1$PIf they've come this far, $w2they're
prepared to die.$w4 We let our guard
down, didn't we?$K$F3$FD$F4$FD
$F3$FCL_SENERIO|$F3$PWe're in trouble.$w4 They have us completely
surrounded.$w4 We cannot escape.$K
$F4$FCL_TIAMAT|$F4$PSo many of them$MC...$MD$w3and so few of us$MC...$MD$w3
It doesn't look good, does it?$K
$F1$PDoesn't matter.$w4 We have to fight.$w4
Greil Mercenaries, $w2ready yourselves!$K
$F4$PYes, sir!$K$F4$FD
$F3$PI'll begin formulating a
strategy $w2immediately.$K$P$F3$FD$N$UB$H   $=0300$R�w�i��b|$B���-���O�Y-�J|$<$F1$FCL_IKE|$F1$PThat's not what I think, is it?$K
$F4$FCL_TIAMAT|$F4$PUnless my eyes are deceiving me,$w3
that's a squad of Daein soldiers.$w4
Why do they have to show up now?$K
$F3$FCL_BOLE|$F3$PWhat gives?$w4 We're inside Gallia's
borders, aren't we?$K$PThey must be out of their minds$w2
to pursue us this far!$K
$F1$PIf they've come this far, $w2they're
prepared to die.$w4 We let our guard
down, didn't we?$K$F3$FD
$F3$FCL_SENERIO|$F3$PWe're in trouble.$w4 They have us completely
surrounded.$w4 We cannot escape.$K
$F4$PSo many of them$MC...$MD$w3and so few of us$MC...$MD$w3
It doesn't look good, does it?$K
$F1$PDoesn't matter.$w4 We have to fight.$w4
Greil Mercenaries, $w2ready yourselves!$K
$F4$PYes, sir!$K$F4$FD
$F3$PI'll begin formulating a
strategy $w2immediately.$K$P$F3$FD$N$UB$H   $=0300$R�w�i��b|$B���-���O�Y-�J|$<$F1$FCL_IKE|$F1$PThat's not what I think, is it?$K
$F3$FCL_KILROY|$F3$PIf I'm not $w2imagining things,$w2
that's a squad of Daein soldiers.$w4
Why do they have to show up now?$K$PWhat could they possibly be
thinking,$w2 coming this far into
Gallian territory?$K
$F1$PIf they've come this far, $w2they're
prepared to die.$w4 We let our guard
down, didn't we?$K$F3$FD
$F3$FCL_SENERIO|$F3$PWe're in trouble.$w4 They have us completely
surrounded.$w4 We cannot escape.$K
$F4$FCL_TIAMAT|$F4$PSo many of them$MC...$MD$w3and so few of us$MC...$MD$w3
It doesn't look good, does it?$K
$F1$PDoesn't matter.$w4 We have to fight.$w4
Greil Mercenaries, $w2ready yourselves!$K
$F4$PYes, sir!$K$F4$FD
$F3$PI'll begin formulating a
strategy $w2immediately.$K$P$F3$FD$N$UB$H   $=0300$R�w�i��b|$B���-���O�Y-�J|$<$F1$FCL_IKE|$F1$PThat's not what I think, is it?$K
$F4$FCL_TIAMAT|$F4$PIf my eyes are not deceiving me$MC...$MD$w2 That's
a unit of Daein soldiers.$K
I can't believe they would pursue us
all the way into Gallia$MC...$MD$K
$F1$PIf they've come this far, $w2They're
prepared to die.$w4 We let our guard
down, didn't we.$K
$F3$FCL_SENERIO|$F3$PWe're in trouble.$w4 They have us completely
surrounded.$w4 We cannot escape.$K
$F4$PSo many of them$MC...$MD$w3and so few of us$MC...$MD$w3
It doesn't look good, does it?$K
$F1$PDoesn't matter.$w4 We have to fight.$w4
Greil Mercenaries, $w2ready yourselves!$K
$F4$PYes, sir!$K$F4$FD
$F3$PI'll begin formulating a
strategy $w2immediately.$K$P$F3$FD$N$UB$H    $=0300$F1$FD$w5$F3$FCL_MISTs|$F3$PIke!$w2 Brother!$K
$F1$FCL_IKE|$F1$PMist!$w4 I want you and Rolf to
go in the back and hide!$K$P$F3$PBut, $w2Ike$MC...$MD$K
$F1$PJust do it now!$w4$FS Everything will be fine,
but I need you to do this,$w4 all right?$K
$F3$PMm$MC... $MD$w2All right.$w4 Be careful$MC...$MD$K$F1$FD$w5
$F3$P$Fc$MC...$MD$K
$Ub$H$F3$P$FdAh!$K$PIt's happening again$MC...$MD$w4
My medallion's glowing.$w2$K $R�w�i��b|$B���-���O�Y-�J|$<$F3$FCL_MISTs|$F3$P$FcMother$MC...$MD$w4 Father$MC...$MD$w5 If you can hear
me, $w2please$w4 watch over Ike.$K$PPlease. $w5Will you protect him?$K
$=1000 $R�㉺��b|$c1IKE|$s1All right, everyone, $w2are you ready?$w4
Greil Mercenaries, $w2move out!$K    $R�㉺��b|$c1KAMURA|$s1Huh?$w3 What's going on?$w4
All troops,$w3 attack!$K    $R�㉺��b|$c0ELAICE|$s0$MC...$MD$K
$c1IKE|$s1Huh?$w4
Who $w2are you?$K
$s0I$MC...$MD$w2I$MC...$MD$w4I'm a traveling mage.
My name is Ilyana.$K$PThis castle$MC...$MD$w4$Fc Oh$MC...$MD$K
$s1Hey, $w2are you all right?$K
$s0$FhI'm sorry$MC...$MD$w4
This rain is so c-cold.$w4
I feel like I'm f-$w1freezing$MC...$MD$K
$s1You don't look too good.$w4 Are you
sick? Do you need medicine?$K
$s0$Fd$FSYou're awfully kind, aren't you?$K
$s1You know,$w2 you don't look like
any Daein soldier I've ever seen.$K$PAre you really one of them, or have
they press-ganged you into service?$K
$s0$FAI was traveling with some merchants,
but we got separated.$K$PI came here to escape this rain,$w4 but
some soldiers in black found me.$w3 They
thought I was a Crimean refugee.$K
$s1Oh?$K
$s0I tried to tell them who I was,$w2
but they wouldn't believe me.$K$PThey said they would put me to the
sword if I didn't help fight you.$w4
I'm$MC...$MDvery sorry$MC...$MD$K
$s1Don't apologize. You didn't have
any choice. If it had been me,
I'd have done the same.$K$PBut listen, I think I've seen the
merchant convoy you were
traveling with in the castle!$K$PThere was a weapons vendor
named Muston, and I think a
woman named Aimee sold items$MC...$MD$K
$s0$FSThat's them!$w4 Oh, that's incredible! Are
they all unharmed? Where are they?$K
$s1They're fine, they're fine! In fact,
we've all come to an agreement,
and they're traveling with us now.$K$PI don't see any reason we should
go on fighting.$w2 If you're with them,
we can protect you from Daein.$K
$s0You're right!$w4 Yes, would you please
allow me to join your company, too?$K
$s1That sounds fine, Ilyana.$w4
This is a dangerous place. $w2Go ahead
and seek safety within the castle.$K$PWe'll hold off the enemy troops.$K
$s0No$MC... $MD$w2I'll fight, too.$K
$s1But $w2you're sick$MC...$MD$K
$s0$FAYou'll need some help. This isn't the
full force of Daein soldiers.$K$PMore of them are waiting$w2
in the forest.$w4 You need me.$K
$s1$MC...$MD$w2Well,$w4 I wish you weren't
right,$w3 but it sounds like we will
need your help.$K
$s0$FSI'm just glad to get away from those
awful black-clad soldiers.$K    $R�㉺��b|$c0ELAICE|$s0Forgive me$MC...$MD$K   $R�㉺��b|$c0ELAICE|$s0$FcOh$MC...$MD$K    $R�㉺��b|$c1KAMURA|$s1What? They still resist?$w3
Impossible!$K
Fight, dogs!$w4 Focus!$w3
Focus and press forward!$K  $R�㉺��b|$c0KAMURA|$s0You fool$MC...$MD$w4 What are you doing
on the front line?$w3 This is no place
for an officer!$K$PIf you die, $w2your army loses.$w4
Soldiers fight;$w2 officers lead.$w3
That is the foundation of war!$K
$c1IKE|$s1Hate to tell you this, $w2but I'm
not an officer, and I'm not in
the military.$K$PI fight with my men, and I bleed with
my men. I lead the Greil Mercenaries.
If I can't fight, I've no right to lead.$K
$s0Bah! $w5This is war, not some child's
game! The only thing that matters
here is who fights and who dies.$K $R�㉺��b|$c1SENERIO|$s1Ike!$w4 The enemy has taken the castle!$K
$c0IKE|$s0No! $w5Mist and the others$MC...$MD$K
$d1$c1TIAMAT|$s1Ike$MC...$MD$w4 I'm sorry, but$MC...$MD$w3 We've lost.$K
$s0I've lost$MC... $MDI've lost Mist.$w4
Father, $w2forgive me$MC...$MD$K   $R�㉺��b|$c1KAMURA|$s1Urgh$MC...$MD$w2aaa$MC...$MD$w4
Glory to$MC...$MD$w3to$MC...$MD$w3Daein$MC...$MD$K  $R�㉺��b|$c0IKE|Haa$MC...$MD$w3 There are$MC...$MD$w3
still more of them$MC...$MD$w4
Haa$MC...$MD$K$PEveryone, fall back to the castle!$w3
Regroup!$w4 Regroup within the castle!$K   $R�㉺��b|$c0IKE|$FcHaa$MC...$MD$w3haa$MC...$MD$w2
Ah$MC...$MD$K$P$d0$c0IKEa|$s0Blast! $w5Not yet$MC...$MD$w3 Not yet$MC...$MD$w2
We will not fall!$K  $R�㉺��b|$c0MISTs|$s0Brother!$K
$c1IKEa|$s1Mist?$w4 You're not supposed to be
out here! I told you to stay--$K
$s0$FcI don't care!$K
$d1$c1IKE|$s1Mist?$K
$s0$FhThere's no way we can escape!$w5
This is it, isn't it?$w3 We're all going
to die here, aren't we?$K
$s1Don't be foolish!$w3 No matter what
happens,$w2 I'm making sure you and
Rolf get out of here alive!$K$POnce you're out of danger,$w2 you go
straight to the palace and stay
with Princess Elincia.$K
$s0No!$w3 I'm not going anywhere.$w5
I'm staying here $w2with everyone!$w4
I'm staying with you!$K
$s1$MC...$MD$K
$s0As long as I'm with you, $w2I'm not
afraid to die.$w5 We'll see Mother and
Father.$w5 We'll all be together again.$K$PSo, $w2please$MC...$MD$w3 Stop telling me
to leave you.$w4 I can't.$w3 I can't
leave any of you again. $w5All right?$K
$s1All right.$w4 Don't leave my side.$K
$s0$Fd$FSThank you, $w2Brother.$K$d0
$s1But one thing$MC...$MD$w2you're not going
to see Mother $w1just yet.$K
$c0MIST|$s0What?$K
$s1I'm going to protect you.$w4
I'm not going to let you die.$K$PI$w2 gave Father $w1my word.$K
$s0Ike$MC...$MD$K $R�㉺��b|$c0IKE|$s0$MC...$MDHaa$MC...$MD$w2haa$MC...$MD$K
$c2MIST|$s2$MC...$MD$K
$c1KAMURA|$s1You took on the Daein army
with meager numbers,$w2 and you've
fought well.$w4 My compliments.$K$PHowever, it ends now.$w4
Prepare to die!$K
$s2$MC...$MD$K  $R�㉺��b|$c3DAYNE1|Aaah! $w2Noooo!!!$K    $R�㉺��b|$c0KAMURA|What was that? What happened?$K    $R�㉺��b|$c0KAMURA|$s0Cursed Gallian beasts$MC...$MD$w5 There are
only two of them! How could they
have brought my army to its knees!?$K$PHow$MC...$MD$w3 How are they so strong?$K
$d0$c0IKE|Is that$w3 why people fear the laguz?$K $R�㉺��b|$c1KAMURA|$s1Urgh$MC...$MD$w2aaa$MC...$MD$w4
Glory to$MC...$MD$w3to$MC...$MD$w3Daein$MC...$MD$K  $R�㉺��b|$s0$Fo$c0IKEa|$s0$MC...$MDHaa$MC...$MD$w2haa$w2$MC...$MD$K
$c2MISTs|$s2$Fh$MC...$MD$K
$c1DAYNE3|$s1So few soldiers, $w2and yet you
managed to defeat our general?$w4
You have fought well.$K$PBut it all ends here.$w4
Prepare to die!$K
$s2$Fc$MC...$MD$w3$K    $R�㉺��b|$c3DAYNE1|Aaah! $w2Noooo!!!$K    $R�㉺��b|$c0DAYNE3|Wh-what happened? What was that?$K $R�㉺��b|$c1DAYNE3|$s1Filthy beasts$MC...$MD$w5 So strong$MC...$MD$w3
It's incredible$MC...$MD$K
$c0IKE|$s0Is that$w3 why people fear the laguz?$K    $R�㉺��b|$c1DAYNE3|Glaaarr$MC...$MD$w2blasted$MC...$MD$w4
stinking$MC...$MD$w3beast$MC...$MD$K    $=1300$R�w�i��b|$B���-���O�Y-�J|$<$F1$FCL_MORDY|$F0$FCL_LETHE|$F3$FCL_IKE|$F4$FCL_MIST|$MC...$MD$K
$F3$PSo, uh$MC...$MD$w2 Are you two from the palace?
Did the king of Gallia send you?$K
$F1$P$FSHe did.$w4 I am Mordecai, warrior
of Gallia.$K$PYour hair is blue. $w2You are Ike.$w4
Is this correct?$K
$F3$PThat's right$MC--$MDI'm Ike.$w5
You saved us back there.$w4 Thank you.$K
$F1$PRanulf told me$w4 Ike is not a bad stranger.$K$PMordecai and Ike$MC...$MD$w2 We will become friends.$K
$F0$PYou don't know that.$w2 You don't
know if we can trust him. It's too
soon to tell.$K$PHe's a beorc. A human.$w2 You know
all humans have two faces.$K
$F1$P$FALethe!$K
$F3$PBeorc?$w4 What's that?$K
$F0$PThat's what you are.$K$PWe$w2 with the power are laguz.$w4
You soft, hairless things with no
power at all, you are called beorc.$K
$F3$PWhat did you say?$K
$F1$PLethe!$w4 You are being bad.$K$PThe king forbids this.$w4
We cannot fight with beorc!$K
$F0$PMost beorc $w2call us by hated names,$w2
look at us with eyes filled with scorn.$K$P"Sub-human"? Hss! Is that how beorc
treat their friends? Is that how beorc
treat their allies?$K
$F3$PYou're right$MC...$MD$w2 Some of us use that
name far too readily.$K$PI guess if we had thought about it, $w2we'd
have realized it's not a polite term, but$w4 we
didn't know you $w1by any other name.$K$PI'm sorry.$K
$F0$PYou knew no other name for us?$w4
Are we really so little to you, human?$K$PYou, $w1who forced us into slavery?$w2
How easily you forget.$K$PBut we laguz! $w1We remember.$w4 We
remember how we have suffered
at your hands.$K$PThe king can say whatever he likes,$w2
I $w2will not trust you. I warn you now$MC...$MD$w4
never speak to me in such a way!$K
$F1$PLethe$MC...$MD$K
$F4$FD$Ub$H$F4$FCL_SENERIO|$F4$PWhat's your point?$w4 Did you come all
this way to complain to us?$K$P$Fh$FSHa ha$MC... $MD$w2Typical sub-humans.$K
$F0$PScum!$w4 Those who use that name
are enemies of Gallia!$w2$K
$F1$PGrrr, $w2grraa, $w2sub-human$MC...$MD$w4
Enemy$MC...$MD$w4 He is $w2enemy$MC...$MD$K
$F4$P$FdYou think you're humans? The only
thing human about you is your conceit!$w4
You filthy, $w2hairy sub-human!$K
$F1$P$FcGraaaaoooooooow!$w5  $R�㉺��b|$c1LETHE|$s1Mordecai!$w4 Kill him!!$K
$c0SENERIO|$s0$Fo$MC...$MD$K   $R�㉺��b|$c0SENERIO|$s0Ike!$K
$c2IKE|$Fc$s2$w3Ow$MC...$MD$K
$d0$d2$c3LETHE|$s3What?$K
$c1MORDY|$s1I$MC...$MD$w3Ike$MC...$MD$K $R�㉺��b|$c1MORDY|$s1$MC...$MDIke, $w2I'm sorry$MC...$MD$w4
I have hurt you$MC...$MD$w4
I did not intend to hurt you.$K
$c0IKE|$s0Mordecai, $w2this injury$w2
is nothing.$w4 I'm fine.$K  $R�㉺��b|$c0SENERIO|$s0You're nothing but a beast.$K  $R�㉺��b|$c0IKE|$s0Soren!$w4 Stand down!$K    $R�w�i��b|$B���-���O�Y-�J|$<$F0$FCL_IKE|$F1$FCL_SENERIO|$F1$PWhy did you stop me?$K$PHe hurt you!$w4 He could have killed
you! We can't let him get away$MC--$MD$K$P$F0$PIf you hadn't provoked him,$w2
none of this would have happened.$w4
Right?$K
$F1$PBut$MC--$MD$w4 I only$w5$MC... $MD$FcI'm sorry$MC...$MD$K$F1$FD
$Ub$H$F3$FCL_MORDY|$F4$FCL_LETHE|$F0$PMordecai, $w2Lethe,$w4 I apologize on
behalf of my company.$w4
Please forgive Soren.$K$PIt's a poor excuse, but we recently
lost$MC...$MD$w3some companions.$w4 We're
tired, and we're not thinking clearly.$K
$F3$PIke $w2forgave Mordecai.$w4
So now I $w2forgive Soren.$w4
No one $w2need be angry.$K
$F4$PI$w2 apologize as well.
My behavior has been unkind.$K$PI forgot our mission,$w3 and I have
blundered terribly.$K
$F0$PMission?$K
$F4$PThe king wants to see you.$w4
We are here $w2to guide you$w2
to the royal palace.$K
$=1000  $R�w�i��b|$B���-���O�Y-��|$<$F0$FCL_WEAPON|$F1$FCL_TOOL|$F4$FCL_IKE|$F1$P$FSWell, hello$MC... $MD$w3You must be $w2the young
commander I've heard so much about.$w4
My,$w4 and you are a young one, $w2aren't you?$K
$F4$PAnd you $w2must be from the merchant caravan
Titania told me about.$w4 The one that asked$w2
to travel with us?$K
$F0$P$FSYep, $w2that's us.$w5 It must have been fate
that brought us all here together.$K$PIf you'll$w2 offer us protection,$w4 we'll
supply you $w2with the provisions you require.$w5
At a reasonable price, of course.$K$PWhat do you say?$w4 It's for the greater
good of us all, wouldn't you agree?$K
$F4$PWell$MC...$MD$w3it is a sound proposition.$K
$F0$PYes!$w3 Then we have an agreement.$w5
I'm the weapon merchant, Muston.$w2 I'll be
sure to stock the weapons you prefer.$K
$F1$PAnd I am Aimee, $w2a vendor of$MC...$MDvarious
goods.$w5 I have a wide variety of items
for sale.$w3 I hope you'll stop by soon.$K$P$F1$FD$F0$FD$F0$FS$F0$FCL_TRAIN|$F1$FS$F1$FCL_ANTIQUE|$F1$PThe name's Jorge.$w4 I buy things.$w5
Anything, really. You got any weapons or
items you don't need, $w2bring 'em to me.$K
$F0$PMy name's $w1Daniel.$w4
I'm a craftsman.$w5 I specialize in
made-to-order items.$K$P$F0$FD$F1$FD$F1$FCL_WEAPON|$F1$PThere's one last item to cover.$K$FS
If you'd like, $w2we can also act as a storage
warehouse of sorts,$w3 carrying your
extra things.$w5 What do you think?$K
$F4$P$FSThat would be fantastic. We recently
left our stronghold, and I was afraid
we'd have to carry our goods ourselves!$K$PI'm happy to take you up on your offer.$K
$F1$PVery good.$w2 Well then, $w2may our
enterprise be profitable for us all.$K   $R�w�i��b|$B�X�̑O-��|$<$F4$FCL_IKE|$F4$PI hear someone$MC... $MD$w4Is it
coming from over here?$K $=0500$R�w�i��b|$B�X-��|$<$F5$Fc$F5$FCL_TIAMAT|$F5$P$MC...$MDAh$MC...$MD$w4sniff$MC...$MD$K$P$MC...$MD$w2Why$w1$MC...$MD$w4
Gre-$w2Greil$MC...$MD$w2
Why?$w4 Why you?$K$PWhy did you$MC...$MD$w3have to$MC...$MD$w1sniff$MC...$MD$w4
Sniff$MC...$MD$w2 Why$w4$MC...?$MD$K
$=0500   $R�w�i��b|$B�X�̑O-��|$<$F3$FCL_IKE|$F3$P$MC...$MD$Fc$K
$=1000 $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_LOFA2|$F1$P$MC...$MD$K
$F3$FCL_IKE|$F3$PWhat's going on, Rolf?$K
$F1$P$FSOh, $w2Ike.$w4 If you're wondering
about Mist, $w2she just fell asleep.$K
$F3$PReally?$w3 Sorry, I didn't mean
to disturb you, Rolf.$K
$F1$PIt's all right. I don't mind.$K
$F3$PIt's getting late.$w4 You should get
yourself to bed.$K
$F1$PI will, but$MC...$MD$K$w4$FA$Fh$PUm$w2$MC...$MD$K
$F3$PWhat is it?$K
$F1$P$Fd$FSMist$w3 is just fine.$K
$F3$PHm?$K
$F1$PYou're here, Ike. $w5So$w3 she's fine.
I mean, she's going to be just fine.$K
$F3$PHuh?$K
$F1$PThat's all!$w4 Well, $w2good night.$K$F1$FD$w4
$F3$PRolf$MC...$MD$w3 Thank you.$K
$=1000    $R�w�i��b|$B���-���O�Y-��|$<$F1$FCL_IKE|$F4$FCL_BOLE|$F4$P$FSHey!$w2 Working already,$w4 Ike?$K$PIf you need any help, $w2just let me know.$K
$F1$PBoyd,$w4 how do you feel about this?$K
$F4$PAbout what?$K
$F1$PAbout me being the new commander.$w3
Before, $w2you hated the idea, right?$w4
So,$w3 I want to know the truth.$K
Will you $w2really take orders from me?$K
$F4$P$FAWell$MC...$MD$w5I know what you can do and what
you can't$MC...$MD$w4 I don't know if I want you
in charge if things get really dangerous.$K$PBut on the other hand,$w4 this is what
Commander Greil wanted$MC...$MD$w4 He had
faith in you, and$w4 I've got faith in him.$K
$F1$P$MC...$MD$K
$F4$PThe commander $w2hired both Oscar$w3
and me.$K$PWhen our dad died,$w4 I was the one who had
to care for baby Rolf$MC...$MD$w3 I had no clue
what I was supposed to do.$K$POscar received a discharge $w1from his military
service and came home,$w4 but life was hard.$K$PThat's when Commander Greil found us$MC...$MD$w3
He gave us jobs, $w2a place to sleep, $w2food on
our plates$MC...$MD$w4 He gave us our lives back.$K
$F1$PBoyd,$w3 you've all $w2worked off any debt
you may have owed him.$w4 You don't have
any obligation to me.$K
$F4$P$FSThis isn't about obligations anymore.$K
Commander Greil $w2always said we were
all part of one big family, didn't he?$K$PI'll do anything to protect my family$MC...$MD$w4
That's why $w2you can always count on me.$K
$F1$PI see.$K
$F4$PAnyway, that's all I wanted to say.$K
But don't you ever $w2try to hold us
at arm's length.$w4 You got that?$K
$F1$P$FSDon't worry about that.$w3 I'm going to
work you to the bone.$K
$F4$POh, $w2really?$w4 I'll take whatever
you can dish out!$w4 Try me!$K    $R�w�i��b|$B���-���O�Y-��|$<$F3$FCL_IKE|$F3$PRhys?$K
$F1$FCL_KILROY|$F1$P$FSIke$MC...$MD$K
$F3$PWhat were you doing?$K
$F1$PI was$w3 praying.$K
$F3$PFor my father?$K
$F1$PYes.$w2
You see, $Fhthe commander$FA$MC...$MD$w6$Fc
He$MC...$MD$w2 He$MC...$MD$w4$K
$F3$PRhys$MC...$MD$K
$F1$P$FhI'm sorry$MC...$MD$w2 I know $w2this$w3 must
be$MC...$MD$Fcso much harder$w1 on you$MC...$MD$w5
Forgive me$MC...$MD$K
$F3$P$MC...$MD$w2A long time ago,$w5 my father $w2told
me a story$MC...$MD$K$PIt was about the dead$MC... $MD$w3He said the more
tears we shed$MC...$MD$w4the more blessings they
receive $w2in the hereafter$MC...$MD$w3$K$PI$w3 envy you, Rhys.$w4 For some reason,$w2
I can't seem to cry at all$MC...$MD$K$PRhys, $w2if you could, shed a tear
for me, too.$w4 I'd be grateful.$K
$F1$P$Fd$MC...$MDI-$w3Ike.$w4
$FcI $w2would $w2be honored.$K
$F3$P$FS$MC...$MDThanks, Rhys.$w4
Thanks for caring$w3 so much$w4
about my father$MC...$MD$K
$=1000    �L      ��   	  ��     ��   &  �    0  �\   A  �   P  ��   a  ��   r  Ȭ   �  ��   �  ɸ   �  �    �  ��   �  �X   �  �   �  �@    ʴ    �  *  Ӝ  :  ��  F  �l  U  �(  a  �`  o  Ր  ~  �L  �  ��  �  �  �  ߀  �  ��  �  ��  �  �8  �  ��  �  �h  �         �     �  #  h  /  �  ;  �  I  �  W  
D  h  *x  y  �  �  P  �   �  �  /�  �  8|  �  @�  �  I4  �  M�    V�    _�  /  h|  B  m  U  t�  f  |l  y  ��  �  ��  �  �  �  �  �  �l  �  ��  �  �T  �  ��    ��    �L  "  ��  2  ��  B  ��  R  ��  b  �0  q  �h  �  ��  �  ��  �MS_09_BT MS_09_BT_ELAICE MS_09_BT_IKE MS_09_DIE MS_09_DIE_ELAICE MS_09_ED_01_00 MS_09_ED_01_00_1 MS_09_ED_01_00_2 MS_09_ED_01_00_2_2 MS_09_ED_01_00_2_2_B MS_09_ED_01_00_3 MS_09_ED_01_00_3_B MS_09_ED_01_00_4 MS_09_ED_01_00_4_B MS_09_ED_01_00_5 MS_09_ED_01_00_5_B MS_09_ED_01_00_6 MS_09_ED_01_00_6_B MS_09_ED_02_new MS_09_ED_04 MS_09_ED_05_02 MS_09_ED_06 MS_09_ED_06_X MS_09_ED_06_XX MS_09_ED_07 MS_09_EV_02 MS_09_GAMEOVER MS_09_INFO_01 MS_09_INFO_02 MS_09_INFO_02_1 MS_09_INFO_02_2 MS_09_INFO_03 MS_09_INFO_04 MS_09_INFO_05 MS_09_OP_01 MS_09_OP_02 MS_09_OP_03 MS_09_OP_05 MS_09_OP_05_2 MS_09_OP_05_3 MS_09_OP_06_01_A MS_09_OP_06_01_B MS_09_OP_06_02_3 MS_09_OP_06_02_A MS_09_OP_06_02_A_1 MS_09_OP_06_02_A_2 MS_09_OP_06_02_B MS_09_OP_06_02_B_1 MS_09_OP_06_02_B_2 MS_09_OP_06_02_B_3 MS_09_OP_06_02_C MS_09_OP_06_02_C_1 MS_09_OP_06_02_C_2 MS_09_OP_06_02_C_3 MS_09_OP_06_02_D MS_09_OP_06_02_D_1 MS_09_OP_06_02_D_2 MS_09_OP_06_02_D_3 MS_09_OP_06_02_D_4 MS_09_OP_06_03 MS_09_OP_06_03_x MS_09_OP_06_04A MS_09_OP_06_04B MS_09_OP_06_04C MS_09_OP_06_04D MS_09_OP_06_04E MS_09_OP_06_04F MS_09_OP_06_04G MS_09_OP_06_04H MS_09_OP_06_04X MS_09_OP_06_05 MS_09_OP_06_05_2 MS_09_OP_06_BASE MS_09_OP_07 MS_09_TK_ELAICE 