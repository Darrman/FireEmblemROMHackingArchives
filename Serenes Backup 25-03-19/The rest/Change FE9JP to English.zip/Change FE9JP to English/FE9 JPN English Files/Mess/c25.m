  t�  p        7                $RGMAP��b|$O3$GThe Crimean army $w2defeats General Petrine,$w3
one of King Ashnard's $w2feared Four Riders,
and finally arrives home.$K$P$Ub$HThe princess's return$w3 is met with the
jubilation $w2and tears of the retainers who
have managed to survive.$K$P"As long as we have Princess Elincia,$w3
Crimea will be liberated."$K$PThese are the words $w2that gave the people
hope $w2as they endured the harsh rule
of a conquering country.$K$PThe silent masses, $w2who long for the
restoration of their homeland, $w2slowly
begin to give voice to their dream.$K$PSurely, they think,$w3 this chance to see
Crimea freed $w2will not be wasted.$K$Ub$H  $R�w�i��b|$B���-�U��|$<$F1$FS$F1$FCL_GEOFFRAY|$F4$FS$F4$FCL_ULYSSES|$F1$PCan it be?$K
$F4$PThere is no mistake in my words.$w4
The princess has returned to Crimea!$K$PLady Lucia serves as her guide. $w2They
should be on their way here as we speak.$K
$F1$P$FAHow long it's been since we've seen
the princess...$K$PWe have been living for the day where we$w2
steal the eyes from Daein's army$w4 and
bring her home.$w3 And now it has come.$K
$F4$P$FAIndeed. For His Majesty, $w2for the Queen,$w2
and...$w4for Crown Prince Renning as well...$K$PWe must act as one $w2and support
our beloved Princess Elincia.$K
$F1$PYes. If all goes well...$w4$Fcour dearest wish will
soon come to fulfillment.$K
$F4$P$FSThere's no time to wait. If we wish to
properly$w4 greet the princess and her
retinue,$w2 there is much to be done.$K
$F1$P$Fd$FSRight!$w3 Let's let everyone know!$w4
We must divide the tasks and begin
preparations for a feast at once!$K
$F4$PAnd flowers must be prepared for the
princess's chamber!$w4 Oh, we mustn't
forget music and entertainment, either.$K
$F1$PI suppose I shall have to polish $w2the silver
tableware I was hiding, too.$K
$F4$P$FAYou? You possess such refined things?$w4
I figured a rustic boor like you would have
sold them for a lamb shank.$K
$F1$PI received the silver from His Majesty$w2
when I was awarded my knighthood...$w4 I have
been saving it for just such an occasion.$K
$F4$P$FSWell done!$w4 Get ready! $w2We are going to
be very, very busy! Ha ha! What a fantastic
day this will be!$K
$=1000 $=0700$R�w�i��b|$B�V����c�p|$<$F1$FCL_LUCHINO|$F3$FS$F3$FCL_ERINCIAh|$F4$FCL_IKE2|$F4$PThe Crimean retainers are waiting for us at
this Castle Delbray?$K
$F1$PYes. In your absence, Princess, we used the
cellars beneath the castle $w2as a secret
meeting place.$K$PIt is from there that we contacted other
retainers who were hiding throughout
the land.$K
$F4$PAnd no one was discovered?$K
$F1$PWe disguised ourselves as merchants or
peasants, $w2and Daein looked right past
us. Their arrogance is without equal...$K$P$FSHowever, $w2now that we've heard of your
return, $w2we are bringing out our hidden
Crimean armor$w4 and polishing away!$K
$F4$FD$F3$PMerchants? Ha! Geoffrey is one thing, $w2but
I cannot imagine Bastian as a shopkeeper.$K
$F1$PNo one could.$w4 That's why he dressed
as a street performer.$K
$F3$PNow that, $w2I can see!$w4 I'm sure it
suited him perfectly. Did he juggle and
gambol about? Hee hee!!$K
$F1$PAnd Geoffrey... $w2Never have you seen
a merchant with such perfect posture!$K
$F3$PHee hee hee!$w4 That sounds just like him.$K  $R�w�i��b|$B�V����c�p|$<$F3$FCL_IKE2|$F4$FS$F4$FCL_MIST|$F4$PPrincess Elincia $w2seems to be having
a wonderful time.$w4 She's been smiling
and laughing for hours.$K
$F1$FS$F1$FCL_LAY|$F1$PIt seems she and Lucia $w2grew up together.$w5
She feels completely at ease around her.$K
$F3$PThe princess seemed to be of good cheer$w2
when she was with us as well, but...$w4
I suppose she was putting on a brave face.$K
$F0$FS$F0$FCL_TIAMAT|$F0$PWhen I see her in this light, $w2I'm reminded
that she's still only a young woman.$K$PWhat we see now $w2is the princess as she
was before Daein's attack.$w5 That $w2is the
true Princess Elincia.$K
$F1$PIt's good to be home, isn't it?$K
We've still many battles ahead, $w2but
for tonight, $w2we should relax and
let ourselves forget our cares.$K$PNo one can continue under this much
stress forever, $w2right?$K
$F3$P$FSI suppose you're right.$K    $R�w�i��b|$B���-�U��|$<$F6$FCL_GEOFFRAY|$F6$PToday's the happy day the princess returns,$w3
yet the goddess sees fit to bring rain...$K
$F1$FS$F1$FCL_ULYSSES|$F1$PCalm rain is like a kiss upon the face.
A scent and feel unparalleled in kind.$w4
Reunions in the rain are most heartfelt.$K$P$F6$FD$F3$FCL_GEOFFRAY|$F3$PSay, $w2Bastian...$w4 How far do you suppose
the princess and her escort have come?
Why aren't they here yet?$K
$F1$P$FA...Sigh. Listen, friend.$w4 You have asked
me that same question$w3 fifty-eight times.
And I have responded fifty-seven times.$K$PBut now, fifty-eight comes anon...$w5
You. Need. To. Calm. Yourself.$K
$F3$PI know, but--$K
$F1$PIt's only a little while longer.$w4 Make no
mistake, our princess will arrive today.$K$PI understand your impatience, I really do.$w2
But you're the general of our little army.
If you act so, the men will react in kind.$K
$F3$PYou, $w1you're right...$K
$F1$P$FcA true knight is the essence of composure.
Take a deep breath. Breathe in...and out...$K
$F3$P$Fc...$w2Sigh$w2...$w3
...$w2Woooooo$w2...!
...$w2Whew$w2...$K
$F1$PSee? Don't you feel better?$K
$F3$P...$w2Hmmm$w2...$w3
$FoAh, blast! It's no good!$w5 I'm going to
go...uh... Check on...stuff!$K$P$F3$FD$w6
$F1$P$Fo$FSWhat am I supposed to do with him?$K$F1$FD $R�㉺��b|$c0GEOFFRAY|$s0$FSThey're here! I see them!$K
$Ub$H$c2ULYSSES|$s2What? Really?$K
$s0That's them, isn't it?$w4
The princess's army?$K$d2
$d0$s0$FS$c0ULYSSES|$s0Where? $w2Show me where
you're looking.$K$w4$Ub$H$P$FAGeoffrey, $w2that's not the princess...$w5
Those are...$w4Daein troops!$K
$Ub$H$c2GEOFFRAY|$s2What? No! Please tell me
you're joking...$K   $R�w�i��b|$B����-���J|$<$F3$FS$F3$FCL_LUCHINO|$F4$FCL_ERINCIAh|$F3$POnce we cross the hills, we'll be in Delbray
territory.$w4 Count Bastian went ahead of us,
so they should know of your return by now.$K$PSpeaking of which...here he comes now!$w2
I suppose he couldn't wait any longer$w2
and came riding to meet you.$w3 How sweet.$K
$F7$FCDUMMY|$F7$PPrincess Elincia!$w4 Lady Lucia!$K$F7$FD
$F4$P$FSBastian!$w4 There's no need for you to
rush so! I'm $w2coming in your direction
anyway--$K$P$F4$FD
$Ub$H$F0$FCL_ULYSSES|$F0$PWe've been attacked!$w4 Castle Delbray is
surrounded by enemy troops!$K
$F4$FCL_ERINCIA|$F4$PNo!$K
$F3$P$FAIt can't be...$K
$F0$PGeoffrey's $w2acting as a decoy.$w4
You must $w2continue on this road to
the southwest.$K
$F3$PSo the enemy's found us, eh?$K$P$F3$FD$F1$FCL_LUCHINO|$F1$PNothing to do about it but change course.
I'll lead you to another hiding place.$K
$F4$PWh-$w2what are you saying, Lucia?$w4
We must help Geoffrey! $w5Bastian?$K
$F1$P$FcLuck was not with us, Princess. We have no
choice.$w4 We'll have to abandon our
companions in Castle Delbray.$K
$F4$PNo!! $w2We will not!!$K$PGeoffrey$w3 and the others have survived so
much already...$w2 I will not abandon them!$K
$F1$P$FdPrincess, $w2please understand. If we
could do so without danger to you, we
would gladly risk our lives to go back.$w2$K
$F4$PWe cannot do this!$w4 Please, Lucia! We
must go to the castle!$w5 ...Bastian! You must
not do this thing!$K
$F0$PGeoffrey is a knight. $w5In the name of our
friend's honor,$w3 Princess, you must escape.$K
$F4$PNo...$w4 No! They've survived this long!$w4
They're alive!$w2$Fc$K$PNO!!!$K$P$F4$FD
$F3$FCL_IKE2|$F1$PGeneral Ike... $w2We don't have much time.$K$PWhile we stand here squabbling, $w2Daein
scouts may spot our position.$w4 Please
move the army southwest on this road.$K
$F3$PNo.$K
$F1$PPardon?$w4 What did you say?$K
$F3$PWe're going to the castle. If it's surrounded
by Daein troops, $w2we cut our way through
and join the other knights. $w5Understood?$K
$F1$PWeren't you listening?$w4 I said we had
no choice but to leave them behind!$K$PThey were lost to us the moment the
enemy discovered and surrounded them!$K
$F3$PThey're not so lost $w2that we can't
take them back.$K
$F1$PYou are the general of Crimea's army, are
you not? ...Even if only for the moment?$K$PI would hope that you would act more
in accordance with your responsibilities.$K
$F3$PI didn't choose or ask to be general.$w2
I was put here by matters of
time and circumstance.$K$PBut, $w2as a mercenary, I have a contract
with Princess Elincia that's still in effect.
That means she's my employer.$K$PAnd right now, my employer $w2says she wants
to go and save the people stuck in that
castle.$w4 Is that correct, $w2Elincia?$K
$F4$FCL_ERINCIA|$F4$PYes.$w4 I don't want...$w2 I don't want
anyone else$w4 to be sacrificed.$K
$F3$PSo...$w4we're going to help them.$K$PIf you're so worried about the princess,$w2
I'll leave her here with you, $w2and you
can keep her safe.$K
$F4$PMy lord Ike...$K
$=0800  $R�w�i��b|$B����-���J|$<$F2$FCL_IKE2|$F2$PAttention! $w2Greil's Mercenaries, move out!$w4
The enemy awaits, and we go to meet him!$K
$=1500    $R�㉺��b|$c0GEOFFRAY|$s0Until the princess's army is out of sight,
we must not let the enemy spot them!
Do what you must to draw their attention!$K
$c1CRIMEA1|Yes, sir!$K    $R�㉺��b|$c1IKE2|$s1They're coming into view!$w5
Combat formations!$K $R�㉺��b|$c1IKE2|$s1Our goal $w2is to rescue those
knights near the castle!$w4
Attack!$K  $R�㉺��b|$c0RIHITORU|$s0These Crimean refugees are no easy
meat.$w4 And there are more of them
than I expected. Hmm...$K
$c1DAYNE3|$s1G-$w2General Rikard!$w4 Enemy
reinforcements are approaching from
the east!$K
$s0What?$K
$s1It appears to be troops from Princess
Crimea's army!$K
$s0The army that brushed aside our
troops in Daein and defeated General
Petrine at the Riven Bridge?$K$PThey're marching towards us?$K$P$FSFantastic!$w4 I was getting bored
hunting stragglers.$K$PLet's smash all of these curs $w2and
wrap ourselves in glory.$K  $R�㉺��b|$c1CRIMEA1|$s1G-$w2General Geoffrey!$w4 It's the
Crimean army!$w3 Princess Elincia's army
is headed this way!$K
$c0GEOFFRAY|$s0Fools!$w4 What are you thinking, Bastian?$w4
Oh, Princess...$w4 It's not too late.$w2$Fc
Please take wing and flee!$K $R�㉺��b|$c1ERINCIA|$s1Lucia, $w2Bastian...$w4 Are you sure
you want to do this?$K
$c0ULYSSES|$s0The words of Ike ring yet on in my
ears...$K
$d0$c0LUCHINO|$s0We were so trapped by our own ideas
that we were unable to sympathize
with your feelings.$w4$Fc I'm terribly sorry.$K
$s1Because the two of you $w2think to put
me above all else, $w2you say you will
sacrifice your lives for me.$K$PYet...$w4 Even if I'm able to borrow of
Ike's strength and win back Crimea...$K$PIf the cost of that victory $w2is the
lives of the two of you,$w4
I shall never smile again.$K
$FcAnd joy?$w4 Never again would
that emotion fill my heart...$K
$s0$FdPrincess Elincia...$K
$s1$FdPlease aid Ike and rescue Geoffrey
and the others. Then return to me.$w3
Come back alive.$K
$d0$s0$FS$c0ULYSSES|$s0For you, we would the world itself
depart.$K$d1
$c1LUCHINO|$s1We'll be back.$K    $R�㉺��b|$c0DARKKNIGHT|$s0Is that the Crimean army?$w4
...$w2Where is Gawain's son?$w4
...Ah...$w2 He's much improved...$K$PHe is his father's son after all.$w2
Contrary to my initial estimation,$w2
he may prove to be worthy.$K   $R�㉺��b|$c0IKE2a|$s0What?$w4 Him...$w4
It's him!$K   $R�㉺��b|$c0ULYSSES|$s0H-$w2hold a moment!$w4
Please, my brave general!$K
$c1IKE|$s1You again?$K
$s0I was but a humble court official in$w2
the service of our late king.$w4 My
name is Bastian, Count of Fayre.$K$PAllow me to give you proper greeting
and respects, $w2General Ike.
Many thanks are due to you!$K
I am here to formally request $w2your
permission to join $w2in the
battle taking place in the--$K
$s1Shut up!$K
We're in combat!$w4 If you want to
prattle on and on like this, $w2do so
after we defeat the enemy!$K$d1
$s0Oh, yes, but of course...$w4 Well!
It seems I've found yet another$w3
font of good humor...$w4 Hmph.$K   $R�㉺��b|$c0LUCHINO|$s0General Ike! Allow me to apologize
for my earlier remarks! I've a selfish
request, but... I would like to join--$K
$c1IKE|$s1Yeah, all right, fine. Now hurry up!$K
$s0Eh?$K
$s1If you've got the time to apologize,
you've got time to take out some
enemies!$K
$s0$FSOf course! To save my companions,
I will give my all!$K
$s1$FSFantastic. Now let's go!$K    $R�㉺��b|$c0IKE|$s0Are you Sir Geoffrey?$w4$K
$c1GEOFFRAY|$s1Eh?$w4 Who are you?$K
$c0IKE|$s0I'm Ike.$w4 I'm leading the Crimean
army $w2for Princess Elincia!$K
$s1The princess, $w2where is she?$K
$s0Don't worry. I didn't bring her to the
battlefield with me.$K
$s1$FSI see...$w3 Thank goodness...$w4
Thank you for that regard!$K
$s0Are the other soldiers $w2inside
the castle?$K
$s1Yes. $w5I'm sure they're staving off any
attacks by enemy infiltrators.$K
$s0Good. $w2I'm glad we made it in time.$w4
Let's combine forces and finish this!$K  $R�㉺��b|$c0ULYSSES|$s0Are you well,$w3 my friend?$w4$K
$c1GEOFFRAY|$s1Bastian...?$w4 Why did you come back?$K
$s0I'll explain it to you later!$w5
For the sake of the princess,$w2
expend your energy on living!$K
$s1Understood!$K  $R�㉺��b|$c0LUCHINO|$s0$FSGeoffrey!$w4 I'm so glad we made
it in time!$K
$c1GEOFFRAY|$s1Lucia, my sister...$w4 What are you
doing? Why did you leave the side
of the princess!$K
$s0$FAThere's no time to discuss it now!$K
Just know that she is safe.$w5
If you want to see her yourself,$w3
you'd best $w2try and survive!$K$d0
$s1Sister! Wait! ...Blast!$K   $R�㉺��b|$c0KEVIN|$s0Crimean Royal Knight, Fifth Platoon
Captain Kieran reporting for duty, sir!$K
$c1GEOFFRAY|$s1Kieran!$w4 You $w2live?$K
$s0$FSYes sir, General! I was taken prisoner
by Daein$w2 and held in the dungeon
of Canteus Castle.$K$POh, it was a vile place! They tried all
manner of terrible tortures on me...
but I resisted to the last!$K
Then I was freed by a company of
mercenaries in the hire of
Princess Elincia!$K$PSince that time, $w2I have been
faithfully at the side of the princess$w2
protecting her from all harm!$K
$s1Is the princess in good spirits?$K
$s0She is!$w3 General Geoffrey,$w2 it is her
great wish that you live, $w2so that she
may see you once again!$K
$s1Is that...so?$w4 Very well!$w3 Now that
I've heard that, $w2I must stay alive
at any cost!$K
Rally your hearts, men of Crimea!$w4
We will fight and we will win!$w3
The princess needs her castle!$K    $R�w�i��b|$B���Ƃ̓���-����|$<$F4$FCLME|$F1$FCL_WOMAN2|Oh, $w2thank the goddess!$w4 The Crimean
army has arrived.$K$PWe who have suffered so much under
Daein's rule$w3 will finally be free!$w4
We can put our faith in that, $w2can't we?$K$P$FSIf there's anything we can do to help,$w2
we'll do it.$w4 Please, $w2rescue our
beloved Crimea.$K  $R�w�i��b|$B��-�J|$<$F1$FS$F1$FCL_MAN2|$F4$FCLME|$F1$PYou're part of the army $w2that brought
the princess, aren't you?$w4
Oh, you've done a great thing!$K$PI've been hiding this scroll$w3 so I could
give it to you.$K$PUse it $w2to drive Daein out of our homeland!$w4
You can do it!$K   $R�㉺��b|$s0$Fh$c0IKE2|$s0Urgh$w2gg... $w5I'm...$w2$Fc
...$w4not strong...$w2enough...yet...$K
$c1DARKKNIGHT|$s1Is that all you have?$w4 It seems you
do not possess the talents to surpass$w2
your father after all.$w4 A pity.$K    $R�㉺��b|$c0IKE2|$s0I've found you at last.$K
$c1DARKKNIGHT|$s1Hmph.$w4 You see me, and instead
of fleeing, $w2you come to face me.
Interesting...and foolish.$K
$s0I will keep challenging you until I have$w2
avenged my father!$K
$s1There will be no next time.$w4
I will $w2snuff the life from your
breast here today.$K
$s0I $w2will not lose!$w4
Ready yourself!$K    $R�㉺��b|$c0DARKKNIGHT|$s0Fool!$w4 Run now, $w2and I'll let you live.$K   $R�㉺��b|$c1DARKKNIGHT|$s1You're not as overly clumsy as I had
feared.$w4 It is regrettable$w2 that
your weapon is so poorly made.$K
$c0IKE2|$s0Why do my attacks have no effect?$K
$s1My armor is blessed by the goddess.
Only weapons that are also blessed
can so much as scratch it.$K
$s0Grrr...$w3 So common weaponry is
useless? Is that it?$K
$s1You should not worry about such
trivialities. You possess the sacred
blade Ragnell, do you not?$K
$s0Ah!$K
$s1It is the counterpart $w2to my blade,
Alondite.$w4 Tell me you were not idiot
enough to leave it in that place.$K$PYou took it with you, did you not?$w4
Along with your father's corpse?$K
$s0That...that sword?$w4 The one you threw
to my father $w2like an act of charity?$w4
The one he refused? That's Ragnell?$K
$s1I claim victory today.$K$PWhen next we meet, bring Ragnell.
Without the proper weapon,$w2
I grow bored.$K
$s0...$K  $R�㉺��b|$c0GEOFFRAY|$s0Glory to...Crimea!$K
Sister...$w3Bastian...$w4
Protect...$Fc$w2the...$w2princess...$K $R�㉺��b|$c0RIHITORU|$s0I am Rikard! Your corpse will be the
sustenance that feeds my hunger
for fame!$K  $R�㉺��b|$c0RIHITORU|$s0Are you the dog of a general who led
his forces to victory over General
Petrine?$w4 Speak your name!$K
$c1IKE2|$s1Ike.$K
$s0Ike!$w4 My battle with you will send
my own name soaring to new heights
of glory!$w4 Now... Die!$K    $R�㉺��b|$c0RIHITORU|$s0Oh, how I've missed you half-breeds!$w4
$FSIt's been so long since I've
hunted your kind!$K   $R�㉺��b|$c0RIHITORU|$s0Birds from the southern isles...$w4
Can you be as strong as I've heard?
Now's my chance to find out!$K    $R�㉺��b|$c0RIHITORU|$s0Your traitorous blood will decorate
the blade of my axe. $w2Long
live my glorious name!$K $R�㉺��b|$c0RIHITORU|$s0Killing one who cannot fight$w2
will gain me no glory...$w2 But
you must die nonetheless!$K   $R�㉺��b|$c0RIHITORU|$s0No matter one's proven deeds,$w4
...one defeat unmans us all...$w4
And so...it ends...$K  $R�㉺��b|$c0TIAMAT|$s0Ike! The castle has fallen
to the enemy!$K
$c1IKE2|$s1Curses! We were too slow.$K   $R�㉺��b|$c0DARKKNIGHT|$s0And yet another general of Daein
is defeated...$K$PI wonder how powerful you will
become, $w2army of Crimea.$w4
I look forward to our next meeting...$K $R�w�i��b|$B���-��-��|$<$F1$FCL_ERINCIA|$F3$FCL_IKE2|$F1$PMy lord Ike!$K
$F3$PPrincess Elincia!$w4 So $w2you came after all.$K
$F1$P$FSThanks to your words, $w2both of my friends$w2
came to understand how vital it was.$K
$F3$PI don't understand the feelings of knights.$w3
But, $w2I do understand how important
your former retainers are to you.$K$PAnd I also understand the strong support
with which they provide you.$K$P$FSI'm happy $w2we were able to
save them.$K
$F1$PAs am I!$K
$F3$P$FAAll right, $w2shall we return?$w4
If I'm going to be fighting with them,$w4
I should probably introduce myself.$K
$F1$P$FAWait, $w2my lord Ike.$K
$F3$PYes?$K
$F1$PAs you said, $w2Lucia and the others$w2
are very important to me. They are family.$w3
I may presume too much,$w4 but...$w4well...$K$PMy lord Ike, $w2you and the others are
also irreplaceable to me, so...$w4
I ask $w2for your continued support!$K
$F3$P$FSOf course. $w2It's an honor.$K $R�w�i��b|$B���-��-��|$<$F1$FCL_ERINCIA|$F3$FCL_IKE2|$F1$PMy lord Ike!$K
$F3$PPrincess Elincia!$w4 So $w2you came after all.$K
$F1$P$FSThanks to your words, $w2both of my friends$w2
came to understand how vital it was.$K
$F3$PI don't understand the feelings of knights.$w3
But, $w2I do understand how important
your former retainers are to you.$K$PAnd I also understand the strong support
with which they provide you.$K$PI only wish we had been able to save
Sir Geoffrey as well...$K
$F1$PAs do I.$K   $R�w�i��b|$B���-��-��|$<$F1$FCL_ERINCIA|$F3$FCL_IKE2|$F1$PMy lord Ike!$K
$F3$PPrincess Elincia!$w4 So $w2you came after all.$K
$F1$P$FSThanks to your words, $w2both of my friends$w2
came to understand how vital it was.$K
$F3$PI don't understand the feelings of knights.$w3
But, $w2I do understand how important
your former retainers are to you.$K$PAnd I also understand the strong support
with which they provide you.$K$PI'm happy $w2we were able to
save them.$K
$F1$PBut...Bastian was lost...$K
$F3$PNothing would have pleased me more than
to have saved everyone.$w4 It's a shame.$K
$F1$P$FcI...I know...$K   $R�w�i��b|$B���-��-��|$<$F1$FCL_ERINCIA|$F3$FCL_IKE2|$F1$PMy lord Ike!$K
$F3$PPrincess Elincia!$w4 So $w2you came after all.$K
$F1$P$FSThanks to your words, $w2both of my friends$w2
came to understand how vital it was.$K
$F3$PI don't understand the feelings of knights.$w3
But, $w2I do understand how important
your former retainers are to you.$K$PAnd I also understand the strong support
with which they provide you.$K$PI only wish we had been able to save
Sir Geoffrey as well...$K
$F1$PAnd...Bastian was lost as well...$K
$F3$PNothing would have pleased me more than
to have saved everyone.$w4 It's a shame.$K
$F1$P$FcI...I know...$K  $R�w�i��b|$B���-��-��|$<$F1$FCL_ERINCIA|$F3$FCL_IKE2|$F1$PMy lord Ike!$K
$F3$PPrincess Elincia!$w4 So $w2you came after all.$K
$F1$P$FSThanks to your words, $w2both of my friends$w2
came to understand how vital it was.$K
$F3$PI don't understand the feelings of knights.$w3
But, $w2I do understand how important
your former retainers are to you.$K$PAnd I also understand the strong support
with which they provide you.$K$PI'm happy $w2we were able to
save them.$K
$F1$PBut...Lucia was lost...$K
$F3$PNothing would have pleased me more than
to have saved everyone.$w4 It's a shame.$K
$F1$P$FcI...I know...$K $R�w�i��b|$B���-��-��|$<$F1$FCL_ERINCIA|$F3$FCL_IKE2|$F1$PMy lord Ike!$K
$F3$PPrincess Elincia!$w4 So $w2you came after all.$K
$F1$P$FSThanks to your words, $w2both of my friends$w2
came to understand how vital it was.$K
$F3$PI don't understand the feelings of knights.$w3
But, $w2I do understand how important
your former retainers are to you.$K$PAnd I also understand the strong support
with which they provide you.$K$PI only wish we had been able to save
Sir Geoffrey as well...$K
$F1$PAnd...Lucia was lost as well...$K
$F3$PNothing would have pleased me more than
to have saved everyone.$w4 It's a shame.$K
$F1$P$FcI...I know...$K    $R�w�i��b|$B���-��-��|$<$F1$FCL_ERINCIA|$F3$FCL_IKE2|$F1$PMy lord Ike!$K
$F3$PPrincess Elincia!$w4 So $w2you came after all.$K
$F1$P$FSThanks to your words, $w2both of my friends$w2
came to understand how vital it was.$K
$F3$PI don't understand the feelings of knights.$w3
But, $w2I do understand how important
your former retainers are to you.$K$PAnd I also understand the strong support
with which they provide you.$K$PI'm happy $w2we were able to
save them.$K
$F1$PBut...Lucia and Bastian were lost...$K
$F3$PNothing would have pleased me more than
to have saved everyone.$w4 It's a shame.$K
$F1$P$FcI...I know...$K    $R�w�i��b|$B���-��-��|$<$F1$FCL_ERINCIA|$F3$FCL_IKE2|$F1$PMy lord Ike!$K
$F3$PPrincess Elincia!$w4 So $w2you came after all.$K
$F1$P$FSThanks to your words, $w2both of my friends$w2
came to understand how vital it was.$K
$F3$PI don't understand the feelings of knights.$w3
But, $w2I do understand how important
your former retainers are to you.$K$PAnd I also understand the strong support
with which they provide you.$K$PI only wish we had been able to save
Sir Geoffrey as well...$K
$F1$PAnd...Lucia and Bastian were lost as well...$K
$F3$PNothing would have pleased me more than
to have saved everyone.$w4 It's a shame.$K
$F1$P$FcI...I know... Still...so much death...$K  $R�w�i��b|$B���-��-��|$<$F1$FCL_GEOFFRAY|$F3$FCL_ERINCIA|$F1$PPrincess!$K
$F3$PGeoffrey!$K
$F1$PPrincess...$w4 Ah, to behold you again...$w4
It's... It's...$K
$F3$PIf you had lost your life today, $w2this
reunion would not be taking place.$w4
Geoffrey, $w2do you hear me? Be careful!$K
$F1$PYes, Princess.$w4 Lucia...$w4told me of what
occurred. Our country and princess$w2
now exist as one.$K$PIt was never our intent to sacrifice your
feelings $w2for the sake of the nation.$w4
Please forgive us.$K
$F0$Fc$F0$FS$F0$FCL_ULYSSES|$F0$PBut soft!$w3 What luck that we do feel
fate's kiss? Anon, the clouds do part,$w2
the rains do stop.$K$PHeaven itself $w2does sing and thus rejoice.
At the return of our one true ruler!$K$Fd$POh, Princess...$w4 Until world's end, $w2do you
we vow to follow! We are planets of your
fair blazing sun!$K
$F4$FCL_LUCHINO|$F4$PNo longer will we$w4 think of honor and
dying in so cavalier a fashion.$K$PNo matter the difficulties we face,$w4 we
will choose the road that allows us to
continue living at your side.$K    $R�㉺��b|$s0$FS$c0ERINCIA|$s0Geoffrey, $w2Bastian, $w2Lucia...$w4
Thank you.$w3 Thank you.$w4
I am...$w3so very happy.$K$P$FAWith you at my side,$w3 I want to
retake $w2the kingdom of Crimea.$w4
Please, lend me your strength.$K
$s1$Fc$c1GEOFFRAY|$s1Of course!$K$d1
$s1$FS$c1ULYSSES|$s1For our fair sun, we would this
life forswear.$K$d1
$s1$FS$c1LUCHINO|$s1To you, Princess Elincia, we three$w2$Fc
pledge our eternal loyalty.$K   $R�㉺��b|$c0IKE2|$s0Why appear now?$w4 Do you mean to
tell me $w2you purposely waited until
the battle was over?$K
$c1DARKKNIGHT|$s1Hmph.$w4 I know how your mind works.
I assumed you would attack the
moment you saw me.$K$PBut perhaps you've learned to judge
the importance of time and place.$K
$s0To a mercenary, nothing's more
important than the contract between
him and his employer.$K
$s1Shall we call off our contest then?$w4
When you die here, you'll be in
breach of contract after all.$K
$s0That's not a problem.$w4 All I have to
do is win...$w5 Ready yourself!$K
$s1Hmph.$K  $R�㉺��b|$c0DARKKNIGHT|$s0You're not as overly clumsy as I had
feared.$w4 It is regrettable $w2that
your weapon is so poorly made.$K
$c1IKE2|$s1Why do my attacks have no effect?$K
$s0My armor is blessed by the goddess.
Only weapons that are also blessed
can so much as scratch it.$K
$s1Grrr...$w3 So common weaponry is
useless? Is that it?$K
$s0You should not worry about such
trivialities. You possess the sacred
blade Ragnell, do you not?$K
$s1Ah!$K
$s0It is the counterpart $w2to my blade,
Alondite.$w4 Tell me you were not idiot
enough to leave it in that place.$K$PYou took it with you, did you not?$w4
Along with your father's corpse?$K
$s1That...that sword?$w4 The one you threw
to my father $w2like an act of charity?$w4
The one he refused? That's Ragnell?$K
$s0I claim victory today.$K$PWhen next we meet, bring Ragnell.
Without the proper weapon,$w2
I grow bored.$K$d0
$s1...$K
$=1500    $R�w�i��b|$B�V��-��|$<$F4$FCL_MARCIA|$F4$PAh!$w4 Ike!$w4 There, hiding in the shadows
of that tent! $w2Grab him!$K
$F1$FCL_IKE2|$F1$PHuh?$w4 What?$K$F1$FD
$F0$FCL_IKE2|$F1$FCL_MAKAROV|$F1$PHey! $w2Ouch!$w4 Come on,$w2 you gotta let me go!$K
$F4$PStop whining you little baby!$w2
Get over here!$K$F1$FD
$F3$FCL_MAKAROV|$F4$PYou spineless sop!$w4 You never learn, do you?$K
$F0$PWhat's going on?$K
$F4$PListen to this, $w2Ike!$w4 While I was changing
my clothes, $w2my dear brother here $w2tried
stealing from my purse again!$K
$F3$PDon't do this here! $w2You don't need to tell
the whole camp about it, do you?$K
$F4$PWho's created this situation in the first
place!$w4 And here I was $w1thinking that
you'd finally turned yourself around...$K
Even as we speak, $w2Mother is at home
weeping in her soup! You chowderhead!$K
$F3$P$FSDon't worry about Mom!$w4
Dad's there to take care of her.$K
$F4$PYou $w2brainless $w2eunuch! $w2Gaaaaaa!!!$w2$K
$F3$P$FAM-$w2Marcia!$w4 Ow! Ow!$w4 My foot!$w4
You're crushing it! $w2I heard something
crunch! $w2Help!$w3 I'm being crippled!$K
$F4$PAnd no one cares!$K
$F0$PAll right, all right. $w2I think that's enough.$K
$F4$PHmph! It's one thing that you're a
guppy-brained lout... But it's worse
that you never, ever change!$K$PYou're ALWAYS being chased by thugs,$w2
and I ALWAYS have to go looking for you.$w2
Do you have any idea how much I worry?$K$Fh$PWould it hurt you to $w2think of others
once in a while?$w3 You're my OLDER
brother, $w2remember?$Fc$K
$F3$PMarcia...$K
$F0$P...$w5
$F3$FD$F1$FCL_MAKAROV|$F1$PI'm sorry!$w4 I'll give up gambling.$K$PI'll work hard and repay all of my debts!$w4
Please,$w4 you've gotta believe me!$K$F1$FD
$F4$P...$K
$F0$PWhy not forgive him?$w4 He's the only
brother you've got, right?$K
$F4$P$Fd...$w2Well, if Ike insists...$K
$F1$FS$F1$FCL_MAKAROV|$F1$PR-$w2really?$w4 Do you forgive me?$K
$F4$POnly if you keep your word!$w4
This is the absolute last time!$K
$F1$PI swear!$w4 I swear on Dad's grave.$K
$F4$P$FSHeh... That's not going to work, you twit!$w2
Dad's still alive.$K
$F1$PMade you laugh!$w3 'Bout time, too.$K
$F0$PStraighten up and don't trouble your
sister anymore.$K$F0$FD
$F1$PSay, $w2Marcia?$K
$F4$PWhat is it, $w2Makalov?$K
$F1$PYou want to bet on how long I can keep
my promise? I'll give you four-to-one odds!$K
$F4$P$FAAAAHHH!!!$K $R�w�i��b|$B�V��-��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 By your leave,$w2
I will excuse myself.$K    @�      <�   	  <�     ;   "  A(   3  B$   @  B�   L  C    X  C�   d  D   p  @L   z  :0   �  D�   �  E�   �  IL   �  KD   �  M�   �  P(   �  R�   �  U   �  Wx     Z    ^4    _�  '  b,  3  'X  ?  *�  K  +�  W  D�  c      r  e�  �  �  �  |  �  �  �    �    �  �  �  #�  �  #�  �  "T  �  "�    $8    &X    n�  *  oD  ;  o�  J  o\  Y  +�  j  .T  v  /�  �  1�  �  2�  �  4<  �  7�  �  9  �MS_25_BT MS_25_BT_02 MS_25_BT_BLK MS_25_BT_BLK_IKE MS_25_BT_IKE MS_25_BT_R1 MS_25_BT_R2 MS_25_BT_R3 MS_25_BT_RI MS_25_DIE MS_25_DIE_GIOFLE MS_25_DIE_IKE MS_25_ED_01 MS_25_ED_02A MS_25_ED_02B MS_25_ED_02C MS_25_ED_02D MS_25_ED_02E MS_25_ED_02F MS_25_ED_02G MS_25_ED_02H MS_25_ED_03 MS_25_ED_03_2 MS_25_ED_X1 MS_25_ED_X2 MS_25_EV_01 MS_25_EV_02 MS_25_EV_03 MS_25_GAMEOVER MS_25_GMAP_01 MS_25_INFO_05 MS_25_OP_01 MS_25_OP_02 MS_25_OP_03 MS_25_OP_03X MS_25_OP_03X2 MS_25_OP_04 MS_25_OP_04X MS_25_OP_04X2 MS_25_OP_04_01 MS_25_OP_04_02 MS_25_OP_05 MS_25_OP_06 MS_25_REPO_BEGIN MS_25_REPO_DIE MS_25_REPO_END MS_25_REPO_NODIE MS_25_TK_01 MS_25_TK_02 MS_25_TK_03 MS_25_TK_04 MS_25_TK_05 MS_25_TK_06 MS_25_VIL_01 MS_25_VIL_02 