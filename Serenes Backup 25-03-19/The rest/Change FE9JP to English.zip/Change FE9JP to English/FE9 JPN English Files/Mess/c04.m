  ^<  Z�       %                $R�w�i��b|$B�A�W�g-�H��-��|$<$F4$FCL_IKE|$F4$PYou wanted to see me, $w2Father?$K
$F1$FCL_GREIL|$F1$PSit down, Ike.$K
$F4$FD$F1$PWe haven't had a chance to speak yet.$K$PTitania told me what happened while I was
gone$MC...$MD$w2 About the kidnappings.$w4 About my
own men disobeying Titania's direct orders.$K
$F3$FCL_IKE|$F3$PI was the one who left first.$w4
I'll take responsibility $w2for everything.$K
$N$UB$H   $R�w�i��b|$B�A�W�g-�H��-��|$<$F4$FCL_IKE|$F4$PYou wanted to see me, $w2Father?$K
$F1$FCL_GREIL|$F1$PSit down, Ike.$K
$F4$FD$F1$PWe haven't had a chance to speak yet.$K$PTitania told me what happened while I was
gone$MC...$MD$w2 About the kidnappings.$K
$F3$FCL_IKE|$F3$PI take responsibility for my actions. I'm
ready to accept my punishment.$K
$N$UB$H   $F4$FCL_BOLE|$F4$PNo fair playing the martyr!$w4 Nobody made
me go with you. I left of my own free will!$w4
I'm ready to accept my punishment, too!$K
Wait, what am I saying?$K$F4$FD
$N$UB$H   $F4$FCL_KILROY|$F4$PPlease, $w2Commander Greil!$w4
Titania entrusted me with her orders. If
anyone's to blame for this mess, it's me.$K$PI'm the one who should be punished$MC...$MD$K$F4$FD
$N$UB$H    $F4$FCL_OSCAR|$F4$PI set a poor example, Commander Greil.$w4
Any punishment $w2should be mine alone.$K$F4$FD
$N$UB$H    $F1$PI'm pleased to see that you are willing to
shield one another. $w2However$MC...$MD$K$P$N$UB$H  $F1$PRegardless of your reasons, $w2you disobeyed
the orders of a superior officer.$w4 You are
confined to quarters for ten days.$K
$F0$FCL_MIST|$F0$PBut, $w2Father!$w4 They did what they did
to help me and Rolf!$K$F0$FD
$F1$PRules exist for a reason, Mist.$w4 Men won't
survive on a battlefield if they do as they
wish without so much as a by-your-leave.$K
$F3$P$MC...$MDI understand.$w5
And accept the reprimand.$K$F3$FD$w5
$F1$PThat being said, $w2we've got more work
than we can handle.$w4 Your punishment
is$w2 deferred until things calm down.$K$N$UB$H   $F1$PRegardless of your reasons, $w2you disobeyed
the orders of a superior officer.$w4 You are
confined to quarters for ten days.$K
$F0$FCL_MIST|$F0$PBut, $w2Father!$w4 Ike did what he did
to help me and Rolf!$K$F0$FD
$F1$PRules exist for a reason, Mist.$w4 Men won't
survive on a battlefield if they do as they
wish without so much as a by-your-leave.$K
$F3$P$MC...$MDI understand.$w5
And accept the reprimand.$K$F3$FD$w5
$F1$PThat being said, $w2we've got more work
than we can handle.$w4 Your punishment
is$w2 deferred until things calm down.$K$P$UB$H  $F3$FCL_OSCAR|$F4$FCL_BOLE|$F1$POscar, $w2Boyd,$w4
$F3$FD$F4$FD$F4$FCL_KILROY|$F1$PRhys.$w4
You come with me.$K$P$F4$FD$F1$FD$w6$F1$FCL_TIAMAT|$F3$FCL_CHINON|$F4$FCL_GATRIE|$F1$PShinon, $w2Gatrie,$K
$F3$FD$F4$FD$F3$FCL_IKE|$F1$Pand you, Ike.$w4
You're with me.$K  $F3$FCL_OSCAR|$F4$FCL_BOLE|$F1$POscar, $w2Boyd.$w4
You come with me.$K$P$F3$FD$F4$FD$F1$FD$w6$F1$FCL_TIAMAT|$F3$FCL_CHINON|$F4$FCL_GATRIE|$F1$PShinon, $w2Gatrie,$K
$F3$FD$F4$FD$F3$FCL_IKE|$F1$Pand you, Ike.$w4
You're with me.$K $F3$FCL_OSCAR|$F4$FCL_KILROY|$F1$POscar, $w2Rhys.$w4
You come with me.$K$P$F3$FD$F4$FD$F1$FD$w6$F1$FCL_TIAMAT|$F3$FCL_CHINON|$F4$FCL_GATRIE|$F1$PShinon, $w2Gatrie,$K
$F3$FD$F4$FD$F3$FCL_IKE|$F1$Pand you, Ike.$w4
You're with me.$K   $F3$FCL_KILROY|$F4$FCL_BOLE|$F1$PRhys, $w2Boyd.$w4
You come with me.$K$P$F3$FD$F4$FD$F1$FD$w6$F1$FCL_TIAMAT|$F3$FCL_CHINON|$F4$FCL_GATRIE|$F1$PShinon, $w2Gatrie,$K
$F3$FD$F4$FD$F3$FCL_IKE|$F1$Pand you, Ike.$w4
You're with me.$K $F4$FCL_OSCAR|$F1$POscar,$w4 come with me.$K$P$F4$FD$F1$FD$w6$F1$FCL_TIAMAT|$F3$FCL_CHINON|$F4$FCL_GATRIE|$F1$PShinon, $w2Gatrie,$K
$F3$FD$F4$FD$F3$FCL_IKE|$F1$Pand you, Ike.$w4
You're with me.$K $F4$FCL_BOLE|$F1$PBoyd,$w4 come with me.$K$P$F4$FD$F1$FD$w6$F1$FCL_TIAMAT|$F3$FCL_CHINON|$F4$FCL_GATRIE|$F1$PShinon, $w2Gatrie,$K
$F3$FD$F4$FD$F3$FCL_IKE|$F1$Pand you, Ike.$w4
You're with me.$K   $F4$FCL_KILROY|$F1$PRhys,$w4 come with me.$K$P$F4$FD$F1$FD$w6$F1$FCL_TIAMAT|$F3$FCL_CHINON|$F4$FCL_GATRIE|$F1$PShinon, $w2Gatrie,$K
$F3$FD$F4$FD$F3$FCL_IKE|$F1$Pand you, Ike.$w4
You're with me.$K $F1$FD$w2$F1$FCL_TIAMAT|$F3$FCL_CHINON|$F4$FCL_GATRIE|$F1$PShinon, $w2Gatrie,$K
$F3$FD$F4$FD$F3$FCL_IKE|$F1$Pand you, Ike.$w4
I want you to come with me.$K $R�㉺��b|$c0HIBUCCHI|Yar har ho!$w2
Me belly's emptier 'n me first mate's
head! Fetch me some grub!$K $R�w�i�Ȃ���b|$F3$FCL_TIAMAT|$F3$PThat's the pirate ship in question,$w2 isn't it?$K
$F0$FCL_GRANDPA|$F0$PAye.$w4 They sailed into port a few days ago
and have been causing trouble ever since.$K$PI pray that you and your companions$w2
can drive them away.$K
$F3$P$FSI understand.$w4 We'll do all we can.$K
$Ub$H$F0$FD$F1$FS$F1$FCL_CHINON|$F1$PFeathering sea scum $w2is like shooting apples
off a tree.$w4 Let's do the job $w2and
get out of here.$K
$F0$FS$F0$FCL_GATRIE|$F0$PHo, Deputy Commander!$w4 You want standard
thunder and lightning maneuvers here?$K
$F4$FCL_IKE|$F4$PEr$MC...$MD$w4 Thunder and lightning?$K
$F0$PYeah! $w2I crash into 'em like thunder, and
Shinon rains arrows down on 'em like
lightning!$K
$F3$PSounds good.$K
$F4$PWhat should I do?$K
$F3$PLet's hold back and let Shinon
and Gatrie soften them up.$K$POnce they've whittled down the numbers,$w2
we'll all rush the ship$w3 and wipe out
whatever's left.$K  $R�w�i�Ȃ���b|$F3$FCL_TIAMAT|$F3$PThat's the pirate ship in question,$w2 isn't it?$K
$F0$FCL_GRANDPA|$F0$PAye.$w4 They sailed into port a few days back
and have been causing trouble ever since.$K$PI pray that you and your companions can$w2
do something to drive them away.$K
$F3$P$FSI understand.$w4 We'll do all we can.$K
$Ub$H$F0$FD$F1$FS$F1$FCL_CHINON|$F1$PFeathering sea scum $w2is like shooting apples
off a tree.$w4 Let's get this done $w2and
get out of here.$K
$F0$FS$F0$FCL_GATRIE|$F0$PHo, Deputy Commander!$w4 Standard
thunder and lightning maneuvers here?$K
$F4$FCL_IKE|$F4$PEr$MC...$MD$w4thunder and lightning?$K
$F0$PYeah! $w2I crash into 'em like thunder, and
Shinon rains arrows down on 'em like
lightning!$K
$F3$PYes, $w2I think that's a good strategy.$K
Were I not wounded, $w2I would lend
my strength to yours, but$MC...$MD$K
$F4$PLet me take up the slack, Titania$MC...$MD$w4
What should I do?$K
$F3$PLet's sit back and let Shinon
and Gatrie work.$K$POnce they've whittled down the numbers,$w2
you three rush the ship$w3 and wipe out
whatever's left.$K $R�㉺��b|$c0TIAMAT|Are you all ready?$w4
Greil Mercenaries, move out!$K
$s2$FS$c2CHINON|On my way!$K$d2
$s3$FS$c3GATRIE|Here we go!$K
$c1IKE|$MC...$MDReady!$K    $R�㉺��b|$s0$FS$c0CHINON|You ready?$w4
Greil Mercenaries,$w3 move out!$K
$s3$FS$c3GATRIE|Here we go!$K
$c1IKE|Ready!$K    $R�㉺��b|$c0MARCIA|$s0Hey! You! Boat monkey!$w2
You tricked me, didn't you?$K
$s1$FS$c1HIBUCCHI|$s1Tricked ye? $w2What a vile and nasty
thing that is to be sayin'.$w4
Don't ye agree,$w2 matey?$K
$s3$FS$c3BANDIT3|$s3Yar, that I do!$w2 There be nothing but
honest pirates aboard this ship, missy.$K
$c0MARCIA|$s0You said you knew the whereabouts of
my older brother. $w2That's why
I came all the way to your ship.$K
$s1Aye, and we do know!$w4 He was on
board for a while, $w2and then$MC...$MD$w4 Do
ye recall where he went, $w2matey?$K
$s3Yar, that I do. $w2He was a penniless
oaf,$w4 so we tossed his worthless
carcass$w2 into the rolling waves.$K$PYar har ho!$K
$s0My$MC... $MDMy brother?
That's horrid!$K
$s3$FAHorrid? $w2Did ye say horrid?$w4
Yer scurvy brother was the horrid one!$w2
He lost a game o' chance, he did.$K$PIf ye lose, ye must pay$MC...$MD$w5
And the scallywag tried to cheat me!
By Shanty Pete he did!$K
$s1Arr, $w2calm yerself, me hearty!$K
$s3Yar!$w6
$MC...$MDYar?$w6
$MC...$MDYar.$K$d3
$s1After all, his darling sister's come to
pay us a visit.$w4 What say ye$w2
work off yer brother's debt?$K
$s0What say I run you through with
my lance and call it a day?!$K
$s3$FS$c3BANDIT3|$s3Yo ho har!$w4
It matters not that ye be a
pegasus knight, lassie.$K
$s1A wee minnow like yerself is no
match for us sea dogs!$w4
Prepare yourself, $w2ye flying wench!$K
$s0Pfff! I'm not afraid of you, clambake!$w4
If your axe is as dull as your wit,
this will be over in no time!$K    $R�w�i��b|$B����|$<$F1$FS$F1$FCL_NASIR2|$F4$FCL_IKE|$F1$PThis town seems quite$w2 unruly, wouldn't
you say?$w5 Is it always this dangerous?$K$P$FAOh$MC... $MD$w4So it's plagued by pirates, is it?$w5
I see.$w2 That would explain $w2why the
people here seem so anxious.$K$PYou seem so very$MC...$MD$w3young.$w4
And you claim you were hired to rid the
town of these pesky pirates?$K$P$FSHere, perhaps you should take this.$w3
It might help you if you run into trouble
contending with the pirates. But do hurry.$K$PI came all this way to see the world-famous
fish market, and I'll never do so with those
ruffians around.$w4 Best of luck to you.$K $R�w�i��b|$B����|$<$F1$FS$F1$FCL_NASIR2|$F4$FCLME|$F1$PThis town seems quite$w2 unruly, wouldn't
you say?$w5 Is it always this dangerous?$K$P$FAOh$MC... $MD$w4So it's plagued by pirates, is it?$w5
I see.$w2 That would explain $w2why the
people here seem so anxious.$K$PYou$w3 appear to be a mercenary.$w4
Would I be right in supposing that you were
hired to clean out the pirates?$K$P$FSHere, perhaps you should take this.$w3
It might help you if you run into trouble
contending with the pirates. But do hurry.$K$PI came all this way to see the world-famous
fish market, and I'll never do so with those
ruffians around.$w4 Best of luck to you.$K  $R�㉺��b|$c0MARCIA|$s0Oh, crackers! There's too many of them.$w2
I don't want to die here$MC...$MD$w5$Fc
Brother$MC...$MD$w3this might be the end!$K$w4
$c1IKE|$s1Hey!$w4 Are you all right?$K
$s0$MC...$MDSo cold$MC...$MD$w6 So$MC...$MD$w4$Fd Huh?$K
$s1Don't give up!$K
$s0Wh-$w1who are you?$K
$s1I'm a mercenary. $w2The villagers
hired us to get rid of these pirates.$K
$s0Are you$MC...$MD$w2 Are you going
to help me?$K
$s1Of course.$w4 Let me and my companions
take it from here.$w2 You can escape
while the pirates are distracted.$K
$s0$FSOh, hey, that would be fantastic! Thanks
so much!$w4 I $w2don't know what to say.$K
$s1You don't have to say anything.$w4
It's all in a day's work.$K
$s0Pshaw! You're helping me out!$w4
I should $w2show my gratitude somehow.$K
$s1That's$MC...$MDnice, but$w3 I can't think of
anything off the top of my head.$w4 Just get
yourself somewhere safe, $w2please.$K
$s0Well then$MC...$MD$w4 I'll come talk to you
about repaying my debt later.$K
What's your name, handsome?$K
$s1Um$MC... $MDI'm Ike.$w4 I'm with the Greil
Mercenaries.$K
$s0Ike! Got it!$w3 And I$w2 am Marcia, a pegasus
knight of Begnion.$w4 Don't forget me!$K
All right, $w2I'll be seeing you later!$K$d0   $R�㉺��b|$c0MARCIA|Urrr$MC... $MDAh, nuts$MC...$MD$w5
Bro-$w2$FcBrother$MC...$MD
I'll be with you soon.$K $R�㉺��b|$s0$FS$c0HIBUCCHI|Yahar har harrr!$w4 Yer bustin' me
gut, $w2ye rudderless fool!$K$PDo ya truly think ye can face me
mighty axe $w2and live?$K   $R�㉺��b|$c1IKE|$s1Give back what you've stolen from the
good folk here$w4 and set sail.$K
$s0$FS$c0HIBUCCHI|$s0Yahar har harrrr!$w4
Now I know yer tetched
in the head, lassie!$K$PWe show 'em our axes an' say "Arrrr,"$w3
and the gold and grub come rainin'
down.$w4 We'll not be givin' this up!$K
$s1I see$MC...$MD$w5 Looks like we'll have to rely
on force of arms, then.$w2$K   $R�㉺��b|$c0HIBUCCHI|Yaaaarr$MC...$MD$w4arrr$MC... $MD$w2Help me$MC...$MD$K   $R�w�i��b|$B�X�O��|$<$F3$FCL_IKE|$F1$FCL_TIAMAT|$F3$PTitania, $w2how's that injury of yours?$K
$F1$P$FSNot to worry$MC...$MD$w4 It's nothing
life threatening.$K$FA
I may find it difficult to$w4
continue fighting as before, but$MC...$MD$K
$F3$PWell, for now, $w2don't try to do too much.$K
$F1$PI know, I know.$w5 But I still have to tell
the mayor $w2that our work is done.$K
$=0300 $R�w�i��b|$B�X�O��|$<$F0$FS$F0$FCL_GRANDPA|$F3$FS$F3$FCL_TIAMAT|$F3$PWe've driven off all the pirates.
Your people will suffer no more
indignities at their hands.$K
$F0$POh!$w3 That is joyful news!$w4
Here is your pay, as promised.$K
$F3$PThank you very much.$w4 And if you find
yourself in need again, do not hesitate
to send word.$K
$F0$POf course, of course.$w4
All of you put on a most marvelous
show$MC--$MD$w2such combat skills!$K$PTo be honest, $w2I was expecting Commander
Greil to be here today.$K$PWhen I saw just you, nothing more
than, no offense, a band of children$MC...$MD$w3
Well, I will admit to being a tad nervous!$K
$F3$PI apologize for troubling you.$w4
Unfortunately, Commander Greil had other
pressing matters to attend to.$K
$F0$POh, no. Don't apologize. There's no need.$w4
After all, $w2you got rid of those brigands,
and you did it impeccably well!$K
$F3$PIt's a fine compliment you pay, sir,$w2
but it was our pleasure.$K
$F0$PAs a matter of fact,$w2 you're more than
good enough to be in the royal army
if you so desired.$K$PEspecially your Commander Greil.$w2
He's far and away better than most
any general I've seen hereabouts.$K$PEr$MC... $MDWhat I mean to say is$MC...$MD$w2
Don't you think running off pirates is
a bit$MC...$MD$w5beneath you?$K
$F3$PThat's not$MC--$MD$K
$F0$PDon't get me wrong, now.$w3 You certainly
helped all of us simple folk out.$K$PEven so,$w3 it seems to me the proper place
for you and your Commander Greil$w2 is
in the service of the Crimean throne!$K$PWell, that's what this old man thinks.$K
$F3$PWe$MC--$MDand Commander Greil$MC--$MD$w2are quite
satisfied with the work we do now.$K
$F0$PYou've nary a selfish bone among you.$K$PWell then, $w2rest assured we'll speak again
if any problems arise.$w4 Thank you again.$K$F0$FD
$F3$P$FAHmm$MC...$MD$K
$F1$FCL_IKE|$F1$PTitania?$w4 Is something amiss?$K
$F3$P$FSNo, $w2of course not.$w5
Our mission is complete, and that's
all that matters.$K
You did well today, every one of you.$K$F1$FD
$F0$FCL_CHINON|$F0$PPah!$w3 Jobs like this$w2 barely make a
dent in my $w2incurable boredom!$K$PIt's like that old buzzard said,$w2
there's better work $w2out there.
Something with a bit of challenge.$w2$K
$F3$P$FAShinon!$K
$F0$P$FSI'm joking. $w2J-O-K-ing.$K$F0$FD
$F1$FS$F1$FCL_GATRIE|$F1$PCome, $w2Titania.$K$PBe honest.$w5 Don't you find the work
we do to be$w2 a bit$MC...$MD$w4
disheartening? Unglamorous?$K
$F3$PWhat?$w4 You too, Gatrie?$w2
What's gotten into you?$K
$F1$PPlease!$w3 Look, we're not a band of money-
hungry recruits. We're professionals, and
we're very good at what we do.$K$PShinon and I have discussed this at length.$w3
All of this mundane mercenary work is
unworthy of us.$w2 We're wasting our talents.$K
$F3$PI see.$w4 You're telling me that you
think Commander Greil is mismanaging
us.$w3 Do I have that right?$K
$F1$P$FAWhoa!$w3 Hold it right there!$w4
That's not $w2what I'm saying at all!$K
$F0$P$F0$FCL_IKE|$F0$PWhat is it, $w2Titania?$K
$F3$PWhat's what?$K
$F0$PYou seem so angry.$w3
It's not like you.$K
$F3$PHmph$MC...$MD$K
$F1$PExactly!$w4
Ike's got the right of it!$K
$F3$PIt's just that I$MC...$MD$w3 Look, we do
good work, and we help people.$w2
I want you to be proud of that.$K$PI felt like you were saying work that
doesn't bring fame$w2 and fortune$w2
isn't worth doing, that's all.$w4 Sorry.$K
$F1$PNo$MC...$MDyou're right.$w3 We are the ones
who ought to apologize.$K
$F3$P$FSEnough. Let's get going, shall we?$w4
Rest is part of our jobs, too.$w3 We can't
go into the next battle exhausted.$K
$F1$P$FSNow that's a plan!$w4
I'm so hungry, I could eat a
wyvern!$K$F3$FD$F1$FD
$F0$PTitania!$K
$F4$FS$F4$FCL_TIAMAT|$F4$PWhat is it?$K
$F0$PIf you're looking for pride$MC...$MD$w6I have it.$K
$F4$P$FAHm?$K
$F0$PYou and my father have kept
this mercenary group together.$K$PAnd I'm$MC...$MDjust$MC...$MD$w4proud to be
a part of it.$w4 That's all.$K$F0$FD
$F4$P$FSIke$MC...$MD$K$P$F4$FD$w6
$F0$FCL_CHINON|$F0$PPah.$w4 I'm surrounded by$w2 idealistic
fools. What's so wrong with fame? What's
wrong with having money to live well?$K
$=1200 $R�w�i��b|$B�X�O��|$<$F0$FS$F0$FCL_GRANDPA|$F3$FS$F3$FCL_TIAMAT|$F3$PWe've mopped up all the pirates.
Your citizens will suffer no more
indignities at their hands.$K
$F0$POh!$w3 That is joyful news!$w4
Here is your pay, as promised.$K
$F3$PThank you very much.$w4
And if you find yourself in need
again, do not hesitate to send word.$K
$F0$POf course, of course.$w4
All of you put on a most marvelous
show$MC--$MD$w2such combat skills!$K$PTo be honest, $w2I was expecting Commander
Greil to be here today.$K$PWhen I saw just you, nothing more
than, no offense, a band of children$MC...$MD$w3
Well, I will admit to being a tad nervous!$K
$F3$PI apologize for troubling you.$w4
Unfortunately, Commander Greil had other
pressing matters to attend to.$K
$F0$POh, no. Don't apologize. There's no need.$w4
After all, $w2you got rid of those brigands,
and you did it with style!$K
$F3$PIt's a fine compliment you pay, sir,$w2
but it was our pleasure.$K
$F0$PAs a matter of fact,$w2 you're more than
good enough to be in the royal army
if you so desired.$K$PEspecially your Commander Greil.$w2
He's far and away better than most
any general I've seen hereabouts.$K$PEr$MC... $MDWhat I mean to say is$MC...$MD$w2
Don't you think running off pirates is
a bit$MC...$MD$w5beneath you?$K
$F3$PThat's not$MC--$MD$K
$F0$PDon't get me wrong, now.$w3 You certainly
helped all of us simple folk out.$K$PEven so,$w3 it seems to me the proper place
for you and your Commander Greil$w2 is
in the service of the Crimean throne!$K$PWell, that's what this old man thinks.$K
$F3$PWe$MC--$MDand Commander Greil$MC--$MD$w2are quite
satisfied with the work we do now.$K
$F0$PYou've nary a selfish bone among you.$K$PWell then, $w2rest assured we'll speak again
if any problems arise.$w4 Thank you again.$K$F0$FD    $=0300$R�w�i��b|$B�X�O��|$<$F1$FCL_CHINON|$F3$FCL_TIAMAT|$F4$FCL_IKE|$F3$P$MC...$MD$K
$F1$PHey, Captain.$w4
I'm $w2gonna take off for a while.$K
$F3$PThat's no problem.$w4 We have nothing
scheduled until tomorrow afternoon.$w2
Take what time you need.$K
$F1$PYeah.
I'll do that.$K$F1$FD
$F4$PWhere's Shinon going?$K
$F3$PHe needs some time alone.$w4
Usually, $w2I make everyone report in, but$MC...$MD$w3
with what happened to Gatrie today$MC...$MD$w2$K
$F4$PI see.$K
$F3$PNo matter how many times it happens,$w4
you never get used to losing a friend.$K$PIke, $w2this is$MC...$MD$w3 This is the world$w2
we mercenaries live in. Never lose sight
of that one, cold truth.$K$P$F4$P$MC...$MD$K
$F3$POur duty's done.$w3 Let's head
for home.$w5 We have to report$w2
what happened$MC...$MD$w5 Ah, Gatrie$MC...$MD$K
$=1500 $R�w�i��b|$B�X�O��|$<$F0$FS$F0$FCL_GRANDPA|$F3$FS$F3$FCL_TIAMAT|$F3$PWe've mopped up all the pirates.
Your citizens will suffer no more
indignities at their hands.$K
$F0$POh!$w3 That is joyful news!$w4
Here is your pay, as promised.$K
$F3$PThank you very much.$w4
And if you find yourself in need
again, do not hesitate to send word.$K
$F0$POf course, of course.$w4
All of you put on a most marvelous
show$MC--$MD$w2such combat skills!$K$PTo be honest, $w2I was expecting Commander
Greil to be here today.$K$PWhen I saw just you, nothing more
than, no offense, a band of children$MC...$MD$w3
Well, I will admit to being a tad nervous!$K
$F3$PI apologize for troubling you.$w4
Unfortunately, Commander Greil had other
pressing matters to attend to.$K
$F0$POh, no. Don't apologize. There's no need.$w4
After all, $w2you got rid of those brigands,
and you did it with style!$K
$F3$PIt's a fine compliment you pay, sir,$w2
but it was our pleasure.$K
$F0$PAs a matter of fact,$w2 you're more than
good enough to be in the royal army
if you so desired.$K$PEspecially your Commander Greil.$w2
He's far and away better than most
any general I've seen hereabouts.$K$PEr$MC... $MDWhat I mean to say is$MC...$MD$w2
Don't you think running off pirates is
a bit$MC...$MD$w5beneath you?$K
$F3$PThat's not$MC--$MD$K
$F0$PDon't get me wrong, now.$w3 You certainly
helped all of us simple folk out.$K$PEven so,$w3 it seems to me the proper place
for you and your Commander Greil$w2 is
in the service of the Crimean throne!$K$PWell, that's what this old man thinks.$K
$F3$PWe$MC--$MDand Commander Greil$MC--$MD$w2are quite
satisfied with the work we do now.$K
$F0$PYou've nary a selfish bone among you.$K$PWell then, $w2rest assured we'll speak again
if any problems arise.$w4 Thank you again.$K$F0$FD    $=0300$R�w�i��b|$B�X�O��|$<$F1$FCL_GATRIE|$F3$FCL_TIAMAT|$F4$FCL_IKE|$F3$P$MC...$MD$K
$F1$PTitania?$w4
I'd$MC...$MDum$MC...$MDlike to take off for a while.
Is that a problem?$K
$F3$PNo. No problem.$w4 There's nothing
scheduled until tomorrow afternoon.$w2
Take your time.$K
$F1$PThanks.$K$F1$FD
$F4$PWhere's Gatrie going?$K
$F3$PHe needs some time alone.$w4
Usually, $w2I make everyone report in, but$MC...$MD$w3
with what happened to Shinon$MC...$MD$w2$K
$F4$PI see.$K
$F3$PNo matter how many times it happens,$w4
you never get used to losing a friend.$K$PIke, $w2this is$MC...$MD$w3this is the world$w2
we mercenaries live in. Never lose sight
of that one, cold truth.$K$P$F4$P$MC...$MD$K
$F3$POur duty's done.$w3 Let's head
for home.$w5 We'll have to tell$w2
Greil what happened to Shinon$MC...$MD$K
$=1500  $R�w�i��b|$B�X�O��|$<$F0$FS$F0$FCL_GRANDPA|$F3$FS$F3$FCL_TIAMAT|$F3$PWe've mopped up all the pirates.
Your citizens will suffer no more
indignities at their hands.$K
$F0$POh!$w3 That is joyful news!$w4
Here is your pay, as promised.$K
$F3$PThank you very much.$w4
And if you find yourself in need
again, do not hesitate to send word.$K
$F0$POf course, of course.$w4
All of you put on a most marvelous
show$MC--$MD$w2such combat skills!$K$PTo be honest, $w2I was expecting Commander
Greil to be here today.$K$PWhen I saw just you, nothing more
than, no offense, a band of children$MC...$MD$w3
Well, I will admit to being a tad nervous!$K
$F3$PI apologize for troubling you.$w4
Unfortunately, Commander Greil had other
pressing matters to attend to.$K
$F0$POh, no. Don't apologize. There's no need.$w4
After all, $w2you got rid of those brigands,
and you did it with style!$K
$F3$PIt's a fine compliment you pay, sir,$w2
but it was our pleasure.$K
$F0$PAs a matter of fact,$w2 you're more than
good enough to be in the royal army
if you so desired.$K$PEspecially your Commander Greil.$w2
He's far and away better than most
any general I've seen hereabouts.$K$PEr$MC... $MDWhat I mean to say is$MC...$MD$w2
Don't you think running off pirates is
a bit$MC...$MD$w5beneath you?$K
$F3$PThat's not$MC--$MD$K
$F0$PDon't get me wrong, now.$w3 You certainly
helped all of us simple folk out.$K$PEven so,$w3 it seems to me the proper place
for you and your Commander Greil$w2 is
in the service of the Crimean throne!$K$PWell, that's what this old man thinks.$K
$F3$PWe$MC--$MDand Commander Greil$MC--$MD$w2are quite
satisfied with the work we do now.$K
$F0$PYou've nary a selfish bone among you.$K$PWell then, $w2rest assured we'll speak again
if any problems arise.$w4 Thank you again.$K$F0$FD    $=0300$R�w�i��b|$B�X�O��|$<$F1$FCL_IKE|$F3$FCL_TIAMAT|$F1$PTitania$MC...$MD$w2
About Shinon and Gatrie, I$MC...$MD$K
$F3$PNo matter how many times it happens,$w4
you never get used to losing a friend.$K$PIke, $w2this is$MC...$MD$w3this is the world$w2
we mercenaries live in. Never lose sight
of that one, cold truth.$K$P$F1$P$MC...$MD$K
$F3$PWe're done here.$w3 Let's go.$w5
We have to report$w2 what happened
to Shinon and Gatrie$MC... $MDWhat a blow$MC...$MD$K
$=1500   )�      *X   	  +�     )P      ,$   1  -�   A  =�   O  D�   ]  G�   n  N�   |  Q�   �  X�   �  �   �       �  �   �     �  �   �  �   �  h    �      /  	�  @  
�  R  �  c  �  t  |  �  @  �    �  �  �  d  �  �  �  @  �  �  �  l    $�    �    "  -MS_04_BT MS_04_BT_IKE MS_04_DIE MS_04_DIE_MARCIA MS_04_ED_00_DIE MS_04_ED_02_A MS_04_ED_02_B MS_04_ED_02_B_02 MS_04_ED_02_C MS_04_ED_02_C_02 MS_04_ED_02_D MS_04_ED_02_D_02 MS_04_EV_01 MS_04_OP_01_01_A MS_04_OP_01_01_B MS_04_OP_01_02_A MS_04_OP_01_03_A MS_04_OP_01_04_A MS_04_OP_01_05_A MS_04_OP_01_05_B MS_04_OP_01_05_S MS_04_OP_01_06_A2 MS_04_OP_01_06_B MS_04_OP_01_06_C MS_04_OP_01_06_D MS_04_OP_01_06_E MS_04_OP_01_06_F MS_04_OP_01_06_G MS_04_OP_01_06_H MS_04_OP_02_00 MS_04_OP_02_01 MS_04_OP_02_02 MS_04_OP_02_A MS_04_OP_02_B MS_04_TK_01 MS_04_VIL_03_A MS_04_VIL_03_B 