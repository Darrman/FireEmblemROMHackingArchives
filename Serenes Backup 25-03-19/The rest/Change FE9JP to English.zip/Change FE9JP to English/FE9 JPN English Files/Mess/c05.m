  ~<  x�       :                $R�w�i��b|$B�A�W�g����-01|$<$F3$FCL_IKE|$F1$FS$F1$FCL_MIST|$F1$PIke!$w2 Ike!$w4
I've got to tell you something!$w2
Listen to this!$K
$F3$PSettle down, Mist. $w2It's too early for
you to be yelling like that.$w4
Now, what's going on?$K
$F1$PSoren's back!$w1 He just arrived.$K
$F3$PReally?$w4 That's odd. He wasn't supposed
to return for a while yet.$K
$F1$P$FAI know!$w4 I wonder what he's doing
back so soon$MC...$MD$K
$F3$PIt's probably nothing to worry about.$w4
I'll go and talk to him.$K$PWhere is he?$K
$F1$P$FSIn the mess hall.$w3 I think he
wanted to talk to Father.$K
$F3$PRight. $w2I'll go check there.$K $R�w�i��b|$B�A�W�g-�H��-��|$<$F1$FCL_GREIL|$F4$FCL_TIAMAT|$F1$P$MC...$MDTroubling news indeed.
Gather the troops.$K
$F4$PYes, Commander.$K$F4$FD
$F4$FCL_IKE|$F1$PIke,$w4 if you've got time to waste,
you've got time to work.$w3 Get
over to the briefing room.$w4$K
$F4$PYes, sir.$K$P$F1$FD$F4$PHey!$w4 What's going on around here?$K
$F1$FCL_SENERIO|$F1$PBad news.$w4 Something big is happening,$w2
and we need to formulate a plan of action.$K
$F4$PSoren!$K
$F1$P$FSHello, Ike. Long time, no see.$K
$F4$P$FSI'm happy to see you're back.$K$FA
But$w2 what happened?$w4 I thought
you were going to be studying
for a while longer.$K
$F1$P$FAIt's a long story$MC...$MD$K$P$F7$FCL_GREIL|What's the hold up?$w4
Get over here now!$K
$F1$PLet's go.$w4 I'll fill you in later.$K  $R�w�i��b|$B�A�W�g-��펺|$<$F3$FCL_GREIL|$F4$FCL_SENERIO|$F3$PYou probably remember that Soren's been
training with another mercenary group.$w4
Well, he's back now.$K$PAnd he has some unbelievable news.$K
$F1$FCL_IKE|$F1$PWhat news is that?$K
$F4$PIt's Crimea and Daein.$w5
They've gone to war.$K
$F0$FCL_MIST|$F0$PWar?!$w4 It$MC...$MD$w2 It can't be!$K
$F3$PThat's why I've called everyone
here.$w4 Soren has some more
information.$w2 Go ahead, Soren.$K
$F4$PAll right.$K  $R�̂݉�b|$F1$FCL_SENERIO|$F1$PTake a look at this map.$K$F1$FD
$F1$FCL_GREIL|$F1$PAh. It's a map of Crimea. Quite
detailed, from the looks of it.$K$F1$FD
$Ub$H$F1$FCL_SENERIO|$F1$PYes. $w2This is the Melior, Crimea's capital.$K$POur base of operations is$MC...$MD$w2
$Ub$Hright about here.$K   $R�̂݉�b|$F1$FCL_SENERIO|$F1$PEverything started $w2three days ago.$K$PI needed to do some research,
$Ub$H$w3so I went to the archives$w2 of Melior's
royal library.$K    $R�̂݉�b|$F1$FCL_SENERIO|$F1$PWithout warning, $w2the scream of a terrible
beast$MC--$MDa wyvern, perhaps$MC--$MDrent the air,$w4
and the building was rocked by a tremor.$K  $R�̂݉�b|$F1$FCL_SENERIO|$F1$PI rushed outside $w2and saw$w3 wave after wave
of knights,$w3 cavalry,$w3 and $w2wyvern riders,$K$Peach $w2clad in glistening ebon armor, black
as night.$K$F1$FD$P$F1$FCL_GREIL|The Daein army?$K$F1$FD$P$F1$FCL_SENERIO|Correct.$K$F1$FD$P$F1$FCL_GREIL|Was there provocation?$K$F1$FD$P$F1$FCL_SENERIO|As you know,$w2 relations between Crimea and
Daein$w3 have never been$MC...$MD$w4friendly.$K$PHowever, the past centuries have seen only
minor skirmishes, nothing that has ever
approached the scale of this attack.$K$PIt was brutal and without warning.$w2 Daein
laid the capital to waste.$w3 I've never seen
destruction on this scale before.$K$F1$FD$P$F1$FCL_TIAMAT|A swift attack, devastating and brutal$MC...$MD
A daring gambit, indeed.$K$F1$FD$P$F1$FCL_GREIL|But if it succeeds, $w2a very well-chosen
one at that.$K $R�̂݉�b|$F1$FCL_GREIL|$F1$PYes, the king of Daein$w2 would not hesitate
to employ such treacherous tactics.$K$PWhat happened next?$K $R�̂݉�b|$F1$FCL_SENERIO|$F1$PKing Crimea's brother deployed the Crimean
army$w2 to meet the attack.$K$PThe king ordered his people to flee the city
before the battle reached them.$w3 Fearing the
worst,$w4 I also fled and made my way here.$K$F1$FD
$F1$FCL_GREIL|$F1$PSo we don't know how the tides
of battle flow now, do we?$K
$Ub$H  $R�w�i��b|$B�A�W�g-��펺|$<$F3$FCL_SENERIO|$F1$FCL_GREIL|$F1$PThat's all right.$w3 Word of the war cannot
have traveled far yet. We may well be the
first ones who know of it out here.$K$FS$PYou did well to bring us this information,
Soren. I know some risk was involved.$K
$F3$PIt was nothing.$K
$F0$FCL_TIAMAT|$F0$PDaein has invaded Crimea$MC...$MD$w4
We may be mercenaries,$w2 but this still
affects us.$K
$F4$FCL_IKE|$F4$PWhat are we going to do?$K
$F1$P$FAThat's the question of the day.$w4
How do you see it, Titania?$K
$F0$PCrimea $w2is the closest thing our company
has to a homeland.$K$PThe Crimean royal family and noble houses
have been generous,$w3 providing us with
many lucrative jobs.$K$PFrom a moral standpoint as well as a
business one,$w2 it's in our best interest
to help Crimea.$K
$F1$PAnd you, $w2Soren?$K
$F3$PI agree on one point: we are mercenaries.
We are not Crimea's private militia.$K$PNo coin has crossed our palms,$w2
so I think we should stay out of it.$K
$F1$PSo you would have us sit and watch
as Crimea is overrun?$K
$F3$PI would.$w5 Daein's troops$w2 are superior in
both numbers and morale.$w4 The chances
of a Crimean victory are slim indeed.$K
$F0$PBut $w2Crimea is ruled by King Ramon, who is
known throughout the land for his wisdom.$K$PAnd his brother, Duke Renning, is said to
possess peerless valor and courage.$w4
Daein may not find victory so easily.$K
$F3$PValor and courage are for children's tales.
In terms of military prowess,$w2 Daein's King
Ashnard is every bit Lord Renning's equal.$K$PVictory will hinge on troop numbers$w2
and supplies, and Daein is superior in both.$w4
I think the outcome is painfully obvious.$K
$F0$PCurse you, Soren! Crimea is not doomed!$w4
If they can turn aside Daein's initial thrust
and turn it into a test of endurance$MC...$MD$K
$F3$PWith the Crimean army both demoralized
and ill prepared? $w2They simply will not
be able to hold out that long.$K
$F1$PAll right. $w2That's enough.$w4
Both of you.$K$w4
$F3$FD$F0$FD$F1$PI hear what you say.$w4 However,
we must ascertain the current situation
before we decide on any action.$K$PWe'll send a scouting party to get$w2
a closer look at Melior.$K$N$UB$H $F1$PIke, $w2I want you in charge of this.$w4
Assemble your men$w2 and get going.$K
$F4$PWhat?$w4 Me?$K
$F1$PTitania will accompany you as an advisor.$K
$F0$FCL_CHINON|$F0$PCommander, you must be joking!$w2
He's just a boy, and he's had barely
more than a taste of battle.$K$PWhat do you expect a whelp like
him to accomplish?$K
$F1$PAh, Shinon.$w3 Since you're so concerned,$w2
you can go as well.$w2$K
$F0$PWait, that's not what I$MC...$MD
Blast.$K$F0$FD
$F1$PWho else$MC... $MD$w4Gatrie, $w2Rhys, $w2and
Soren.$w4 That should do.$K
$F4$PFather, wait$MC...$MD$w4
Why do you want me$MC--$MD$K
$F1$PThat was an order.$w3 Get moving.$w4
There's no time to waste.$K
$F4$PYes, sir.$K
$F1$PTitania, $w2I'm going out for a bit.$w4
I want you to give Ike some direction.$K$F1$FD
$F0$FCL_TIAMAT|$F0$PUnderstood.$K
$F4$P$MC...$MDYes, sir.$K
$=0500 $F1$PIke, $w2I want you in charge of this.$w4
Assemble your men$w2 and get going.$K
$F4$PWhat?$w4 Me?$K
$F1$PTitania will accompany you as an advisor.$K
$F0$FCL_CHINON|$F0$PCommander, you must be joking!$w2
He's just a boy, and he's had barely
more than a taste of battle.$K$PWhat do you expect a whelp like
him to accomplish?$K
$F1$PAh, Shinon.$w3
Since you're so concerned,$w2
you can go as well.$w2$K
$F0$PWait, that's not what I$MC...$MD
Blast.$K$F0$FD
$F1$PSoren,$w1 I want you to go, too.$K
$F4$PFather, wait$MC...$MD$w4
Why do you want me$MC--$MD$K
$F1$PThat was an order.$w3 Get moving.$w4
There's no time to waste.$K
$F4$PBut$MC--$MD$w4 Yes, sir.$K
$F1$PTitania, $w2I'm going out for a bit.$w4
I want you to give Ike some direction.$K$F1$FD
$F0$FCL_TIAMAT|$F0$PUnderstood.$K
$F4$P$MC...$MD$K
$=0500 $F1$PIke, $w2I want you in charge of this.$w4
Assemble your men$w2 and get going.$K
$F4$PWhat?$w4 Me?$K
$F1$PTitania will accompany you as an advisor.$w3
Take Gatrie$w2 and Soren as well.$K
$F4$PHold on, $w2Commander!$w4
Why do you want$MC...$MD$K
$F1$PThat was an order.$w3 Get moving.$w4
There's no time to waste.$K
$F4$PBut$MC--$MD$w4 Yes, sir.$K
$F1$PTitania, $w2I'm going out for a bit.$w4
I want you to give Ike some direction.$K$F1$FD
$F0$FCL_TIAMAT|$F0$PUnderstood.$K
$F4$P$MC...$MD$K
$=0500 $F1$PIke, $w2I want you in charge of this.$w4
Assemble your men$w2 and get going.$K
$F4$PWhat?$w4 Me?$K
$F1$PTitania will accompany you as an advisor.$w3
Take Rhys$w2 and Soren$w1 as well.$K
$F4$PFather, wait$MC...$MD$w4
Why do you want me$MC--$MD$K
$F1$PThat was an order.$w3 Get moving.$w4
There's no time to waste.$K
$F4$PBut$MC--$MD$w4 Yes, sir.$K
$F1$PTitania, $w2I'm going out for a bit.$w4
I want you to give Ike some direction.$K$F1$FD
$F0$FCL_TIAMAT|$F0$PUnderstood.$K
$F4$P$MC...$MD$K
$=0500   $F1$PIke, $w2I want you in charge of this.$w4
Assemble your men$w2 and get going.$K
$F4$PWhat?$w4 Me?$K
$F1$PTitania will go along as an advisor$MC...$MD$K
$F0$FCL_CHINON|$F0$PYou've got to be kidding!$w2
Commander,$w4 what do you expect a
whelp like Ike to accomplish?$K
$F1$PAh, Shinon.$w3
Since you're so concerned,$w2
you can go along as well.$w2$K
$F0$PWait, that's not what I$MC...$MD
Blast.$K$F0$FD
$F1$PWho else? $w1Rhys $w2and
Soren?$w4 Yes, that should do.$K
$F4$PFather, wait$MC...$MD$w4
Why do you want me$MC--$MD$K
$F1$PThat was an order.$w3 Get moving.$w4
There's no time to waste.$K
$F4$PBut$MC--$MD$w4 Yes, sir.$K
$F1$PTitania, $w2I'm going out for a bit.$w4
I want you to give Ike some direction.$K$F1$FD
$F0$FCL_TIAMAT|$F0$PUnderstood.$K
$F4$P$MC...$MD$K
$=0500 $F1$PIke, $w2I want you in charge of this.$w4
Assemble your men$w2 and get going.$K
$F4$PWhat?$w4 Me?$K
$F1$PTitania will go along as an advisor$MC...$MD$w3
And take Gatrie,$w2 Rhys,$w2
and Soren$w1 as well.$K
$F4$PFather, wait$MC...$MD$w4
Why do you want me$MC--$MD$K
$F1$PThat was an order.$w3 Get moving.$w4
There's no time to waste.$K
$F4$PBut$MC--$MD$w4 Yes, sir.$K
$F1$PTitania, $w2I'm going out for a bit.$w4
I want you to give Ike some direction.$K$F1$FD
$F0$FCL_TIAMAT|$F0$PUnderstood.$K
$F4$P$MC...$MD$K
$=0500    $F1$PIke, $w2I want you in charge of this.$w4
Assemble your men$w2 and get going.$K
$F4$PWhat?$w4 Me?$K
$F1$PTitania will go along as an advisor$MC...$MD$w3
And take Soren$w1 as well.$K
$F4$PFather, wait$MC...$MD$w4
Why do you want me$MC--$MD$K
$F1$PThat was an order.$w3 Get moving.$w4
There's no time to waste.$K
$F4$PBut$MC--$MD$w4 Yes, sir.$K
$F1$PTitania, $w2I'm going out for a bit.$w4
I want you to give Ike some direction.$K$F1$FD
$F0$FCL_TIAMAT|$F0$PUnderstood.$K
$F4$P$MC...$MD$K
$=0500    $F1$PIke, $w2I want you in charge of this.$w4
Assemble your men$w2 and get going.$K
$F4$PWhat?$w4 Me?$K
$F1$PTitania will go along as an advisor$MC...$MD$K
$F3$FCL_CHINON|$F3$PYou've got to be kidding!$w2
Commander,$w4 what do you expect a
whelp like Ike to accomplish?$K
$F1$PAh, Shinon.$w3
Since you're so concerned,$w2
you can go along as well.$w2$K
$F3$PWait, that's not what I$MC...$MD
Blast.$K$F3$FD
$F1$PGatrie$w2 and Soren.$w1
You go as well.$K
$F4$PFather, wait$MC...$MD$w4
Why do you want me$MC--$MD$K
$F1$PThat was an order.$w3 Get moving.$w4
There's no time to waste.$K
$F4$PBut$MC--$MD$w4 Yes, sir.$K
$F1$PTitania, $w2I'm going out for a bit.$w4
I want you to give Ike some direction.$K$F1$FD
$F0$FCL_TIAMAT|$F0$PUnderstood.$K
$F4$P$MC...$MD$K
$=0500 $R�w�i��b|$B�A�W�g�O��-��|$<$F4$FS$F4$FCL_MIST|$F4$PIke!$w4 Wait up!$K
$F1$FCL_IKE|$F1$PWhat?$K
$F4$PHere!$w4 This is for you.$K$w4$N$UB$H $R�w�i��b|$B�A�W�g�O��-��|$<$F4$FS$F4$FCL_MIST|$F4$PIke!$w4 Wait up!$K
$F1$FCL_IKE|$F1$PWhat?$K
$F4$PHere!$w4 This is for you.$K$w4$N$UB$H     $R�w�i��b|$B�A�W�g�O��-��|$<$F4$FS$F4$FCL_MIST|$F1$FCL_IKE|$N$UB$H $F1$PA sword?$w4
Where did you get it?$K
$F4$PFrom Father. $w2He told me to come
and give it to you.$K
$F1$P$FSIt's beautiful.$K
$F4$PThis is the first sword $w2you've gotten
that wasn't a hand-me-down from
somebody, isn't it?$w5 That's great!$K
$F1$PYeah...$K
$F4$PWell, $w2be careful!$w4 Oh, and bring
me a souvenir!$w5 Something nice.
I've never been to Melior before...$K$F4$FD
$F1$P$FAMist, I'm not going on vacation. $w5$FSSheesh!$K
$=1000   $R�w�i�Ȃ���b|$F3$FCL_IKE|$F1$FCL_KILROY|$F3$P...$K
$F1$PAre you feeling all right, $w2Ike?$w4
You haven't said a word in
quite some time.$K
$Ub$H$F3$PI don't understand what my father's doing.$w4
Why put a new recruit like me$w2 in
charge of something so important?$K
$F1$P$FSYou're$w3 going to succeed him as
our commander one day.$K$PDon't you think he wants you to
know$w2 how to lead?$K
$F3$PMe? $w2I don't... I don't know if I'm capable.$w4
And even if I am, $w2that day's a long
way off, right?$K$PI mean, $w2I'm inexperienced. Weak.$w4
I'm nothing compared to my father.$K
$F1$PI'm not so sure about that.$w4
When I look at you, $w2I see a young
man full of promise.$K$PCommander Greil is a great man, but...
I think you'll be every bit his equal.$K$PIn time, you might even $w5surpass him.$K
$F3$PDon't be ridiculous!$K
$F1$PIt's just my opinion. You need
not pay it any mind.$K$PYet, if you fear your own weakness,$w2
why not take this chance$w2
to go out and better yourself?$K$PThat would be more in keeping with
your personality, no?$K
$F3$PI suppose you're right.$K    $R�w�i�Ȃ���b|$F3$FCL_IKE|$F1$FCL_TIAMAT|$F3$P...$K
$F1$PWhat's wrong, $w2Ike?$w4
You seem lost in thought.$K
$Ub$H$F3$PI don't understand what my father's doing.$w4
Why put a new recruit like me$w2 in
charge of something so important?$K
$F1$PYou're$w3 going to succeed him$w2
as our commander some day.$K$PPerhaps he wants you to learn$w2
the qualities of leadership.$K
$F3$PMe? $w2I don't... I don't know if I'm cut out
to be a leader.$w4 And even if I am,$w2
that day's a long way off, right?$K$PI mean, $w2I'm inexperienced. Weak.$w4
I'm nothing compared to my father.$K
$F1$PWell,$w4 I'm sure $w2you have some time.$w4
Still, $w2it's never too early for you to
start preparing for that day.$K$FS$PAnd if you truly think you're weak, shouldn't
you train and study to improve yourself?$K$PCommander Greil's counting on you,$w2
you know?$K
$F3$PYou're right...$K   $R�w�i�Ȃ���b|$F3$FCL_IKE|$F1$FCL_SENERIO|$F3$PHow did things look over there,$w2 Soren?$K
$F1$PSame as here. There are corpses
strewn everywhere.$K
There are quite a lot of them,$w2
especially when you consider how
far we are from the capital.$K
$F4$FCL_TIAMAT|$F4$PAre they Crimean?$K
$F0$FCL_KILROY|$F0$P...$w2Judging by the armor,$w2
the vast majority of the dead
are$w2 Daein soldiers.$K
$F3$PSo Crimea has the upper hand?$K
$F1$PJust the opposite, I think.$w4
The Crimean soldiers were members
of the Imperial Guard.$K$PThat means King Ramon--$w2or another
member of the royal family--$w2was on
the move when Daein soldiers fell on them.$K
$F4$PCould it have been$w4 Lord Renning?$K
$F1$PNo. $w2As long as the Crimean army still
draws breath, $w2Lord Renning will not
leave their command.$K$PPerhaps $w2another member of the court...$K
$F0$FD$F0$FCL_GATRIE|$F0$PWe've got Daein soldiers moving in on our
location!$w4 And they don't look happy!$K    $R�w�i�Ȃ���b|$F3$FCL_IKE|$F1$FCL_SENERIO|$F3$PHow did things look over there,$w2 Soren?$K
$F1$PSame as here. There are corpses
strewn everywhere.$K
There are quite a lot of them,$w2
especially when you consider how
far we are from the capital.$K
$F4$FCL_TIAMAT|$F4$PAre they Crimean?$K
$F0$FCL_KILROY|$F0$P...$w2Judging by the armor,$w2
the vast majority of the dead
are$w2 Daein soldiers.$K
$F3$PSo Crimea has the upper hand?$K
$F1$PJust the opposite, I think.$w4
The Crimean soldiers were members
of the Imperial Guard.$K$PThat means King Ramon--$w2or another
member of the royal family--$w2was on
the move when Daein soldiers fell on them.$K
$F4$PCould it have been$w4 Lord Renning?$K
$F1$PNo. $w2As long as the Crimean army still
draws breath, $w2Lord Renning will not
leave their command.$K$PPerhaps $w2another member of the court...$K
$F0$PUh-oh.$w4 Trouble...$w3 I see Daein
soldiers--$w2and they're coming this way!$K $R�w�i�Ȃ���b|$F3$FCL_IKE|$F1$FCL_SENERIO|$F3$PHow did things look over there,$w2 Soren?$K
$F1$PSame as here. There are corpses
strewn everywhere.$K
There are quite a lot of them,$w2
especially when you consider how
far we are from the capital.$K
$F4$FCL_TIAMAT|$F4$PAre they Crimean?$K
$F0$FCL_GATRIE|$F0$PI don't think so.$w2 Look at that black
armor,$w2 Ike. The vast majority of the
dead are$w2 Daein soldiers.$K
$F3$PSo Crimea has the upper hand?$K
$F1$PJust the opposite, I think.$w4
The Crimean soldiers were members
of the Imperial Guard.$K$PThat means King Ramon--$w2or another
member of the royal family--$w2was on
the move when Daein soldiers fell on them.$K
$F4$PCould it have been$w4 Lord Renning?$K
$F1$PNo. $w2As long as the Crimean army still
draws breath, $w2Lord Renning will not
leave their command.$K$PPerhaps $w2another member of the court...$K
$F3$PWait, over there!$w4 Someone's
coming this way!$K   $R�w�i�Ȃ���b|$F3$FCL_IKE|$F1$FCL_SENERIO|$F3$PHow are things looking over there,$w2 Soren?$K
$F1$PSame as here. There are corpses
strewn everywhere.$K
There are quite a lot of them,$w2
especially when you consider how
far we are from the capital.$K
$F4$FCL_TIAMAT|$F4$PAre they Crimean?$K
$F1$PNo. $w2See their armor? They seem
mostly to be Daein soldiers.$K
$F3$PSo Crimea has the upper hand?$K
$F1$PJust the opposite, I think.$w4
The Crimean soldiers were members
of the Imperial Guard.$K$PThat means King Ramon--$w2or another
member of the royal family--$w2was on
the move when Daein soldiers fell on them.$K
$F4$PCould it have been$w4 Lord Renning?$K
$F1$PNo. $w2As long as the Crimean army still
draws breath, $w2Lord Renning will not
leave their command.$K$PPerhaps $w2another member of the court...$K
$F3$PAh!$w4
Someone's coming this way!$K  $R�w�i�Ȃ���b|$F0$FCL_MAIZIN|$F0$PYou there! $w2Who are you?$w4
What are you doing here?$K
$F3$FCL_TIAMAT|$F3$PWe're no one you need--$K
$F0$PYou're armed!$w3 Heed me!$w4
Drop your weapons and surrender!$w5
Act quickly, or else!$K
$F4$FCL_CHINON|$F4$PListen to me, fool.$w4 You're making
a mistake.$w4 We're not...$w2$K
$F0$PAh, not going to cooperate, $w2eh?$K$PReady your weapons, $w2men!$w5
Move in $w2and kill them all!$K$F4$FD$N$UB$H $R�w�i�Ȃ���b|$F0$FCL_MAIZIN|$F0$PYou there! $w2Who are you?$w4
What are you doing here?$K
$F3$FCL_TIAMAT|$F3$PWe're no one you need--$K
$F0$PYou're armed!$w3 Heed me!$w4
Drop your weapons and surrender!$w5
Act quickly, or else!$K
$F3$PListen,$w4 we have nothing to do with
the Crimean army. We're only--$K
$F0$PAh, not going to cooperate, $w2eh?$K$PReady your weapons, $w2men!$w5
Move in $w2and kill them all!$K$N$UB$H    $F3$PTsk!$w4 Headstrong fools!$K
$F3$FD$F3$FCL_SENERIO|$F3$PGetting caught up in some skirmish$w2
is not $w2part of the plan...$K
$F4$FCL_IKE|$F4$PBut $w2they're obviously not going
to listen to us.$w4
Greil Mercenaries! Get ready to fight!$K  $R�㉺��b|$s0$FS$c0CHINON|$s0All right, $w2Ike.$w4 Let's see how you
handle the role of captain.$K$PWell? What are your orders, boy?$w4
We'll do what you say, so long as
you hurry up and spit it out!$K
$c1IKE|$s1I know, I know!$w4 I'm thinking!$w2
Give me a moment,
will you, $w2Shinon?$K
$s0$FABah.$w4 Useless! We'd be
better led with Mist than this
soft, untested whelp.$K$d0  $R�㉺��b|$s0$FS$c0CHINON|$s0All right, $w2Ike.$w4 Let's see how you
handle the role of captain.$K$PWell? What are your orders, boy?$w4
We'll do what you say, so long as
you hurry up and spit it out!$K
$c1IKE|$s1I know, I know!$w4 I'm thinking!$w2
Give me a moment,
will you, $w2Shinon?$K
$s0$FABah.$w4 Useless! We'd be
better led with Mist than this
soft, untested whelp.$K$d0
$s1Let's see...$w4
We're in the middle of the road,$w2
and there's not much $w2cover.$K$PSoren and Rhys are vulnerable,$w2
so we have to protect them from
enemy attacks... $w2Right?$K
$s0$FS$c0SENERIO|$s0That's a sound strategy, Ike.$w4
I can attack from behind your
defenses. Good thinking.$K
$s1Do you mean that?$w5 Um...all right!$w2
Let's do that then.$K   $R�㉺��b|$s0$FS$c0CHINON|$s0All right, $w2Ike.$w4 Let's see how you
handle the role of captain.$K$PWell? What are your orders, boy?$w4
We'll do what you say, so long as
you hurry up and spit it out!$K
$c1IKE|$s1I know, I know!$w4 I'm thinking!$w2
Give me a moment,
will you, $w2Shinon?$K
$s0$FABah.$w4 Useless! We'd be
better led with Mist than this
soft, untested whelp.$K$d0
$s1Let's see...$w4
We're in the middle of the road,$w2
and there's not much $w2cover.$K$PSoren's vulnerable,$w2 so we have
to protect him from enemy
attacks, $w2right?$K
$s0$FS$c0SENERIO|$s0That's a sound strategy, Ike.$w4
I can attack from behind your
defenses. Good thinking.$K
$s1Do you mean that?$w5 Um...all right!$w2
Let's do that then.$K $R�㉺��b|$c0SENERIO|$s0Ike, $w2do you have any ideas
on how you want to approach
this fight?$K
$c1IKE|$s1Let's see...$w4
We're in the middle of the road,$w2
and there's not much $w2cover.$K$PYou're vulnerable, $w2so I have to
be sure you're protected from
enemy attacks, $w2right?$K
$s0$FSThat's a sound strategy, Ike.$w4
I can attack from behind your
defenses. Good thinking.$K
$s1Really?$w5 All right, $w2let's do that then.$K  $R�㉺��b|$c0SENERIO|$s0Ike, $w2do you have any ideas
on how you want to approach
this fight?$K
$c1IKE|$s1Let's see...$w4
We're in the middle of the road,$w2
and there's not much $w2cover.$K$PYou're vulnerable, $w2so we have to
protect you from enemy attacks...$w2
Right?$K
$s0Right.$w2 Er...sorry for the trouble...$w4
but I appreciate the consideration.$K
$s1Sure.$w5 All right, $w2let's do that then.$K  $R�㉺��b|$c0IKE|$s0Titania, $w2I want you to fall back.$K
$c1TIAMAT|$s1Understood.$w4 I'm leaving this in
your hands, $w2Ike.$K
$s0Right. $w2I'll give it a shot.$K   $R�㉺��b|$c0MAIZIN|$s0Grrr!$w3 Blasted mercenaries.$w4
They're better than I expected.$K$PEven so, they'll not prove a match
for Daein's finest!$K    $R�㉺��b|$c0MAIZIN|$s0Bah!$w4 You're nothing more than
a bunch of ragtag sellswords.$w2
Who are you to oppose Daein!?$K$PYou are so terribly ignorant$w2 of your
position in this world.$K
$c1IKE|$s1You refused to listen to us,$w2 and then
you attacked without provocation!$w2
Is this the way of the Daein army?$K
$s0You're a cheeky little monkey, aren't
you?$w4 Once you're dead,
you'll regret sassing me!$K    $R�㉺��b|$c0MAIZIN|$s0I've fought the Crimean army before.$w3
The Imperial Guard has some skill,$w2
but the rest are a poor joke.$K$PWhich will you prove to be?$w4 Hmm?$FS
Perhaps you'll offer me some
entertainment after all.$K
$c1TIAMAT|$s1If you attacked us because you
thought we were with the Crimean
army,$w4 you made a mistake.$K$PI left my post years ago.$w4
Now, $w2I'm nothing more than
a common mercenary.$K
$s0That means nothing to me.$w4
You're not of Daein, $w2you're
armed, $w2and you're here.$K$PIt's our job to destroy you.$w4
Simple, wouldn't you say?$w5
Come, dog! $w1Prepare yourself!$K
$s1I'd just as soon avoid this bloodshed,
but that seems unlikely.$w4 If that's
the way it is, I'll not hold back!$K    $R�㉺��b|$c0MAIZIN|$s0A mage, eh?$w4 I'll have to keep my
guard up around you, no matter
how young you look.$K
$c1SENERIO|$s1You forced this combat.$w2 We
cannot allow you to return
home.$w4 Are you ready to die?$K    $R�㉺��b|$c0MAIZIN|Gwaa haa...$w4 Wretched curs...$w2
You will $w2regret your$w3 decision
to oppose$w3 Daein$w1...$K  $R�w�i��b|$B����-�[��|$<$F3$FCL_IKE|$F1$FCL_TIAMAT|$F3$PDid we suffer any casualties?$K
$F1$PAny wounded or dead?$w4$FS
No? Excellent!$w3 Well done!$K $=0300$R�w�i��b|$B����-�[��|$<$F3$FCL_IKE|$F1$FCL_TIAMAT|$F3$PTitania, $w2are you all right?$K
$F1$PI got careless,$w4 Ike.$w2
I've let you down.$K$PI'm in no shape to fight,$w2 not after
that battle, but I'll dedicate myself
to serving as your advisor.$K
$F3$PBut, Titania...$K
$F1$PI'm sorry...$w3$Fc
This injury is...$w4 I cannot--$K
$F3$PIt's all right, Titania. I understand.
You don't have to say anything more.$K
$F1$P$Fd$FSDon't look so glum, Ike.$w5
I'm...still alive.$w3 I was lucky.$K
$F3$PLucky...$K
$=0300 $=0300$R�w�i��b|$B����-�[��|$<$F3$FCL_IKE|$F1$FCL_SENERIO|$F1$P...Forgive me.$w4 I $w2was nothing more
than a hindrance.$K
$F3$PDon't worry about it.$w4
Your health is more important.$w2
How bad is the wound?$K
$F1$P$Fc...$K
$F3$PThat bad?$w4 Well then, $w2from now on,
I want you to be an intelligence officer.$K
$F1$P$FdWhat?$w4
Are you serious?$K
$F3$PAre you so opposed to the idea?$K
$F1$POf course not!$w5
I thought...$w2I...$w4 I assumed
I would be...$w2let go...$K
$F3$PDon't be stupid.$w4 An intelligence officer$w2
assists with strategy and planning,
right? There's no combat of any kind.$K$PThere shouldn't be any problems.$w4
I'm sure the commander will approve
of the idea.$K
$F1$P$FS...Th-thank you.$w5 I'll try to$w2
bring honor to the position.$K
$=0300  $=0300$R�w�i��b|$B����-�[��|$<$F1$FCL_IKE|$F3$FCL_TIAMAT|$F1$P...$K
$F3$P...Ike...$w2 I understand how you must
be feeling, but...$w3 You can't blame
yourself for what happened.$K$PWe faced a well-trained opponent...$w4
There was no way we could have fought
Daein$w3 and escaped without losses.$K
$F1$PBut these losses? $w2Rhys...$w2
Gatrie...$w4and Shinon?$K
$F3$PRemember this feeling always.$w5
Use the pain to win next time.$K$PThat is the best way$w3 to honor our
fallen companions.$K
$F1$P...$w2I understand...$K
$=0500  $=0300$R�w�i��b|$B����-�[��|$<$F1$FCL_IKE|$F3$FCL_TIAMAT|$F1$P...$K
$F3$P...Ike...$w2 I understand how you must
be feeling, but...$w3 You mustn't blame
yourself for what happened.$K$PWe faced a well-trained opponent...$w4
There was no way we could have fought
Daein$w3 and escaped without losses.$K
$F1$PI can't believe Shinon's gone.$K
$F3$PRemember this feeling always.$w5
Use the pain to win next time.$K$PThat is the best way$w3 to honor
his memory.$K
$F1$P...$w2I understand...$K
$=0500    $=0300$R�w�i��b|$B����-�[��|$<$F1$FCL_IKE|$F3$FCL_TIAMAT|$F1$P...$K
$F3$P...Ike...$w2 I understand how you must
be feeling, but...$w3 You mustn't blame
yourself for what happened.$K$PWe faced a well-trained opponent...$w4
There was no way we could have fought
Daein$w3 and escaped without losses.$K
$F1$PI can't believe Gatrie's gone.$K
$F3$PRemember this feeling always.$w5
Use the pain to win next time.$K$PThat is the best way$w3 to honor
his memory.$K
$F1$P...$w2I understand...$K
$=0500    $=0300$R�w�i��b|$B����-�[��|$<$F1$FCL_IKE|$F3$FCL_TIAMAT|$F1$P...$K
$F3$P...Ike...$w2 I understand how you must
be feeling, but...$w3 You mustn't blame
yourself for what happened.$K$PWe faced a well-trained opponent...$w4
There was no way we could have fought
Daein$w3 and escaped without losses.$K
$F1$PI can't believe Rhys is gone.$K
$F3$PRemember this feeling always.$w5
Use the pain to win next time.$K$PThat is the best way$w3 to honor
his memory.$K
$F1$P...$w2I understand...$K
$=0500 $=0300$R�w�i��b|$B����-�[��|$<$F1$FCL_IKE|$F3$FCL_TIAMAT|$F1$P...$K
$F3$P...Ike...$w2 I understand how you must
be feeling, but...$w3 You mustn't blame
yourself for what happened.$K$PWe faced a well-trained opponent...$w4
There was no way we could have fought
Daein$w3 and escaped without losses.$K
$F1$PBut these losses? $w2Shinon$w4 AND Rhys?$K
$F3$PRemember this feeling always.$w5
Use the pain to win next time.$K$PThat is the best way$w3 to honor our
fallen companions.$K
$F1$P...$w2I understand...$K
$=0500   $=0300$R�w�i��b|$B����-�[��|$<$F1$FCL_IKE|$F3$FCL_TIAMAT|$F1$P...$K
$F3$P...Ike...$w2 I understand how you must
be feeling, but...$w3 You mustn't blame
yourself for what happened.$K$PWe faced a well-trained opponent...$w4
There was no way we could have fought
Daein$w3 and escaped without losses.$K
$F1$PBut these losses? $w2Shinon$w4 AND Gatrie?$K
$F3$PRemember this feeling always.$w5
Use the pain to win next time.$K$PThat is the best way$w3 to honor our
fallen companions.$K
$F1$P...$w2I understand...$K
$=0500 $=0300$R�w�i��b|$B����-�[��|$<$F1$FCL_IKE|$F3$FCL_TIAMAT|$F1$P...$K
$F3$P...Ike...$w2 I understand how you must
be feeling, but...$w3 You mustn't blame
yourself for what happened.$K$PWe faced a well-trained opponent...$w4
There was no way we could have fought
Daein$w3 and escaped without losses.$K
$F1$PBut these losses? $w2Gatrie...$w4and Rhys?$K
$F3$PRemember this feeling always.$w5
Use the pain to win next time.$K$PThat is the best way$w3 to honor our
fallen companions.$K
$F1$P...$w2I understand...$K
$=0500 $R�w�i��b|$B����-�[��|$<$F0$FCL_CHINON|$F3$FCL_GATRIE|$F3$PI don't know... $w2Taking out these
Daein soldiers may have been a bad move.$w4
Um...$w4 Hey, Shinon? $w2What are you doing?$K
$F0$P$FSThis swine's $w2got some nice weapons.$w4
Besides, he ain't gonna complain.
He won't need them where he's going.$K
$F3$FD$F3$FCL_IKE|$F3$PShinon!$K
$F4$FCL_SENERIO|$F4$PGet ahold of yourself!$w4 We can't afford
such behavior right now. Steal from the
dead on your own time.$K
$F0$P$FAWhat? $w2You judgmental little--$K
$F4$FD$F4$FCL_TIAMAT|$F4$PSoren! Shinon! Stop this at once!$w4
This is no place for us to waste time
bickering amongst ourselves!$K
$=0300    $R�w�i��b|$B����-�[��|$<$F3$FCL_IKE|$F3$PLet's clear out of here.$w4 We have
to tell the commander what happened.$K
$F5$FCL_SENERIO|$F5$PLet's take this road.$w4 We should be able
to cut through the forest and...$K$PHuh?$K
$F3$PSomething wrong?$K
$F5$PNo, $w2as I said, this road...$K
$Ub$H$F4$FCL_KILROY|$F4$PWait!$w4 Ike, I just saw something move
on the far side of that thicket!$K
$F3$PA wounded soldier, perhaps?$w4
Let's go have a look.
Careful, now.$K
$=0500  $R�w�i��b|$B����-�[��|$<$F3$FCL_IKE|$F3$PLet's clear out of here.$w4
We have to tell the commander
what happened.$K
$F5$FCL_SENERIO|$F5$PLet's take this road.$w4
We should be able to cut through
the forest and...$K$PHuh?$K
$F3$PSomething wrong?$K
$F5$PNo, $w2as I said, this road...$K
$Ub$H$F4$FCL_TIAMAT|$F4$PIke, $w2I just saw something move
on the far side of that thicket!$K
$F3$PA wounded soldier, perhaps?$w4
Let's go take a look.
Careful, now!$K
$=0500    $R�w�i��b|$B�X-�[��|$<$F5$FCL_KILROY|$F5$POh, no...$K
$F3$FCL_IKE|$F3$PDid you find anything, Rhys?$K
$F5$P...It's a woman...$K
$F4$FCL_SENERIO|$F4$PLeave her.$w4
We shouldn't get involved in matters
that don't concern us.$K
$F0$Fc$F0$FCL_ERINCIA|$F0$POooh$w4...$K$F0$FD
$F5$P$FSThank goodness...$w4 It looks like
she's merely fainted.$K$F5$FD
$F3$PRight.$w2 We'd better take her with us
for now and make sure she's all right.$w4
Give me a hand, $w2will you, Rhys?$K
$F1$FS$F1$FCL_KILROY|$F1$POf course.$K
$F4$P...I don't like this...$K
$=1500    $R�w�i��b|$B�X-�[��|$<$F5$FCL_TIAMAT|$F5$POh, look...$K
$F3$FCL_IKE|$F3$PDid you find anything, Titania?$K
$F5$PIt's...a young woman...$K
$F4$FCL_SENERIO|$F4$PLeave her.$w4
We shouldn't get involved in matters
that don't concern us.$K
$F0$Fc$F0$FCL_ERINCIA|$F0$POooh$w4...$K$F0$FD
$F5$P$FSShe fainted, but she's still breathing...
Ike, we can't leave her here.$K$F5$FD
$F3$PRight.$w2 We'd better take her with us
for now and make sure she's all right.$w4
Give me a hand, $w2will you, Titania?$K
$F1$FS$F1$FCL_TIAMAT|$F1$POf course.$K
$F4$P...$w5I don't like this...$K
$=1500   T`      T�   	  Yl     V�   "  ZH   .  Z�   8  [X   F  ]`   T  `d   c  bt   r  dd   �  fT   �  h@   �  jD   �  lH   �  nL   �  p�   �  r�   �  t�   �  v�    D    l     	  1  	�  B    S  �  d  �  u      �  h  �  h  �  x  �  �  �  �  �  �  �  !�  �  $�  �  &�    (�  !  +�  2  ,�  A  ,�  T  ,h  h  -<  |  .�  �  38  �  6�  �  :X  �  =�  �  A�  �  S�  �  D�  �  F�  �  HH    I<    Pp  &  R   3  J�  @  M�  SMS_05_BT MS_05_BT_IKE MS_05_BT_SE MS_05_BT_TI MS_05_DIE MS_05_ED_01_A MS_05_ED_01_B MS_05_ED_01_B2 MS_05_ED_01_C1 MS_05_ED_01_C2 MS_05_ED_01_C3 MS_05_ED_01_C4 MS_05_ED_01_C5 MS_05_ED_01_C6 MS_05_ED_01_C7 MS_05_ED_02_S MS_05_ED_03_A MS_05_ED_03_B MS_05_ED_04_A MS_05_ED_04_B MS_05_GMAP_02 MS_05_GMAP_04_01 MS_05_GMAP_04_02 MS_05_GMAP_04_03 MS_05_GMAP_04_04 MS_05_GMAP_04_05 MS_05_GMAP_05 MS_05_OP_01 MS_05_OP_02 MS_05_OP_03_00 MS_05_OP_03_02_A MS_05_OP_03_02_B MS_05_OP_03_02_C MS_05_OP_03_02_D MS_05_OP_03_02_E MS_05_OP_03_02_F MS_05_OP_03_02_G MS_05_OP_03_02_H MS_05_OP_03_03 MS_05_OP_03_03_DEL MS_05_OP_03_03_DISP MS_05_OP_03_03_SKIP MS_05_OP_03_04 MS_05_OP_04_A MS_05_OP_04_B MS_05_OP_05_A MS_05_OP_05_B MS_05_OP_05_C MS_05_OP_05_D MS_05_OP_06_02 MS_05_OP_06_A2 MS_05_OP_06_B2 MS_05_OP_06_C MS_05_OP_07 MS_05_OP_07B MS_05_OP_07C MS_05_OP_07_NORMAL MS_05_OP_07_NORMAL_2 