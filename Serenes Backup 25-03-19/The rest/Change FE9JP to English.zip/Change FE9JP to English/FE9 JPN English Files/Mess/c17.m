  v�  t       !                $R�w�i��b|$B�^�i�X�@-����|$<$F3$FCL_RIEUSION|$F1$FS$F1$FCL_OLIVER|$F3$PWhat is this?$w4 Who are you?$w4
What have you done with Naesala?$K
$F1$POh$MC...$MD$w4 Ooooo$MC...$MD$K
This $w2is something$w4 everyone should see.$w5
There can be no doubt--$w2I gaze upon the
last living wonder of the Serenes royalty.$K$PThose golden locks!$w2 Witness how they
gather in the morning sun$w2 and multiply
its brilliance.$K$PThe gentle lustre of those argent wings!
Manifest proof of royalty, as sure as I
am alive.$K$PMagnificent$MC...$MD$w4 Absolutely$w3 magnificent.
A true work of art wrought in flesh and
feather.$K$PAll this beauty$MC... $MDMine$MC...$MD$w4 The fortune I
paid the raven king$w2 seems like a
pittance compared to this treasure!$K
$F3$PWhat?$w4 Naesala$MC...$MDsold me?$w4
To YOU?!$K
$F1$POh ho ho ho!$K
You are exquisite, even in rage!$w5
Now, $w2if you behave yourself,$w2
I'll grant you a life of luxury$MC...$MD$K
$Ub$H$P$F1$FD$F0$FCL_OLIVER|$F0$POww!!!$w4 My nose!$w4 My beautiful nose!$K
$F4$FCL_BEGNION1|$F4$PBishop Oliver?!$w4 You winged freak!
You'll pay for that!$K
$F0$FD$F1$FCL_OLIVER|$F1$PNoooo!$w4 You mustn't harm him!
You mustn't ruffle a single feather
of those gorgeous wings!$K
$F4$FD$F1$PMy beauty, $w2you mustn't be frightened.$K$P$FSIn time, $w2you will come to see how kind$w2
and charitable a master I can be.$K
$F3$PThis is madness!$K
$F1$P$F1$FD$F0$FCL_OLIVER|$F0$POooh!$w4 S-so frightening! How delicious!$w4
But I fear that we must now be
separated for a short while.$K$PLoyal servants! Attend my words!$w4
You must not raise a hand to this one.$K$PPrepare his meals with care,$w3 and do
not disturb his rest.$w2 I would not see
his countenance marred by displeasure.$K$PHerons, you see, are$w5 such delicate things.$K$PAnd then, at the proper time$MC...$MD$w4
Yes, the proper time. $w2When will it be?$K$PI say to you, those haughty senators and
their ilk $w2have looked down their noses at
me for the last time! $w2I shall show them all!$K
Ooooh, but I must have a grand stage.
One where none can fail to see me.$K$PThe Serenes royals are creatures of legend,$w2
and when I arrive with one at my side$MC...$MD$w4 I
can hardly wait to see Duke Gados's face.$K$POh ho ho ho!$w4 Aho ho ho ho ho ho ho!$K$F0$FD
$F3$PNaesala, you wretch$MC...$MD$w2 Curse your eyes!$w5
How dare you $w2do this to me$MC...$MD$K
$=0800 $R�w�i��b|$B���{-�x�O�j�I��|$<$F1$FCL_SANAKI|$F3$FCL_IKE|$F4$FCL_TOPUCK|$F3$PI've brought him.$K
$F1$P$FSWell done, $w2Ike.$w4
I shall see that you are well rewarded.$K
$F3$PWhere's your usual entourage?$w4
I see only two of your holy guard$MC...$MD$K
$F1$P$FAOh, there was some sort of disturbance.$w4
I think they're clearing away the rabble.$K$PBut on to business$MC...$MD$w4 Is that one there$w2
the ringleader of the thieves?$w4
Why, $w2he's nothing but a child!$K$PHas he$w3 offered up any kind of defense
for his deplorable actions?$K
$F4$PWe are no thieves!$w4 We are trying to free
the laguz that$w3 these filthy
aristocrats hold in captivity!$K
$F1$PWhat manner of absurd fairy tale is this?$K$PIn the year Begnion 624,$w4 Apostle Misaha,
my honored grandmother, emancipated
every last laguz slave.$K$PIn accordance with her law,$w2 today there
is not a single slave to be found in all of
the Begnion Empire.$K
$F4$PYou lie!$K
Countless noble houses$w2 even
now keep laguz as servants or
entertainment$MC...$MD$w5or worse!$K$PAnd the senate! $w2Those vast windbags
grant tacit approval by doing nothing!$K
$F3$PThat's enough!$w4 I told you to
keep a cool head.$K
$F4$PBu-$w2but$MC--!$MD$K
$F1$PIke$MC...$MD$w2 Whyever would you bring such
an ill-mannered rogue to meet me?$K$PWhat is it you're planning?$K
$Ub$H$F3$PIf anyone's planning something,$w2
it's you.$K
$F1$PReally? $w2And what could you possibly
mean by that?$K
$F3$PYour last mission showed us the slave trade,$w2
and now you've put us in contact with an
underground emancipation group.$K$PFrom the very beginning, I found this
whole arrangement a little odd.$K$PYou have more vassals than you can use,$w2
yet you hire us for these missions?$w2
Your motivations have me puzzled.$K
$F1$POh, I see. And have you solved this
puzzle of yours?$K
$F3$PYou want to expose the depravity of the
inner circles of power.$K
But $w5you don't want the general public
to know that the majority of the senate
is involved in slavery.$K
$F1$PAnd to think I thought you were as
untutored as a wild monkey.$w2$FS
You're actually quite bright.$K
$F3$PI didn't figure it all out by myself.$w4
I have companions whom I trust
with my life. They helped.$K
$F4$PHey! Hold it!$K$PWhat in the world are you talking about?$w4
Would someone like to explain this to me?$K
$Ub$H$F3$PThe apostle is aware of the laguz slavery.$w4
On top of that, $w2it appears she intends
to do something about this problem.$K
$F4$PAre you$w2 serious?$K
$F1$PI am. However, whether I succeed or fail$w2
depends largely on what you do next.$K$F4$FD
$F3$PSo be it. $w2I think it's time you told us about
the next job you have lined up for us.$K
$F1$P$FAI've received reports that Bishop Oliver,
the duke of Tanas,$w3 is up to something
suspicious.$K$PDuke Tanas has a villa near the woods of
Serenes. $w2Go there,$w3 and return with
irrevocable proof of$MC...$MDwhatever he's doing.$w2$K$PIf you succeed in this, $w2I promise to support
your Princess Elincia with all the power
at my command.$w2$K
$F3$PWe'll bring back whatever information
it is you're looking for.$w3 Be ready for us!$K
$=1000$Ub$H   $R�w�i��b|$B�^�i�X�@-��O|$<$F3$FCL_IKE|$F4$FCL_SENERIO|$F3$PIs this the place?$K
$F4$PYes, it is.$w4 It's rather heavily guarded.$K$PEven so, I think a direct attack would be
our best chance of gaining entrance.$K
$F0$FCL_BEGNION1|$F0$PHalt!$K$PWho goes there? $w2What are you doing?$w4
This villa is the property of Duke Tanas,
senator of the empire! $w2No trespassing!$K
$F3$PI am Ike, of the Greil Mercenaries.$K$PUnder orders from the apostle,$w2 we've been
charged with investigating the duke.$w2$K
$F0$PWhat?$w4 The apostle sent you?$w4
Wa-$w2wait here a moment!$K$F0$FD
$Ub$H$F1$FCL_MIST|$F1$PAll right, $w2Brother,$w4 we'll sneak around
out here and see what we can see.$K
$F3$PGood idea.$K
$F0$FS$F0$FCL_TIAMAT|$F0$PLeave it to us.$w4 If we get stopped,
we can talk our way out of it.$w4
All right, $w2Mist, $w2let's get going.$K
$F1$PYeah!$K$P$F0$FD$F1$FD
$Ub$H$F0$FCL_OLIVER|$F0$PWhat is it I hear? That you lads claim
to be here on the apostle's business?$K
$F3$PWe have a letter here that bears her seal.$K
$F0$PHmm$MC...$MD$w4 Well$MC...$MD$w2 I see.$w4 It appears genuine.$K$PVery well. $w2Am I in a position to ask what,
exactly, I am $w2suspected of doing?$K
$F4$P$FhWe are here by the apostle's leave.$w2
Do you honestly intend to make us
discuss this private matter outside?$K
$F0$POh!$K
No, $w2no,$w4 of course not.$w4 Never!$w6
I would never insult$MC...$MD$w5
Please, $w2c-come inside$MC...$MD$K $R�w�i��b|$B�^�i�X�@-����|$<$F3$FCL_IKE|$F0$FCL_OLIVER|$F0$POh?$K$PSlavery? $w2Me?$w3 The apostle would
honestly accuse me of such an
unfashionable thing as slaveholding?$K$POh ho ho ho!$K
$F3$PDo you claim no knowledge of
such a thing?$K
$F0$PI've shown you every nook of my mansion,
every cranny. I've been most thorough,$w2
have I not?$K$PAnd you saw no trace,$w2 not a single sign,$w2
of any laguz here,$w2 did you?$K
$F3$PThat is true.$w2$K
$F0$PThis accusation is absolutely ridiculous!$K$PTo think that I, a bishop who serves only
the apostle's will,$w2 would do anything to
violate our country's emancipation act!$K$PBe certain that $w2you tell the apostle
everything!$w2 Tell her that Duke Tanas
is upright and cleanhanded!$K$PThere is not even a shadow of falsehood
in my noble eyes! Look into them deeply,
my boy, and tell me what you see$MC...$MD$K$FD
$F1$FCL_OLIVER|$F1$PWell?$w4 Hmmmmm?$K
$F3$PUgh! Hey, stop that!$w4 Back off!$K
$F1$FD$F0$FCL_OLIVER|$F4$FCL_SENERIO|$F4$PWe have little choice, do we$MC...$MD$w2
I think it would be best if we left
for the time being.$K
$F7$FCDUMMY|$F7$PHey! $w2Halt!$w2 You can't go in there!$K$FD
$F3$PAh!$K
$F0$FD$F0$FCL_BEGNION1|$Ub$H$F1$FCL_MIST|$F1$PIke!$K
$F3$PMist, $w2what is it?$K
$F1$PIke, I saw him! In a room on the top floor
of this building,$w3 I saw someone$MC--$MDI think
he was one of the bird tribe!$K$PHe looked like he was trying to jump
out a window, $w2but he was forced away
from it $w2and back into the room.$K
$F0$FD$F0$FCL_OLIVER|$F0$PWha-$w4what?$w4 What is this$MC...$MD$w4
this child babbling about?$K
$F4$PSomeone from the bird tribe?$w4
Can you describe him?$K
$F1$PUm, $w2he had long hair!$w4 It was$MC...$MD$w2
sparkling, like gold.$w2 And his skin$MC...$MD$w2
it was so pale$MC--$MDalmost translucent.$K$POh!$w4 And his wings! $w2They were pure white!$K$FD
$F1$FCL_TIAMAT|$F3$PIs that accurate, $w2Titania?$K
$F1$PIt is.$w4 I saw him as well.$K$FD
$F4$PThat can only mean there is a member
of the heron clan in this place.$K$PAccording to books, $w2only members of the
royal heron family possess white wings.$K
$F3$PIt appears that $w2there is at least one
room we have yet to see.$K$PWhat is it going to be, Duke Tanas?$w4
You can cooperate and show us this room
that you somehow forgot, or$MC...$MD$K
$F0$PGuards!$K$PKill them all!$w4 Don't let a single one escape!$K$FD
$F3$PSo this is how you want to play it, eh?$w4
I thought it might come to this.$w2
Mercenaries! It's time!$K  $R�㉺��b|$c0DALAHOWE|$s0Devdan hears the sounds of battle$MC...$MD$K  $R�㉺��b|$c0KIMARSI|$s0You dare to bring conflict$w2 into Bishop
Oliver's home?$w4 My lance will make
you pay for your impudence!$K   $R�㉺��b|$c0DALAHOWE|$s0Uh-oh. $w2This won't do.$w4
Youngsters like you aren't supposed
to be fighting, you know?$K
$c1MIST|$s1Who, $w1who are you?$w4
Aren't you one of the guards?$K
$s0$FSDevdan is not a guard, little one.$w4
Devdan was looking at the pretty
garden$w2 and was captured.$K$PThe punishment for trespassing$w2
is to work for a year without pay...
That makes Devdan upset!$K
$s1Well,$w3 that doesn't seem fair.$w4
But $w2there's no need for you to
just accept such injustice.$K$PThe owner of this place, Duke Tanas,$w3
is keeping innocent laguz as slaves.
He's a very bad man.$K
$s0$FAMmm...$w3 That is not acceptable.$K
Devdan cannot forgive such $w2callous
and unjust actions.$w2$K
$s1So, $w2why don't you come with us then?$w5
Let's go and $w2teach the bad guys a
lesson together!$K
$s0$FSThat is a fine idea.$w4 Let us make
this Duke Tanas pay!$K  $R�㉺��b|$c0DALAHOWE|$s0Uh-oh. $w2This won't do.$w4
Youngsters like you aren't supposed
to be fighting, you know?$K
$c1LOFA|$s1Huh?$w4 Uh, who are you, sir?$K
$s0$FSSir? Ho!$w3 Devdan is no knight!$K$PDevdan is just a simple man who was
imprisoned for looking at the
flower garden.$K$PThe punishment was to work here for
an entire year$MC...$MD$w4without pay,
unfortunately.$K
$s1Is that so?$w4 That doesn't seem fair.$K
$s0This sad world knows little of "fair,"
does it?$w5 Now tell me, young one,
what are you doing here?$K
$s1Um, well$MC...$MD$w4there's a laguz birdman
being held captive here.$w4 I came
to help him.$K$PDuke Tanas is a bad man $w2who keeps
laguz as slaves. $w2That's why my
friends and I are here to stop him!$K
$s0$FASlaves?$w3 That is not acceptable!$K
Devdan cannot forgive such $w2callous
and unjust actions!$w2$K
$s1$FSIn that case, you should join up and
help us free them!$K
$s0$FSMmm... A fine idea!$w4 Devdan is ever
on the side of justice.$K  $R�㉺��b|$c0DALAHOWE|$s0Uh-oh. $w2This won't do.$w4
Youngsters like you aren't supposed
to be fighting, you know?$K
$c1SENERIO|$s1What was that?$w2 And who are you
supposed to be?$K
$s0$FSDevdan is not supposed to be anyone.$K$PDevdan was imprisoned for looking at
the flower garden.$K$PThe punishment for trespassing$w2
is to work here for an entire year$MC...$MD$w4
without pay, unfortunately.$K
$s1And then?$K$PAre you telling me this so that I will
let you go?$K
$s0$FAA moment! $w1Wait a moment.$w2
Devdan does not fight children.$K
$s1If that's true, $w2then why not switch
sides and join us?$K$PIf you become a member of the Greil
Mercenaries,$w2 we would pay you
for your services.$K
$s0$FSThat would be an honor!$w4 Please,$w2
allow Devdan to join you!$K
$s1Our contract is complete then.$w4
I will pass along the terms of the
agreement to our commander, Ike.$K$PNow then, $w2I expect you
to do your best.$K$d1
$s0Understood. Devdan is a very
hard worker.$K    $R�㉺��b|$c0DALAHOWE|$s0Uh-oh. $w2This won't do.$w4
Youngsters like you aren't supposed
to be fighting, you know?$K
$c1TOPUCK|$s1Wha-$w2what are you doing, old man?$w4
Don't startle me like that.$K
$s0$FSDevdan is no old man.$w4
Devdan was imprisoned for looking at
the lovely flower garden.$K$PThe punishment for trespassing$w2
is to work here for a single year$MC...$MD$w4
without pay, unfortunately.$K
$s1For free? Oh, I know all about that!$w2
Well, it's time to fight back!$K$P$FSC'mon!$w4 We came here$w2 to help
you out!$K$PFight with us!$w4 Get your freedom back!$K
$s0You speak oddly,$w2 but if you help me,$w2
then Devdan says thank you.$w4
Devdan is polite and well mannered!$K  $R�㉺��b|$c0DALAHOWE|$s0Uh-oh. $w2This won't do.$w4
Youngsters like you aren't supposed
to be fighting, you know?$K
$c1SOTHE|$s1And you are?$K
$s0$FSWho is Devdan? Devdan is$w5 Devdan.$w4
Devdan was imprisoned for looking at
the lovely flower garden.$K$PThe punishment for trespassing$w2
is to work here for a single year$MC...$MD$w4
without pay, unfortunately.$K
$s1Is that so$MC...$MD$w5 That's too bad,$w2
but I've got a job to do.$w4 A sad story
won't make me stay my blade!$K
$s0$FAA moment! $w1Wait a moment.$w2
Devdan does not fight children.$K
$s1Hmm$MC...$MD$K$PIn that case, $w2you should join us.$w4
That way, $w2we can take care of this
without me killing you.$K
$s0$FSUnderstood.$w4 Devdan is a friend
to young people everywhere.$K  $R�㉺��b|$c0DALAHOWE|$s0Forgiveness, please.$w4 Devdan will try
to restrain himself.$K    $R�㉺��b|$c0DALAHOWE|$s0No, no, no!$w4 Devdan $w2does not
fight children!$w4 Let us talk, please!$K   $R�㉺��b|$c0DALAHOWE|$s0It is better$MC...$MD$w4that Devdan gets hurt$MC...$MD$w4
than hurts$MC...$MD$w2someone else$MC...$MD$K   $R�㉺��b|$c0KIMARSI|$s0This is the domain of my master,$w2
Bishop Oliver, $w2the duke of Tanas.$K
You will learn that no one impugns his$w2
honor and lives to walk away!$K   $R�㉺��b|$c0IKE|$s0I don't want unnecessary bloodshed.$w4
Tell your men to stand down!$K$PIn your service to Duke Tanas,$w2
would you go so far as to oppose
the will of the apostle herself?$K
$c1KIMARSI|$s1...Defying Apostle Sanaki? Mmm...$w2
It is not something I am fool
enough$w2 to take lightly.$K$PTherefore, I will simply ensure that the
incompent messengers who attacked us
never return to her palace$MC...$MD$w2$K
$s0So that's your answer, is it?$K  $R�㉺��b|$c0KIMARSI|$s0Wretched, baseborn animal! Begone!$w2
You will not defile this place!$K    $R�㉺��b|$c0KIMARSI|$s0What$MC... $MD$w2What fate is this?$w5
Is it$w2 just punishment$MC...$MD$w4
for my complicity$MC...$MD$w2in this evil$MC...$MD$K   $R�w�i��b|$B�^�i�X�@-����|$<$w6$Ub$H$F4$FCL_RIEUSION|$F4$PAh!$K$P$F0$FS$F0$FCL_OLIVER|$F0$POh,$w2 my sweet, beautiful little bird!$w4
Don't be frightened!$w4
Come, let us fly away together$MC...$MD$K
$F4$PStay away from me,$w4 you filthy fat man!$K$P$Ub$H$F4$Fh$MC...$MDUrgh!$K$P$F0$FD$F6$FCL_OLIVER|$F6$PCome quietly!$w4$Fh You $w2belong to me!$K$PI will not give you up.$w4
No one shall take you from me$MC...$MD$K
$F4$P$FdThough the price may be my life,$w2
I will never cooperate with you!$K$F4$FD
$Ub$H$F7$FCDUMMY|$F7$PHey!$w4 Where are you, $w2Duke Tanas?$K$P$MC...$MDAre you in here?$K$P$Ub$H$F6$FD$F2$FCL_OLIVER|$F2$P$MC...$MDAh$MC...$MD N-n-$w2nooo$MC...$MD$K$P$F2$FD$w6$=0300  $R�w�i��b|$B�^�i�X�@-����|$<$F0$FCL_IKE|$F0$PDuke Tanas$MC...$MD$K
$F4$FCL_RIEUSION|$F4$PWho are you?$K
$F0$PAh!$K
You$MC... $MDYou're the Serenes$MC--$MD$K$PAre you unharmed?$w5
We have come to help you.$w4
Your injury$MC... $MD$w3Did that man do that to you?$K
$F0$FD$F1$FCL_IKE|$F1$PThis wound must be tended to$MC...$MD$K
$Ub$H$F4$PStay back!$K
$F1$PBut$MC...$MD$K
$F4$PDo not approach me!$w4
Cursed human!$K
$=1500    $R�w�i��b|$B���-��|$<$F1$FS$F1$FCL_SIGRUN|$F4$FCL_IKE|$F4$PThe Greil Mercenaries have returned.$K
$F1$PAh, Master Ike. It is good to see you well.$w5
How went the mission?$w4 Did you unearth
any $w2meaningful proof?$K
$F4$PWhere is the apostle?$K
$F1$PMaster Ike?$K
$F4$PI must speak with the apostle.$w4
Where is she?$K
$F1$P$FAApostle Sanaki $w2is in the garden, having a
pleasant conversation with
Princess Elincia.$K$PI will go directly and see if she will
meet with you.$w5 Please wait here.$K
$F4$PIn the garden?$w3 Great.$K$F4$FD
$F1$PAh, $w2Master Ike! No!$w4 You mustn't behave
so! You will cause such problems!$K
$=0500 $R�w�i��b|$B��̒�|$<$F3$FCL_IKE|$F3$PApostle$MC...$MD$K
$Ub$H$F1$FCL_SANAKI|$F1$PWhat?$w4 You! What are you doing?$w4
How dare you approach me unannounced!$w2
This is most inappropriate, and I will not$MC--$MD$K
$F0$FCL_ERINCIA|$F0$PWhat has happened, my lord Ike?$K
$F3$PAll of it. $w5I want to hear all of it$MC...$MD$w7
Now!$K
$F1$PWhat are you talking about?$K
$F4$FCL_SIGRUN|$F4$PMaster Ike!$w4 One must not speak to the
apostle in such a discourteous fashion!$K
$F3$PTwenty years ago,$w4 something happened
in Serenes Forest. Something terrible.$w4
I want to know.$K
$F1$PWhat?$K
$F4$PMaster Ike?$K
$F0$PW-what happened twenty years ago?$K$=1000   $=1000$R�w�i��b|$B���{-�x�O�j�I��|$<$F1$FCL_SANAKI|$F4$FCL_ERINCIA|$F3$FCL_IKE|$F0$FCL_SIGRUN|$F1$PYou found one of the heron clan?$w5
And a Serenes noble no less$MC...$MD$w3
One of them still lives?$K$PBut that$MC...$MD$w3such a thing$MC...$MD$K
$F0$PApostle Sanaki$MC...$MD$K
$F3$PTell me.$K
$F1$PThat is $w2a very$MC...$MDdifficult problem$MC...$MD
Hmm... How to impart this tale$MC...$MD$K
$F4$FD$F4$FCL_NASIR|$F4$PIt would appear $w2that no one is willing
to begin this story.$K$PThat being so, $w2I would open with
what is commonly known of the matter.$w4
Do you find this acceptable?$K
$F1$PAnd you are?$K
$F3$PHe is a friend of mine.$w4 Nasir, $w2if you
know something, I would hear it.$w4
When you are done,$w2 the apostle can clarify.$K$PAgreed?$K
$F1$PHmmm$MC...$MD$K
$Ub$H$F4$PIt begins with the assasination$w2 of
the previous Begnion apostle.$K$PIt was twenty years ago$MC...$MD$w4 One year after
the declaration of emancipation was made.$K$PThe leader at the time was the Apostle
Misaha, $w2who was more adored by the public
than any apostle before$MC...$MDor since.$K$PWhen she was assassinated,$w4
the citizenry was wracked with grief.$w4
All of Begnion despaired.$K$PAnd then, $w2a rumor began to circulate$w4
that the assassination was the work
of the Serenes herons.$K$PIn the twinkling of an eye, the rumor
spread throughout the Begnion capital.$K$POne night shortly thereafter,$w4 it happened.$w4$K
The citizens grew violent. $w2They massed at
the edge of Serenes Forest,$w4 home of their
supposed enemy, and set it to burn.$K$PThe crowd raged on for three nights,
and in the end,$w4 the heron clan was lost.$K$P$F4$FD$F4$FCL_ERINCIA|$F4$PBut their involvement was just a rumor...
Wasn't it?$w4 Why, $w2why did they$MC...$MD$K
$F1$POh, the shame of it$MC...$MD$K$P$F4$FD$F4$FCL_NASIR|$F4$PApostle?$w4 The remainder of the tale is yours.$K$PYou $w2stand as the empress of Begnion.$w4
You are responsible for the acts of your
citizens, are you not?$K
$F1$P$MC...$MDFalse. The accusation was completely
false.$K
$F3$PThe assassination of the apostle$w2
was not the work of the Serenes clan?$K
$F1$PThat is correct.$K
$F4$PThe heron clan $w2possess no fighting skills.$w4
Their tribe survived$w2 by living a life of
peace and piety within their forest.$K$PUnlike other laguz, $w2they never focused
on developing their strength for
the purposes of combat.$K$PAnyone with any knowledge of laguz$w2
would have known such a thing.$K$PAt the very least, $w2the citizens of Begnion
would have known this.$K$PHowever, $w2they had lost their leader,$w2
and in their grief, they cared little for
the truth.$K$PThey were merely looking for some way to
vent their rage and despair. Isn't that true$MC...$MD
Apostle?$K$P$F4$FD$F4$FCL_ERINCIA|$F4$PPlease,$w4 Lord Nasir!$w4
Your tone of voice$MC...$MD$K
$F1$PIt's all right,$w2 Princess Elincia.$w4
He speaks the truth, be it with
a sharpened tongue or no.$K$P$F4$FD$F4$FCL_NASIR|$F4$PIke, $w2the bird tribes of Phoenicis target
only Begnion ships with their piracy.$K$PThe ravens of Kilvas$w2 are after cargo,
and so they attack everyone
with equal vigor.$K$PThe hawk clans, however, hold the heron
clan as brethren$MC...$MDand still remember the
false accusations.$w5 And their brutal murder.$K
$F3$PThe heron at Oliver's mansion$MC...$MD$w4
He slapped my hand away when I tried
to help him.$K
He had such hatred in his eyes.$K$PWhen he leapt from the window,$w2 he spoke
to me.$K$P"Remember the genocide," he said.$w4
"Twenty years have passed, $w2but I will
never forgive what you did!"$w4$K
$Ub$H$F1$P$FcSuch needless pain$MC...$MD$K$P$FdIt may sound like utter hypocrisy,$w2
but my people $w2regret deeply the actions
of that horrific night.$K$P$FcWe stole the heron clan from this world$MC...$MD$w4
Every time we see the blackened forest,$w4
our grave sin comes back to haunt us.$K
$F4$PApostle$MC...$MD$w4 You are honorable.$K$PThe majority of the senators $w2have done their
best to banish all memory of the Serenes
and that night.$w2 Yet you have resisted.$K
That is your intent, is it not?$K$PYou are not like them$MC...$MD$w4
You are attempting to take responsibility
for the actions of the people.$K$PTo undo the wrongs of the past,$w2
you launched your own investigation
into the laguz emancipation issue.$K$PYou've even gone so far as to hire
outsiders like Ike and his mercenaries
to expose the problem, haven't you?$K
$F1$P$MC...$MD$w4$FdPrincess Elincia?$K$P$F4$FD$F4$FCL_ERINCIA|$F4$PYes?$K
$F1$PI would like once more to make use of your
escorts.$w4 Would you grant me this boon?$K
$F4$POf course! Er, that is$MC...$MD$w4
If Ike and his group agree,$w2 I have
no objection to your proposal.$K
$F3$PDepends on what you want.$K
$F1$PThe member of the heron clan you met$MC...$MD$w3
I want you to find him.$K
I want to meet with him.$w2
I want to speak with him.$K
$F3$P$FSIf that is your wish, $w2we will do it.$w4
$FAIn any case, $w2we let that monster
Oliver slip through our grasp.$K$PWe'll handle both tasks at the
same time.$w2$K
$F1$PI'm counting on you.$K
$=2000 $R�w�i��b|$B���-����-�x�O�j�I��|$<$F3$Fc$F3$FCL_MWARIM|$F3$PAhem$MC...$MD$K
$F1$FS$F1$FCL_TOPUCK|$F1$PMuarim!$K
$F3$P$FdLittle one!$K$PHow$MC...$MD$w2 How was it?$w4
Were you treated roughly?$w3
Did they attempt to$w2 punish you?$K
$F1$PNo,$w4 it was nothing.$K$PAnd the apostle?$w3 I thought she'd be some
mean old hag,$w4 but she's just a kid.$w4
Really, $w2she's even shorter than I am.$K
$F3$PLi-$w2little one!$w4 You must lower your voice.$w3
And watch your tongue!$K
$F1$P$FAWhat? $w2Why?$K
$F4$FCL_IKE|$F4$PRest easy, $w2Muarim.$w4
Everyone in this room$w3 is with me.$w4
The apostle has no ears here.$K
$F3$P$FcThat is good.$K
$F1$PMuarim?$K
$F3$P$Fd$F4$PSpeaking ill of the apostle here$w3 is
considered$w5 treasonous.$w4 Keep it up,
and $w2they'll kill you--or threaten to.$K
$F1$PWhat?$K
$F3$PLittle one$MC...$MD$w4 While we are here,$w2
please choose your words with
more care than you have shown.$K
I beg of you.$K
$F1$POh, right. Right.$w4 I understand.$K
$F4$PFor a laguz,$w3 you seem to know more
about the court etiquette here than my
fellow beorc, Tormod.$K
$F3$PBah$MC...$MD$K
$F1$PThat's 'cause$MC...$MD$w2'cause I don't know
much about any of this stuff.$w4
That's all!$w3$K
$F3$PIt is no matter,$w3 little one.$K$PIke,$w4 the reason I am familiar with the
customs of the Begnion nobles is$MC...$MD$w5
I myself was once a slave.$K
$F4$PWhat?$K
$F1$POh, no$MC...$MD$K
$F3$PFor generations, my family$MC...$MD$w4served as
slaves to one house.$w2 They were wealthy
and powerful, senators all.$K$PAs a child,$w3 I was raised never to
question my station as a slave.$K$PFrom the day that I was born,$w3 the
most grueling physical labor$w3 was as
natural as breathing. $w2I knew nothing else.$K$PTo ensure we were liked by our masters,$w4
we were drilled in the etiquette of polite
society $w2until it became second nature.$K$PWe were slaves$MC...$MD$w3 We did what we could
to live as long as we could.$K$PThe most important thing $w2was not to
incur the wrath of our masters.$K
If we displeased them, $w2we were punished.$w4
If we were lucky, we were beaten.$w5
If we were unlucky$MC...$MD$K
$F1$PMuarim!$w4
That's enough!$K
$F3$P$FcI am sorry.$w4 Lord Ike$MC...$MD$K$PIf a former slave like myself is present,$w3
all of you will$w3 be judged, scorned,$w2
and looked down upon.$K$PI came here$MC...$MDto ask if you would$MC...$MD
$w3take care of something for me.$w4
I would have you $w2take care of the little one.$K
$F1$PWhy would you say such a thing?$K$PYou were born a laguz slave$MC...$MD$w3
And you're not allowed to be free$MC...$MD$w5
That's not right!$K$PThat's why$w4 we promised each
other we'd change all of that.$w3
We made a promise!$K$PLaguz,$w3 like beorc, would build homes$w2
and plant fields!$w3 Families would live
together$w3 in peace and freedom!$K
That's the world $w2we dreamed of$MC...$MD$K
$F3$PThat's$w3 a dream $w2that belongs to us
as$w3 former laguz slaves.$K$Fd$PWe don't need the help of another beorc
like you.$K
$F1$P$FoWhat?$w4
$MC...$MD$Fhsniff!$K$P$F1$FD
$F3$PLittle one!$K$P$MC...$MD$Fc$K$P$F4$P$MC...$MD$w4Does it really$w3
warrant that much concern?$K
$F3$FD$F1$FCL_MWARIM|$F1$PHuh?$K
$F4$PSince I first arrived here in Begnion,$w4
it's something that's been bothering me.$K$PIf you're born into a noble house,
you're a noble.$w4 If your parents are
slaves, you're a slave.$K$PDo you think a person's worth is decided
at the moment of their birth?$K$PThat's$MC... $MD$w3I can't understand a country where
that passes for normal,$w4 I just can't.$K
$F1$PThose don't sound like the words of
someone working for Princess Crimea.$K$PPrincesses$w3 are princesses because
they're born into royal families, right?$K
Are you going to deny that?$K
$F4$PNo, $w2you're right.$w4 Elincia$MC...$MD$w2 She is a princess.$K$PI don't think we've treated her with more
respect than any other employer we've
had, but$MC...$MD$K$PHeh. Funny. We've addressed her as
"Princess" the entire time,$w3 but I've
never really considered what it meant.$w4$K
$F1$PFrom where I stand,$w3 I think you've
been $w2blessed.$K$PYou were born a beorc$w3 and raised in
a country with a lenient social structure.$w4
That's$w3 an enviable life.$K
$F4$PIt's so hard$MC...$MD$w4 I$MC...$MD$w3 No matter how I try,$w2
I'll never fully understand your pain.$K$PBut listen,$w3 I didn't treat Elincia any
differently after I learned of her heritage.$w3$K
I'm not going to think of you $w2or treat you
differently $w2just because you used to be
a slave.$w4 It's not going to happen.$K$PYou're$MC...$MD$w5you.$w4 And I'm free to think of it
that way if I want,$w4 right?$K
$F1$P$Fc$MC...$MD$K
$F4$PMuarim,$w3 there's nothing anyone
can do about your past.$w2
About the burdens you carry.$K$PAnd I know I don't know everything that's
going on,$w4 but you shouldn't be trying
to push Tormod away.$w3$K$PHe's dedicated to you, $w2and being with you
is his choice. $w5It's part of his $w2freedom.$K
$F1$P$MC...$MDI see now.$w5$Fd
I will go$MC...$MD$w3and find him.$K
$F4$PIf meeting those in the temple is
uncomfortable,$w3 I can go and bring
him back.$w2 What do you think?$K
$F1$P$FSNo, I can do it.$K
I have a good nose.$w4 Tracking the young
one's scent$w3 while avoiding other beorc
is an easy task.$K
$F4$P$FSI see.$K
$F1$P$FAIke$MC...$MD I want$MC...$MD$w2 I mean$MC...$MD$w5
$w2$FSNever mind.$K$PMay our friendship$w4 be true and enduring.$K
$F4$PI share your sentiment.$w4 Our troop will have
you$w2 for as long as you wish.$K    $SD$R�w�i��b|$B��̒�|$<$F3$FS$F3$FCL_SOANVALCKE|$F1$FCL_IKE|$F1$PWhat the...? Um...who are you?$w4
How long $w2have you been a member
of my troop?$K
$F3$PI $w2joined after the battle in the sands.$w4
My name is Stefan.$w4 I apologize for
not introducing myself earlier.$w2$K
$F1$PWhy are you here?$K
$F3$PIn part it's because I'm curious.$w3
But mostly, $w2it's the guiding hand of
fate that has led me to you.$K
$F1$PHuh?$K
$F3$P$FAIn the desert,$w3 I watched the dance
of your sword.$K$PYou have a unique style,$w2 but it is
incomplete, filled with hesitation.$w4 You
have$w4 recently lost your teacher,$w2 no?$K
$F1$PAh$MC...$MD$K
$F3$PLuckily, your foundation is quite strong.$w4$FS
Which is why $w2I can be of service.$K$PYour technique$MC... $MD$w3How powerful will it be
when perfected? $w2I would like to know.$K
$F1$PWh-who are you?$K
$F3$PYou can learn the dance of blades from me$w2
without knowing my history, can you not?$w4
What say you?$w3 Let your heart decide.$K$N$UB$H    Study   Don't study $SE$F1$PI understand. If you can help me perfect
my technique, I will gladly accept an
invitation to learn from you.$K
$F3$PThen prepare yourself.$w4 Come!$w3
Attack me with all your strength.$K  $SE$F1$PI appreciate the offer, $w2but I decline.$w4
I must perfect my technique on my own.
Under my own power.$K
$F3$PVery well.$w3
That, too, $w2is an honorable path.$w4
With your leave.$w2$K   $R�w�i��b|$B���-����-�x�O�j�I��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H    $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 By your leave,$w2
I will excuse myself.$K    7L      6   	  6`     7�   3  9�   @  :,   L  6�   V  :�   i  =x   u  ?    �  A�   �  D(   �  W�   �  m$   �  q   �  q�   �  q   �  q   �        	0    d    �  %  $�  1  $�  =  r�  I  s,  Z  s�  i  sD  x  %d  �  (�  �  ,�  �  0d  �  3  �MS_17_BT MS_17_BT_DALAHOWE MS_17_BT_DALAHOWE_CHILD MS_17_BT_IKE MS_17_BT_R1 MS_17_DIE MS_17_DIE_DALAHOWE MS_17_ED_01 MS_17_ED_03 MS_17_ED_04 MS_17_ED_05 MS_17_ED_06 MS_17_INFO_04 MS_17_INFO_05 MS_17_INFO_05_A MS_17_INFO_05_B MS_17_INFO_05_N MS_17_INFO_05_Y MS_17_OP_00 MS_17_OP_01 MS_17_OP_03 MS_17_OP_04 MS_17_OP_05 MS_17_OP_06 MS_17_REPO_BEGIN MS_17_REPO_DIE MS_17_REPO_END MS_17_REPO_NODIE MS_17_TK_01 MS_17_TK_02 MS_17_TK_03 MS_17_TK_04 MS_17_TK_05 