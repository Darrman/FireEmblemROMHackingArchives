  PA  Mt                        $RGMAP��b|$O3$GIn a valley amidst the Marhaut Range,$w3
Ike and company are reunited $w2with King
Caineghis of Gallia.$K$PKing Tibarn of Phoenicis $w2also arrives,
and brings with him a disturbing tale...$K$PHis words serve notice: There is no time
to waste. The final showdown with
Ashnard is coming.$K$P$Ub$HBetween the forces King Caineghis grants
them before returning home$w3 and the
soldiers King Tibarn brings,$K$Pthe Crimean army possesses three times
the fighting power that it did when it
left Begnion.$K$PEven so,$w3 the Daein forces encamped in
the capital $w2are strong, rested,
and comparable in number.$K$PIn addition,$w3 the road to the final
confrontation$w3 is blocked by two
formidable obstacles--$K$P$Ub$HFort Pinell and$w4 Nados Castle.$Ub$H$w4
How these two tests are faced$w3 will
mightily affect the course of the war.$K   $=0750$R�w�i��b|$B���{-�N���~�A|$<$F0$FS$F0$FCL_ASHNARD|$F4$FCL_DARKKNIGHT|$F0$PI see. $w2So Crimea and Gallia have finally
joined forces, have they?$w3 Half-breeds and
humans fighting side by side... How sweet!$K
$F4$PIn addition, $w2it seems the incident with
the heron princess has brought more
Phoenicians to the struggle as well.$K
$F0$POh, $w2the hawk king is getting involved, eh?$K
$F4$PWhich means that the Crimean army's
strength of arms is all but equal to our
own...and growing daily.$K$POf course, $w2this pathetic, ragged band
is still no match for our superior leadership
and skill.$K
$F0$PHeh heh heh... $w2Heeee hee hee hee!$w4
Things are getting interesting, are they not?$w3
But $w2I am still unsatisfied.$K$PDivide our army into two battalions,$w2
and send one to meet the Crimeans.$K
$F4$PAnd who...$w2will be in charge of that
battalion?$K
$F0$PBertram.$K
$F4$PBertram?$K
$F0$PDoes that bother you? Well then...$w4 Perhaps
I should leave it to you$w3 and see what
happens!$w4 Heee heee heee!$K
$F4$PDo you believe I would betray you?$K
$F0$PI believe$w3 your heart has considered it.$K
$F4$PSurely you jest...$K$PI will divide our forces and see that they
march to meet Crimea under Bertram's
command.$w4 Is this satisfactory?$K
$F0$PI leave it to you, good sir knight.$K
$F4$POne other thing, $w2Your Majesty.$w4
In my absence, $w2did you order the
death of Ena?$K
$F0$PEna? $w2Ena...?$w4 Oh, yes, her.
I'd forgotten about that one.$K$PI lost all interest in her when she failed to
hold Daein's capital, you know?
I've no use for failures...$K$PYes, yes, $w2I remember it now. I ordered
General Petrine to take care of her...$w4
Ha! Another failure under my command...$K$PI told Petrine that if the task was beyond
her,$w2 capturing Ena would be enough.$K
$F4$PI see.$K
$F0$PWhy do you ask?$K
$F4$PAccording to one of General Petrine's men,$w2
they have indeed captured Ena.$K$PBut, $w2with the general's death, $w2they're
unsure what to do with her.$K
$F0$PHeh heh.$w4 That was one of Petrine's better
qualities. $w2She always did follow orders.$w4
Well, $w2what do you intend to do?$K
$F4$PI wish to receive your instructions.$w3 Do
you still wish to see her killed, $w2or have
you changed your mind?$K
$F0$P$FAMmm. Do as you will. I care not.$w4$FS However!
Do not bring her into my presence!$K$PWhen that one is near, $w2Rajaion seems to
grow restless.$K
$F4$PAs you wish.$K
$=0900   $R�w�i��b|$B�V����c�p|$<$F3$FCL_SENERIO|$F1$FCL_IKE2|$F1$PEveryone seems to be here.$w4 Go ahead,
Soren. You can begin now.$K
$F3$PVery well.$K   $R�̂݉�b|$F1$FCL_SENERIO|Please look at this map.$K$PThe current position of our army$w3
$Ub$His here in the Marhaut Range.$K$PBetween us and the capital there are two
large outposts of enemy troops--$w4
Fort Pinell and $w2Nados Castle.$K    $R�̂݉�b|$F1$FCL_ULYSSES|Both holds were built to guardian our
fair land.$K$PBut now Daein rules them both,
and knows of us. With rations set,
they could hold out a year.$K$PSay what you will of Daein and her foul
plans.$w4 One must admire her skill
in things of war.$K$F1$FD$P$F1$FCL_GEOFFRAY|Come now, $w2Bastian!$w4 Why would you
praise our foe?$K$F1$FD$P$F1$FCL_ULYSSES|I do but speak the mean of it, good sir.
The truth is harsh, but lies would be
worse still.$K$F1$FD$P$F1$FCL_LUCHINO|Will you two please shut up?$w4 Please?
Sheesh!$K$F1$FD$P$F1$FCL_GEOFFRAY|...$K$F1$FD$P$F1$FCL_IKE|Pinell and Nados are fairly close to one
another.$w4 I doubt they would expect us
to attack both at once, but...$K$F1$FD$P$F1$FCL_TIAMAT|That seems to be a waste of our strength.$w4
And we don't want to get ambushed from
the rear while attacking.$K$F1$FD$P$F1$FCL_SENERIO|We cannot divide our army, $w2but we could
send a small force $w2to attack the base with
weaker defenses and keep it occupied.$K$PAt the same time, $w2the main army $w2can
focus on the other one and conquer it.$K    $R�̂݉�b|$F1$FCL_SENERIO|These $w2are both strongholds built
for the defense of Crimea...$K$PNow that they're under enemy control,
they pose a significant danger.$K$F1$FD$P$F1$FCL_IKE|These are fairly close to one another.$w4
I doubt they would expect us to attack
both at once, but...$K$F1$FD$P$F1$FCL_TIAMAT|That seems to be a waste of our strength.$w4
And we don't want to get ambushed from
the rear while attacking.$K$F1$FD$P$F1$FCL_SENERIO|We cannot divide our army, $w2but we could
send a small force $w2to attack the base with
weaker defenses and keep it occupied.$K$PAt the same time, $w2the main army $w2can
focus on the other one and conquer it.$K $R�w�i��b|$B�V����c�p|$<$F3$FCL_IKE2|$F4$FCL_SENERIO|$F3$PI see...$w4 So which one has more soldiers?$K
$F4$PThat would be Fort Pinell.$K
$F0$FCL_TIBARN|$F0$PVery well. Then the main army will lead an
assault on Fort Pinell.$K$PMeanwhile, I'll take my army and a unit
or so of Gallians and set out for
Castle Nados.$K$PWe'll launch an attack, and when they come
out to meet us, we'll retreat.$w4 Then we'll
attack again!$w4 It will keep them busy.$K$P$F3$PThat should give us the time we need.$w4
We'll take care of our front by day's end...$w4
Let's go capture a fort!$K
$F0$P$FSIt's settled then.$K
$=1000   $R�w�i��b|$B�V��-��|$<$F1$FCL_IKE2|$w4$F4$FCL_ERINCIA2|$F4$PMy lord Ike.$K
$F1$PPrincess Elincia...$w4
Huh?$K  $R�̂݉�b|$F1$FCL_IKE2|What's going on? $w2Why are you dressed
like that?$K$F1$FD$P$F1$FCL_ERINCIA2|I thought to join you on the battle lines--$K$F1$FD$P$F1$FCL_IKE2|Is that $w2a pegasus?!$w5
Where did you get that?$K$F1$FD$P$F1$FCL_ERINCIA2|He belonged to my great-grandmother.$w3
I'm a bit nervous about riding him,$w4 but
I'm going to try $w2nevertheless.$K$F1$FD$P$F1$FCL_IKE2|I appreciate your desire, $w2but your retainers
will never allow it. Will they?$K$F1$FD$P$F1$FCL_ERINCIA2|As for that...$K$F1$FD$P$F1$FCL_IKE2|Did you agree to this, $w2Geoffrey?$K$F1$FD$P$F1$FCL_GEOFFRAY|No, personally, I'm against it, but...$w3
She is the princess, and it is her wish.
I can do nothing.$K$F1$FD$P$F1$FCL_LUCHINO|The princess's great-grandmother was a$w2
Begnion pegasus knight of some renown
before marrying into House Crimea.$K$PPrincess Elincia herself $w2is skilled at both
riding and swordsmanship.$K$PAs a child, she was granted permission to
train $w2in case the need for her to fight
ever arose.$K$F1$FD$P$F1$FCL_ULYSSES|Behold the pegasus and uniform!
All treasures of our House Crimea fair.$K$PWe did fear much that we would never see
a chance to use them in their proper stead.$K$P$FSOh, muse of fire! I cannot find the words!$w2
Behold a light that dares to shame the sun!$K$POur princess clad in raiments fair and fine,
gives courage, love, and vigor to our cause.$K $R�w�i��b|$B�V��-��|$<$F1$FCL_IKE2|$F3$FCL_ERINCIA2|$F4$FCL_ULYSSES|$F1$PI'm surprised you were able to hide armor
and a flying horse from the Daein army.$K
$F4$PAhem... Prince Renning $w2foresaw a time when
the princess would need them, $w2and bade us
convey them from the palace.$K$PPrince Renning's $w2thoughts were always
of the princess, even as his life
abandoned him.$K$P"Be true to your heart, and live life as it
dictates." $w2Those were his final words
to her.$K
$F3$PMy lord uncle was always the one person
who understood me best...$K$PEven though I'm dressed like this, I have
no experience, $w2and do not expect
to fight as well as the rest of you.$K
$FcBut...$w4this constant waiting behind and doing
nothing...$w4it sets my heart beating with such
unease I fear it may burst.$K$P$FdEven if I cannot fight, I could use a staff
to heal the wounded.$w3 If I could save just
one soldier, it would mean so much to me.$K$PPlease, $w2my lord Ike.$w4 I promise to obey
orders and stay out of harm's way as
best I can.$K
$F4$FD$F4$FCL_GEOFFRAY|$F4$PLord Ike, $w2we will take responsibility
and guard the princess.$K
$F4$FD$F4$FCL_LUCHINO|$F4$PIt is her heartfelt wish...$K
$F1$PThis is not something that I can allow or
disallow. She is my employer. If this is what
the princess wants, $w2all I can do is comply.$K$P$FSBe careful, will you?$K
$F3$P$FSOh, $w2thank you so much!$K
$F4$FD$F4$FS$F4$FCL_ULYSSES|$F4$PLet us go forth like sunlight to the dawn.
Elincia fights, and Crimea wins the day!$K    $R�̂݉�b|$F1$FCL_IKE2|What's going on? $w2Why are you dressed
like that?$K$F1$FD$P$F1$FCL_ERINCIA2|I thought to join you on the battle lines--$K$F1$FD$P$F1$FCL_IKE2|Is that $w2a pegasus?!$w5
Where did you get that?$K$F1$FD$P$F1$FCL_ERINCIA2|This pegasus, $w2armor, and sword all$w4
belonged to my great-grandmother.$K$PMy retainers were able to bring it with them
when they fled the palace.$K$PWhether I can use it well or not, I don't
know...but I want to try.$K$F1$FD$P$F1$FCL_IKE2|You are the rallying point of this war.
You've considered what would happen if
you were to fall in battle, have you not?$K$F1$FD$P$F1$FCL_ERINCIA2|...If I die... $w2The dream of a free
and liberated Crimea would die with me.$w5
Of course I understand that.$K$F1$FD$P$F1$FCL_IKE2|Then why?$K    $R�w�i��b|$B�V��-��|$<$F1$FCL_IKE2|$F3$FCL_ERINCIA2|$F3$PThis pegasus and the uniform and all else...$w4
My dear uncle Renning $w2was the one who
arranged for me to have it.$K$PMy lord uncle was the person who
understood me best...$K$PHe always told me, $w2"Be true to your
heart, and live life as it dictates."$K$PEven though I'm dressed like this, I have
little experience. I do not expect to
fight like the rest of you.$K
$FcBut...$w4this constant waiting behind and doing
nothing...$w4it sets my heart beating with such
unease I fear it may burst.$K$P$FdEven if I cannot fight, I could use a staff
to heal the wounded.$w3 If I could save just
one soldier, it would mean so much to me.$K$PPlease, $w2my lord Ike.$w4 I promise to obey
orders and stay out of harm's way as
best I can.$K
$F1$P...$w2I'm not one to complain about the
decisions of my employer.$K$PIf you say you're going into battle, then
I will do my best to protect you.$w4
I've nothing else to say.$K$PExcept this...$w2 Stay where I can see you!$w4
Please.$K
$F3$PI will! $w2I promise!$K
$F1$P$FSAll right then, let's go.$K
$F3$P$FSYes, sir!$K    $R�㉺��b|$c1BEUFORRES|$s1...$K    $R�㉺��b|$c0TIAMAT|$s0Ike, $w2there are more enemy
soldiers than we expected.$K$PJust from what I can see now,$w2
they are double our numbers.$K
$c1SENERIO|$s1And we must assume that the fort
houses many more troops.$w4 This
may prove to be a long battle.$K
$d0$c0IKE2|$s0Even if they have twenty times our
numbers, we must overcome them.$w4
In this war, there can be no retreat!$K $R�㉺��b|$c0DAYNE3|$s0General Bertram!$w4 The Crimean army
has risen to the bait! Orders, sir?$K
$c1BEUFORRES|$s1...$K
$s0...Your orders, sir?$K
$s1...$K
$s0General?$w4 Um...$w3 How shall we$w2
make answer?$K
$s1Turn the ground...ssssoft with blood.$w4
Make a graveyard...of thissss place.$w4
Bury them all.$K
$s0Y-$w4yes, sir!$K $R�㉺��b|$c0IKE2|$s0Soren, $w2do you have any information
on the enemy general?$K
$c1SENERIO|$s1Our intelligence reports say the
commander of this army is Bertram,$w2
one of Daein's Four Riders.$K
$s0One of the Four Riders? $w2So he's
on par with that woman we fought
earlier, $w2General Petrine?$K
$s1...That's $w2not necessarily so.$K$PThe name Four Riders is given to the
four persons of highest ability
among the king's advisors.$K
$c2TIAMAT|$s2So the members can change,
is that it?$w4 Who are the current
Four Riders?$K
$s1First, there was General Petrine,
whom we defeated at Riven Bridge.$K$PThen the man we face today,$w2
General Bertram.$K$PNext is General Bryce, $w2who served
the previous king.$K$PAnd finally, the enigmatic general
known as the Black Knight.$w2
Those are the four.$K
$s2This is the same Black Knight who
murdered Commander Greil?$K
$s1Of that, $w2there appears to be
little doubt.$K
$s0...$K
$s2Tell us, Soren,$w4 do you have any
more information on General Bertram?$K
$s1I know not where he hails from. He
appeared after the fall of Crimea and
has quickly gained Ashnard's favor.$K
$s2So $w2he's a man of no mean ability.$K
$s1Like the Black Knight, he always wears
his armor and never shows his face
unhelmed.$K$PSome say he's not even in his armor,$w2
but that it's inhabited by an ancient
spectre $w2or a demonic creature.$K$PIt's all just superstition and rumor
designed to heighten fear of the man.$K
$s0It's not important.$w4 Once we cross
swords, we'll know the truth.$K$PThen we can discover for ourselves if
he's just a loudmouthed braggart$w2
or truly a monster.$K$PAs long as our blades can wound him,$w2
I care not either way.$w4 Let's go!$K  $R�㉺��b|$c0BEUFORRES|$s0...$w4
...Gu$w2...$w3guuoo...$K
$c1ERINCIA2|$s1...Eeep...$K
$s0...Gu...$w3oo...$w4OOO...$K   $R�㉺��b|$c0BEUFORRES|$s0...Perissssh...$w3
...Perissssh...$K $R�㉺��b|$c0BEUFORRES|...$w4Perissssh...$w4
Perissssh...$K
$c1IKE2|$s1So you're Bertram, are you?$K
Sorry, $w2but I can't perish right now.$K
$s0...Me...$w4 Kill...$K
$s1What?$K
$s0Kill...$w4me...$K$P...KILL...M-ME...$K
$s1What's going on?$w4
Are you mad?$K
$s0...Gu, $w2gu...$K
GUAAAA!$K
$s1Ah!!$K    $R�㉺��b|$c0BEUFORRES|$s0...I will eat...your ssssoul...$K    $R�㉺��b|$c0BEUFORRES|$s0...I will eat...your ssssoul...$K    $R�㉺��b|$c0BEUFORRES|$s0...I will eat...your ssssoul...$K    $R�㉺��b|$c0BEUFORRES|$s0...I will eat...your ssssoul...$K    $R�㉺��b|$c0BEUFORRES|$s0...Ga...aaa... Releasssse...$K   $R�㉺��b|$c0CRIMEA1|$s0Sir, the enemy troops $w2are fleeing!$w4
Shall we give chase?$K
$c1IKE2|$s1No, $w2let them run. We fought enough
today.$w4 Get our men inside the fort$w2
and give everyone a break.$w2$K
$s0Yes, sir!$K   $=1000$R�w�i��b|$B���{-�N���~�A|$<$F0$FS$F0$FCL_ASHNARD|$F4$FCL_BURAISU|$F0$PI see. $w2So Crimea's won another victory,
have they?$w4 Heh heh heh.
Heeeee heee heee!$K$PWell then, $w2send the rest of our troops
to Castle Nados as reinforcements.$K$PPut General Hafedd in charge $w2and
let him exchange blows with them.$K
$F4$PYet, $w2that would leave the capital protected
by only the Imperial Guard.$K
$F0$PYou forget yourself, knight.$w4
I will be here as well.$K$PIf they defeat Hafedd $w2and make it all
the way here, $w2then they are worthy
to cross swords with me.$K
$F4$PI would beg a question, Your Highness.$w4
Why $w2do you divide our troops $w2and
give the enemy the advantage?$K$PIt's as if you were--$K
$F0$PAs if I were...?$w4 What?$w3 Go on.$K
$F4$PIt's as if you desire the Crimean army$w2
to continue winning and make its way
here to you.$K
$F0$PI'll not deny it.$K
$F4$PAre you saying...$w4that you desire
Daein's defeat?$K
$F0$PNo, I am not.$w4 If you think through it
clearly, Daein will not lose.$K$PWe had many plans when we started this
war. We went through many scenarios,
many predictions...$K$PBut, as you know, $w2our predictions have been
completely overturned by this
gang of rabble.$K$PWas that luck?$w4 Or was it the gap in skill
between the individual soldiers?$K$PAnd if it is, $w2aren't you interested in seeing
how far they can come?$K
$F4$P$FcI...do not understand.$K$F4$FD
$F0$PHeh heh heh. Heeee heeee heee!$w4
Perfect!!$K$PNothing raises my spirits like war!
Come, Crimea! Let me be the one to
consume your noble hearts!$K
$=1500    $R�w�i��b|$B�V���l�p-��|$<$F0$FCL_CRIMEA1|$F3$FCL_IKE2|$F0$PGeneral,$w3 may I have a moment of
your time?$K
$F3$PYes? What is it?$K
$F0$PI'd like your advice on something, sir.$w3
Let's say I was faced with an undefeatable
enemy.$K$PIn that case,$w3 what should I, $w2as the
weaker fighter, do?$K$PShould I try to avoid slowing down other
better fighters and retreat?$K$POr do I sacrifice myself and try to at least
land a single blow on the opponent?$K
$F3$PIf it's an enemy general, or just someone
that's far too strong for you,$w3 there's no
need to get yourself killed.$K$PBut I don't want you to simply run away,
either.$K$PStudy the enemy first, and$w3 see if
retreating is your only option.$w3 I'd like
you to do that much, at least.$K
$F0$PStudy the enemy?$K
$F3$PThat's right.$w4 What type of fighter is he?$w2
What kind of weapon is he using?$w2
Things like that.$K$PIf you can learn to do that, $w2you can
determine how best to engage your
opponent.$K
$F0$PThose are the very core of combat
fundamentals, aren't they?
Oh, I'm a danged fool!$K$PIt could be...$w3I think all my troubles
started$w3 because I wasn't paying enough
attention to the basics!$K$FS$PYou've given me $w2something to think about.$w2
And some hope, too.$w4 Thank you, sir!
You're the smartest general ever!$K
$F3$P$FSHuh...$w4 What a brave little fella'.$K $R�w�i��b|$B�V��-��|$<$F1$FS$F1$FCL_TIBARN|$F3$FCL_RIEUSION|$F4$FCL_IKE2|$F4$PAre you leaving now?$K
$F1$PYep.$w4 We're going to do some
reconnaissance$w2 and tease those
Daeins a bit.$K
$F4$PGood luck.$K
$F1$PPah! You don't need luck when you're as
tough as me!$K
$F3$PTibarn, about--$K
$F1$P$FAReyson, no. I truly am sorry.$w3 Leanne's
kidnapping is $w2completely my fault.$K
$F3$PIt's not your fault.$w4 Please don't apologize.$w3
I know$w3 Leanne is alive.$K$PThese battlefields are filled with chaotic
energy,$w4 but I can still sense her...$w2
It's faint, but I know it's Leanne.$K
$F1$PWhich is all the more reason for us to
hurry. There may be other ways to finish
this,$w4 but crushing Daein is the surest.$K
$F3$PAgreed.$K
$F4$PReyson,$w4 is this mysterious power that
you use to sense Leanne something
only herons possess?$K
$F1$PIt's not something any of the hawk clans
have! That is a certainty!$K
$F3$PThat's not true, Tibarn.$w4 The power may
differ in potency between us,$w3 but all
laguz possess it to some degree.$K
$F1$PAh, so it's just that my sense isn't
developed, is that it?$K
$F3$PThe power is distributed something like
this...$w4 Among the bird tribes, $w2it's
very strong in the heron clan.$K$PAmong the beast tribes,$w3 I've heard it's
most developed in the cat clan, $w2though
not as strongly as in the herons.$K$PAs for the dragon tribes...$w4 It's said they
may be equal to,$w3 or even surpass, $w2the
strength of the herons.$K
$F4$PEven though I knew that all laguz were
not alike,$w3 there are even more differences
than I'd imagined.$K
$F1$P$FSYour eyes should have told you that.$w4
Once we change, $w2we don't look alike
do we?$K
$F4$PGood point.$K
$F1$PEnough pleasantries. It's time for me and
my men to take wing.$K
$F4$P$FSRight.$w3 See you later then.$K
$F3$P$FSTibarn, $w2may the fortunes of war
be with you.$K
$F1$P$FSAnd you as well.$w4 Don't try anything
too dangerous.$K$P$F1$FD$w5$F4$P$FA$F3$P$FA$Fc...$K
$F4$P...Reyson?$K
$F3$FD$F1$FS$F1$FCL_RIEUSION|$F1$PMy apologies, $w2Ike.$w4 Though I knew this
was coming...$w3 It's still...$FAdifficult.$K
$F4$PDon't apologize.$w3 You've nothing left to
prove to me.$K
$F1$P...Ah...$K$Fc
...$K
$F4$P...$K  $R�w�i��b|$B�V��-��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 By your leave,$w2
I will excuse myself.$K    4�      4   	  4�     6   "  6D   .  6�   :  6�   F  7   R  7@   \  8$   h  -�   t  �   �  P   �  D   �  |   �     �       �  >H   �  C�   �  P   �  t    �    H    #,  ,  &8  :  *�  I  *�  U  ,8  a  L  m  L�  ~  M4  �  L�  �MS_27_BT MS_27_BT_01 MS_27_BT_IKE MS_27_BT_R1 MS_27_BT_R2 MS_27_BT_R3 MS_27_BT_RI MS_27_DIE MS_27_ED_01 MS_27_ED_02 MS_27_EV_01 MS_27_GMAP2_01 MS_27_GMAP2_02 MS_27_GMAP2_04A MS_27_GMAP2_04B MS_27_GMAP2_06 MS_27_GMAP_01 MS_27_INFO_01 MS_27_INFO_02 MS_27_OP_01 MS_27_OP_02 MS_27_OP_03_a MS_27_OP_03_a2 MS_27_OP_03_b MS_27_OP_03_b2 MS_27_OP_04 MS_27_OP_05 MS_27_OP_06 MS_27_REPO_BEGIN MS_27_REPO_DIE MS_27_REPO_END MS_27_REPO_NODIE 