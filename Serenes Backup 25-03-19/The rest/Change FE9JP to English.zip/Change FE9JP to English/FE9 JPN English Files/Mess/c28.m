  \�  Z�                       $RGMAP��b|$O3$GOf all the battles in the war so far,$w3 the
contest for Fort Pinell $w2is the fiercest to
date.$K$PAnd from this horrific clash of weapons and
wills, $w2the Crimean army emerges$w2
bloodied and exhausted, yet victorious.$K$PThe prize of Fort Pinell is no small thing,$w3
but it is the promise of additional
reinforcements $w2from Gallia--$K$Pand the large Begnion army encamped in
Castle Daein--that keeps the breath of
hope alive in the soldiers' hearts.$K$P$Ub$HThere is one other pivotal piece in Daein's
defense of the former Crimean capital--$w3
$Ub$Hthe severely undermanned Castle Nados.$K$PAs the day's end draws near,$w3 Tibarn's small
force of hawks and Gallians $w2cease their
attacks and return to camp headquarters.$K $R�w�i��b|$B�V��-�[��|$<$F1$FS$F1$FCL_TIBARN|$F3$FCL_IKE2|$F1$PAh,$w3 well met.$w4 From the looks of things,$w2
the battle ended in our favor.$K
$F3$PWe claimed victory.$w4 Yet Daein had more
troops than we expected, and it was
a hard-fought battle.$K
$F1$P$FAI don't have the best news to report, either.$K
$F3$PWhat is it?$K
$F1$PAs the day ended, $w2we withdrew as planned.
But as we were leaving, $w2reinforcements
began flooding in from the capital.$K
$F3$PMmm... That's a piece of ill news.$K
$F1$PThe men that were originally guarding the
castle $w2were nothing special, but...$K$PThere was one who appeared midbattle and$w3
crushed an entire unit by himself.$K$PHe was so much stronger than the others,$w3
it was as if a wolf had appeared in a
kennel of blind, newborn pups.$K
$F3$PWhat did he look like?$K
$F1$PHe was covered from toe to tip in black
armor.$w4 That made it difficult to judge
his size,$w3 but I think he was bigger than me.$K$PIf my intuition's right,$w3 he is the villian
you've all been talking about.$K
$F3$PThe Black Knight...$w4 He's in that castle!$K
$=1000  $R�w�i��b|$B�V��-�[��|$<$F1$FCL_IKE2|$F4$FCL_ULYSSES|$F4$PGeneral Ike!$w4 Please come with me.$K$PWe're getting ready to have a war council$w3
and discuss tomorrow's battle.$K    $R�w�i��b|$B�V��-�[��|$<$F1$FCL_IKE2|$F4$FCL_CRIMEA1|$F4$PGeneral Ike!$w4 Please proceed to that
tent over there.$w3 We are having a war
council$w3 on tomorrow's battle.$K    $=1000$R�w�i��b|$B�V����c�p|$<$F4$FCL_TIAMAT|$F3$FCL_IKE2|$F4$PSo the Black Knight's in that castle, is he?$K
$F3$PThere's little doubt of it.$K
$F1$FCL_LAY|$F1$PThat beorc's $w2a real handful.$w4 Even when
I attacked him in cat form, $w2I barely
scratched him!$K
$F3$PIt's his armor.$w3 It's apparently blessed
by the goddess.$w4 Ordinary weapons,
natural or no, can't damage it.$K
$F1$POh, that's just swell. $w2So how are we
supposed to defeat him?$w4 Angry looks?$K
$F3$PLeave that to me.$w4 I've got a sword
that should be effective against him...$K
$F0$FCL_TIBARN|$F0$PI don't like it, $w2but I suppose there's no
choice.$w4 We don't use weapons or shields.$w4
Those are beorc tools $w2for beorc alone.$K
$F4$FD$F4$FCL_ULYSSES|$F4$PVery well, $w2if the villain in question appears,$w3
we'll leave him to General Ike.$K
Now then, shall we determine who among us
storms the castle?$K
$Ub$H$F0$FD$F1$FD$F1$P$F1$FCL_MIST|$F1$PIke...$w4 Can I talk to you?$K
$F3$PNot right now, Mist.$w4 We're discussing
battle strategy.$K
$F1$PI know that.$w4 Even so... $w2Please?$w4
It'll only take a moment.$K
$F3$PMist...$w4 I promise I'll make time later.$K
Be patient and wait quietly.$K
$F0$FCL_ERINCIA2|$F0$P...Ah...$w2um...$K
$F3$FD$F1$FD$F4$P$FSWhat is it,$w4 O beauteous one?$K
$F0$PI feel...$w4a bit dizzy.$w4 May I rest$w2 a moment?$K
$F4$P$FAOh, what foul deed is this that
rears its head?$K$PThe gods of war do charge a heavy toll.
Bewitch us, $w2and attack our very minds!$K$PThe princess, she is faint and o'er tired.$w4
Forgive your humble servant this trespass.$K
$F4$FD$F5$FS$F5$FCL_ULYSSES|$F5$PHark, my dear, and bless me with your arm.$w4
Good folk, $w2we shall retire for a spell.$K
$F4$FS$F4$FCL_GEOFFRAY|$F4$POf course.$w4 Princess, $w2please rest and allow
us to proceed with these preparations.$K
$F0$PTh-$w2thank you.$w4 I'm sorry.$Fc$K    $R�w�i��b|$B�V����c�p|$<$F4$FCL_TIAMAT|$F3$FCL_IKE2|$F4$PSo the Black Knight's in that castle, is he?$K
$F3$PThere's little doubt of it.$K
$F1$FCL_LAY|$F1$PThat beorc's $w2a real handful.$w4 Even when
I attacked him in cat form, $w2I barely
scratched him!$K
$F3$PIt's his armor.$w3 It's apparently blessed
by the goddess.$w4 Ordinary weapons,
natural or no, can't damage it.$K
$F1$POh, that's just swell. $w2So how are
we supposed to defeat him?$w4
Angry looks?$K
$F3$PLeave that to me.$w4 I've got a sword
that should be effective against him...$K
$F0$FCL_TIBARN|$F0$PI don't like it, $w2but I suppose there's no
choice.$w4 We don't use weapons or shields.$w4
Those are beorc tools $w2for beorc alone.$K
$F4$FD$F4$FCL_ULYSSES|$F4$PVery well, $w2if the villain in question appears,$w3
we'll leave him to General Ike.$K
Now then, shall we determine who among us
storms the castle?$K
$Ub$H$F0$FD$F1$FD$F1$P$F1$FCL_MIST|$F1$PIke...$w4 Can I talk to you?$K
$F3$PNot right now, Mist.$w4 We're discussing
battle strategy.$K
$F1$PI know that.$w4 Even so... $w2Please?$w4
It'll only take a moment.$K
$F3$PMist...$w4 I promise I'll make time later.$K
Be patient and wait quietly.$K
$F0$FCL_ERINCIA2|$F0$P...Ah...$w2um...$K
$F4$P$FSWhat is it,$w4 O beauteous one?$K
$F0$PI feel...$w4a bit dizzy.$w4 May I rest$w2
a moment?$K
$F4$P$FAOh!$w4 What foul deed is this that
rears its head?$K$PThe gods of war do charge a heavy toll.
Bewitch us, $w2and attack our very minds!$K$PThe princess, she is faint and o'er tired.
Forgive your humble servant this trespass.$K
Hark, my dear, and bless me with your arm.$w4
Good folk, $w2we shall retire for a spell.$K
$F4$FD$F4$FS$F4$FCL_TIAMAT|$F4$PYes, $w2let's take a small break, shall we?$w4
Princess Elincia, $w2this way please.$K
$F0$PTh-$w4thank you.$w4
$FcI'm sorry.$K  $R�w�i��b|$B�V����c�p|$<$F4$FCL_TIAMAT|$F3$FCL_IKE2|$F4$PSo the Black Knight's in that castle, is he?$K
$F3$PThere's little doubt of it.$K
$F1$FCL_LAY|$F1$PThat beorc's $w2a real handful.$w4 Even when
I attacked him in cat form, $w2I barely
scratched him!$K
$F3$PIt's his armor.$w3 It's apparently blessed
by the goddess.$w4 Ordinary weapons,
natural or no, can't damage it.$K
$F1$POh, that's just swell. $w2So how are
we supposed to defeat him?$w4
Angry looks?$K
$F3$PLeave that to me.$w4 I've got a sword
that should be effective against him...$K
$F0$FCL_TIBARN|$F0$PI don't like it, $w2but I suppose there's no
choice.$w4 We don't use weapons or shields.$w4
Those are beorc tools $w2for beorc alone.$K
$F1$P$FSAll right, $w2we'll leave the toppling of
the giant knight to Ike.$K
Now we need to decide who's going to
the castle in the first place.$K
$Ub$H$F0$FD$F1$FD$F1$P$F1$FCL_MIST|$F1$PIke...$w4 Can I talk to you?$K
$F3$PNot right now, Mist.$w4 We're discussing
battle strategy.$K
$F1$PI know that.$w4 Even so... $w2Please?$w4
It'll only take a moment.$K
$F3$PMist...$w4 I promise I'll make time later.$K
Be patient and wait quietly.$K
$F0$FCL_ERINCIA2|$F0$P...Ah...$w2um...$K
$F0$PI feel...$w4a bit dizzy.$w4 May I rest$w2
a moment?$K
$F4$FD$F4$FCL_LAY|$F4$POf course!$w4 My apologies!$w4 If something
were to happen to you, all our talk of war
would be a waste of time, wouldn't it?$K$P$FSWhy not step away for a while?$K
$F4$FD$F4$FS$F4$FCL_GEOFFRAY|$F4$PA very good idea.$w4 Princess, $w2please retire
and allow us to proceed with these
preparations.$K
$F0$PTh-$w2thank you.$w4 I'm sorry.$Fc$K  $R�w�i��b|$B�V����c�p|$<$F4$FCL_TIAMAT|$F3$FCL_IKE2|$F4$PSo the Black Knight's in that castle, is he?$K
$F3$PThere's little doubt of it.$K
$F1$FCL_LAY|$F1$PThat beorc's $w2a real handful.$w4 Even when
I attacked him in cat form, $w2I barely
scratched him!$K
$F3$PIt's his armor.$w3 It's apparently blessed
by the goddess.$w4 Ordinary weapons,
natural or no, can't damage it.$K
$F1$POh, that's just swell. $w2So how are
we supposed to defeat him?$w4
Angry looks?$K
$F3$PLeave that to me.$w4 I've got a sword
that should be effective against him...$K
$F0$FCL_TIBARN|$F0$PI don't like it, $w2but I suppose there's no
choice.$w4 We don't use weapons or shields.$w4
Those are beorc tools $w2for beorc alone.$K
$F1$P$FSAll right, $w2we'll leave the toppling of
the giant knight to Ike.$K
Now we need to decide who's going to
the castle in the first place.$K
$Ub$H$F0$FD$F1$FD$F1$P$F1$FCL_MIST|$F1$PIke...$w4 Can I talk to you?$K
$F3$PNot right now, Mist.$w4 We're discussing
battle strategy.$K
$F1$PI know that.$w4 Even so... $w2Please?$w4
It'll only take a moment.$K
$F3$PMist, I promise to make time later.$K
Be patient and wait quietly.$K
$F0$FCL_ERINCIA2|$F0$P...Ah, $w2um...$K
$F0$PI feel...$w4a bit dizzy.$w4 May I rest$w2
a moment?$K
$F4$FD$F4$FCL_LAY|$F4$POf course!$w4 My apologies!$w4 If something
were to happen to you, all our talk of war
would be a waste of time, wouldn't it?$K$P$FSWhy not step away for a while?$K
$F4$FD$F4$FS$F4$FCL_TIAMAT|$F4$PA good idea.$w4 Princess, $w2please retire
and allow us to proceed with these
preparations.$K
$F0$PTh-$w2thank you.$w4 I'm sorry.$Fc$K $R�w�i��b|$B�V��-�[��|$<$F1$FCL_MISTs|$F3$FCL_IKE2|$F3$PWhat is it?$K
$F1$P$Fh...Mmm...$K
$F3$PCome on, $w2Mist. $w2You realize the princess
was making time for you to talk with me,
don't you?$K
$F1$P$Fd...Well,$w4 um...$w4 I thought I could talk
to you later, but then I changed my mind
and wanted to talk to you now.$K
$F3$PI've been hoping to talk to you, too.$w4
I haven't heard very much from you
since the other day.$K
$F1$PYeah...$w4 I'm sorry.$K$P$FhWhen you told us that story...$w4
I was so shocked...$w4 That's why.$Fc$K
$F3$PThe part about Mother's death...$w4
and about Father, right?$K
$F1$P$FdUh-huh.$K
$F3$PThat's only natural.$w4 So, $w2you have come
to some kind of understanding with it all?$w2
Is that it?$K
$F1$PAt first, $w2I couldn't believe it.$K$PThe stuff about the medallion $w2and the
revival of the dark god $w2and all of that?$w3
None of it...$w4 None of it sounded real.$K$P$FhAnd everything about Father...$w2
That was even more unbelievable.$w3
It was all I could think about.$w4 But...$K$PBut I didn't want to think about it anymore.
It made my head hurt.$K$P$FcI didn't know what to do.$w4 I couldn't
even sleep. I would just lie awake at night
and stare at the tent walls.$K
$F3$PYeah, $w2I was the same way.$K
$F1$P$Fd$FSI guess my body finally reached its limit.$w4
Last night, $w2I fell asleep.$K$PAnd when I woke up this morning...$w4
I don't know.$w2 It was all gone.$w4
$FAI only had $w2one emotion left.$K
$F3$POne emotion?$w4 What was it?$K
$F1$P$FcIt's hard to say... Sympathy,$w4 I suppose.$K
$F3$PFor $w2Mother?$K
$F1$P$FdUh-huh.$w4 And for Father. $w2I think more
for him than anyone else...$w4 Father and
Mother were in love, weren't they?$K$PAnd then the medallion, $w2it made Father
go...$w2what did you say?$w4 Berserk?$K$P$FhWhen he returned to himself,$w2
he found Mother...$K$P$FcWhen, $w2when Father died, $w2it hurt so
much...$w4I thought I was going to die.$w3
Father must have felt the same.$K$P$FhNo,$w4 he must have felt$w4 even
worse.$K
$F3$PI think you're right.$w4 And Father kept it
all to himself, too.$K$PMother, $w2the medallion,$w2 being hunted...$w4
He never said a word to us. $w2It was his
burden alone.$K
$F1$P$FdThe man who killed Father was that knight
we saw in Port Toha.$w4 Right?$w4 The one
in the black armor?$K
$F3$PYes.$K
$F1$PYou're going to fight him, $w2aren't you.$w4
For Father.$K
$F3$PYes, I am.$w4 That's one thing$w4 I won't
let anyone else do in my stead.$K
$F1$PTrying to stop you is pointless. I know.$K$PIf I were stronger,$w4 $Fhif I $w2were a swordfighter,
I'd be doing the same thing.$K
$F3$PMist...$K
$F1$P$FdBut...$w4you must keep your promise.$w4
You promised to lead the company in
Father's place, and to protect me.$K$PIf you go and get yourself killed,$w2
I'll never forgive you.$K
$F3$P$FSI understand.$w4 That's why I'm not going
to lose!$K
$F1$P$FS...I know!$K
$=1000  $R�w�i�Ȃ���b|$F2$FCL_ANNA|$F2$P$KMESSAGE HAS BEEN DELETED!!!$K    $R�w�i��b|$B�V����c�p|$<$F1$FS$F1$FCL_ULYSSES|$F3$FCL_ERINCIA2|$F1$PHow are you feeling, $w2Princess?$K
$F3$PUm... It was a lie.$w4 I'm not feeling unwell
at all.$w4 I'm sorry I fooled you.$K
$F1$PAh, I knew it all along.$w4 It was all for Ike
and Mist, $w2was it not?$K$PIt would appear, $w2my dear Princess, that you
care for them greatly.$K
$Ub$H$F1$P$FA$F3$P$FcI witnessed the death of both my father
and mother...$K$PSoldiers fell one after the other...$w4
And then I...$w4I was separated from
Geoffrey...$K$P$FdIt was $w2Ike and his friends who
rescued me. If not for them, $w2I...$w4
I'm sure I would be dead now.$K$PMy lord Ike $w2and Mist, too,$w3 know the
pain that I carry with me.$w4 The pain of
losing one's parents in war.$K$PThat may account for why the two of them,$w2
$FSright from the beginning, $w2were so
warm and friendly.$K$PThey gave me the support I needed to
survive.$w4 Mist and I $w2have continuously
encouraged each other to go on.$K$P$FASo...$K
$F1$P$FSThey rescued you and are your patrons.$w3
There are those among the soldiers who
complain in jealousy of Ike's station, but...$K$PIt is a trivial matter. We, the retainers of
House Crimea,$w2 find this general very
much to our liking.$K
$F3$P...Ah, Bastian. I'm pleased to hear it.$K
$F1$PEnough plain speaking! I must ready my
silver tongue anew! Shall we return
to the council?$K
$F3$P$FSYes.$K
$=1100 $R�㉺��b|$c1HAHUXEDO|$s1Sir Knight.$w4 The Crimean army $w2will
renew their assault of the castle
momentarily.$K$PThe troops we face $w2are not the
half-breeds we fought yesterday. It is
the army that bested General Bertram.$K$PThey are not what one would call an
easy opponent.$K
$c0DARKKNIGHT|$s0Hmph. $w2Resolve it.$K
$s1I beg your pardon?$K
$s0Hafedd, $w2you are in command.$w4 The
castle defenses $w2are on your shoulders.$w4
I have business$w3 with General Ena.$K
$s1Understood.$K    $R�㉺��b|$c0IKE2|$s0Is everyone ready? The castle's
strength has been bolstered with
reinforcements from the capital.$K$PWe must strike now,$w3 before
any more can arrive.$K$PIf $w2the Black Knight appears,$w4
don't try to engage him. He is mine.$w3
I will $w2take care of him!$K   $R�㉺��b|$c0HAHUXEDO|$s0If not for a whim of His Majesty,$w4
I would not be $w2facing you here.$K$PFor a warrior, $w2meeting a powerful foe
is a joy above all others...$w4 And for
this I give thanks to the king!$K$PNow,$w3 let us enjoy the gift
we have been given.$K    $R�㉺��b|$c0IKE2|$s0Is the Black Knight in there?$K
$c1HAHUXEDO|$s1Yes.$K
$s0Step aside.$w4 I have $w2business with him.$K
$s1$FSAha...$w3 It would seem you and
Sir Knight have some connection!$w4
My curiosity knows no bounds, but...$K$P$FABefore you reach Sir Knight,
you must first vanquish me!$K    $R�㉺��b|$c0HAHUXEDO|$s0It's one of the beast tribe...$w3
Quite a formidable foe, indeed!$K$PYet, $w2you will find that I, too,
am a robust opponent.$w4 Begin!$K $R�㉺��b|$c0HAHUXEDO|$s0A hawk!$w4 Which means $w2you
hail from Phoenicis.$K$PYesterday, we lost a virtual mountain
of men$w3 to your king!$K$PNow then, $w2if I may be so bold,$w3
I would be grateful for the chance to
test the power of his subjects.$K   $R�㉺��b|$c0HAHUXEDO|$s0Leaving Daein and siding with
Crimea is not unheard of.
Soldiers are human, after all.$K$PHowever, the penalty for treason
is steep. And now you must pay!$K  $R�㉺��b|$c0HAHUXEDO|$s0Aha, $w2you are one of the Serenes
nobles I've heard whispers of...$K$PIf only this were not war,$w2 I
would request a song of you...
What a shame.$K $R�㉺��b|$c0HAHUXEDO|$s0It appears...$w2this is the end...
Gwaaa... Hurrrkkk... Aaahhhh...$K  $R�㉺��b|$c0IKE2|$s0The one I seek $w2is behind these
doors.$w4 Don't follow me.$w4
I'm going in alone.$K $R�w�i�Ȃ���b|$F3$FCL_SENERIO|$F3$PIke!$w4 Wait!$w4 I'm going with--$K
$F4$FCL_TIAMAT|$F4$PNo, $w2Soren.$w4 We have to let Ike go alone.
The Black Knight is his.$K
Defeating him$w3 is a crucial step that
Ike must take in order to truly get
over the death of his father.$K$P$F3$FD$F1$FCL_SENERIO|$F1$PIdiocy! I'll hear no more $w2of this naive
nonsense!$K What if something happens
to him? What then?$K
$F4$PI think Ike$w3 has gained the composure
to keep calm $w2and judge whether or not
he can match an opponent.$K$PIf, $w2in fact, he can't...$w4it means he's reached
his full potential, and that's all there is
to him.$Fc$K$PWe just have to accept that.$K$Fd$PBut$w3 I believe in Ike. I trust him.$w4
His life $w2is not his alone any longer.$K$PI don't believe he's so irresponsible $w2as to
leave his companions behind$w4 by choosing to
engage in a contest he cannot win.$K
Please, Soren, $w2you must feel the
same way. $w2Don't you?$K
$F1$P...I don't like it.$w4 Sometimes, bravery
and good judgment aren't enough.$K
$F4$P$FcCommander Greil...$w4 Watch over your son.$K  $=0500$R�w�i��b|$B�V���l�p-��|$<$F3$FCL_IKE2|$F1$FCL_TIAMAT|$F1$PCommander, $w2can I speak to you for
a moment?$K
$F3$PWhat is it, Titania?$K
$F1$PI have...$w3something important to ask of you.$K
$F3$PAll right,$w3 what is it?$K
$F1$PI want you to tell me...$w3about the night
Commander Greil was killed.$w4 I understand$w2
that it's$w3 difficult for you.$K$PHowever, $w2I need to know.$w3 I have to.
Just tell it once... It's all I ask.$K$PIf you can't, I...$w3 $FcHis death will be
something I'll never be able to face.$K
$F3$PI feel I've done you a terrible disservice by
not telling you earlier.$K$PIt's just that...$w3 There was a lot I had to
get clear in my own mind.$w4 I know I've
kept you waiting.$K
$F1$P$FdSo you'll tell me?$K
$F3$PYes.$w4 I think I've finally come to a point$w3
where I can face it.$K
$F1$PAll right.$w3 Whenever you're ready.$Fc$K
$F3$PThat night...$w3 I've already told you everything
up to where I was on my way into the
forest, right?$K$PAt the head of the path, Father had told
me to go back to the fort--$w3but I had
a bad feeling$w4 and followed him anyway.$K$PWhen I entered the clearing,$w3 he and the
Black Knight were already fighting.$K$PThey seemed to be evenly matched$w2
at first.$K$PThen they exchanged a few more blows,$w3
and suddenly Father was sent flying.$K$PThey spoke to each other for a moment,
but...$w4 I was so far away, I couldn't
hear what they said.$K$PThen the Black Knight threw a sword at
Father's feet.$w3 I think he wanted
Father to pick it up and use it.$K
$F1$P...$K
$F3$PBut Father didn't touch the sword.$w4 He
just readied his axe again and$w3 charged.$w5
...$K$P...It was over$w3 in an instant.$K$PI...$w2I couldn't believe my own eyes. $w5They...$w3
they looked like they were embracing...
Just... Standing there. Frozen.$K$PBut, $w2I saw the Black Knight's blade...$w4$Fc
It was protruding from Father's back, and
shining in the moonlight.$K
$F1$P$FoOh, Greil...$K
$F3$P$FdWhen the knight pulled his sword out,$w3
Father sagged and fell backwards...$K$PI ran and tried to catch him, but I couldn't$w2
hold him,$w3 and we both fell to the ground.$K$PThe wound Father had taken was terrible,$w4
but $w2at that point,$w3 he was still alive.$K
$F1$P$Fc...$K
$F3$PThe Black Knight approached$w3 and said,
"Give it to me."$K$PI had no idea what he was talking about.$w3
I do now, though. He had been sent by
King Ashnard to retrieve the medallion.$K$PFather told him he'd thrown the medallion
away,$w3 but the knight didn't believe him.$K$PThen he tried to get Father to talk by
threatening to kill me...$w4and Mist.$K$PI was so angry,$w3 I leapt up and attacked
him, $w2but it was useless.$K$PI didn't give up, though.$w4 I didn't care what
happened to me,$w3 and I attacked again.$K
$F1$P$FdOf all the stubbornness...$K
$F3$PIf King Gallia hadn't been nearby,$w3
I probably would have died that night, too.$K
$F1$P$Fc...$K
$F3$PAfter the Black Knight vanished,$w5
I simply...$w3 All I could think was that
I didn't want Father to die.$K$FS$PHe...$w3 He was still alive.$w4 I thought if
I could just get him back to the fort,$w2
we could save him.$K$PI clung to that...false hope...$w4$FAand started
walking toward the light of the fort...$w3$Fc
I just kept walking$w4...$K
$F1$P$Fd...$w2Thank you, Ike.$w4 It must have been$w3
so hard for you.$K
$F3$P$FdTitania...$K
$F1$PCommander Greil$w3 died on your back.$K$FS$PHis last moments must have been...$w4
much happier than I had imagined...$K$Fc$P...Thank you... $w5Now I can finally...$w3
move past my grief...$K
$F3$P...Titania.$K
$F1$P$FdYes?$K
$F3$PI, um...$w3 There's something else I haven't
told you about.$K
$F1$P$FA...$K
$F3$PI...$w3met him...$w4 I met the Black Knight again.$K
$F1$PWhat?$K
$F3$PWe fought.$K
$F1$PYou did well$w3 to keep your life.$K
$F3$PI'm not the same boy I was on that night.$w3
I've grown a lot. $w2I've worked hard.$K$PYet,$w2 even so,$w4 I wasn't able to defeat him.$K
$F1$PThere's nothing you can do about that.$w4
Not even Commander Greil could defeat
him.$w4 You're not ready to--$K
$F3$PIt's not that.$w4 It's not that my blade work
wasn't good enough.$K
$F1$PThen,$w4 what do you mean?$K
$F3$PTitania, $w2it's his armor.$w3 It's impervious
to damage.$K
$F1$PWhat? $w2That's not possible.
Even the strongest--$K
$F3$PHe said his armor had been blessed by the
goddess.$w4 He said only weapons that
were also blessed$w3 could hurt him.$K
$F1$PWhere are we supposed to get something
like that?$K
$F3$PI have one here.$K
$F1$PAh!$w4 Ike!$w3 That sword... Where...$K
$F3$PThe night after Father died,$w4 I went back
to that clearing $w2by myself.$K$PI'd hoped to...$w3I'd hoped to find some clues
that might help me hunt down the knight.$K$PThe sword was still there. $w5I brought it back
with me,$w4 and I've been hiding it ever since.$K$PI wasn't thinking about using it. $w5I believed
that if I just carried the sword with me,$w4
I'd meet the Black Knight again.$K$PAnd it worked.$K
$F1$PSo this sword will work against him?$K
$F3$PIt's supposed to.$w4 It was made to contest
Alondite,$w3 which is the sword wielded by
the Black Knight.$K
$F1$PDo you think$w3 you have a chance?$K
$F3$P...I'll win.$K
$F1$PAll right.$w3 I won't stop you.$w4 Use that sword
to avenge Commander Greil.$K$PBut listen, Ike... $w5You must promise me
one thing.$K
$F3$PWhat is it?$K
$F1$PWhen you meet him, $w2you'll exchange blows.
If, at that moment, you don't feel you
stand a chance...you must flee.$K$PThere are times when running away$w3
is not the same as losing.$K
$F3$PDon't you believe in me, Titania?$K
$F1$POf course I do. One day, you will defeat
the Black Knight.$w4 I'm sure of it.$K$PThat's why$w3 I don't want you to lose your
life on the first go-around.$K$PWhen the time comes,$w4 I promise not to
interfere. And$w3 I won't let anyone else
interfere, either.$K$PI want you to face him, one-on-one.$w3
And I want you to be calm $w2and use
your own best judgement.$K$PAt times,$w3 withdrawing can be the key that
unlocks a future victory.$w5 Don't forget that.$K
$F3$P...Understood.$K
$=1000 $R�w�i��b|$B�V��-�[��|$<$F1$FCL_SENERIO|$F3$FCL_IKE|$F1$PIke,$w3 I'd like to report the results
of our last battle.$K$N$UB$H   $F3$P$FcI see.$K$P$UB$H $F1$P$FSThere were no deaths $w2and no injuries
beyond our capabilities to heal.$w4
Everyone performed exceedingly well.$K$P$UB$H   $F1$PThat is all.$w4 By your leave,$w2
I will excuse myself.$K    7T      8d   	  9�     :8   "  ;8   .  ;�   :  <�   F  =    P  =l   \       h  A�   v  �   �  0   �  �   �  �   �  �   �  �   �  (   �  #`   �  .�   �  .�   �  4L    68    Y<     Y�  1  ZX  @  Y�  OMS_28_BT MS_28_BT_IKE MS_28_BT_R1 MS_28_BT_R2 MS_28_BT_R3 MS_28_BT_RI MS_28_DIE MS_28_ED_01 MS_28_ED_02 MS_28_GMAP_01 MS_28_INFO_04 MS_28_OP_01 MS_28_OP_02A MS_28_OP_02B MS_28_OP_02_A MS_28_OP_02_B MS_28_OP_02_C MS_28_OP_02_D MS_28_OP_03 MS_28_OP_04 MS_28_OP_04_A MS_28_OP_05 MS_28_OP_06 MS_28_REPO_BEGIN MS_28_REPO_DIE MS_28_REPO_END MS_28_REPO_NODIE 