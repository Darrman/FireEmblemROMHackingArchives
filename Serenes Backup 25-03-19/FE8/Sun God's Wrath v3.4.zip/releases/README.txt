Sun God's Wrath V3.

This is the first release of version 3, which covers 14 chapters (prologue to chapter 13). There are no gaiden chapters

Please understand that I am generally very busy and will not have much time to respond to all
feedback right away if you have a question or comment during the week.

How to patch:

Apply the UPS patch to a clean FE8 Rom using NUPS/any UPS patching program.

Instructions on how to patch a rom can be found here: http://serenesforest.net/forums/index.php?showtopic=349

Please remember to read the credits and feedback form.

Known Glitches/Errors:

1. Supports are not fully completed. Some characters do have support conversations, others don't.

2. The troubadour class's dodging animation freaks out when dodging a ranged attack.

3. If a halberdier doubles for zero damage, the game seems to freak out for a bit and then returns to normal.

4. Easy mode does nothing

5. If map animations are on, dancing with the trickster class breaks the game

6. The archer animations seems to freeze at times when dodging certain spell attacks. Just restart and skip the animations by holding L if this happens

7. In chapters 10 - 13, there seem to be issues loading all the reinforcements properly at times

8. Exact weapon level doesn't display properly for units using physical weapons

Gameplay changes:

1. Skills have been added in. Skills are both class and character based and are gained on level up and class change.

2. Units now have a con growth.

3. Growth rates are affected by the units current class. Promoted classes have worse growths than unpromoted ones, generally by a factor of 60% total.

4. Reclassing/promoting is based on class cap.

5. To see what weapons your unit can use, check their classes description. Magic units can use any magic they know.

6. Staff weapon level is set based on class and does not grow.

7. Growth altering hold items exist (crusader scrolls). See their item description to see the bonus they give.

8. A unit may promote once they reach level 10. Upon promoting, their level does not change. 

9. The level cap is now 30.

10. Weapons now give various bonuses depending on their level. These bonuses are dropped when a unit has a weapon triangle disadvantage.

11. Hold L to skip battle animations. Try using this if you run into a bug with the animations

12. You can view a units growth rates on the stat screen by pressing L (or R, but pretty sure it's L)

13. Weapon level bonuses are as follows:

Swords:

C: +1 Str

B: +2 Str

A: +3 Str

S: +4 Str, 5 Crit

Lance:

C: +1 Str

B: +1 str, 5 crit

A: +2 Str, 5 crit

S: +3 Str, 10 crit

Axe:

C: +5 Hit

B: +10 Hit

A: +1 Str, 10 hit

S: +1 Str, 10 Crit, 10 hit

Bow:

C: +5 Crit

B: +1 Str, +5 Crit

A: +2 Str, +5 crit

S: +3 Str, +10 crit

Anima:

C: +1 Str

B: +1 Str, 5 hit

A: +2 Str, 5 hit

S: +2 Str, 15 hit

Light:

C: +5 Hit

B: +5 Hit, 5 Crit

A: +10 Hit, 5 crit

S: +10 Hit, +15 Crit

Dark:

C: +1 Str

B: +2 Str

A: +3 Str

S: +5 Str

14. The weapon Triangle is greatly altered. 
Bows are always advantageous against magic and have better bonuses when attacking a magic user. The bonuses given depending on
which weapon is weak in the triangle is also changed.

15. The exp formula is much stricter.

16. HP bars and icons indicating enemies have effective or high crit weapons now show up

17. It is possible to check enemy range.

18. You always crit when you kill a boss