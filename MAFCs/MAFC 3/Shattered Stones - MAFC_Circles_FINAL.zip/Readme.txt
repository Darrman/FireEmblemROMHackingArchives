MAFC 3 Submission
Shattered Stones: The Last Stand (FE8)
-circleseverywhere

Tips and changes:
-Hold A to make units move faster.
-Hold L to toggle animations on/off
-Effective weapons have a white and red '!' warning, Killer weapons have orange and black
-Myrrh can use Dragon Veins
-Anyone can rescue anyone, you can Switch and Transfer as in 3DSFE but rescue penalties still apply
-Falcoknights and Wyvern Lords have Saviour which negates rescue penalties
-Mortar item can strengthen cracked walls up to a max of 127 HP
-Weapon experience is doubled
-Siege tomes cannot double.

Known issues:
-Lag can happen when there are too many units, especially map animations for some reason. Turning off HP Bars can help a little.
-Attacking walls when they have HP greater than 60 will show incorrect numbers in the map animation
-Dragon Vein text box palette does not update after certain actions e.g. opening minimap. Solution - put cursor over any unit to refresh the palette.
-Opening menus/minimap while the secret code event is running will cause unexpected weirdness, but should be nothing permanent. Opening and closing the R menu should fix it.
-Using the Mortar item ends turn without canto.

Credits:
-Nintenlord and Crazycolorz for EA and the associated tools
-Crazycolorz for Dragon Veins and various other hacks
-Solum for the map
-Tequila, Solum, Letha for playtesting
-Ash for the player phase map theme
-The Blind Archer for the secret mug
