Patch to FE8(U)
Boss quotes/death quotes might be finnicky, I've tested them myself and they worked for me but some testers reported it being weird for them.
The status screen text is intentionally unchanged

Most of the houses have conversations, one has nothing.

B-Beagle is a beagle
B-Belle is a southern belle (hah)
B-Owen is a child
B-Sawyer is normal
B-Elijah is a skyrim guard
B-Axel and B-Stark are normal
B-Oona is an abomination
B-Seneca is an edgelord

Characters have boss conversations with their beta versions, check them out!

Enjoy!