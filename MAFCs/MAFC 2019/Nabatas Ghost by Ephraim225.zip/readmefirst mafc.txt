Let the record show that I did not know there was a chapter in Elibean Nights with the exact same concept as my chapter when I got the idea.

Anyways. Patch to english FE7.

Read "What was in the box?" to see what was in my box and my rationale for how I used it!

Credits:

Alusq for running the contest

FEBuilder for being a wonderful new tool

Xenith for the lord animation
Maiser6 for the Hawkeye sword animation
Deranger for the Sniper animation
Mikey Seregon, Alfred Kamon, PrincessKilvas, Spud, Blue Druid for the Wyvern w/ Axes animation

If SgtSmilies is judging this, hi sarge!

And remember, you are given a ranking at the end, so check out the rankings screen to see how you did!