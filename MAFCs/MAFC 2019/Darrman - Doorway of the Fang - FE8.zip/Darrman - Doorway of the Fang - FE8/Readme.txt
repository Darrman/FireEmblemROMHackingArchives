MAKE A FUN CHAPTER 4: DOORWAY OF THE FANG
Submission by Darrman

Apply the patch to an FE8 rom. 

Credits:
Events, map
Lloyd Swordmaster: Greentea, DerTheVaporeon
Linus Hero: DerTheVaporeon, Nuramon, Greentea
Playtesting: MCProductions