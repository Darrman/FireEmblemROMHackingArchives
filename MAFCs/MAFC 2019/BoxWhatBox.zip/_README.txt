MAFC - What's in the Box? is a small one-chapter hack made by me (Lenh) during the 2019 May Make a Fun Chapter contest on FEU. 
https://feuniverse.us/t/make-a-fun-chapter-feu-it-again/5426/75

-----------
Installation Instructions
-----------
Patch the .ups to a clean FE8(U) rom.
