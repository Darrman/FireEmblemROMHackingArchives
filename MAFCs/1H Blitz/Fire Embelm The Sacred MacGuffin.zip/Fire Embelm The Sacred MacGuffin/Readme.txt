Hello there!

Thank you for playing my game/checking my rom hack!
This rom hack was made for the one hour blitz challenge.

If you want to use some of the assets present in
this rom hack, check out my F2U/F2E folder on the
main page of my project or message me.

Have fun playing this rom hack :D