Make sure you're using NUPS to patch the FE7 (U) ROM.

Things of note concerning the chapter.

1: Standing on the differently colored tiles opens the path forward. (with the exception of the tile in front of the first chest. it does nothing.)

2: At turn 20, a particularly dangerous enemy will spawn. It's strongly recommended you move quickly.

3: Losing Matthew will make things much harder, since the chest near the boss contains a particularly strong weapon which
makes the boss much easier to deal with. 
