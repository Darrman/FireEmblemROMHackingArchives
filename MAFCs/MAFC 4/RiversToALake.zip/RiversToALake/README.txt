This patch goes onto an clean FE8U ROM

There are 5 achievements, although it's probably more feasible to get one or two. I'll use codenames for them here.
Speed: Clear in 10 turns.
Elite: Defeat all Paragonites.
Gronder: Rout the enemy.
Life: Have no player deaths. / Death: Only the lord survives.
