THE AKANEIAN MAFIA
A Make a Fun Chapter 4 entry by Darrman

Apply the patch to an FE8 rom.

READ THE GUIDE BEFORE PLAYING. IT EXPLAINS HOW THE GAME FLOW WORKS; IT IS NOT A TYPICAL SRPG LEVEL.

Credits:
Eventing: Darrman
Portraits: Alusq (the good ones with frames), Darrman (the bad ones without shoulders), IntSys (original artwork)
Music: Sme, based on IntSys
Testing: RandomWizard, MCProductions, Sme

Known Issues:
Don't suspend. It will reset the counters tracking who is alive and who is dead, causing the ending to display early. Play through the chapter in one sitting; save state if a break is required for whatever reason.
The disabling of Wait and End are intentional: this is to prevent exploits from skipping turns.

Secrets:
There are three endings in this game. Check the accompanying "Endings.txt" file to figure out how to get them. Don't read if you want to go in blind!