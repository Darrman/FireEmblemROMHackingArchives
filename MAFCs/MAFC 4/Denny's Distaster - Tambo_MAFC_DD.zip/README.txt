Hello, before you begin, I would like
to point out that you should pay attention to
the dialogue as that will contain key
elements on how to complete the chapter.

NOTE: There is a way to crash the game without doing
anything groundbreaking. More than likely, if you
experience this crash, a Game Over is inevitable 
even if the crash is nonexistant. Thank you
for your understanding.

Patch the .ups file to FE7U

Read "The_Box" to see what my box was and how I use it

Credits:

Alusq - Hosting the contest

Xenith for the long haired lord animation + map sprite; Tambo, Jacob, Lenny, Xenith portraits.
Imperial and Vandal for Vandal portrait 
Maiser6 for the Hawkeye sword animation
Melliel for Tambo Swordmaster animation
FEier for weapon icons
All of FEU's Sprite Blitzes.

Xenith for General Playtesting
RandomWizard for last minute playtesting

Music credits & ownership located in the sound room